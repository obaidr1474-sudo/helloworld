# Dashboard audit fixes — 21 October 2026

## Completed

1. Main browser authentication uses an HttpOnly, SameSite=Strict cookie, the existing revocable session table and GET /api/auth/me at startup. Cookie login does not return the token to JavaScript. Production/HTTPS uses a Secure, host-only __Host- cookie; plain HTTP is supported only as a local development exception. Cookie writes require a custom browser header and reject foreign Origin headers, including browser login. Existing bearer clients are unchanged.
2. Removed public prototype key/signing-value literals and the fake key-generation handler. No real provider credential was found in the reviewed public assets; no provider rotation was performed. Credentials substituted in a separate local deployment cannot be inspected or rotated from this workspace.
3. Main, finance and status login forms explicitly POST to the login endpoint; password forms explicitly POST as well. A handler-free main-form browser check confirms no password in the URL.
4. Added Content-Security-Policy-Report-Only. This is a compatibility baseline, not an enforced XSS defence: the existing inline scripts/styles are allowed during rollout. It restricts resource origins, objects, base URLs, framing and form destinations. No CSP violations were observed on tested login/dashboard flows. External deployment/provider flows need separate validation before enforcement.
5. Notification items have button roles, keyboard focus and Enter/Space activation matching click behaviour. Their content remains prototype data pending notification integration.
6. Clock time, seconds and AM/PM stay on one line using widget-scoped CSS. Shared pages.css and theme tokens were not changed.
7. Added favicon and description metadata.
9. Dashboard reminders compare scheduled times with the current browser time; past unfinished items are labelled Overdue and excluded from the upcoming count. At 17:49 in Asia/Dubai, the six sample reminders produce one upcoming and five overdue. This corrects the prototype display; real backend task/date/timezone integration remains part of the dashboard hookup.
10. Funnel labels distinguish percentage of the previous stage from percentage of all leads.

## Deferred, explicitly requested at backend hookup

Item 8: replace prototype Booked/Invoiced, intake/source breakdowns, funnel and revenue figures with consistent backend numbers for each date filter. Dashboard revenue must use closed-deal commission, matching Revenue Summary. The old invoice-based dashboard revenue endpoint remains unchanged in this patch.
All remaining fake-success controls from the earlier audit must be hidden for v1 during their respective integration phases. This patch removes fake credential generation; it does not complete that wider hiding pass.

## Verification

- Full suite: 402 checks plus migration passed after each implementation step, including 45 account lifecycle checks.
- Account browser regression: 30 checks passed, including cookie reload restore, forced password changes, reset, deactivation/reactivation, inactive directory, role denials and separate browser-device session revocation.
- Dashboard audit browser: 28 checks passed, including signed-out display:none, public asset credential scan, POST fallback, persistent identity, reminder timing, funnel labels, keyboard activation, clock layout at 1440/390 px, no page-level phone overflow, no observed CSP violations and no JavaScript exceptions.
- Screenshots use synthetic fixture data and a fixed browser clock of 17:49 Asia/Dubai. Prototype figures are intentionally still visible because item 8 is deferred.

## Updating an existing Windows copy

Stop the server with Ctrl+C. Extract the updated archive, then copy its code files into the existing app folder. Preserve .env, leadvolt.db and its WAL/SHM files, data/, storage/, backups/ and any local launcher. The ZIP contains none of those runtime files. No dependency changes were made; restart with the existing Node 22 launcher. Refresh the browser. The first login after this update establishes the new cookie; subsequent reloads stay signed in.
