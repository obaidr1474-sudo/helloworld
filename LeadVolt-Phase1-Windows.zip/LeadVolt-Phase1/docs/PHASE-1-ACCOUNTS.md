# Phase 1: main sessions and Admin accounts

Implemented on 21 October 2026. This phase connects authentication and account management; other CRM prototype screens still require their own integration phases.

## User behaviour

- Main CRM requires sign-in. Server authentication, revocation and permission checks remain the authority; hiding a menu is not authorization.
- Main menus derive from `/api/auth/me` role and permissions. User management is Admin-only in both browser and API.
- Main browser sessions use a persistent HttpOnly, SameSite=Strict cookie and a who-am-I check at startup. HTTPS/production cookies use Secure and the __Host- prefix. Local HTTP development uses a non-Secure cookie so localhost works. Tokens are not exposed to JavaScript in cookie login responses or stored in browser storage. Existing backend sessions expire after eight hours. Foreground pages recheck identity every 30 seconds; any API 401 locks the page immediately. Bearer clients remain supported.
- Admins create users with a server-generated temporary password shown in a one-time panel. The plaintext is not stored for later retrieval, placed in the account directory, emailed or written to audit records. Dismissal, leaving/reopening the screen or logout removes the displayed value.
- New users and users whose passwords were reset must change their temporary password before using CRM APIs. Password change revokes old sessions; users then sign in again.
- No invitation email and no self-service forgotten-password flow. Admin reset only.
- Active/all/inactive user filters use the real directory. Admins can deactivate/reactivate and reset other active users. Self-deactivation is forbidden. Reactivation preserves the current password; Admin can reset it separately.
- Logout revokes the current session. “Sign out other devices” revokes other sessions for the authenticated user and preserves the current one. The existing Security-panel button calls the same real endpoint.

## Narrow changes

- Existing route files extended: `src/routes/auth.js`, `admin.js`, `team.js`.
- `src/util.js`: forced-password gate allows the new logout-others action.
- `src/middleware.js`: password-change audit fields `current` and `next` are redacted.
- New frontend files: `public/session.js`, `account-admin.js`, scoped `session.css`.
- `public/index.html`: account scripts/style and root scope class only; existing theme definitions unchanged.
- `test/accounts.js` added to full npm test; browser acceptance in `test/phase1-browser.py`.
- `public/pages.js`, `public/pages.css`, journal routes and journal schema are unchanged.

## Validation

Baseline: 357 checks plus migration.
Each Phase 1 implementation step passed the full suite: 391 checks plus migration, including 34 account lifecycle checks.
Browser acceptance: 27 checks passed with no JavaScript exceptions, using an isolated synthetic database. Includes generated password creation, change confirmation, reset, agent UI/API denials, deactivation/reactivation, inactive directory, two simultaneous sessions, real Security button, logout clearing and reload behaviour.
Screenshots contain fixture identities and no temporary passwords.

## Recorded requirements for later phases

1. Dashboard revenue must be closed-deal commission, identical in meaning and source to Revenue Summary. The older invoice-based dashboard endpoint has not been changed in Phase 1.
2. Every fake-success control from the frontend audit must be hidden for v1, not relabelled as a preview. Phase 1 replaces the sample user-management actions and sign-out-others action; the remaining modules have not been changed or globally hidden in this phase.
3. Finance browser screenshots requested before Phase 1 are still outstanding; the account screenshots do not replace that acceptance work.
4. No change to the existing theme or shared/global CSS.
