/* Optional adapter for the EXISTING frontend/native-web shell. No automatic UI changes.
   Tokens remain in memory. Offline lead changes are acknowledged individually.
   Host application must call clearOffline() on logout/account switch. */
(function(global){'use strict';
class LeadVoltClient {
 constructor(base=''){this.base=base.replace(/\/$/,'');this.token='';this.user=null;this.db=null;}
 async request(path,{method='GET',body,headers={}}={}){const r=await fetch(this.base+'/api'+path,{method,headers:{'Content-Type':'application/json',...(this.token?{Authorization:'Bearer '+this.token}:{}),...headers},body:body===undefined?undefined:JSON.stringify(body)});const j=await r.json();if(!r.ok){const e=new Error(j.error||'Request failed');e.status=r.status;e.details=j;throw e;}return j;}
 async login(email,password){const j=await this.request('/auth/login',{method:'POST',body:{email,password}});if(this.user&&this.user.id!==j.user.id)await this.clearOffline();this.token=j.token;this.user=j.user;const capabilities=j.user.password_reset_required?{finance:false}:await this.request('/capabilities');global.dispatchEvent(new CustomEvent('leadvolt-auth',{detail:{capabilities,api:this}}));return j.user;}
 async logout(){let error;try{if(this.token)await this.request('/auth/logout',{method:'POST',body:{}});}catch(e){error=e;}finally{await this.clearOffline();this.token='';this.user=null;global.dispatchEvent(new CustomEvent('leadvolt-auth',{detail:{capabilities:{finance:false}}}));}if(error)throw error;}
 async storage(){if(!this.user)throw new Error('Sign in first');if(this.db)return this.db;const name='leadvolt-offline-'+this.user.id;this.db=await new Promise((resolve,reject)=>{const r=indexedDB.open(name,1);r.onupgradeneeded=()=>{r.result.createObjectStore('pending',{keyPath:'event_id'});r.result.createObjectStore('snapshot',{keyPath:'id'});};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});return this.db;}
 async transaction(store,mode,work){const db=await this.storage();return new Promise((resolve,reject)=>{const tx=db.transaction(store,mode);let result;try{result=work(tx.objectStore(store));}catch(e){tx.abort();reject(e);return;}tx.oncomplete=()=>resolve(result?.result);tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||new Error('Local transaction aborted'));});}
 async queueChange(change){const event={...change,event_id:change.event_id||crypto.randomUUID()};await this.transaction('pending','readwrite',s=>s.put(event));return event;}
 async pending(){return (await this.transaction('pending','readonly',s=>s.getAll()))||[];}
 async flush(){await this.request('/auth/me');const pending=await this.pending(),results=[];for(let i=0;i<pending.length;i+=100){const j=await this.request('/sync/changes',{method:'POST',body:{changes:pending.slice(i,i+100)}});for(const ack of j.results){results.push(ack);if(ack.status==='accepted')await this.transaction('pending','readwrite',s=>s.delete(ack.event_id));}}return results;}
 async refreshLeads(){let after=0,rows=[];for(;;){const j=await this.request('/sync/leads?limit=200&after='+after);rows.push(...j.data);if(!j.has_more)break;after=j.next_after;}
 // Replace the complete cache so reassigned/deleted records cannot linger after successful refresh.
 const db=await this.storage();await new Promise((resolve,reject)=>{const tx=db.transaction('snapshot','readwrite'),s=tx.objectStore('snapshot');s.clear();for(const row of rows)if(!row.is_deleted)s.put(row);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);});return rows.filter(r=>!r.is_deleted);}
 async cachedLeads(){return (await this.transaction('snapshot','readonly',s=>s.getAll()))||[];}
 async clearOffline(){if(!this.user)return;const name='leadvolt-offline-'+this.user.id;if(this.db){this.db.close();this.db=null;}await new Promise((resolve,reject)=>{const r=indexedDB.deleteDatabase(name);r.onsuccess=resolve;r.onerror=()=>reject(r.error);r.onblocked=()=>reject(new Error('Close other LeadVolt tabs before clearing local data'));});}
}
global.LeadVoltClient=LeadVoltClient;
})(window);
