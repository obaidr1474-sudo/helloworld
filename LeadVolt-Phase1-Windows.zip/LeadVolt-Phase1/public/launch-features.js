// Launch gates complement server enforcement. Fail closed if capability lookup fails.
window.LV_FEATURES={finance:false,automatic_call_sync:false};
document.documentElement.dataset.financeEnabled='false';
window.LV_FEATURES_READY=fetch('/api/capabilities',{cache:'no-store'}).then(r=>{if(!r.ok)throw Error('Capabilities unavailable');return r.json();}).then(c=>{window.LV_FEATURES=c;document.documentElement.dataset.financeEnabled=String(c.finance===true);return c;}).catch(()=>window.LV_FEATURES);
addEventListener('leadvolt-auth',e=>{window.LV_API=e.detail.api||null;window.LV_FEATURES=e.detail.capabilities||{finance:false};document.documentElement.dataset.financeEnabled=String(window.LV_FEATURES.finance===true);if(!window.LV_FEATURES.finance&&window.LV?.curName==='Invoice')window.LV.show('Dashboard');window.LV_REFRESH_FINANCE?.();});
addEventListener('DOMContentLoaded',()=>{
 const L=window.LV;
 if(L?.openReport){const original=L.openReport;L.openReport=function(name,...args){if(!window.LV_FEATURES.finance&&/revenue|commission|invoice/i.test(String(name)))return;return original.call(this,name,...args);};}
 function mark(){
  document.querySelectorAll('#rK .kpi,#rL,#rS td:nth-last-child(-n+2)').forEach(el=>{if(el.id==='rL'||el.closest('#rS')||/Revenue/.test(el.textContent))el.setAttribute('data-unfinished-finance','');});
  document.querySelectorAll('h3,button,a,.meter,.fld').forEach(el=>{
   if(/^(Revenue|Invoice|Invoices|Commission invoices|Default commission|New invoice|Create invoice)$/.test(el.textContent.trim())){
    if(el.closest('#liveFinanceRevenue'))return;const target=el.closest('.panel,.kpi,.fld')||el;target.setAttribute(/Revenue/.test(el.textContent)?'data-unfinished-finance':'data-feature-finance','');
    if(el.classList.contains('meter'))el.nextElementSibling?.setAttribute('data-unfinished-finance','');
   }
  });
  const source=document.querySelector('#rS')?.closest('table');source?.querySelectorAll('thead th:nth-last-child(-n+2)').forEach(el=>el.setAttribute('data-unfinished-finance',''));
 }
 window.LV_REFRESH_FINANCE=async()=>{
  let card=document.getElementById('liveFinanceRevenue');
  if(!window.LV_FEATURES.finance||!window.LV_API){card?.remove();return;}
  if(!card){card=document.createElement('section');card.id='liveFinanceRevenue';card.className='card';card.style.gridColumn='1 / -1';card.setAttribute('data-feature-finance','');document.querySelector('[data-w="rev"]')?.after(card);}
  const client=window.LV_API;
  try{const data=await client.request('/finance/dashboard?range=all');if(!window.LV_FEATURES.finance||window.LV_API!==client)return;const h=document.createElement('h3');h.textContent='Revenue';const value=document.createElement('p');value.id='liveRevenueValue';value.textContent=new Intl.NumberFormat(undefined,{style:'currency',currency:'AED'}).format(data.revenue);const link=document.createElement('a');link.href='/finance.html';link.textContent='Open Admin finance and reports';card.replaceChildren(h,value,link);}catch(e){card.textContent='Revenue is unavailable. Sign in again or retry.';if(e.status===401||e.status===403){window.LV_FEATURES.finance=false;document.documentElement.dataset.financeEnabled='false';card.remove();}}
 };
 L?.on?.('route',()=>window.LV_REFRESH_FINANCE());
 let scheduled=false;mark();new MutationObserver(()=>{if(scheduled)return;scheduled=true;requestAnimationFrame(()=>{scheduled=false;mark();});}).observe(document.body,{childList:true,subtree:true});
});
