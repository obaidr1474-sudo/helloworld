// LeadVolt client helper: enable push on this device + live updates. Usage: LVLive.start(token, onNotification)
window.LVLive = (() => {
  const b64 = s => { const p = '='.repeat((4 - s.length % 4) % 4), r = atob((s + p).replace(/-/g, '+').replace(/_/g, '/')); return Uint8Array.from([...r].map(c => c.charCodeAt(0))); };
  async function enablePush(token) {
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) return { ok: false, why: 'This browser has no push support. On iPhone, add LeadVolt to the Home Screen first (Share → Add to Home Screen).' };
    const reg = await navigator.serviceWorker.register('/sw.js', { scope: '/' });
    const perm = await Notification.requestPermission(); if (perm !== 'granted') return { ok: false, why: 'Notifications are blocked. Allow them in the browser or phone settings.' };
    const { publicKey } = await (await fetch('/api/push/key', { headers: { Authorization: 'Bearer ' + token } })).json();
    const sub = await reg.pushManager.getSubscription() || await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64(publicKey) });
    const r = await fetch('/api/push/subscribe', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token }, body: JSON.stringify(sub) });
    return { ok: r.ok, ...(await r.json()) };
  }
  function stream(token, onNote) {
    let es, wait = 1000;
    const open = () => { es = new EventSource('/api/stream?token=' + encodeURIComponent(token));
      es.addEventListener('notification', e => { wait = 1000; const n = JSON.parse(e.data); onNote && onNote(n); fetch(`/api/notifications/${n.id}/delivered`, { method: 'POST', headers: { Authorization: 'Bearer ' + token } }).catch(() => {}); });
      es.onerror = () => { es.close(); setTimeout(open, wait = Math.min(wait * 2, 30000)); }; };
    open(); return () => es && es.close();
  }
  return { enablePush, stream, start: (t, cb) => { enablePush(t).catch(() => {}); return stream(t, cb); } };
})();
