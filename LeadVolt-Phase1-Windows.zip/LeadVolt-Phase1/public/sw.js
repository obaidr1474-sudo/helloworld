// LeadVolt service worker: shows push alerts even when the app is closed, and confirms delivery to the server.
self.addEventListener('install', e => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));
self.addEventListener('push', e => {
  let d = {}; try { d = e.data ? e.data.json() : {}; } catch { d = { title: 'LeadVolt', body: e.data && e.data.text() }; }
  const show = self.registration.showNotification(d.title || 'LeadVolt', {
    body: d.body || '', tag: d.lead_id ? 'lead-' + d.lead_id : 'n-' + d.id, renotify: true, requireInteraction: d.kind === 'lead' || d.kind === 'unassigned',
    icon: '/icon.svg', badge: '/icon.svg', vibrate: [200, 100, 200], data: { url: d.url || '/', id: d.id, u: d.u, t: d.t },
    actions: d.lead_id ? [{ action: 'open', title: 'Open lead' }] : []
  });
  const ack = d.id ? fetch('/api/notifications/ack', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: d.id, u: d.u, t: d.t }) }).catch(() => {}) : Promise.resolve();
  e.waitUntil(Promise.all([show, ack]));
});
self.addEventListener('notificationclick', e => {
  e.notification.close(); const url = e.notification.data && e.notification.data.url || '/';
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(ws => { for (const w of ws) { if ('focus' in w) { w.postMessage({ type: 'open', url }); return w.focus(); } } return self.clients.openWindow(url); }));
});
