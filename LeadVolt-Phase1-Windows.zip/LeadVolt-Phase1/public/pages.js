/* LeadVolt pages: router + every page beyond the dashboard. Relies on window.LV from the main page. */
(function(){
const L=window.LV;if(!L)return;
const {$,$$,esc,av,pal,burst,fmt}=L;
L.auditLog=[];L.tracker=[];
const NOAUD=/\(demo\)|blocked|Previewing|preview|^Enter|^Drag|^Copied|copied|^Choose|^Give|Back to|Template|^That|Try it|^Write/i;
L.audit=(action,detail,area)=>{L.auditLog.unshift({at:new Date(),user:L.viewAs?'Obaid Raza (as '+L.viewAs+')':'Obaid Raza',area:area||L.curName||'Dashboard',action,detail:detail||''});L.emit&&L.emit('audit')};
const toast=m=>{L.toast(m);if(!NOAUD.test(m))L.audit(m)};
const icon=(id,st='')=>`<svg class="i" ${st}><use href="#${id}"/></svg>`;L.icon=icon;
const SLUG={'Dashboard':'dashboard','Global Config':'config','Leads':'leads','Data':'data','Invoice':'invoice','Reports':'reports','Projects':'projects','Listing':'listing','Off Plan':'offplan','Attendance':'attendance','Tasks':'tasks','Team':'team','Org Profile':'org','LeadVolt AI':'ai','About':'about','Ref. ID Management':'refids','Manage Teams':'teams','Roles and Permissions':'roles','Audit Log':'audit'};
const NAME=Object.fromEntries(Object.entries(SLUG).map(([a,b])=>[b,a]));
const pages={},built={},subs={};L.pages=pages;
L.on=(ev,fn)=>(subs[ev]=subs[ev]||[]).push(fn);
L.emit=ev=>(subs[ev]||[]).forEach(f=>{try{f()}catch(e){console.error(e)}});
const segPos=s=>{const b=s.querySelector('[aria-pressed="true"]'),t=s.querySelector('.th');if(!b||!t)return;t.style.width=b.offsetWidth+'px';t.style.transform=`translateX(${b.offsetLeft}px)`};
L.segPos=segPos;
addEventListener('resize',()=>$$('.seg2').forEach(segPos));
const replay=el=>{el.style.animation='none';void el.offsetHeight;el.style.animation=''};
const head=(title,sub,acts='',cnt)=>`<div class="pg-head"><div class="tt"><h1>${title}${cnt!=null?`<span class="cnt num">${cnt}</span>`:''}</h1><p>${sub}</p></div><div class="pg-actions">${acts}</div></div>`;
L.head=head;
const stagger=root=>root.querySelectorAll('.panel,.kpi').forEach((p,i)=>p.style.setProperty('--i',i));
L.stagger=stagger;

function soon(el,name){el.innerHTML=`<div class="pg"><div class="soon"><div><div class="orb">${icon('i-spark')}</div><h2>${esc(name)} is being built</h2><p>This page is next in the build queue. It will use the same design and motion as the rest of LeadVolt.</p><button class="btn-primary rip" style="margin:18px auto 0" data-go-dash>${icon('i-grid')}Back to Dashboard</button></div></div></div>`;
  el.querySelector('[data-go-dash]').onclick=()=>L.navTo('Dashboard')}

L.show=function(name,opts={}){
  if(name==='Invoice'){if(!window.LV_FEATURES?.finance)return L.show('Dashboard');location.assign('/finance.html');return;}
  const slug=SLUG[name]||'dashboard';L.curName=NAME[slug]||'Dashboard';
  $$('.main .page').forEach(p=>p.hidden=p.dataset.page!==slug);
  if(slug==='dashboard'){const d=$('.page[data-page="dashboard"]');replay(d);L.refreshDash()}
  else{let el=$(`#pages > .page[data-page="${slug}"]`);
    if(!el){el=document.createElement('div');el.className='page';el.dataset.page=slug;$('#pages').appendChild(el)}
    el.hidden=false;replay(el);
    if(!built[slug]){(pages[slug]||soon)(el,NAME[slug]);built[slug]=true;stagger(el)}else if(el._refresh)el._refresh();
    requestAnimationFrame(()=>el.querySelectorAll('.seg2').forEach(segPos))}
  try{history.replaceState(null,'',slug==='dashboard'?location.pathname+location.search:'#'+slug)}catch(e){}
  L.emit('route');
  window.scrollTo(0,0);
};

/* ---------- Shared lead data ---------- */
const STS=['New','Callback','Meeting Done','Site Visit Done','Booked','Invoiced','Overdue'];
const STC={New:'#4C9AFF',Callback:'#0B6BE6','Meeting Done':'#2B2F3A','Site Visit Done':'#E8A400',Booked:'#12805C',Invoiced:'#22C55E',Overdue:'#D13438'};
L.STS=STS;L.STC=STC;
const first=['Maya','Omar','Lina','Faisal','Sophia','Hamza','Nadia','Leo','Amira','Rami','Julia','Karim','Sana','Ethan','Dina','Adam','Rania','Viktor','Huda','Marco'];
const last=['Collins','Rashid','Kapoor','Nguyen','Saleh','Bauer','Farouk','Silva','Odeh','Rossi','Khan','Moreau','Yilmaz','Park','Novak','Qureshi','Grant','Laurent','Haddad','Ibrahim'];
for(let i=0;i<44;i++){const n=first[i%20]+' '+last[(i*7+3)%20];if(L.leads.some(l=>l.n===n))continue;
  L.leads.push({n,ini:n.split(' ').map(w=>w[0]).join(''),st:STS[(i*3)%7],src:L.srcN[(i*2)%5],ag:L.agentN[(i+1)%4],proj:L.projects[(i*3)%5],bud:'AED '+(0.7+((i*41)%38)/10).toFixed(1)+'M',ph:'+971 5'+((i+3)%9)+' '+(410+i*13)+' '+String(2000+i*317).slice(0,4),note:['Looking for a ready unit, can move fast.','Investor, interested in rental yield.','Needs a 3BR near a school.','Asked for floor plans and brochure.','Wants to negotiate the payment plan.'][i%5],last:(i%9)+' days ago',c:pal[(i+2)%5]})}
function norm(l,i){if(!l.id)l.id='L'+(1001+i);l.days=parseInt(l.last)||0;if(/days? ago/.test(l.last))l.last=l.days===0?'Today':l.days===1?'Yesterday':l.days+' days ago';l.bn=parseFloat(String(l.bud).replace(/[^\d.]/g,''))||0;if(l.score==null)l.score=38+((i*17)%60);if(!l.email)l.email=l.n.toLowerCase().replace(/[^a-z]+/g,'.')+'@mail.com';if(!l.created)l.created=(3+(i*5)%40)+' days ago';if(!l.notes)l.notes=[]}
const normAll=()=>L.leads.forEach(norm);normAll();
L.on('leads',normAll);
const moneyM=v=>'AED '+v.toFixed(v>=10?0:1)+'M';

/* ---------- Lead profile (global) ---------- */
function timeline(l){const base=[
  {ic:'i-plus',c:['#DCE8FC','#0957C3'],t:'Lead created',s:l.created+' · via '+l.src,p:''},
  {ic:'i-phone',c:['#E5F5EE','#12805C'],t:'Call with '+l.ag,s:'4 days ago · 6 min',p:l.note},
  {ic:'i-msg',c:['#E3E5EA','#2B2F3A'],t:'WhatsApp brochure sent',s:'3 days ago',p:l.proj+' brochure and price list'},
  {ic:'i-pin',c:['#FFF3DC','#9A5B00'],t:'Status: '+l.st,s:l.last,p:''}];
  return [...l.notes.map(n=>({ic:'i-task',c:['#EEF4FE','#0B6BE6'],t:'Note by Obaid Raza',s:n.when,p:n.text})),...base.reverse()]}
function tlHtml(l){return timeline(l).map((e,i)=>`<li style="animation-delay:${i*50}ms"><span class="dot" style="background:${e.c[0]};color:${e.c[1]}">${icon(e.ic)}</span><div><b>${esc(e.t)}</b><small>${esc(e.s)}</small>${e.p?`<p>${esc(e.p)}</p>`:''}</div></li>`).join('')}
function openProfile(l){L.setLast(document.activeElement);
  L.layer.innerHTML=`<div class="veil" data-close></div><aside class="profile" role="dialog" aria-modal="true" aria-label="${esc(l.n)}">
  <div class="pf-hero"><div class="pf-top">${av(l.ini,l.c)}<div style="min-width:0"><h2>${esc(l.n)}</h2><small>${esc(l.proj)} · ${esc(l.src)} · ${esc(l.id)}</small></div><button class="x" data-close aria-label="Close">${icon('i-x')}</button></div>
  <div class="pf-acts"><button data-pa="call">${icon('i-phone')}Call</button><button data-pa="wa">${icon('i-msg')}WhatsApp</button><button data-pa="sch">${icon('i-cal')}Schedule</button><select id="pfSt" aria-label="Lead status">${STS.map(s=>`<option ${s===l.st?'selected':''}>${s}</option>`).join('')}</select></div></div>
  <div class="pf-body">
    <div class="panel"><div class="score"><div class="ring" style="--p:${l.score}"><span class="num">${l.score}</span></div><div><b style="font-weight:500">Lead score</b><small style="display:block;color:var(--muted);font-size:var(--fs-xs)">${l.score>=80?'Hot lead. Call today.':l.score>=60?'Warm. Keep the conversation going.':'Cool. Nurture with updates.'}</small></div></div></div>
    <div class="panel"><h3>Details</h3><div class="pf-grid">
      <div><small>Phone</small><span class="num">${esc(l.ph)}</span></div><div><small>Email</small>${esc(l.email)}</div>
      <div><small>Budget</small>${esc(l.bud)}</div><div><small>Project</small>${esc(l.proj)}</div>
      <div><small>Source</small>${esc(l.src)}</div><div><small>Assigned agent</small>${esc(l.ag)}</div>
      <div><small>Created</small>${esc(l.created)}</div><div><small>Last contact</small>${esc(l.last)}</div></div></div>
    <div class="panel"><h3>Add a note</h3><div class="note-box"><textarea id="pfNote" placeholder="What happened on the last call?"></textarea><button class="btn-primary rip" id="pfAdd" style="align-self:flex-end">${icon('i-plus')}Add</button></div></div>
    <div class="panel"><h3>Activity</h3><ul class="tl" id="pfTl">${tlHtml(l)}</ul></div>
  </div></aside>`;
  const box=L.layer.querySelector('.profile');box.querySelector('.x').focus();
  box.addEventListener('click',e=>{const b=e.target.closest('[data-pa]');if(!b)return;
    if(b.dataset.pa==='call')toast('Calling '+l.n+' (demo)');if(b.dataset.pa==='wa')toast('WhatsApp opened for '+l.n+' (demo)');
    if(b.dataset.pa==='sch'){L.tasks&&L.tasks.unshift({id:'T'+Date.now(),t:'Follow up with '+l.n,lead:l.n,due:'Tomorrow',pri:'High',done:false,ag:l.ag});toast('Follow-up added to Tasks for tomorrow');L.emit('tasks')}});
  box.querySelector('#pfSt').addEventListener('change',e=>{const old=l.st;l.st=e.target.value;l.last='Just now';l.days=0;l.notes.unshift({text:'Status changed from '+old+' to '+l.st,when:'Just now'});box.querySelector('#pfTl').innerHTML=tlHtml(l);toast(l.n+' moved to '+l.st);if(l.st==='Booked'){const r=e.target.getBoundingClientRect();burst(r.left+r.width/2,r.top,120)}L.emit('leads')});
  box.querySelector('#pfAdd').addEventListener('click',()=>{const t=box.querySelector('#pfNote');const v=t.value.trim();if(!v){t.focus();t.placeholder='Write a note first';return}l.notes.unshift({text:v,when:'Just now'});l.last='Just now';t.value='';box.querySelector('#pfTl').innerHTML=tlHtml(l);toast('Note added');L.emit('leads')});
}
L.openProfile=openProfile;
document.addEventListener('click',e=>{const a=e.target.closest('.lead-link');if(!a)return;const l=L.findLead(a.dataset.lead);if(l){e.stopPropagation();L.openProfile(l)}},true);

/* ---------- Leads page ---------- */
/* ---- more pages are added below ---- */
L.team=[
  {n:'Obaid Raza',i:'OR',role:'Sales Manager',c:pal[0]},{n:'Ashfaq Haji Haroon',i:'AH',role:'Senior Agent',c:pal[0]},{n:'Raish Ahmed',i:'RA',role:'Agent',c:pal[1]},
  {n:'Farwa Shah',i:'FS',role:'Agent',c:pal[2]},{n:'Daniel Costa',i:'DC',role:'Agent',c:pal[3]},{n:'Mariam Khan',i:'MK',role:'Team Lead',c:pal[4]},
  {n:'Yara Saeed',i:'YS',role:'Agent',c:pal[2]},{n:'Bilal Ahmed',i:'BA',role:'Agent',c:pal[1]},{n:'Kevin Lee',i:'KL',role:'Agent',c:pal[3]},{n:'Anaya Singh',i:'AS',role:'Junior Agent',c:pal[0]},{n:'Danyal Abid',i:'DA',role:'Agent',c:pal[2]}];
const tm=n=>L.team.find(t=>t.n===n)||{i:n.split(' ').map(w=>w[0]).join(''),c:pal[1]};
const DAY=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
const dayLbl=o=>{if(o<0)return o===-1?'Yesterday':(-o)+' days overdue';if(o===0)return 'Today';if(o===1)return 'Tomorrow';const d=new Date();d.setDate(d.getDate()+o);return DAY[d.getDay()]+' '+d.getDate()};

/* ---------- Tasks ---------- */
const TT=[['Call','i-phone'],['Meeting','i-team'],['Site visit','i-pin'],['WhatsApp','i-msg'],['Email','i-inbox']];
L.tasks=[
  ['Call back about payment plan','Khalid Mansoor','Call',0,'High','Ashfaq Haji Haroon','9:30 AM'],['Send floor plans','Elena Petrova','WhatsApp',0,'Medium','Raish Ahmed','11:00 AM'],
  ['Site visit at Creek Heights','Rahul Verma','Site visit',0,'High','Farwa Shah','1:45 PM'],['Confirm budget range','Fatima Zahra','Call',0,'Medium','Ashfaq Haji Haroon','3:15 PM'],
  ['Prepare offer letter','James Whitfield','Email',0,'Low','Daniel Costa','4:30 PM'],['Follow up on brochure','Aisha Karim','Call',-1,'High','Raish Ahmed',''],
  ['Share rental yield report','Yusuf Demir','Email',-2,'Medium','Farwa Shah',''],['Book viewing slot','Mei Lin','Meeting',1,'Medium','Daniel Costa','10:00 AM'],
  ['Collect passport copy','Carlos Rivera','WhatsApp',1,'Low','Ashfaq Haji Haroon',''],['Second meeting with family','Hana Sato','Meeting',2,'High','Raish Ahmed','5:00 PM'],
  ['Payment reminder','Tariq Aziz','Call',3,'Medium','Farwa Shah',''],['Introduce mortgage partner','Olivia Brooks','Email',4,'Low','Daniel Costa',''],
  ['Handover documents','Arjun Mehta','Meeting',5,'Medium','Ashfaq Haji Haroon','2:00 PM'],['Thank-you call after booking','Layla Hassan','Call',0,'Low','Raish Ahmed','6:00 PM']
].map((r,i)=>({id:'T'+i,t:r[0],lead:r[1],type:r[2],off:r[3],pri:r[4],ag:r[5],at:r[6],done:i===13}));
const PRI=['Critical','High','Medium','Low'];const PRW={Critical:0,High:1,Medium:2,Low:3};
const tWhen=t=>{if(t.when)return new Date(t.when);const d=new Date();d.setDate(d.getDate()+(t.off??1));const m=/(\d+):(\d+)\s*(AM|PM)/i.exec(t.at||'');d.setHours(m?(+m[1]%12)+(/pm/i.test(m[3])?12:0):18,m?+m[2]:0,0,0);return d};
const tOff=t=>{const a=new Date();a.setHours(0,0,0,0);const b=tWhen(t);b.setHours(0,0,0,0);return Math.round((b-a)/864e5)};
const tGrp=t=>t.done?'done':tOff(t)<0?'overdue':tOff(t)===0?'today':'upcoming';
L.addTask=function(pre={},editId){L.setLast(document.activeElement);const ed=editId?L.tasks.find(t=>t.id===editId):null,v=ed||pre;
  const dt=v.when||v.t&&ed?tWhen(v):(()=>{const d=new Date(Date.now()+36e5);d.setMinutes(0,0,0);return d})();
  const loc=new Date(dt.getTime()-dt.getTimezoneOffset()*6e4).toISOString().slice(0,16);let pri=v.pri||'Medium';
  L.layer.innerHTML=`<div class="veil" data-close></div><aside class="drawer tdrw" role="dialog" aria-modal="true" aria-label="${ed?'Edit task':'Add task'}"><header><div style="flex:1"><h3>${ed?'Edit task':'Add task'}</h3><small>Fields marked * are required</small></div><button class="x" data-close aria-label="Close">${icon('i-x')}</button></header>
    <form id="atF" novalidate class="tform">
      <label class="fld"><span>Title<i class="rq">*</i></span><input id="atT" value="${esc(v.t||'')}" placeholder="e.g. Need to call"><span class="err" id="atTe"></span></label>
      <label class="fld"><span>Assign to<i class="rq">*</i></span><select id="atA">${L.team.map(m=>`<option ${m.n===(v.ag||L.me||'Obaid Raza')?'selected':''}>${esc(m.n)}</option>`).join('')}</select></label>
      <label class="fld"><span>Date &amp; time<i class="rq">*</i></span><input id="atD" type="datetime-local" value="${loc}"><span class="err" id="atDe"></span></label>
      <div class="qpick" id="atQ">${[['In 1 hour',1/24],['Tomorrow 10 AM','t10'],['In 3 days',3],['Next week',7]].map(q=>`<button type="button" data-q="${q[1]}">${q[0]}</button>`).join('')}</div>
      <label class="fld"><span>Type</span><select id="atY">${TT.map(t=>`<option ${t[0]===(v.type||'Call')?'selected':''}>${t[0]}</option>`).join('')}</select></label>
      <label class="fld"><span>Linked lead</span><input id="atL" list="atLl" value="${esc(v.lead&&v.lead!=='No lead linked'?v.lead:'')}" placeholder="Search a lead (optional)"><datalist id="atLl">${L.leads.slice(0,300).map(l=>`<option>${esc(l.n)}</option>`).join('')}</datalist></label>
      <label class="fld"><span>Task description<i class="rq">*</i></span><textarea id="atX" rows="4" placeholder="e.g. I want to say…">${esc(v.desc||'')}</textarea><span class="err" id="atXe"></span></label>
      <div class="fld"><span>Priority<i class="rq">*</i></span><div class="prio" id="atP">${PRI.map(p=>`<button type="button" class="pr-${p}" data-p="${p}" aria-pressed="${p===pri}">${p}</button>`).join('')}</div></div>
      <label class="fld"><span>Reminder</span><select id="atR">${['No reminder','At the time','15 minutes before','1 hour before','1 day before'].map(r=>`<option ${r===(v.rem||'15 minutes before')?'selected':''}>${r}</option>`).join('')}</select></label>
      <label class="ck"><input type="checkbox" id="atN" ${ed?'':'checked'}>Send a push notification to the assignee</label>
    </form>
    <footer class="tfoot">${ed?`<button type="button" class="ghost danger" id="atDel">${icon('a-trash')}Delete</button>`:''}<span style="flex:1"></span><button type="button" class="ghost" data-close>Cancel</button><button class="btn-primary rip" form="atF" type="submit">${icon('i-check')}Save</button></footer></aside>`;
  $('#atT').focus();
  $('#atP').addEventListener('click',e=>{const b=e.target.closest('[data-p]');if(!b)return;pri=b.dataset.p;$$('#atP button').forEach(x=>x.setAttribute('aria-pressed',x===b))});
  $('#atQ').addEventListener('click',e=>{const b=e.target.closest('[data-q]');if(!b)return;let d=new Date();if(b.dataset.q==='t10'){d.setDate(d.getDate()+1);d.setHours(10,0,0,0)}else{d=new Date(Date.now()+ +b.dataset.q*864e5);if(+b.dataset.q>=1)d.setHours(10,0,0,0)}$('#atD').value=new Date(d.getTime()-d.getTimezoneOffset()*6e4).toISOString().slice(0,16)});
  const del=$('#atDel');if(del)del.addEventListener('click',()=>{if(!del.dataset.sure){del.dataset.sure=1;del.textContent='Tap again to delete';return}L.tasks.splice(L.tasks.indexOf(ed),1);L.closeLayer();toast('Task deleted: '+ed.t);L.emit('tasks')});
  $('#atF').addEventListener('submit',e=>{e.preventDefault();const t=$('#atT').value.trim(),d=$('#atD').value,x=$('#atX').value.trim();
    $('#atTe').textContent=t?'':'Enter a title.';$('#atDe').textContent=d?'':'Pick a date and time.';$('#atXe').textContent=x?'':'Add a short description.';if(!t||!d||!x)return;
    const ln=$('#atL').value.trim(),lead=L.leads.find(l=>l.n.toLowerCase()===ln.toLowerCase());
    const o={t,ag:$('#atA').value,when:new Date(d).toISOString(),desc:x,pri,type:$('#atY').value,lead:lead?lead.n:(ln||'No lead linked'),rem:$('#atR').value};
    if(ed){Object.assign(ed,o);delete ed.off;toast('Task updated: '+t)}else{L.tasks.unshift({id:'T'+Date.now(),done:false,by:L.me||'Obaid Raza',created:new Date().toISOString(),...o});toast('Task added for '+o.ag)}
    if($('#atN').checked&&L.notify)L.notify('New task: '+t,`${o.pri} priority · due ${tWhen(o).toLocaleString('en-GB',{day:'numeric',month:'short',hour:'numeric',minute:'2-digit'})}`,lead?lead.n:null);
    L.closeLayer();L.emit('tasks')})};
pages.tasks=function(el){
  const S={f:'all',q:'',ag:'',pri:'',sort:'when',dir:1};
  const CARDS=[['today','Today','i-cal','linear-gradient(135deg,#0B6BE6,#5B9BF0)'],['upcoming','Upcoming','i-up','linear-gradient(135deg,#12805C,#3FB58A)'],['overdue','Overdue','i-alert','linear-gradient(135deg,#C62828,#E86A5D)'],['done','Completed','i-check','linear-gradient(135deg,#2B2F3A,#596173)'],['all','All','i-task','linear-gradient(135deg,#7A5AF8,#A38BFA)']];
  el.innerHTML=`<div class="pg">${head('Tasks','Calls, meetings and follow-ups for you and your team.',`<button class="btn-primary rip" id="tAdd">${icon('i-plus')}Add task</button>`)}
    <div class="tcards" id="tC">${CARDS.map((c,i)=>`<button class="tcard2" data-f="${c[0]}" aria-pressed="${c[0]==='all'}" style="--g:${c[3]};--i:${i}"><span class="ti">${icon(c[2])}</span><span>${c[1]}</span><b class="num" data-c="${c[0]}">0</b></button>`).join('')}</div>
    <div class="panel ttab"><div class="tbar2"><label class="field">${icon('i-search')}<input id="tQ" placeholder="Search tasks, leads or notes" autocomplete="off"></label>
      <select class="sel" id="tAg" aria-label="Assigned to"><option value="">Everyone</option>${[...new Set([...L.team.map(t=>t.n),...L.tasks.map(t=>t.ag)])].map(a=>`<option>${esc(a)}</option>`).join('')}</select>
      <select class="sel" id="tPr" aria-label="Priority"><option value="">All priorities</option>${PRI.map(p=>`<option>${p}</option>`).join('')}</select></div>
      <div class="tblw"><table class="ttbl"><thead><tr><th style="width:36px"></th>${[['pri','Priority'],['t','Task name'],['ag','Assigned to'],['when','Scheduled date'],['desc','Task description']].map(h=>`<th><button data-sort="${h[0]}">${h[1]}<span class="sa"></span></button></th>`).join('')}<th style="width:80px"></th></tr></thead><tbody id="tB"></tbody></table></div>
      <div class="tfootr" id="tF2"></div></div></div>`;
  const fmtW=t=>{const d=tWhen(t),o=tOff(t);return `<b>${o===0?'Today':o===1?'Tomorrow':o===-1?'Yesterday':d.toLocaleDateString('en-GB',{day:'numeric',month:'short'})}</b><small>${d.toLocaleTimeString([],{hour:'numeric',minute:'2-digit'})}</small>`};
  function counts(){const c={all:L.tasks.length,today:0,upcoming:0,overdue:0,done:0};L.tasks.forEach(t=>c[tGrp(t)]++);$$('[data-c]',el).forEach(b=>L.countTo?L.countTo(b,c[b.dataset.c],v=>v,600):b.textContent=c[b.dataset.c])}
  function rows(){const q=S.q.toLowerCase();let r=L.tasks.filter(t=>(S.f==='all'||tGrp(t)===S.f)&&(!S.ag||t.ag===S.ag)&&(!S.pri||t.pri===S.pri)&&(!q||(t.t+' '+t.lead+' '+(t.desc||'')+' '+t.ag).toLowerCase().includes(q)));
    const k=S.sort;r.sort((a,b)=>S.dir*(k==='when'?tWhen(a)-tWhen(b):k==='pri'?PRW[a.pri]-PRW[b.pri]:String(a[k]||'').localeCompare(String(b[k]||''))));
    $$('[data-sort]',el).forEach(b=>{b.classList.toggle('on',b.dataset.sort===k);b.querySelector('.sa').textContent=b.dataset.sort===k?(S.dir>0?'↑':'↓'):''});
    $('#tB').innerHTML=r.map((t,i)=>{const a=tm(t.ag),g=tGrp(t),ty=TT.find(x=>x[0]===t.type)||TT[0];return `<tr class="${t.done?'done':''} ${g==='overdue'?'od':''}" data-id="${t.id}" style="--r:${i}">
      <td><button class="tcheck" data-chk aria-label="${t.done?'Mark not done':'Mark done'}: ${esc(t.t)}"><svg class="i"><use href="#i-check"/></svg></button></td>
      <td><span class="pchip pr-${t.pri}">${t.pri}</span></td>
      <td><button class="tname" data-edit><b>${esc(t.t)}</b></button><small>${icon(ty[1],'style="width:12px;height:12px"')} ${esc(t.type||'Task')}${t.lead&&t.lead!=='No lead linked'?` · <button class="lead-link" data-lead="${esc(t.lead)}">${esc(t.lead)}</button>`:''}</small></td>
      <td><span class="who2"><span class="avatar" style="width:26px;height:26px;font-size:10px;background:${a.c[0]};color:${a.c[1]}">${a.i}</span>${esc(t.ag)}</span></td>
      <td class="${g==='overdue'?'odt':''}">${fmtW(t)}</td><td class="tdesc">${esc(t.desc||'—')}</td>
      <td><div class="ra">${!t.done?`<button class="rbtn" data-snz title="Move to tomorrow" aria-label="Move to tomorrow">${icon('i-cal')}</button>`:''}<button class="rbtn" data-edit title="Edit" aria-label="Edit task">${icon('i-pen')}</button></div></td></tr>`}).join('')||`<tr><td colspan="7"><div class="empty2">${icon('i-task')}<b>No tasks found</b><small>${S.q||S.ag||S.pri?'Try clearing the search or filters.':'Add a task and it shows up here.'}</small></div></td></tr>`;
    $('#tF2').textContent=r.length+' of '+L.tasks.length+' tasks'}
  function draw(){counts();rows()}
  el._refresh=draw;L.on('tasks',()=>{if(el.isConnected)draw()});draw();
  $('#tAdd').addEventListener('click',()=>L.addTask());
  $('#tQ').addEventListener('input',e=>{S.q=e.target.value;rows()});$('#tAg').addEventListener('change',e=>{S.ag=e.target.value;rows()});$('#tPr').addEventListener('change',e=>{S.pri=e.target.value;rows()});
  el.addEventListener('click',e=>{let b;
    if(b=e.target.closest('[data-f]')){S.f=b.dataset.f;$$('#tC [data-f]').forEach(x=>x.setAttribute('aria-pressed',x===b));rows();return}
    if(b=e.target.closest('[data-sort]')){const k=b.dataset.sort;S.dir=S.sort===k?-S.dir:1;S.sort=k;rows();return}
    const tr=e.target.closest('tr[data-id]');if(!tr||e.target.closest('[data-lead]'))return;const t=L.tasks.find(x=>x.id===tr.dataset.id);
    if(e.target.closest('[data-chk]')){t.done=!t.done;tr.classList.toggle('done',t.done);if(t.done){const r=e.target.getBoundingClientRect();burst(r.left+12,r.top+12,30);toast('Task completed: '+t.t)}else toast('Task reopened: '+t.t);counts();setTimeout(()=>{if(el.isConnected)rows()},500);return}
    if(e.target.closest('[data-snz]')){const d=tWhen(t),n=new Date();n.setDate(n.getDate()+1);n.setHours(d.getHours(),d.getMinutes(),0,0);t.when=n.toISOString();delete t.off;toast('Moved to tomorrow: '+t.t);draw();return}
    if(e.target.closest('[data-edit]'))L.addTask({},t.id)});
};

/* ---------- Attendance ---------- */
/* ---------- Attendance: geofenced clock-in + late reason ---------- */
L.clockIn=null;L.attLog=[];L.myAtt=null;
const hm=s=>{const [h,m]=String(s||'0:0').split(':').map(Number);return h*60+(m||0)};
const t12=s=>{const [h,m]=String(s).split(':').map(Number);return new Date(2000,0,1,h,m).toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit'})};
const distM=(a,b)=>{const R=6371e3,r=x=>x*Math.PI/180,dLa=r(b.lat-a.lat),dLo=r(b.lng-a.lng),h=Math.sin(dLa/2)**2+Math.cos(r(a.lat))*Math.cos(r(b.lat))*Math.sin(dLo/2)**2;return 2*R*Math.asin(Math.sqrt(h))};
const dTxt=m=>m>=1000?(m/1000).toFixed(1)+' km':Math.round(m)+' m';
function setClockUi(){const b=$('#clockBtn');if(!b)return;const on=!!L.clockIn;b.classList.toggle('out',on);const t=on?L.clockIn.toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit'}):'';b.querySelector('.tx').textContent=on?'Clocked in at '+t+' · Clock Out':'Clock In'}
function attModal(html){L.setLast(document.activeElement);L.layer.innerHTML=`<div class="veil" data-close></div><div class="modal attm" role="dialog" aria-modal="true" aria-label="Clock in">${html}</div>`;return L.layer.querySelector('.attm')}
function locate(){return new Promise((res,rej)=>{if(!navigator.geolocation)return rej({code:'nogps'});navigator.geolocation.getCurrentPosition(p=>res({lat:p.coords.latitude,lng:p.coords.longitude,acc:p.coords.accuracy}),e=>rej(e),{enableHighAccuracy:true,timeout:12000,maximumAge:0})})}
function nearest(pos){const offs=L.cfg.attendance.offices;let best=null;offs.forEach(o=>{const d=distM(pos,o);if(!best||d<best.d)best={o,d}});return best}
function finishIn(pos,best,late,reason){const now=new Date();L.clockIn=now;
  L.myAtt={in:now,late,reason:reason||'',office:best?best.o.n:'',dist:best?Math.round(best.d):null,acc:pos&&pos.acc?Math.round(pos.acc):null,sim:!!(pos&&pos.sim)};
  L.attLog.unshift({n:L.me||'Obaid Raza',...L.myAtt});L.closeLayer();setClockUi();L.emit('clock');
  L.audit&&L.audit('Clocked in'+(late?' late':''),`${now.toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit'})}${best?' · '+dTxt(best.d)+' from '+best.o.n:''}${late?' · reason: '+reason:''}${pos&&pos.sim?' · simulated location (preview)':''}`,'Attendance');
  L.toast(late?'Clocked in (late). Your reason was sent to your manager.':'Clocked in at '+now.toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit'})+'. Have a great day!');
  const r=$('#clockBtn')?.getBoundingClientRect();if(r&&r.width)burst(r.left+r.width/2,r.top,50)}
function askLate(pos,best){const C=L.cfg.attendance,now=new Date(),mins=now.getHours()*60+now.getMinutes()-hm(C.lateAfter);
  const m=attModal(`<header><h3>You're clocking in late</h3><button class="x" data-close aria-label="Close">${icon('i-x')}</button></header>
    <div class="attb"><div class="latebox"><b class="num">${mins>=60?Math.floor(mins/60)+'h '+(mins%60)+'m':mins+' min'}</b><small>after the ${t12(C.lateAfter)} cut-off</small></div>
    <p>Tell your manager why. This is saved with today's attendance.</p>
    <div class="chips2 sm" id="lrC">${['Traffic','Client meeting','Site visit','Medical','Personal','Other'].map(r=>`<button type="button" data-r="${r}" aria-pressed="false">${r}</button>`).join('')}</div>
    <label class="fld"><span>Reason${C.reasonReq?'<i class="rq">*</i>':''}</span><textarea id="lrT" rows="3" placeholder="e.g. Met a client at Damac Lagoons before coming in"></textarea><span class="err" id="lrE"></span></label></div>
    <div class="actions"><button type="button" class="ghost" data-close>Cancel</button><button class="btn-primary rip" id="lrGo">${icon('i-check')}Clock in</button></div>`);
  let pick='';m.querySelector('#lrC').addEventListener('click',e=>{const b=e.target.closest('[data-r]');if(!b)return;pick=b.dataset.r;m.querySelectorAll('#lrC button').forEach(x=>x.setAttribute('aria-pressed',x===b));m.querySelector('#lrT').focus()});
  m.querySelector('#lrGo').addEventListener('click',()=>{const t=m.querySelector('#lrT').value.trim(),r=[pick,t].filter(Boolean).join(' – ');
    if(C.reasonReq&&(!t||t.length<5)&&pick!=='Traffic'&&pick!=='Medical'){m.querySelector('#lrE').textContent=pick?'Add a few words about it.':'Pick a reason or write one.';return}
    if(!r){m.querySelector('#lrE').textContent='Pick a reason or write one.';return}
    if(L.notify)L.notify('Late clock-in: '+(L.me||'Obaid Raza'),r,null);finishIn(pos,best,true,r)});
  m.querySelector('#lrC button').focus()}
function afterLocation(pos){const C=L.cfg.attendance,best=C.geofence?nearest(pos):null;
  if(C.geofence){const ok=best&&best.d<=(+best.o.r||+C.radius||150)+Math.min(pos.acc||0,100);
    if(!ok){const m=attModal(`<header><h3>You're not at the office</h3><button class="x" data-close aria-label="Close">${icon('i-x')}</button></header>
      <div class="attb"><div class="geo bad">${icon('i-pin')}<div><b>${best?dTxt(best.d)+' from '+esc(best.o.n):'No office set up'}</b><small>Clock-in works within ${best?(best.o.r||C.radius):C.radius} m of the office.${pos.acc?' Your GPS accuracy: ±'+Math.round(pos.acc)+' m.':''}</small></div></div>
      <p>If you're at a client meeting or site visit, ask your manager to mark you present from the Attendance page.</p></div>
      <div class="actions"><button type="button" class="ghost" data-close>Close</button><button class="btn-primary rip" id="geoRe">${icon('i-pin')}Try again</button></div>`);
      m.querySelector('#geoRe').addEventListener('click',()=>L.doClockIn(true));
      L.audit&&L.audit('Clock-in blocked (outside office)',best?dTxt(best.d)+' from '+best.o.n:'','Attendance');return}}
  const now=new Date(),late=now.getHours()*60+now.getMinutes()>hm(C.lateAfter);
  if(late&&C.askReason)return askLate(pos,best);finishIn(pos,best,late,'')}
L.doClockIn=function(force){
  if(L.clockIn&&!force){const s=Math.floor((Date.now()-L.clockIn)/6e4);const m=attModal(`<header><h3>Clock out?</h3><button class="x" data-close aria-label="Close">${icon('i-x')}</button></header><div class="attb"><p>You've worked <b>${Math.floor(s/60)}h ${s%60}m</b> today.</p></div><div class="actions"><button class="ghost" data-close>Stay clocked in</button><button class="btn-primary rip" id="coGo">Clock out</button></div>`);
    m.querySelector('#coGo').addEventListener('click',()=>{const t=new Date();if(L.attLog[0])L.attLog[0].out=t;if(L.myAtt)L.myAtt.out=t;L.clockIn=null;L.closeLayer();setClockUi();L.emit('clock');toast('Clocked out at '+t.toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit'}))});return}
  const C=L.cfg.attendance;
  if(!C.geofence)return afterLocation({});
  const m=attModal(`<header><h3>Checking your location</h3><button class="x" data-close aria-label="Close">${icon('i-x')}</button></header><div class="attb"><div class="geo"><span class="radar"></span><div><b>Finding you…</b><small>Clock-in works within ${C.radius} m of ${esc(C.offices.map(o=>o.n).join(' or '))}.</small></div></div></div>
    <div class="actions"><button class="ghost" data-close>Cancel</button><button class="lnk" id="geoSim" title="Only in this preview. The live app always uses the phone's GPS.">Preview: pretend I'm at the office</button></div>`);
  let done=false;
  m.querySelector('#geoSim').addEventListener('click',()=>{if(done)return;done=true;const o=C.offices[0];afterLocation({lat:o.lat+0.0003,lng:o.lng+0.0002,acc:12,sim:true})});
  locate().then(p=>{if(done||!m.isConnected)return;done=true;afterLocation(p)}).catch(e=>{if(done||!m.isConnected)return;
    const why=e.code==='nogps'?'This device has no location service.':e.code===1?'Location permission is off. Allow location for LeadVolt in your browser or phone settings, then try again.':'Could not get a GPS fix. Move near a window and try again.';
    m.querySelector('.geo').className='geo bad';m.querySelector('.geo div').innerHTML=`<b>Location not available</b><small>${why}</small>`;m.querySelector('header h3').textContent="Can't confirm you're at the office";
    const a=m.querySelector('.actions');a.insertAdjacentHTML('beforeend',`<button class="btn-primary rip" id="geoRe">${icon('i-pin')}Try again</button>`);a.querySelector('#geoRe').addEventListener('click',()=>L.doClockIn(true))})};
(()=>{const ob=$('#clockBtn');if(!ob)return;const nb=ob.cloneNode(true);ob.replaceWith(nb);nb.addEventListener('click',()=>L.doClockIn())})();
pages.attendance=function(el){
  const ST=['Present','Present','Late','Present','Remote','Present','Leave','Present','Late','Present'];
  const ins=['8:52 AM','8:47 AM','9:21 AM','8:58 AM','9:02 AM','8:40 AM','','8:55 AM','9:34 AM','8:59 AM'];
  const hrs=[8.6,9.1,7.4,8.2,8.0,9.4,0,8.3,6.9,8.1];
  const pr=ST.filter(s=>s==='Present'||s==='Remote').length,lt=ST.filter(s=>s==='Late').length,lv=ST.filter(s=>s==='Leave').length;
  const kpi=(i,ic,bg,fg,lbl,v,suf='')=>`<div class="kpi" style="--i:${i}"><span class="ki" style="background:${bg};color:${fg}">${icon(ic)}</span><div><small>${lbl}</small><b class="num" data-v="${v}" data-suf="${suf}">0</b></div></div>`;
  const now=new Date(),y=now.getFullYear(),m=now.getMonth(),days=new Date(y,m+1,0).getDate(),startDow=(new Date(y,m,1).getDay()+6)%7;
  el.innerHTML=`<div class="pg">${head('Attendance','Shifts, clock-ins and the team\'s month at a glance.',`<button class="ghost" id="aExp">${icon('i-inbox')}Monthly summary</button>`)}
    <div class="shift"><div>${av('OR',pal[0])}</div><div><small id="aShift"></small><div class="big-t" id="aT">Not clocked in</div><div class="tl-bar"><span class="w" id="aW" style="left:0;width:0"></span><span class="now" id="aNow"></span></div><div class="tl-lbl"><span>8 AM</span><span>11 AM</span><span>2 PM</span><span>5 PM</span><span>8 PM</span></div><div class="mystat" id="aMe"></div></div><button class="cbtn" id="aBtn"></button></div>
    <div class="kpis">${kpi(0,'i-check','#E5F5EE','#12805C','Present today',pr)}${kpi(1,'i-alert','#FFF3DC','#9A5B00','Late arrivals',lt)}${kpi(2,'i-cal','#EDEFF4','#2B2F3A','On leave',lv)}${kpi(3,'i-bellring','var(--blue-50)','var(--blue)','Average hours',8.2,'h')}</div>
    <div class="split2"><div class="panel"><h3>Team today</h3><div class="tbl-wrap"><table class="tbl" style="min-width:640px"><thead><tr><th>Member</th><th>Status</th><th>Clock in</th><th>Clock out</th><th>Hours</th><th>Location</th></tr></thead><tbody>
      ${L.team.map((t,i)=>`<tr style="--r:${i}"><td><div class="who">${av(t.i,t.c,ST[i]!=='Leave'?'on':'')}<div><b style="font-weight:500">${esc(t.n)}</b><small>${t.role}</small></div></div></td><td><span class="pill-st ps-${ST[i]}">${ST[i]}</span></td><td class="num">${ins[i]||'—'}</td><td class="num">${ST[i]==='Leave'?'—':hrs[i]>8.5?'6:10 PM':'Working'}</td><td><div class="hours"><span class="bar"><i style="width:${Math.min(100,hrs[i]/9*100)}%;${hrs[i]<7.5&&hrs[i]>0?'background:var(--warn)':''}"></i></span><span class="num">${hrs[i]?hrs[i]+'h':'—'}</span></div></td><td>${ST[i]==='Remote'?'Home':ST[i]==='Leave'?'—':'Office · Business Bay'}</td></tr>`).join('')}
      </tbody></table></div></div>
      <div class="panel"><h3>${now.toLocaleDateString('en-GB',{month:'long',year:'numeric'})}</h3><div class="heat" id="aHeat"></div><div class="legend"><span><i style="background:#0B6BE6"></i>95%+</span><span><i style="background:#4C9AFF"></i>85%+</span><span><i style="background:#B9D4FB"></i>Below 85%</span><span><i style="background:var(--chip)"></i>Weekend</span></div></div></div></div>`;
  $$('.kpi b',).forEach(b=>{if(el.contains(b))L.countTo(b,+b.dataset.v,v=>(b.dataset.suf?v.toFixed(1):Math.round(v))+b.dataset.suf)});
  let h=['MON','TUE','WED','THU','FRI','SAT','SUN'].map(d=>`<span class="dn">${d}</span>`).join('')+'<span></span>'.repeat(startDow);
  for(let d=1;d<=days;d++){const dow=(new Date(y,m,d).getDay()+6)%7,we=dow>=5,fut=d>now.getDate(),rate=we?0:80+((d*37)%21);
    const bg=fut?'transparent':we?'#EDEFF4':rate>=95?'#0B6BE6':rate>=85?'#4C9AFF':'#B9D4FB',fg=!fut&&!we&&rate>=85?'#fff':'var(--body)';
    h+=`<span class="d num" style="--r:${d};background:${bg};color:${fg};${fut?'border:1px dashed var(--line)':''}${d===now.getDate()?';box-shadow:0 0 0 2px var(--charcoal)':''}" title="${d} ${now.toLocaleDateString('en-GB',{month:'short'})}: ${fut?'upcoming':we?'weekend':rate+'% attendance'}">${d}</span>`}
  $('#aHeat').innerHTML=h;
  function shift(){const b=$('#aBtn');if(!b)return;const C=L.cfg.attendance;$('#aShift').innerHTML=`Your shift today · ${t12(C.start)} – ${t12(C.end)} · late after <b>${t12(C.lateAfter)}</b>${C.geofence?' · office check '+C.radius+' m':''}`;
    const A=L.myAtt;$('#aMe').innerHTML=A?`<span class="pill-st ps-${A.late?'Late':'Present'}">${A.late?'Late':'On time'}</span><span>In ${A.in.toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit'})}${A.out?' · Out '+A.out.toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit'}):''}</span>${A.office?`<span>${icon('i-pin','style="width:12px;height:12px"')}${A.dist!=null?dTxt(A.dist)+' from ':''}${esc(A.office)}${A.sim?' (preview)':''}</span>`:''}${A.reason?`<span class="rsn">Reason: ${esc(A.reason)}</span>`:''}`:'';const on=!!L.clockIn;b.className='cbtn rip'+(on?' on':'');b.innerHTML=on?'<span class="live"></span>Clock Out':icon('i-check')+'Clock In';
    const t=new Date(),toPct=d=>Math.max(0,Math.min(100,((d.getHours()+d.getMinutes()/60)-8)/12*100));$('#aNow').style.left=toPct(t)+'%';
    if(on){const s=Math.floor((t-L.clockIn)/1000);$('#aT').textContent=[s/3600,s/60%60,s%60].map(v=>String(Math.floor(v)).padStart(2,'0')).join(':');const a=toPct(L.clockIn);$('#aW').style.left=a+'%';$('#aW').style.width=Math.max(1,toPct(t)-a)+'%'}else{$('#aT').textContent='Not clocked in';$('#aW').style.width='0'}}
  shift();const iv=setInterval(()=>{if(!el.isConnected){clearInterval(iv);return}if(!el.hidden)shift()},1000);
  el._refresh=shift;L.on('clock',shift);
  $('#aBtn').addEventListener('click',()=>L.doClockIn());
  $('#aExp').addEventListener('click',()=>toast('Monthly summary: 94% attendance, 7 late arrivals, 4 leave days'));
};
/* ---------- Charts ---------- */
function niceMax(v){if(v<=0)return 1;const p=Math.pow(10,Math.floor(Math.log10(v))),n=v/p;return (n<=1?1:n<=2?2:n<=2.5?2.5:n<=5?5:10)*p}
function smooth(pts){if(pts.length<2)return '';let d=`M${pts[0][0]} ${pts[0][1]}`;for(let i=0;i<pts.length-1;i++){const p0=pts[i-1]||pts[i],p1=pts[i],p2=pts[i+1],p3=pts[i+2]||p2;const c1=[p1[0]+(p2[0]-p0[0])/6,p1[1]+(p2[1]-p0[1])/6],c2=[p2[0]-(p3[0]-p1[0])/6,p2[1]-(p3[1]-p1[1])/6];d+=` C${c1[0].toFixed(1)} ${c1[1].toFixed(1)} ${c2[0].toFixed(1)} ${c2[1].toFixed(1)} ${p2[0].toFixed(1)} ${p2[1].toFixed(1)}`}return d}
L.lineChart=function(wrap,labels,series,fmtv=fmt){
  const W=720,H=260,pl=44,pr=14,pt=16,pb=30,iw=W-pl-pr,ih=H-pt-pb;const vis=series.filter(s=>s.on!==false);
  const mx=niceMax(Math.max(1,...vis.flatMap(s=>s.data))),x=i=>pl+(labels.length<2?iw/2:i*iw/(labels.length-1)),y=v=>pt+ih-(v/mx)*ih;
  let g='';for(let k=0;k<=4;k++){const v=mx*k/4,yy=y(v);g+=`<line class="gl" x1="${pl}" x2="${W-pr}" y1="${yy}" y2="${yy}"/><text class="ax" x="${pl-8}" y="${yy+4}" text-anchor="end">${fmtv(v)}</text>`}
  const step=Math.ceil(labels.length/8);labels.forEach((l,i)=>{if(i%step===0||i===labels.length-1)g+=`<text class="ax" x="${x(i)}" y="${H-8}" text-anchor="middle">${esc(l)}</text>`});
  let defs='',body='';vis.forEach((s,si)=>{const pts=s.data.map((v,i)=>[x(i),y(v)]),d=smooth(pts);defs+=`<linearGradient id="cg${si}${wrap.id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${s.color}" stop-opacity=".22"/><stop offset="1" stop-color="${s.color}" stop-opacity="0"/></linearGradient>`;
    body+=`<path class="ar" d="${d} L${x(s.data.length-1)} ${pt+ih} L${x(0)} ${pt+ih}Z" fill="url(#cg${si}${wrap.id})"/><path class="ln" pathLength="1" d="${d}" stroke="${s.color}"/>`;
    const li=s.data.length-1;body+=`<circle cx="${x(li)}" cy="${y(s.data[li])}" r="4.5" fill="${s.color}" stroke="#fff" stroke-width="2" class="ar"/>`});
  wrap.innerHTML=`<svg class="chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Trend chart"><defs>${defs}</defs>${g}${body}<line class="xh" id="xh${wrap.id}" y1="${pt}" y2="${pt+ih}"/><g id="pts${wrap.id}"></g><rect x="${pl}" y="${pt}" width="${iw}" height="${ih}" fill="transparent"/></svg><div class="ctip"></div>`;
  const svg=wrap.querySelector('svg'),tip=wrap.querySelector('.ctip'),xh=svg.querySelector('.xh'),pg=svg.querySelector('g[id^="pts"]');
  svg.addEventListener('mousemove',e=>{const r=svg.getBoundingClientRect(),sx=(e.clientX-r.left)/r.width*W;let i=Math.round((sx-pl)/iw*(labels.length-1));i=Math.max(0,Math.min(labels.length-1,i));
    svg.classList.add('hov');xh.setAttribute('x1',x(i));xh.setAttribute('x2',x(i));pg.innerHTML=vis.map(s=>`<circle class="pt" cx="${x(i)}" cy="${y(s.data[i])}" r="5" fill="${s.color}" stroke="#fff" stroke-width="2"/>`).join('');
    tip.innerHTML=`<b>${esc(labels[i])}</b>`+vis.map(s=>`<div><i style="background:${s.color}"></i>${esc(s.name)}: <strong class="num">${fmtv(s.data[i])}</strong></div>`).join('');tip.style.left=(x(i)/W*100)+'%';tip.style.top=(Math.min(...vis.map(s=>y(s.data[i])))/H*r.height)+'px';tip.classList.add('on')});
  svg.addEventListener('mouseleave',()=>{svg.classList.remove('hov');tip.classList.remove('on');pg.innerHTML=''});
};

/* ---------- Reports ---------- */
pages.reports=function(el){
  const S={r:'30d',on:{Leads:true,Booked:true,Visits:true}};
  const MON=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  function labels(){const d=new Date();if(S.r==='7d')return Array.from({length:7},(_,i)=>{const t=new Date(d);t.setDate(d.getDate()-6+i);return DAY[t.getDay()]});
    if(S.r==='30d')return Array.from({length:15},(_,i)=>{const t=new Date(d);t.setDate(d.getDate()-28+i*2);return t.getDate()+' '+MON[t.getMonth()]});
    if(S.r==='90d')return Array.from({length:13},(_,i)=>'Wk '+(i+1));return Array.from({length:12},(_,i)=>MON[(d.getMonth()+1+i)%12])}
  const scale={'7d':1,'30d':2,'90d':7,'12m':26};
  function gen(n,base,seed){return Array.from({length:n},(_,i)=>Math.round(base*scale[S.r]*(1+.35*Math.sin(i*.9+seed)+.25*Math.sin(i*.37+seed*2)+i/n*.5)))}
  el.innerHTML=`<div class="pg">${head('Reports','How your pipeline, team and sources are performing.',`<div class="seg2" id="rR"><span class="th"></span>${[['7d','7 days'],['30d','30 days'],['90d','90 days'],['12m','12 months']].map(([k,t])=>`<button data-r="${k}" aria-pressed="${k===S.r}">${t}</button>`).join('')}</div><button class="btn-primary rip" id="rDl">${icon('i-inbox')}Share report</button>`)}
    <div class="rtype" id="rT"></div><div id="rPiv"></div><div id="rMain">
    <div class="kpis" id="rK"></div>
    <div class="split2" style="margin-bottom:14px"><div class="panel"><div class="ph"><h3>Lead trend</h3><div class="lgd" id="rLg"></div></div><div class="chart-wrap" id="rC"></div></div>
      <div class="panel"><h3>Pipeline by status</h3><div class="dn2" id="rD"></div></div></div>
    <div class="split2" style="margin-bottom:14px"><div class="panel"><div class="ph"><h3>Source performance</h3><small style="color:var(--muted)">Cost per lead from your ad spend</small></div><div class="tbl-wrap"><table class="tbl" style="min-width:620px"><thead><tr><th>Source</th><th>Leads</th><th>Booked</th><th>Conversion</th><th>Cost per lead</th><th>Revenue</th></tr></thead><tbody id="rS"></tbody></table></div></div>
      <div class="panel"><h3>Agent leaderboard</h3><div class="lb" id="rL"></div></div></div>
    <div class="panel"><div class="ph"><h3>Best time to call</h3><small style="color:var(--muted)">Answer rate by weekday and hour. Darker is better.</small></div><div class="besttime" id="rB"></div></div></div></div>`;
  const SER=[['Leads','#0B6BE6',40,0],['Visits','#FFC83D',11,1.3],['Booked','#2B2F3A',4,2.1]];
  function draw(){const lb=labels(),n=lb.length,f=scale[S.r];
    const ser=SER.map(([nm,c,b,sd])=>({name:nm,color:c,data:gen(n,b,sd),on:S.on[nm]}));
    const tot=ser[0].data.reduce((a,v)=>a+v,0),bk=ser[2].data.reduce((a,v)=>a+v,0);
    const k=(i,ic,bg,fg,lbl,v,fm,b)=>`<div class="kpi" style="--i:${i}"><span class="ki" style="background:${bg};color:${fg}">${icon(ic)}</span><div><small>${lbl}</small><b class="num" data-v="${v}" data-f="${fm}">0</b></div>${L.badge(b)}</div>`;
    $('#rK').innerHTML=k(0,'i-users','var(--blue-50)','var(--blue)','Leads',tot,'n',12)+k(1,'i-check','#E5F5EE','#12805C','Conversion rate',bk/tot*100,'p',3)+k(2,'i-cash','#E3E5EA','#2B2F3A','Revenue',bk*0.045,'m',18)+k(3,'i-phone','#FFF3DC','#9A5B00','Avg first response',Math.max(4,18-f),'min',-22);
    $$('#rK b').forEach(b=>{const fm=b.dataset.f;L.countTo(b,+b.dataset.v,v=>fm==='p'?v.toFixed(1)+'%':fm==='m'?'AED '+v.toFixed(1)+'M':fm==='min'?Math.round(v)+' min':fmt(v))});
    $('#rLg').innerHTML=SER.map(([nm,c])=>`<button data-s="${nm}" aria-pressed="${S.on[nm]}"><i style="background:${c}"></i>${nm}</button>`).join('');
    L.lineChart($('#rC'),lb,ser);
    const cnt=STS.map(s=>[s,L.leads.filter(l=>l.st===s).length]),sum=cnt.reduce((a,c)=>a+c[1],0),C=2*Math.PI*60;let off=0,arcs='';
    cnt.forEach(([s,v],i)=>{const len=Math.max(0,C*v/sum-3);arcs+=`<circle class="arc" cx="80" cy="80" r="60" fill="none" stroke="${STC[s]}" stroke-width="18" stroke-dasharray="0.01 ${C}" data-len="${len}" stroke-dashoffset="${-off}" transform="rotate(-90 80 80)"><title>${s}: ${v}</title></circle>`;off+=len+3});
    $('#rD').innerHTML=`<svg viewBox="0 0 160 160">${arcs}<text x="80" y="78" text-anchor="middle" style="font:600 24px var(--font);fill:var(--ink)">${sum}</text><text x="80" y="96" text-anchor="middle" style="font:400 11px var(--font);fill:var(--muted)">active leads</text></svg><ul>${cnt.map(([s,v])=>`<li><i style="background:${STC[s]}"></i>${s}<b class="num">${v}</b></li>`).join('')}</ul>`;
    $$('#rD .arc').forEach((a,i)=>setTimeout(()=>a.setAttribute('stroke-dasharray',`${a.dataset.len} ${C}`),150+i*90));
    const src=[['Bayut',486,24,85,'#0B6BE6'],['Property Finder',312,15,92,'#2B2F3A'],['Facebook',208,6,38,'#4C9AFF'],['Website',142,8,22,'#9DB9E8'],['Walk-in',100,9,0,'#FFC83D']];
    $('#rS').innerHTML=src.map(([s,l,b,cpl,c],i)=>{const L2=Math.round(l*f/26*2+l/6),B=Math.max(1,Math.round(b*f/26*2+b/6)),cv=B/L2*100;return `<tr style="--r:${i}"><td><div class="who"><span class="ic" style="width:24px;height:24px;border-radius:7px;background:${c};display:inline-block"></span>${s}</div></td><td class="num">${fmt(L2)}</td><td class="num">${B}</td><td><div class="mbar"><span class="bar"><i style="width:${Math.min(100,cv*8)}%"></i></span><span class="num">${cv.toFixed(1)}%</span></div></td><td class="num">${cpl?'AED '+cpl:'Free'}</td><td class="num">AED ${(B*0.28).toFixed(2)}M</td></tr>`}).join('');
    const ag=L.agents.map(a=>({n:a.n,i:a.i,c:a.c,v:a.booked*f*0.12+parseFloat(a.deal.replace(/[^\d.]/g,''))*(a.deal.includes('K')?.001:1)})).sort((a,b)=>b.v-a.v),mxa=ag[0].v;
    $('#rL').innerHTML=ag.map((a,i)=>`<div class="r"><span class="rk">${i+1}</span>${av(a.i,a.c,'on')}<div style="min-width:0"><div class="nm">${esc(a.n)}</div><div class="bar"><i style="width:${a.v/mxa*100}%"></i></div></div><span class="val num">AED ${a.v.toFixed(2)}M</span></div>`).join('');
  }
  let bt='<span></span>'+Array.from({length:12},(_,h)=>`<span>${(h+8)%12||12}${h+8<12?'a':'p'}</span>`).join('');
  ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].forEach((d,di)=>{bt+=`<span>${d}</span>`;for(let h=0;h<12;h++){const v=Math.max(.08,Math.min(1,.35+.3*Math.sin((h-2)*.6)+(h>=10?.35:0)-(di>=5?.25:0)+((di*7+h*3)%5)/20));bt+=`<span class="c" style="--r:${di*12+h};background:rgba(11,107,230,${v.toFixed(2)})" title="${d} ${(h+8)%12||12}${h+8<12?' AM':' PM'}: ${Math.round(v*100)}% answer rate"></span>`}});
  $('#rB').innerHTML=bt;
  const TYPES=['Overview','Activity','Agency','Data','Leads','Project vs User','Project vs Sub-Status','Received Date vs Source','Sub-Status vs Sub-Source','Visit & Meeting'];const RO={q:'',k:1};
  function typ(){const t=L.reportType||'Overview',fam=(/^(Data|Leads): /.exec(t)||[])[1];$('#rT').innerHTML=TYPES.map(x=>`<button data-ty="${x}" aria-pressed="${x===t||x===fam}">${x}</button>`).join('');$('#rMain').hidden=t!=='Overview';
    $('#rPiv').innerHTML=t==='Overview'?'':(fam?`<div class="rfam"><b>${fam} reports</b>${L.REPFAM[fam].map(x=>`<button data-ty="${fam}: ${x}" aria-pressed="${t===fam+': '+x}">${x}</button>`).join('')}</div>`:'')+`<div class="rhead"><label class="field" style="flex:1;min-width:200px">${icon('i-search')}<input id="rQ" placeholder="Search rows, e.g. a user or project" value="${esc(RO.q)}"></label><select class="sel" id="rK" aria-label="Date range"><option value="1">Till date</option><option value=".04">Today</option><option value=".2">Last 7 days</option><option value=".5">Last 30 days</option></select></div><div id="rPv">${L.renderReport(t,RO)}</div>`;
    const k=$('#rK');if(k)k.value=String(RO.k);if(t==='Overview')draw()}
  $('#rT').addEventListener('click',e=>{const b=e.target.closest('[data-ty]');if(!b)return;const v=b.dataset.ty;L.reportType=v==='Data'||v==='Leads'?v+': '+L.REPFAM[v][0]:v;typ()});
  $('#rPiv').addEventListener('click',e=>{const b=e.target.closest('[data-ty]');if(!b)return;L.reportType=b.dataset.ty;typ()});
  $('#rPiv').addEventListener('input',e=>{if(e.target.id!=='rQ')return;RO.q=e.target.value.toLowerCase();$('#rPv').innerHTML=L.renderReport(L.reportType,RO)});
  $('#rPiv').addEventListener('change',e=>{if(e.target.id!=='rK')return;RO.k=+e.target.value;$('#rPv').innerHTML=L.renderReport(L.reportType,RO)});
  $('#rPiv').addEventListener('click',e=>{if(!e.target.closest('[data-csv]'))return;const rows=[...$('#rPiv table').rows].map(r=>[...r.cells].map(c=>'"'+c.textContent.replace(/"/g,'""')+'"').join(','));const t=rows.join('\n');try{navigator.clipboard.writeText(t).then(()=>toast('Report copied. Paste it into Excel or Sheets.'),()=>toast('Copy blocked by the browser'))}catch(x){toast('Copy blocked by the browser')}});
  L.on('rtype',()=>{if(el.isConnected)typ()});
  draw();typ();el._refresh=()=>typ();
  $('#rR').addEventListener('click',e=>{const b=e.target.closest('[data-r]');if(!b)return;S.r=b.dataset.r;$$('#rR button').forEach(x=>x.setAttribute('aria-pressed',x===b));segPos($('#rR'));draw()});
  $('#rLg').addEventListener('click',e=>{const b=e.target.closest('[data-s]');if(!b)return;const k=b.dataset.s;if(Object.values(S.on).filter(Boolean).length===1&&S.on[k])return;S.on[k]=!S.on[k];draw()});
  $('#rDl').addEventListener('click',()=>toast('Report link copied for your team (demo)'));
};
/* ---------- Property data + artwork ---------- */
let skN=0;
function skyline(seed,c1,c2,water){let s=seed*977+13;const gid='sk'+seed+'_'+(++skN);const r=()=>(s=(s*9301+49297)%233280)/233280;
  let b='';const layer=(n,minH,maxH,col,win)=>{let x=-10;for(let i=0;i<n&&x<410;i++){const w=22+r()*34,h=minH+r()*(maxH-minH),y=200-h-(water?28:0);b+=`<rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${w.toFixed(1)}" height="${(h+40).toFixed(1)}" fill="${col}" rx="2"/>`;
    if(r()>.6)b+=`<rect x="${(x+w/2-1).toFixed(1)}" y="${(y-14).toFixed(1)}" width="2" height="14" fill="${col}"/>`;
    if(win)for(let yy=y+8;yy<200-(water?30:6);yy+=11)for(let xx=x+5;xx<x+w-5;xx+=8)if(r()>.55)b+=`<rect x="${xx.toFixed(1)}" y="${yy.toFixed(1)}" width="3.5" height="5" fill="${r()>.3?'#FFE29A':'#FFFFFF'}" opacity="${(.45+r()*.5).toFixed(2)}"/>`;x+=w+2+r()*8}};
  layer(14,60,130,'rgba(255,255,255,.18)',false);layer(12,40,110,'rgba(20,28,48,.55)',true);layer(10,20,70,'#1B2338',true);
  return `<svg viewBox="0 0 400 200" preserveAspectRatio="xMidYMax slice" aria-hidden="true"><defs><linearGradient id="${gid}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${c1}"/><stop offset="1" stop-color="${c2}"/></linearGradient></defs><rect width="400" height="200" fill="url(#${gid})"/><circle cx="${70+seed*13%90}" cy="56" r="20" fill="#FFE7A8" opacity=".85"/>${b}${water?`<rect y="172" width="400" height="28" fill="#0A3A7A" opacity=".85"/><g opacity=".35">${Array.from({length:14},(_,i)=>`<rect x="${i*30}" y="${178+(i%3)*6}" width="18" height="1.5" fill="#fff"/>`).join('')}</g>`:''}</svg>`}
const heart='<svg class="i" viewBox="0 0 24 24"><path d="M12 20s-7-4.4-9-9.2C1.6 7.4 4 4.5 7.1 4.5c2 0 3.4 1.1 4.9 3 1.5-1.9 2.9-3 4.9-3 3.1 0 5.5 2.9 4.1 6.3C19 15.6 12 20 12 20z"/></svg>';
L.props=[
  {n:'Marina Vista',area:'Dubai Marina',dev:'Azure Bay Developers',st:'Ready',from:1.2,units:180,sold:142,beds:'1–3 BR',size:'720–1,850 sqft',c:['#0B6BE6','#9DC2F7'],seed:3,water:1,prog:100,hand:null,plan:[20,30,50],am:['Infinity pool','Marina walk','Gym','Kids play area','Concierge'],about:'Waterfront towers with full marina views and direct access to the promenade.'},
  {n:'Palm Residences',area:'Palm Jumeirah',dev:'Sandline Properties',st:'Off Plan',from:3.4,units:96,sold:61,beds:'2–4 BR',size:'1,400–3,900 sqft',c:['#1C4FA8','#F7B27A'],seed:7,water:1,prog:72,hand:'2027-06-30',plan:[10,50,40],am:['Private beach','Spa','Sky lounge','Valet','Smart home'],about:'Boutique beachfront residences on the trunk of the Palm with private beach access.'},
  {n:'Creek Heights',area:'Dubai Creek Harbour',dev:'Northgate Estates',st:'Off Plan',from:1.6,units:240,sold:118,beds:'1–3 BR',size:'650–1,700 sqft',c:['#2B2F3A','#7DB4FF'],seed:11,water:1,prog:45,hand:'2027-12-31',plan:[10,60,30],am:['Creek views','Cycling track','Co-working','Pool deck','Retail podium'],about:'Twin towers beside the creek with park access and a ten-minute drive to Downtown.'},
  {n:'Downtown Loft',area:'Downtown Dubai',dev:'Azure Bay Developers',st:'Ready',from:2.1,units:120,sold:104,beds:'Studio–2 BR',size:'480–1,350 sqft',c:['#5B3FD1','#F4A6B5'],seed:5,water:0,prog:100,hand:null,plan:[25,25,50],am:['Burj views','Rooftop cinema','Gym','Lobby café'],about:'Design-led lofts a short walk from the Boulevard and the Dubai Mall.'},
  {n:'Hills Villas',area:'Dubai Hills Estate',dev:'Greenleaf Communities',st:'Off Plan',from:4.8,units:64,sold:52,beds:'4–6 BR',size:'3,200–6,800 sqft',c:['#12805C','#BDEBD3'],seed:9,water:0,prog:88,hand:'2027-03-31',plan:[20,40,40],am:['Golf course','Private garden','Community park','School nearby','Clubhouse'],about:'Detached villas on the golf course with large gardens and family amenities.'},
  {n:'Bay Square Offices',area:'Business Bay',dev:'Northgate Estates',st:'Off Plan',from:0.9,units:150,sold:39,beds:'Offices',size:'850–4,000 sqft',c:['#0957C3','#FFD38A'],seed:13,water:1,prog:20,hand:'2028-09-30',plan:[10,40,50],am:['Grade A offices','Metro access','Conference floor','EV charging'],about:'Grade A office floors with canal views and quick metro access.'}];
const TYPES={'Hills Villas':['Villa'],'Bay Square Offices':['Office'],'Downtown Loft':['Studio','1BR','2BR'],'Palm Residences':['2BR','3BR','4BR']};
L.units=[];L.props.forEach((p,pi)=>{let s=pi*31+7;const r=()=>(s=(s*9301+49297)%233280)/233280;const types=TYPES[p.n]||['1BR','2BR','3BR'];const code=p.n.split(' ').map(w=>w[0]).join('');
  for(let k=0;k<12;k++){const t=types[Math.floor(r()*types.length)],base={Studio:480,'1BR':760,'2BR':1180,'3BR':1650,'4BR':2600,Villa:4200,Office:1400}[t],size=Math.round(base*(.9+r()*.35)/10)*10,fl=t==='Villa'?'—':String(2+Math.floor(r()*38));
    const ppsf=p.from*1e6/(base*.95)*(.95+r()*.3);const rv=r();L.units.push({id:code+'-'+(t==='Villa'?'V':fl)+String(k+1).padStart(2,'0'),proj:p.n,type:t,size,fl,view:p.water?['Sea','Marina','Creek','City'][Math.floor(r()*4)]:['Golf','Park','City','Burj'][Math.floor(r()*4)],price:Math.round(size*ppsf/1000)*1000,st:rv<.5?'Available':rv<.72?'Reserved':'Sold',for:''})}});
const money=v=>v>=1e6?'AED '+(v/1e6).toFixed(2)+'M':'AED '+fmt(v);
const daysTo=d=>Math.max(0,Math.ceil((new Date(d)-new Date())/864e5));
const qtr=d=>{const t=new Date(d);return 'Q'+(Math.floor(t.getMonth()/3)+1)+' '+t.getFullYear()};

/* ---------- Projects ---------- */
function openProject(p){L.setLast(document.activeElement);const left=p.units-p.sold,int=L.leads.filter(l=>l.proj===p.n);
  L.layer.innerHTML=`<div class="veil" data-close></div><aside class="profile" role="dialog" aria-modal="true" aria-label="${esc(p.n)}"><div class="pd-img">${p.cover?`<img src="${p.cover}" alt="">`:skyline(p.seed,p.c[0],p.c[1],p.water)}<button class="x" data-close aria-label="Close">${icon('i-x')}</button><div class="cap"><span class="ptag ${p.st==='Ready'?'rd':'op'}">${p.st}</span><h2>${esc(p.n)}</h2><small>${esc(p.area)} · ${esc(p.dev)}</small></div></div>
  <div class="pf-body"><div class="panel"><div class="stat3"><div><small>Price from</small><b>AED ${p.from.toFixed(1)}M</b></div><div><small>Units left</small><b class="num">${left} of ${p.units}</b></div><div><small>Handover</small><b>${p.hand?qtr(p.hand):'Ready now'}</b></div></div>
    <div style="margin-top:12px"><div class="sold" style="display:flex;justify-content:space-between;font-size:var(--fs-xs);color:var(--muted);margin-bottom:6px"><span>${Math.round(p.sold/p.units*100)}% sold</span><span>${esc(p.beds)} · ${esc(p.size)}</span></div><div class="bar"><i style="width:${p.sold/p.units*100}%"></i></div></div></div>
    <div class="panel"><h3>About</h3><p style="margin:0;color:var(--body);line-height:1.55">${esc(p.about)}</p><h3 style="margin-top:14px">Amenities</h3><div class="amen">${p.am.map(a=>`<span>${esc(a)}</span>`).join('')}</div></div>${p.type?`<div class="panel"><h3>Project details</h3><dl class="pdl">${[['Type',p.type+' · '+p.sub],['Certificate',p.cert],['Facing',(p.face||[]).join(', ')],['RERA',(p.rera||[]).join(', ')],['Price range',p.to?'AED '+L.fmt(Math.round(p.from*1e6))+' – '+L.fmt(p.to):''],['Brokerage',p.brok],['Blocks',(p.blocks||[]).map(b=>b.n).join(', ')],['Contacts',(p.pocs||[]).filter(x=>x.n).map(x=>x.n+(x.ph?' ('+x.ph+')':'')).join(', ')]].filter(r=>r[1]).map(r=>`<dt>${r[0]}</dt><dd>${esc(r[1])}</dd>`).join('')}</dl></div>`:''}
    ${(p.photos||[]).length>1||(p.videos||[]).length||(p.docs||[]).length||(p.urls||[]).length?`<div class="panel"><h3>Gallery</h3><div class="pgal">${(p.photos||[]).map(x=>`<img src="${x.url}" alt="${esc(x.name)}" loading="lazy">`).join('')}${(p.videos||[]).map(x=>`<video src="${x.url}" controls muted preload="metadata"></video>`).join('')}</div>${[...(p.docs||[]).map(x=>`<a class="gdc" href="${x.url}" target="_blank" rel="noopener"><span class="ai pdf">PDF</span><span class="gm2"><b>${esc(x.name)}</b></span></a>`),...(p.urls||[]).map(u=>`<a class="gdc" href="${esc(u)}" target="_blank" rel="noopener noreferrer"><span class="ai">${icon('a-link')}</span><span class="gm2"><b>${esc(u)}</b></span></a>`)].join('')}</div>`:''}
    <div class="panel"><h3>Interested leads <span style="color:var(--muted);font-weight:400">${int.length}</span></h3>${int.length?`<div style="display:flex;flex-direction:column;gap:8px">${int.slice(0,8).map(l=>`<div class="who">${av(l.ini,l.c)}<div style="min-width:0;flex:1"><button class="lead-link" data-lead="${esc(l.n)}">${esc(l.n)}</button><small>${esc(l.bud)} · ${esc(l.ag)}</small></div><span class="st ${L.stClass(l.st)}">${l.st}</span></div>`).join('')}</div>`:'<p style="color:var(--muted);margin:0">No leads linked yet.</p>'}</div>
    <div style="display:flex;gap:8px"><button class="btn-primary rip" style="flex:1;justify-content:center" id="pdUnits">${icon('i-list')}View ${left} available units</button><button class="ghost" id="pdShare">${icon('i-msg')}Share brochure</button></div></div></aside>`;
  L.layer.querySelector('.x').focus();
  $('#pdUnits').onclick=()=>{L.closeLayer();L.openListing(p.n)};$('#pdShare').onclick=()=>toast(p.n+' brochure ready to send on WhatsApp (demo)')}
pages.projects=function(el){
  const S={q:'',st:'All',area:'',fav:new Set(JSON.parse(L.store.get('lv-fav')||'[]'))};
  el.innerHTML=`<div class="pg">${head('Projects','Every development you sell, with live availability.',`<button class="btn-primary rip" id="pjAdd">${icon('i-plus')}Add project</button>`,L.props.length)}
    <div class="kpis" id="pjK"></div>
    <div class="filters"><label class="field">${icon('i-search')}<input id="pjQ" placeholder="Search project or area" autocomplete="off"></label>
      <div class="seg2" id="pjS"><span class="th"></span>${['All','Ready','Off Plan','Saved'].map(s=>`<button data-s="${s}" aria-pressed="${s==='All'}">${s==='Saved'?heart.replace('class="i"','class="i" style="width:14px;height:14px"'):''}${s}</button>`).join('')}</div>
      <select class="sel" id="pjA" aria-label="Area"><option value="">All areas</option>${[...new Set(L.props.map(p=>p.area))].map(a=>`<option>${a}</option>`).join('')}</select></div>
    <div class="pgrid" id="pjG"></div></div>`;
  const tot=L.props.reduce((a,p)=>a+p.units,0),sold=L.props.reduce((a,p)=>a+p.sold,0);
  $('#pjK').innerHTML=[['i-build','var(--blue-50)','var(--blue)','Projects',L.props.length],['i-list','#E5F5EE','#12805C','Units available',tot-sold],['i-check','#E3E5EA','#2B2F3A','Units sold',sold],['i-cash','#FFF3DC','#9A5B00','Sell-through',Math.round(sold/tot*100)]].map((k,i)=>`<div class="kpi" style="--i:${i}"><span class="ki" style="background:${k[1]};color:${k[2]}">${icon(k[0])}</span><div><small>${k[3]}</small><b class="num" data-v="${k[4]}" ${i===3?'data-p="1"':''}>0</b></div></div>`).join('');
  $$('#pjK b').forEach(b=>L.countTo(b,+b.dataset.v,v=>Math.round(v)+(b.dataset.p?'%':'')));
  function draw(){const q=S.q.toLowerCase(),r=L.props.filter(p=>(S.st==='All'||(S.st==='Saved'?S.fav.has(p.n):p.st===S.st))&&(!S.area||p.area===S.area)&&(!q||(p.n+p.area+p.dev).toLowerCase().includes(q)));
    $('#pjG').innerHTML=r.map((p,i)=>`<div class="pcard" role="button" tabindex="0" style="--i:${i}" data-p="${esc(p.n)}"><div class="pimg">${p.cover?`<img src="${p.cover}" alt="" loading="lazy">`:skyline(p.seed,p.c[0],p.c[1],p.water)}<div class="tags"><span class="ptag ${p.st==='Ready'?'rd':'op'}">${p.st}</span><span class="ptag">${Math.round(p.sold/p.units*100)}% sold</span></div><button class="fav ${S.fav.has(p.n)?'on':''}" data-fav="${esc(p.n)}" aria-label="Save ${esc(p.n)}">${heart}</button></div>
      <div class="pbody"><h3>${esc(p.n)}</h3><div class="loc">${icon('i-pin')}${esc(p.area)} · ${esc(p.dev)}</div>
      <div class="pr"><b>AED ${p.from.toFixed(1)}M</b><small>starting price</small></div>
      <div class="facts"><span>${icon('i-build','style="width:13px;height:13px"')}${esc(p.beds)}</span><span>${esc(p.size)}</span><span>${p.hand?'Handover '+qtr(p.hand):'Ready to move'}</span></div>
      <div class="sold"><span>${p.units-p.sold} units left</span><span>${p.sold}/${p.units}</span></div><div class="bar"><i style="width:${p.sold/p.units*100}%"></i></div>
      <div class="pa"><button class="ghost" data-units="${esc(p.n)}">View units</button><button class="btn-primary" style="justify-content:center" data-share="${esc(p.n)}">Share</button></div></div></div>`).join('')||`<div class="panel empty-st" style="grid-column:1/-1"><b>No projects found</b>${S.st==='Saved'?'Tap the heart on a project to save it here.':'Try another search or area.'}</div>`}
  draw();
  $('#pjQ').addEventListener('input',e=>{S.q=e.target.value;draw()});
  $('#pjA').addEventListener('change',e=>{S.area=e.target.value;draw()});
  $('#pjS').addEventListener('click',e=>{const b=e.target.closest('[data-s]');if(!b)return;S.st=b.dataset.s;$$('#pjS button').forEach(x=>x.setAttribute('aria-pressed',x===b));segPos($('#pjS'));draw()});
  $('#pjAdd').addEventListener('click',()=>L.addProject());L.on('props',()=>{if(el.isConnected)draw()});
  el.addEventListener('click',e=>{const f=e.target.closest('[data-fav]');if(f){e.stopPropagation();const n=f.dataset.fav;S.fav.has(n)?S.fav.delete(n):S.fav.add(n);L.store.set('lv-fav',JSON.stringify([...S.fav]));f.classList.toggle('on');if(S.fav.has(n)){const r=f.getBoundingClientRect();burst(r.left+16,r.top+16,24);toast(n+' saved')}if(S.st==='Saved')draw();return}
    const u=e.target.closest('[data-units]');if(u){e.stopPropagation();L.openListing(u.dataset.units);return}
    const s=e.target.closest('[data-share]');if(s){e.stopPropagation();toast(s.dataset.share+' brochure ready to share (demo)');return}
    const c=e.target.closest('.pcard');if(c)openProject(L.props.find(p=>p.n===c.dataset.p))});
  el.addEventListener('keydown',e=>{if(e.key==='Enter'){const c=e.target.closest('.pcard');if(c)openProject(L.props.find(p=>p.n===c.dataset.p))}});
};

/* ---------- Listing ---------- */
let listingPreset=null;
L.openListing=n=>{listingPreset=n;L.navTo('Listing');if(built.listing){const el=$('#pages > .page[data-page="listing"]');if(el&&el._preset)el._preset(n)}};
pages.listing=function(el){
  const maxP=Math.ceil(Math.max(...L.units.map(u=>u.price))/1e5)*1e5;
  const S={q:'',proj:listingPreset||'',type:'All',st:'',max:maxP,sort:'price',dir:1};listingPreset=null;
  const types=['All',...new Set(L.units.map(u=>u.type))];
  el.innerHTML=`<div class="pg">${head('Listing','Unit-level inventory across all projects. Reserve a unit for a lead in two clicks.',`<button class="ghost" id="liRef">${icon('i-list')}Ref. ID Management</button><button class="btn-primary rip" id="liAdd">${icon('i-plus')}Add Listing</button>`,L.units.length)}
    <div class="filters"><label class="field">${icon('i-search')}<input id="liQ" placeholder="Search unit number" autocomplete="off"></label>
      <select class="sel" id="liP" aria-label="Project"><option value="">All projects</option>${L.props.map(p=>`<option ${p.n===S.proj?'selected':''}>${p.n}</option>`).join('')}</select>
      <select class="sel" id="liS" aria-label="Status"><option value="">Any status</option><option>Available</option><option>Reserved</option><option>Sold</option></select>
      <label class="range">Max price: <b class="num" id="liMx">${money(maxP)}</b><input type="range" id="liR" min="500000" max="${maxP}" step="100000" value="${maxP}"></label></div>
    <div class="chiprow" id="liT">${types.map(t=>`<button class="fchip" data-t="${t}" aria-pressed="${t==='All'}">${t}</button>`).join('')}</div>
    <div class="sumbar" id="liSum"></div>
    <div class="panel" style="padding:8px"><div class="tbl-wrap"><table class="tbl"><thead><tr><th>Unit</th><th>Project</th><th>Type</th><th class="sort" data-k="size">Size<span class="ar">▲</span></th><th>Floor</th><th>View</th><th class="sort on" data-k="price">Price<span class="ar">▲</span></th><th>Price / sqft</th><th>Status</th><th></th></tr></thead><tbody id="liB"></tbody></table></div></div></div>`;
  function draw(){const q=S.q.toLowerCase();const r=L.units.filter(u=>(!S.proj||u.proj===S.proj)&&(S.type==='All'||u.type===S.type)&&(!S.st||u.st===S.st)&&u.price<=S.max&&(!q||u.id.toLowerCase().includes(q))).sort((a,b)=>(a[S.sort]-b[S.sort])*S.dir);
    const av2=r.filter(u=>u.st==='Available'),pps=r.length?r.reduce((a,u)=>a+u.price/u.size,0)/r.length:0;
    $('#liSum').innerHTML=`<span><b class="num">${r.length}</b> units</span><span><b class="num">${av2.length}</b> available</span><span>Avg <b class="num">AED ${fmt(pps)}</b> / sqft</span><span>Total value <b class="num">${money(r.reduce((a,u)=>a+u.price,0))}</b></span>`;
    $('#liB').innerHTML=r.map((u,i)=>`<tr style="--r:${Math.min(i,20)}"><td><b class="num" style="font-weight:600">${u.id}</b></td><td>${esc(u.proj)}</td><td>${u.type}</td><td class="num">${fmt(u.size)} sqft</td><td class="num">${u.fl}</td><td>${u.view}</td><td class="num" style="font-weight:600">${money(u.price)}</td><td class="num">AED ${fmt(u.price/u.size)}</td><td><span class="ust us-${u.st}">${u.st}</span>${u.for?`<small style="display:block;color:var(--muted);font-size:var(--fs-xs);margin-top:3px">for ${esc(u.for)}</small>`:''}</td><td style="text-align:right"><button class="btn-sm" data-res="${u.id}" ${u.st!=='Available'?'disabled':''}>${u.st==='Available'?'Reserve':u.st}</button></td></tr>`).join('')||`<tr><td colspan="10"><div class="empty-st"><b>No units match</b>Raise the max price or clear a filter.</div></td></tr>`;
    $$('#liT .fchip').forEach(c=>c.setAttribute('aria-pressed',c.dataset.t===S.type))}
  el._preset=n=>{S.proj=n;$('#liP').value=n;draw()};
  L.on('units',()=>{if(el.isConnected)draw()});
  draw();
  $('#liQ').addEventListener('input',e=>{S.q=e.target.value;draw()});
  $('#liAdd').addEventListener('click',()=>L.addListing());$('#liRef').addEventListener('click',()=>L.navTo('Ref. ID Management'));
  $('#liP').addEventListener('change',e=>{S.proj=e.target.value;draw()});
  $('#liS').addEventListener('change',e=>{S.st=e.target.value;draw()});
  $('#liR').addEventListener('input',e=>{S.max=+e.target.value;$('#liMx').textContent=money(S.max);draw()});
  el.addEventListener('click',e=>{const t=e.target.closest('[data-t]');if(t){S.type=t.dataset.t;draw();return}
    const s=e.target.closest('th.sort');if(s){const k=s.dataset.k;S.dir=S.sort===k?-S.dir:1;S.sort=k;$$('th.sort',el).forEach(x=>{x.classList.toggle('on',x===s);x.classList.toggle('desc',x===s&&S.dir<0)});draw();return}
    const rb=e.target.closest('[data-res]');if(rb){const u=L.units.find(x=>x.id===rb.dataset.res);L.setLast(rb);
      L.layer.innerHTML=`<div class="veil" data-close></div><div class="modal" role="dialog" aria-modal="true" aria-label="Reserve unit"><header><h3>Reserve ${u.id}</h3><button class="x" data-close aria-label="Close">${icon('i-x')}</button></header><form id="rsF" style="grid-template-columns:1fr"><p style="margin:0;color:var(--body)">${esc(u.proj)} · ${u.type} · ${fmt(u.size)} sqft · <b>${money(u.price)}</b></p>
        <label class="fld">Reserve for lead<select id="rsL">${L.leads.filter(l=>l.st!=='Invoiced').map(l=>`<option ${l.proj===u.proj?'':''}>${esc(l.n)}</option>`).join('')}</select></label>
        <label class="fld">Hold for<select id="rsD"><option>48 hours</option><option>7 days</option><option>14 days</option></select></label>
        <div class="actions" style="grid-column:auto"><button type="button" class="ghost" data-close>Cancel</button><button class="btn-primary rip" type="submit">${icon('i-check')}Reserve unit</button></div></form></div>`;
      const pref=L.leads.find(l=>l.proj===u.proj&&l.st!=='Invoiced');if(pref)$('#rsL').value=pref.n;
      $('#rsF').addEventListener('submit',ev=>{ev.preventDefault();u.st='Reserved';u.for=$('#rsL').value;const l=L.findLead(u.for);if(l){l.notes.unshift({text:'Unit '+u.id+' reserved for '+$('#rsD').value,when:'Just now'});l.last='Just now'}L.closeLayer();draw();toast(u.id+' reserved for '+u.for);burst(innerWidth/2,innerHeight/2,120);L.emit('leads')})}});
};

/* ---------- Off Plan ---------- */
pages.offplan=function(el){
  const ops=L.props.filter(p=>p.st==='Off Plan');
  const MS=['Launch','Foundation','Structure','Finishing','Handover'];
  el.innerHTML=`<div class="pg">${head('Off Plan','Construction progress, handover countdowns and payment plans for every launch.','',ops.length)}
    <div id="opL"></div>
    <div class="panel"><h3>Payment plan calculator</h3><div class="calc"><div style="display:flex;flex-direction:column;gap:12px">
      <label class="fld">Project<select id="cP">${ops.map(p=>`<option>${p.n}</option>`).join('')}</select></label>
      <label class="fld">Unit price (AED)<input id="cV" inputmode="numeric" value="${fmt(ops[0].from*1e6)}"></label>
      <label class="fld">Installments during construction<select id="cN"><option>4</option><option selected>6</option><option>8</option><option>12</option></select></label>
      <div class="plan-bar" id="cBar"></div><small style="color:var(--muted)">Booking · During construction · On handover</small></div>
      <ul class="sched" id="cS"></ul></div></div></div>`;
  $('#opL').innerHTML=ops.map((p,i)=>{const done=MS.map((m,k)=>p.prog>=k*25+(k===4?0:1)?'ok':'');const nowI=Math.min(4,Math.floor(p.prog/25));
    return `<div class="op-card" style="--i:${i}"><div class="pimg">${skyline(p.seed,p.c[0],p.c[1],p.water)}<div class="tags"><span class="ptag op">Off Plan</span></div></div><div class="op-in">
      <div class="op-top"><div><h3>${esc(p.n)}</h3><div class="loc" style="font-size:var(--fs-xs);color:var(--muted)">${esc(p.area)} · ${esc(p.dev)}</div></div><div class="cd"><b class="num" data-cd="${daysTo(p.hand)}">0</b><small>days to handover · ${qtr(p.hand)}</small></div></div>
      <div><div style="display:flex;justify-content:space-between;font-size:var(--fs-xs);color:var(--body);margin-bottom:6px"><span>Construction progress</span><b class="num">${p.prog}%</b></div><div class="prog"><i style="width:${p.prog}%"></i></div></div>
      <div class="miles">${MS.map((m,k)=>`<span class="${k<nowI?'ok':k===nowI?'now':''}">${m}</span>`).join('')}</div>
      <div><div style="font-size:var(--fs-xs);color:var(--body);margin-bottom:6px">Payment plan ${p.plan.join(' / ')}</div><div class="plan-bar"><span style="flex:${p.plan[0]};background:var(--charcoal)">${p.plan[0]}%</span><span style="flex:${p.plan[1]};background:var(--blue)">${p.plan[1]}%</span><span style="flex:${p.plan[2]};background:var(--blue-400)">${p.plan[2]}%</span></div></div>
      <div style="display:flex;gap:8px;flex-wrap:wrap"><button class="ghost" data-units="${esc(p.n)}">${icon('i-list')}Available units</button><button class="ghost" data-calc="${esc(p.n)}">${icon('i-cash')}Calculate plan</button></div></div></div>`}).join('');
  $$('[data-cd]',).forEach(b=>{if(el.contains(b))L.countTo(b,+b.dataset.cd,fmt,1300)});
  function calc(){const p=ops.find(x=>x.n===$('#cP').value),v=parseFloat($('#cV').value.replace(/[^\d.]/g,''))||0,n=+$('#cN').value;
    $('#cBar').innerHTML=`<span style="flex:${p.plan[0]};background:var(--charcoal)">${p.plan[0]}%</span><span style="flex:${p.plan[1]};background:var(--blue)">${p.plan[1]}%</span><span style="flex:${p.plan[2]};background:var(--blue-400)">${p.plan[2]}%</span>`;
    const start=new Date(),end=new Date(p.hand),gap=(end-start)/(n+1);const rows=[['Booking payment','Today',v*p.plan[0]/100]];
    for(let k=1;k<=n;k++){const d=new Date(start.getTime()+gap*k);rows.push(['Installment '+k,d.toLocaleDateString('en-GB',{month:'short',year:'numeric'}),v*p.plan[1]/100/n])}
    rows.push(['On handover',qtr(p.hand),v*p.plan[2]/100]);
    $('#cS').innerHTML=rows.map((r,i)=>`<li style="animation-delay:${i*35}ms"><span class="n">${i+1}</span><div><b style="font-weight:500">${r[0]}</b><small>${r[1]}</small></div><b class="num">${money(Math.round(r[2]))}</b></li>`).join('')+`<li class="tot"><span class="n" style="background:rgba(255,255,255,.15);color:#fff">${icon('i-check','style="width:14px;height:14px"')}</span><div><b style="font-weight:500">Total</b><small>${rows.length} payments until ${qtr(p.hand)}</small></div><b class="num">${money(Math.round(v))}</b></li>`}
  calc();
  $('#cP').addEventListener('change',()=>{const p=ops.find(x=>x.n===$('#cP').value);$('#cV').value=fmt(p.from*1e6);calc()});
  $('#cV').addEventListener('input',calc);$('#cN').addEventListener('change',calc);
  $('#cV').addEventListener('blur',()=>{const v=parseFloat($('#cV').value.replace(/[^\d.]/g,''))||0;$('#cV').value=fmt(v)});
  el.addEventListener('click',e=>{const u=e.target.closest('[data-units]');if(u){L.openListing(u.dataset.units);return}
    const c=e.target.closest('[data-calc]');if(c){$('#cP').value=c.dataset.calc;$('#cP').dispatchEvent(new Event('change'));$('#cS').closest('.panel').scrollIntoView({behavior:'smooth',block:'start'})}});
};
/* ---------- Team ---------- */
const memberStats=t=>{const mine=L.leads.filter(l=>l.ag===t.n),h=t.n.length*7;const leads=mine.length||(8+h%17),bk=mine.length?mine.filter(l=>l.st==='Booked'||l.st==='Invoiced').length:(h%5);return {leads,bk,conv:leads?bk/leads*100:0,tgt:Math.min(100,35+(h*3)%60)}};
L.openLeadsFor=n=>{L.leadsPreset=n;L.navTo('Leads')};
pages.team=function(el){
  const S={f:'All',q:''};
  el.innerHTML=`<div class="pg">${head('Team','Your people, their pipeline and how close they are to target.',`<button class="btn-primary rip" id="tmInv">${icon('i-plus')}Invite member</button>`,L.team.length)}
    <div class="filters"><label class="field">${icon('i-search')}<input id="tmQ" placeholder="Search team" autocomplete="off"></label><div class="seg2" id="tmF"><span class="th"></span>${['All','Leaders','Agents','Online'].map(f=>`<button data-f="${f}" aria-pressed="${f==='All'}">${f}</button>`).join('')}</div></div>
    <div class="tgrid" id="tmG"></div></div>`;
  function card(t,i,isNew){const s=memberStats(t),lead=/Manager|Lead/.test(t.role),on=t.n.length%4!==0;
    return `<div class="mcard ${isNew?'new':''}" style="--i:${i}">${lead?'<span class="rtag">Leader</span>':''}${av(t.i,t.c,on?'on':'')}<h3>${esc(t.n)}</h3><div class="role">${esc(t.role)}${t.email?' · '+esc(t.email):''}</div>
      <div class="mstats"><div><b class="num">${s.leads}</b><small>Leads</small></div><div><b class="num">${s.bk}</b><small>Booked</small></div><div><b class="num">${s.conv.toFixed(0)}%</b><small>Conv.</small></div></div>
      <div class="tgt"><div style="display:flex;justify-content:space-between"><span>Monthly target</span><b class="num">${s.tgt}%</b></div><div class="bar"><i style="width:${s.tgt}%;${s.tgt>=80?'background:var(--pos)':''}"></i></div></div>
      <div class="ma"><button class="ghost" data-msg="${esc(t.n)}">${icon('i-msg')}Message</button><button class="btn-primary" data-ld="${esc(t.n)}">${icon('i-users')}Leads</button></div></div>`}
  function draw(newName){const q=S.q.toLowerCase();const r=L.team.filter(t=>(S.f==='All'||(S.f==='Leaders'?/Manager|Lead/.test(t.role):S.f==='Agents'?!/Manager|Lead/.test(t.role):t.n.length%4!==0))&&(!q||(t.n+t.role).toLowerCase().includes(q)));
    $('#tmG').innerHTML=r.map((t,i)=>card(t,i,t.n===newName)).join('')||`<div class="panel empty-st" style="grid-column:1/-1"><b>No one found</b>Try another name.</div>`;el.querySelector('.pg-head .cnt').textContent=L.team.length}
  draw();
  $('#tmQ').addEventListener('input',e=>{S.q=e.target.value;draw()});
  $('#tmF').addEventListener('click',e=>{const b=e.target.closest('[data-f]');if(!b)return;S.f=b.dataset.f;$$('#tmF button').forEach(x=>x.setAttribute('aria-pressed',x===b));segPos($('#tmF'));draw()});
  el.addEventListener('click',e=>{const m=e.target.closest('[data-msg]');if(m){toast('Chat opened with '+m.dataset.msg+' (demo)');return}const l=e.target.closest('[data-ld]');if(l)L.openLeadsFor(l.dataset.ld)});
  $('#tmInv').addEventListener('click',()=>{L.setLast($('#tmInv'));
    L.layer.innerHTML=`<div class="veil" data-close></div><div class="modal" role="dialog" aria-modal="true" aria-label="Invite member"><header><h3>Invite a team member</h3><button class="x" data-close aria-label="Close">${icon('i-x')}</button></header><form id="ivF" novalidate>
      <label class="fld full">Full name<input id="ivN" placeholder="e.g. Hassan Ali"><span class="err" id="ivNe"></span></label>
      <label class="fld full">Work email<input id="ivE" type="email" placeholder="hassan@leadvolt.ae"><span class="err" id="ivEe"></span></label>
      <label class="fld">Role<select id="ivR"><option>Agent</option><option>Senior Agent</option><option>Team Lead</option><option>Sales Manager</option></select></label>
      <label class="fld">Access<select id="ivA"><option>Own leads only</option><option>Team leads</option><option>All leads</option></select></label>
      <div class="actions"><button type="button" class="ghost" data-close>Cancel</button><button class="btn-primary rip" type="submit">${icon('i-msg')}Send invite</button></div></form></div>`;
    $('#ivN').focus();
    $('#ivF').addEventListener('submit',ev=>{ev.preventDefault();const n=$('#ivN').value.trim(),em=$('#ivE').value.trim(),ok=/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(em);$('#ivNe').textContent=n?'':'Enter a name.';$('#ivEe').textContent=ok?'':'Enter a valid email address.';if(!n||!ok)return;
      L.team.push({n,i:n.split(/\s+/).map(w=>w[0]).join('').slice(0,2).toUpperCase(),role:$('#ivR').value,c:pal[L.team.length%5],email:em});L.closeLayer();draw(n);toast('Invite sent to '+em);burst(innerWidth/2,200,90)})});
};

/* ---------- Org Profile ---------- */
const BRANDS=[['LeadVolt blue','#0B6BE6','#0957C3','#EEF4FE','#DCE8FC','#B9D4FB'],['Violet','#6D4AE8','#5634C9','#F2EEFD','#E3DBFB','#C9BAF7'],['Teal','#0E9F94','#0B8178','#E7F7F5','#CDEFEB','#9ADFD8'],['Ruby','#D9264E','#B51C3F','#FDECF0','#FAD5DE','#F4AABB'],['Amber','#E07A10','#BD640A','#FEF3E6','#FCE2C4','#F8C68E'],['Graphite','#2B2F3A','#1C1F27','#EEF0F3','#DDE0E6','#BCC1CB']];
function applyBrand(i){const b=BRANDS[i]||BRANDS[0],r=document.documentElement.style;r.setProperty('--blue',b[1]);r.setProperty('--blue-600',b[2]);r.setProperty('--blue-50',b[3]);r.setProperty('--blue-100',b[4]);r.setProperty('--blue-200',b[5]);r.setProperty('--grad-brand',`linear-gradient(135deg,${b[1]} 0%,${b[2]} 55%,#2B2F3A 100%)`)}
const savedBrand=+(L.store.get('lv-brand')||0);if(savedBrand)applyBrand(savedBrand);
const logoSvg=`<svg viewBox="0 0 99 90" aria-hidden="true"><polygon points="0,0 29.5,0 44.7,28 36,48.3 50.5,48.3 41.7,76" fill="#0B6BE6"/><polygon points="68.5,0 98.5,0 49,89.5 43,78.3 64.5,41 48.5,40.5" fill="#2B2F3A"/></svg>`;
pages.org=function(el){
  const F=[['Company name','LeadVolt Real Estate LLC','text',1],['ORN / RERA number','ORN 48213','text'],['Trade licence','TL-2026-118204','text'],['Phone','+971 4 555 0142','tel'],['Email','hello@leadvolt.ae','email'],['Website','leadvolt.ae','text'],['Address','Office 1804, Bay Square Tower 3, Business Bay, Dubai','area',1]];
  const hours=['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],on=new Set(['Mon','Tue','Wed','Thu','Fri','Sat']);
  el.innerHTML=`<div class="pg">${head('Org Profile','How your company appears to your team and on documents.')}
    <div class="org-hero"><div class="lg" id="oLg">${logoSvg}</div><div style="flex:1;min-width:0"><h2 id="oNm">LeadVolt Real Estate LLC</h2><small>Business Bay, Dubai · 10 team members · Customer since 2026</small><div class="verified">${icon('i-check','style="width:13px;height:13px"')}RERA verified broker</div></div></div>
    <div class="split2"><div style="display:flex;flex-direction:column;gap:14px">
      <div class="panel"><h3>Company details</h3><form class="form2" id="oF">${F.map(([l,v,t,full],i)=>`<label class="fld ${full?'full':''}">${l}${t==='area'?`<textarea id="of${i}">${esc(v)}</textarea>`:`<input id="of${i}" type="${t}" value="${esc(v)}">`}</label>`).join('')}
        <div class="full" style="display:flex;justify-content:flex-end;gap:8px"><button type="button" class="ghost" id="oRs">Reset</button><button type="submit" class="btn-primary rip" id="oSv" disabled style="opacity:.5">${icon('i-check')}Save changes</button></div></form></div>
      <div class="panel"><h3>Working days</h3><div class="chiprow" id="oH">${hours.map(d=>`<button class="fchip" data-h="${d}" aria-pressed="${on.has(d)}">${d}</button>`).join('')}</div><small style="color:var(--muted)">Leads that arrive outside working days get an automatic WhatsApp reply.</small></div></div>
      <div style="display:flex;flex-direction:column;gap:14px">
      <div class="panel"><h3>Brand colour</h3><div class="swatches" id="oSw">${BRANDS.map((b,i)=>`<button style="background:${b[1]}" data-b="${i}" aria-pressed="${i===savedBrand}" aria-label="${b[0]}" title="${b[0]}"></button>`).join('')}</div><small style="display:block;margin-top:10px;color:var(--muted)">Changes the whole app instantly. Try it.</small></div>
      <div class="panel"><h3>Logo</h3><label class="drop" id="oDrop"><input type="file" accept="image/*" id="oFile"><span class="di">${icon('i-cloud')}</span><b>Drop your logo here</b><small>PNG or SVG, square works best</small></label></div>
      <div class="panel"><h3>Subscription</h3><div style="display:flex;align-items:center;gap:10px;margin-bottom:12px"><span class="ptag op" style="font-size:11px">Growth</span><small style="color:var(--muted)">Renews 18 Nov 2026</small></div>
        ${[['Leads',1248,2000],['Team seats',L.team.length,15],['Storage (GB)',3.2,10]].map(([n,v,m])=>`<div style="margin-bottom:10px"><div style="display:flex;justify-content:space-between;font-size:var(--fs-sm)"><span>${n}</span><span class="num">${typeof v==='number'&&v%1?v:fmt(v)} / ${fmt(m)}</span></div><div class="bar" style="margin-top:5px"><i style="width:${v/m*100}%"></i></div></div>`).join('')}
        <button class="btn-red" style="width:100%;height:38px;font-size:var(--fs-sm);margin-top:6px" id="oUp">Upgrade to Scale</button></div></div></div></div>`;
  const orig=F.map(f=>f[1]);const sv=$('#oSv');
  const dirty=()=>{const ch=F.some((f,i)=>$('#of'+i).value!==orig[i]);sv.disabled=!ch;sv.style.opacity=ch?1:.5;$('#oNm').textContent=$('#of0').value||'Your company'};
  $('#oF').addEventListener('input',dirty);
  $('#oF').addEventListener('submit',e=>{e.preventDefault();F.forEach((f,i)=>orig[i]=$('#of'+i).value);dirty();toast('Company profile saved')});
  $('#oRs').addEventListener('click',()=>{F.forEach((f,i)=>$('#of'+i).value=orig[i]);dirty()});
  $('#oH').addEventListener('click',e=>{const b=e.target.closest('[data-h]');if(!b)return;const d=b.dataset.h;on.has(d)?on.delete(d):on.add(d);b.setAttribute('aria-pressed',on.has(d));toast('Working days: '+(hours.filter(h=>on.has(h)).join(', ')||'none'))});
  $('#oSw').addEventListener('click',e=>{const b=e.target.closest('[data-b]');if(!b)return;const i=+b.dataset.b;applyBrand(i);L.store.set('lv-brand',String(i));$$('#oSw button').forEach(x=>x.setAttribute('aria-pressed',x===b));toast(BRANDS[i][0]+' applied across LeadVolt');const r=b.getBoundingClientRect();burst(r.left+19,r.top+19,40)});
  const drop=$('#oDrop'),load=f=>{if(!f||!f.type.startsWith('image/')){toast('Choose an image file (PNG, JPG or SVG)');return}const rd=new FileReader();rd.onload=()=>{$('#oLg').innerHTML=`<img src="${rd.result}" alt="Company logo">`;toast('Logo updated')};rd.readAsDataURL(f)};
  $('#oFile').addEventListener('change',e=>load(e.target.files[0]));
  ['dragenter','dragover'].forEach(t=>drop.addEventListener(t,e=>{e.preventDefault();drop.classList.add('over')}));
  ['dragleave','drop'].forEach(t=>drop.addEventListener(t,e=>{e.preventDefault();drop.classList.remove('over')}));
  drop.addEventListener('drop',e=>load(e.dataTransfer.files[0]));
  $('#oUp').addEventListener('click',()=>toast('Scale plan: unlimited leads and 50 seats. Our team will contact you.'));
};

/* ---------- Global Config ---------- */
/* ---------- Data (CSV import) ---------- */
function parseCSV(t){const rows=[];let row=[],cur='',q=false;for(let i=0;i<t.length;i++){const c=t[i];if(q){if(c==='"'){if(t[i+1]==='"'){cur+='"';i++}else q=false}else cur+=c}else if(c==='"')q=true;else if(c===','){row.push(cur);cur=''}else if(c==='\n'||c==='\r'){if(c==='\r'&&t[i+1]==='\n')i++;row.push(cur);cur='';if(row.some(x=>x.trim()))rows.push(row);row=[]}else cur+=c}row.push(cur);if(row.some(x=>x.trim()))rows.push(row);return rows}
const SAMPLE_CSV='Full Name,Mobile,Email,Lead Source,Budget,Interested In\nMaya Collins,+971 50 123 4567,maya.c@mail.com,Bayut,AED 1.8M,Marina Vista\nHassan Ali,+971 55 987 6543,hassan@mail.com,Facebook,AED 2.4M,Creek Heights\nSofia Marin,+971 52 222 1180,sofia.m@mail.com,Website,AED 3.1M,Palm Residences\nRyan Patel,+971 56 410 7721,ryan.p@mail.com,Property Finder,AED 1.2M,Downtown Loft\nNoura Saif,,noura@mail.com,Walk-in,AED 5.0M,Hills Villas\nDavid Kim,+971 54 300 8899,david.k@mail.com,Bayut,AED 0.9M,Bay Square Offices';
pages.data=function(el){
  const FIELDS=['Skip','Name','Phone','Email','Source','Budget','Project'];
  const guess=h=>{h=h.toLowerCase();return /name/.test(h)?'Name':/phone|mobile|tel/.test(h)?'Phone':/mail/.test(h)?'Email':/source|channel/.test(h)?'Source':/budget|price/.test(h)?'Budget':/project|interest|property/.test(h)?'Project':'Skip'};
  const hist=[['bayut-october.csv','18 Oct 2026','Ashfaq Haji Haroon',124,3],['facebook-campaign-q3.csv','02 Oct 2026','Obaid Raza',318,11],['expo-walkins.xlsx','21 Sep 2026','Raish Ahmed',56,0]];
  let S={step:1,rows:[],head:[],map:[],file:''};
  el.innerHTML=`<div class="pg">${head('Data','Bring leads in from spreadsheets, portals and events.',`<button class="ghost" id="dTpl">${icon('i-list')}Copy CSV template</button>`)}
    <div class="panel" style="margin-bottom:14px"><div class="steps" id="dSt"></div><div id="dB"></div></div>
    <div class="panel"><h3>Import history</h3><div class="tbl-wrap"><table class="tbl" style="min-width:620px"><thead><tr><th>File</th><th>Date</th><th>Imported by</th><th>Leads added</th><th>Skipped</th><th>Status</th></tr></thead><tbody id="dH"></tbody></table></div></div></div>`;
  function hDraw(){$('#dH').innerHTML=hist.map((h,i)=>`<tr style="--r:${i}"><td><div class="who"><span class="ki" style="width:32px;height:32px;border-radius:9px;background:var(--blue-50);color:var(--blue);display:grid;place-items:center">${icon('i-list','style="width:15px;height:15px"')}</span><b style="font-weight:500">${esc(h[0])}</b></div></td><td>${h[1]}</td><td>${esc(h[2])}</td><td class="num">${h[3]}</td><td class="num">${h[4]}</td><td><span class="pill-st ps-Present">Completed</span></td></tr>`).join('')}
  function steps(){$('#dSt').innerHTML=['Upload file','Match columns','Import'].map((t,i)=>`${i?'<i></i>':''}<span class="${S.step===i+1?'on':S.step>i+1?'ok':''}"><b>${S.step>i+1?'✓':i+1}</b>${t}</span>`).join('')}
  function draw(){steps();const B=$('#dB');
    if(S.step===1){B.innerHTML=`<label class="drop" id="dDrop"><input type="file" accept=".csv,text/csv" id="dF"><span class="di">${icon('i-cloud')}</span><b>Drop a CSV file here, or click to browse</b><small>Up to 5,000 rows. Columns are matched automatically.</small></label><div style="text-align:center;margin-top:12px"><button class="link" id="dSm">No file handy? Try a sample file</button></div>`;
      const d=$('#dDrop');['dragenter','dragover'].forEach(t=>d.addEventListener(t,e=>{e.preventDefault();d.classList.add('over')}));['dragleave','drop'].forEach(t=>d.addEventListener(t,e=>{e.preventDefault();d.classList.remove('over')}));
      d.addEventListener('drop',e=>readFile(e.dataTransfer.files[0]));$('#dF').addEventListener('change',e=>readFile(e.target.files[0]));$('#dSm').onclick=()=>load(SAMPLE_CSV,'sample-leads.csv')}
    if(S.step===2){const prev=S.rows.slice(0,5);B.innerHTML=`<p style="margin:0 0 12px;color:var(--body)"><b>${esc(S.file)}</b> · ${S.rows.length} rows found. Check how each column maps to LeadVolt.</p>
      <div class="mapgrid">${S.head.map((h,i)=>`<label class="fld">${esc(h||'Column '+(i+1))}<select class="sel" data-m="${i}">${FIELDS.map(f=>`<option ${f===S.map[i]?'selected':''}>${f}</option>`).join('')}</select></label>`).join('')}</div>
      <div class="tbl-wrap" style="margin-top:14px"><table class="tbl" style="min-width:600px"><thead><tr>${S.head.map((h,i)=>`<th style="${S.map[i]==='Skip'?'opacity:.4':''}">${esc(S.map[i])}</th>`).join('')}</tr></thead><tbody>${prev.map((r,ri)=>`<tr style="--r:${ri}">${S.head.map((h,i)=>`<td style="${S.map[i]==='Skip'?'opacity:.4':''}">${esc(r[i]||'')}</td>`).join('')}</tr>`).join('')}</tbody></table></div>
      <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;margin-top:14px"><label class="fld">Assign imported leads to<select class="sel" id="dAg"><option>Auto-assign (round robin)</option>${L.agentN.map(a=>`<option>${a}</option>`).join('')}</select></label><div class="spacer"></div><button class="ghost" id="dBk">Back</button><button class="btn-primary rip" id="dGo">${icon('i-check')}Import ${S.rows.length} leads</button></div>`;
      B.querySelectorAll('[data-m]').forEach(s=>s.addEventListener('change',e=>{S.map[+e.target.dataset.m]=e.target.value;draw()}));$('#dBk').onclick=()=>{S.step=1;draw()};$('#dGo').onclick=run}
    if(S.step===3){B.innerHTML=`<div style="text-align:center;padding:20px 10px"><div class="orb" style="width:72px;height:72px;border-radius:22px;background:var(--pos);display:grid;place-items:center;color:#fff;margin:0 auto 14px;animation:newIn .6s var(--ease)">${icon('i-check','style="width:32px;height:32px"')}</div><h2 style="margin:0;font-weight:500">${S.added} leads imported</h2><p style="color:var(--muted)">${S.skipped?S.skipped+' rows were skipped because they had no name or phone.':'Every row was imported.'}</p><div style="display:flex;gap:8px;justify-content:center"><button class="ghost" id="dAg2">Import another file</button><button class="btn-primary rip" id="dVw">${icon('i-users')}View leads</button></div></div>`;
      $('#dAg2').onclick=()=>{S={step:1,rows:[],head:[],map:[],file:''};draw()};$('#dVw').onclick=()=>L.navTo('Leads')}}
  function readFile(f){if(!f)return;if(!/\.csv$/i.test(f.name)&&f.type!=='text/csv'){toast('Choose a .csv file. Excel files can be saved as CSV first.');return}const rd=new FileReader();rd.onload=()=>load(String(rd.result),f.name);rd.readAsText(f)}
  function load(text,name){const all=parseCSV(text);if(all.length<2){toast('That file has no data rows');return}S.head=all[0];S.rows=all.slice(1);S.map=S.head.map(guess);S.file=name;S.step=2;draw()}
  function run(){const go=$('#dGo');go.disabled=true;$('#dB').insertAdjacentHTML('beforeend','<div class="prog2" style="margin-top:14px"><i id="dPr"></i></div>');
    const idx=f=>S.map.indexOf(f),ag=$('#dAg').value;let added=0,skipped=0,k=0;
    const tick=()=>{const end=Math.min(S.rows.length,k+Math.max(1,Math.ceil(S.rows.length/12)));for(;k<end;k++){const r=S.rows[k],n=(r[idx('Name')]||'').trim(),ph=(r[idx('Phone')]||'').trim();if(!n||!ph){skipped++;continue}
        L.leads.unshift({n,ini:n.split(/\s+/).map(w=>w[0]).join('').slice(0,2).toUpperCase(),st:'New',src:(r[idx('Source')]||'Import').trim(),ag:ag.startsWith('Auto')?L.agentN[added%L.agentN.length]:ag,proj:(r[idx('Project')]||L.projects[0]).trim(),bud:(r[idx('Budget')]||'Not set').trim(),ph,email:(r[idx('Email')]||'').trim()||undefined,note:'Imported from '+S.file,last:'Today',c:pal[added%5]});added++}
      $('#dPr').style.width=(k/S.rows.length*100)+'%';if(k<S.rows.length)setTimeout(tick,90);else setTimeout(()=>{S.added=added;S.skipped=skipped;S.step=3;L.tracker.unshift({type:'Bulk Upload',what:S.file+' · '+added+' added, '+skipped+' skipped',at:new Date(),by:'Obaid Raza',status:'Completed'});L.audit('Imported '+added+' leads from '+S.file,'','Data');hist.unshift([S.file,new Date().toLocaleDateString('en-GB',{day:'2-digit',month:'short',year:'numeric'}),'Obaid Raza',added,skipped]);hDraw();draw();L.emit('leads');burst(innerWidth/2,260,140);toast(added+' leads added to your pipeline')},250)};tick()}
  hDraw();draw();
  $('#dTpl').addEventListener('click',()=>{const t=SAMPLE_CSV.split('\n')[0];const ok=()=>toast('Template header copied: '+t);try{navigator.clipboard.writeText(t).then(ok,()=>toast('Template columns: '+t))}catch(e){toast('Template columns: '+t)}});
};

/* ---------- Invoice ---------- */
L.invoices=[['Ethan Park','Hills Villas','HV-V03',5200000,'Paid',-38,-24],['Arjun Mehta','Creek Heights','CH-1406',1900000,'Paid',-30,-12],['Layla Hassan','Marina Vista','MV-2201',2300000,'Pending',-9,6],['Huda Rossi','Hills Villas','HV-V07',4900000,'Overdue',-41,-11],['Samir Nasser','Downtown Loft','DL-0903',1450000,'Pending',-4,11],['Chloe Martin','Palm Residences','PR-1102',3600000,'Draft',0,14],['Olivia Brooks','Bay Square Offices','BS-0705',980000,'Paid',-55,-40]].map((r,i)=>({no:'INV-2026-'+String(41+i).padStart(4,'0'),cl:r[0],proj:r[1],unit:r[2],price:r[3],pct:2,st:r[4],iss:r[5],due:r[6]}));
const dstr=o=>{const d=new Date();d.setDate(d.getDate()+o);return d.toLocaleDateString('en-GB',{day:'2-digit',month:'short',year:'numeric'})};
const invTot=v=>{const sub=v.price*v.pct/100;return {sub,vat:sub*.05,tot:sub*1.05}};
pages.invoice=function(el){
  const S={f:'All'};
  el.innerHTML=`<div class="pg">${head('Invoice','Commission invoices for every closed deal.',`<div class="seg2" id="iF"><span class="th"></span>${['All','Paid','Pending','Overdue','Draft'].map(f=>`<button data-f="${f}" aria-pressed="${f==='All'}">${f}</button>`).join('')}</div><button class="btn-primary rip" id="iNew">${icon('i-plus')}New invoice</button>`)}
    <div class="kpis" id="iK"></div><div class="panel" style="padding:8px"><div class="tbl-wrap"><table class="tbl" style="min-width:820px"><thead><tr><th>Invoice</th><th>Client</th><th>Unit</th><th>Issued</th><th>Due</th><th>Amount</th><th>Status</th><th></th></tr></thead><tbody id="iB"></tbody></table></div></div></div>`;
  function draw(){const I=L.invoices,sum=f=>I.filter(f).reduce((a,v)=>a+invTot(v).tot,0);
    $('#iK').innerHTML=[['i-check','#E5F5EE','#12805C','Paid',sum(v=>v.st==='Paid')],['i-cal','#FFF3DC','#9A5B00','Awaiting payment',sum(v=>v.st==='Pending')],['i-alert','var(--neg-bg)','var(--neg)','Overdue',sum(v=>v.st==='Overdue')],['i-bill','var(--blue-50)','var(--blue)','Invoices this year',I.length]].map((k,i)=>`<div class="kpi" style="--i:${i}"><span class="ki" style="background:${k[1]};color:${k[2]}">${icon(k[0])}</span><div><small>${k[3]}</small><b class="num" data-v="${k[4]}" ${i<3?'data-m="1"':''}>0</b></div></div>`).join('');
    $$('#iK b').forEach(b=>L.countTo(b,+b.dataset.v,v=>b.dataset.m?money(v):Math.round(v)));
    const r=I.filter(v=>S.f==='All'||v.st===S.f);
    $('#iB').innerHTML=r.map((v,i)=>`<tr style="--r:${i};cursor:pointer" data-inv="${v.no}"><td><b class="num" style="font-weight:600">${v.no}</b></td><td><div class="who">${av(v.cl.split(' ').map(w=>w[0]).join(''),pal[i%5])}<span>${esc(v.cl)}</span></div></td><td>${esc(v.unit)} · ${esc(v.proj)}</td><td>${dstr(v.iss)}</td><td style="${v.st==='Overdue'?'color:var(--neg);font-weight:500':''}">${dstr(v.due)}</td><td class="num" style="font-weight:600">${money(invTot(v).tot)}</td><td><span class="pill-st is-${v.st}">${v.st}</span></td><td><div class="racts"><button class="rbtn" aria-label="Open invoice">${icon('i-arrow')}</button></div></td></tr>`).join('')||`<tr><td colspan="8"><div class="empty-st"><b>No ${S.f.toLowerCase()} invoices</b>Nice.</div></td></tr>`}
  function openInv(v){L.setLast(document.activeElement);const t=invTot(v);
    L.layer.innerHTML=`<div class="veil" data-close></div><div class="paper" role="dialog" aria-modal="true" aria-label="Invoice ${v.no}"><div class="ph1"><div style="display:flex;align-items:center;gap:10px"><span style="width:34px;height:31px;display:block">${logoSvg}</span><span class="wm"><b>LEAD</b>VOLT</span></div><div><h2>Invoice</h2><small class="num">${v.no}</small><small>Issued ${dstr(v.iss)} · Due ${dstr(v.due)}</small></div></div>
      ${v.st==='Paid'?'<div class="stamp">PAID</div>':''}
      <div class="pp"><div><small>From</small><b style="font-weight:500">LeadVolt Real Estate LLC</b><br>Bay Square Tower 3, Business Bay, Dubai<br>ORN 48213 · TRN 100458233600003</div><div><small>Bill to</small><b style="font-weight:500">${esc(v.cl)}</b><br>${esc(v.unit)}, ${esc(v.proj)}<br>Dubai, United Arab Emirates</div></div>
      <table class="tbl"><thead><tr><th>Description</th><th style="text-align:right">Amount</th></tr></thead><tbody><tr><td>Brokerage commission, ${v.pct}% of property price ${money(v.price)}<br><small style="color:var(--muted)">Unit ${esc(v.unit)} · ${esc(v.proj)}</small></td><td class="num" style="text-align:right">${money(t.sub)}</td></tr><tr><td>VAT 5%</td><td class="num" style="text-align:right">${money(t.vat)}</td></tr></tbody></table>
      <div class="tot"><div><span>Subtotal</span><span class="num">${money(t.sub)}</span></div><div><span>VAT</span><span class="num">${money(t.vat)}</span></div><div class="g"><span>Total due</span><span class="num">${money(t.tot)}</span></div></div>
      <div class="pf"><span class="pill-st is-${v.st}">${v.st}</span><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="ghost" data-close>Close</button>${v.st!=='Paid'?`<button class="ghost" id="ivRem">${icon('i-msg')}Send reminder</button><button class="btn-primary rip" id="ivPay">${icon('i-check')}Mark as paid</button>`:''}</div></div></div>`;
    const pay=$('#ivPay');if(pay)pay.onclick=()=>{v.st='Paid';v.due=Math.min(v.due,0);draw();openInv(v);burst(innerWidth/2,innerHeight/2-80,160);toast(v.no+' marked as paid')};
    const rem=$('#ivRem');if(rem)rem.onclick=()=>toast('Payment reminder sent to '+v.cl+' (demo)')}
  function openNew(){L.setLast($('#iNew'));const cands=L.leads.filter(l=>l.st==='Booked'||l.st==='Invoiced');
    L.layer.innerHTML=`<div class="veil" data-close></div><div class="modal" role="dialog" aria-modal="true" aria-label="New invoice"><header><h3>New invoice</h3><button class="x" data-close aria-label="Close">${icon('i-x')}</button></header><form id="nvF">
      <label class="fld full">Client<select id="nvC">${(cands.length?cands:L.leads).map(l=>`<option>${esc(l.n)}</option>`).join('')}</select></label>
      <label class="fld">Property price (AED)<input id="nvP" inputmode="numeric" value="2,000,000"></label>
      <label class="fld">Commission<select id="nvR"><option value="1">1%</option><option value="2" selected>2%</option><option value="3">3%</option></select></label>
      <div class="fld full" style="background:var(--chip);border-radius:var(--r);padding:12px;display:grid;grid-template-columns:1fr auto;gap:6px" id="nvT"></div>
      <div class="actions"><button type="button" class="ghost" data-close>Cancel</button><button class="btn-primary rip" type="submit">${icon('i-check')}Create invoice</button></div></form></div>`;
    const calc=()=>{const p=parseFloat($('#nvP').value.replace(/[^\d.]/g,''))||0,t=invTot({price:p,pct:+$('#nvR').value});$('#nvT').innerHTML=`<span>Commission</span><b class="num">${money(t.sub)}</b><span>VAT 5%</span><b class="num">${money(t.vat)}</b><span style="font-weight:600">Total</span><b class="num" style="font-size:var(--fs-md)">${money(t.tot)}</b>`};
    calc();$('#nvP').addEventListener('input',calc);$('#nvR').addEventListener('change',calc);
    $('#nvF').addEventListener('submit',e=>{e.preventDefault();const l=L.findLead($('#nvC').value),p=parseFloat($('#nvP').value.replace(/[^\d.]/g,''))||0;if(!p){$('#nvP').focus();return}
      const v={no:'INV-2026-'+String(41+L.invoices.length).padStart(4,'0'),cl:l.n,proj:l.proj,unit:'—',price:p,pct:+$('#nvR').value,st:'Pending',iss:0,due:14};L.invoices.unshift(v);S.f='All';$$('#iF button').forEach(x=>x.setAttribute('aria-pressed',x.dataset.f==='All'));segPos($('#iF'));draw();openInv(v);toast(v.no+' created for '+l.n)})}
  draw();el._refresh=draw;
  $('#iF').addEventListener('click',e=>{const b=e.target.closest('[data-f]');if(!b)return;S.f=b.dataset.f;$$('#iF button').forEach(x=>x.setAttribute('aria-pressed',x===b));segPos($('#iF'));draw()});
  $('#iNew').addEventListener('click',openNew);
  el.addEventListener('click',e=>{const r=e.target.closest('[data-inv]');if(r)openInv(L.invoices.find(v=>v.no===r.dataset.inv))});
};
/* ---------- LeadVolt AI ---------- */
pages.ai=function(el){
  const SUG=['Who should I call first today?','Show my overdue follow-ups','Which agent is performing best?','How are Bayut leads converting?','Summarize my pipeline','Find units under AED 1.5M'];
  el.innerHTML=`<div class="pg">${head('LeadVolt AI','Ask anything about your leads, team and inventory.',`<button class="ghost" id="aiClr">${icon('i-x')}New chat</button>`)}
    <div class="ai-wrap"><div class="chat"><div class="msgs" id="aiM"></div><div class="sugg" id="aiS">${SUG.map(q=>`<button>${q}</button>`).join('')}</div>
      <form class="composer" id="aiF"><label class="field">${icon('i-spark')}<input id="aiQ" placeholder="Ask LeadVolt AI, e.g. hot leads for Marina Vista" autocomplete="off"></label><button type="submit" aria-label="Send">${icon('i-arrow')}</button></form>
      <div class="demo-note">Demo assistant. Answers are worked out from the sample data on this page.</div></div>
      <div class="ai-side"><div class="panel"><h3>Today's insights</h3><div class="ins" id="aiIns"></div></div>
        <div class="panel"><h3>What it can do</h3><div class="ins"><div><span class="d" style="background:var(--blue-50);color:var(--blue)">${icon('i-users')}</span>Rank leads by score and recency</div><div><span class="d" style="background:var(--pos-bg);color:#12805C">${icon('i-pie')}</span>Compare agents and sources</div><div><span class="d" style="background:var(--warn-bg);color:#9A5B00">${icon('i-build')}</span>Search units by budget and project</div></div></div></div></div></div>`;
  const M=$('#aiM'),bot=`<span class="bot-av">${icon('i-spark')}</span>`;
  const add=(html,me)=>{const d=document.createElement('div');d.className='msg'+(me?' me':'');d.innerHTML=(me?av('OR',pal[0]):bot)+`<div class="bub">${html}</div>`;M.appendChild(d);M.scrollTop=M.scrollHeight;return d};
  const lk=l=>`<button class="lead-link" data-lead="${esc(l.n)}">${esc(l.n)}</button>`;
  function answer(q){q=q.toLowerCase();const A=L.leads;
    const lead=A.find(l=>q.includes(l.n.toLowerCase())||q.includes(l.n.split(' ')[0].toLowerCase()+' ')&&q.includes(l.n.split(' ')[1].toLowerCase()));
    if(lead)return `${lk(lead)} is <b>${lead.st}</b> with a lead score of <b>${lead.score}</b>. Budget ${esc(lead.bud)}, interested in ${esc(lead.proj)}, handled by ${esc(lead.ag)}. Last contact: ${esc(lead.last)}.<br>Suggested next step: ${lead.score>=80?'call today, they are hot.':lead.st==='Overdue'?'the follow-up is late, call now.':'send a project update on WhatsApp.'}`;
    if(/call|first|priority|hot/.test(q)){const r=A.filter(l=>!['Booked','Invoiced'].includes(l.st)).sort((a,b)=>b.score-a.score).slice(0,5);return `Call these first. They have the highest scores and are still open:<ul>${r.map(l=>`<li>${lk(l)} · score ${l.score} · ${esc(l.proj)} · ${esc(l.bud)}</li>`).join('')}</ul>`}
    if(/overdue|late|follow/.test(q)){const r=A.filter(l=>l.st==='Overdue');const t=L.tasks.filter(t=>t.off<0&&!t.done);return `You have <b>${r.length} overdue leads</b> and <b>${t.length} late tasks</b>.<ul>${r.slice(0,6).map(l=>`<li>${lk(l)} · ${esc(l.ag)} · last contact ${esc(l.last)}</li>`).join('')}</ul>Open Tasks to clear them quickly.`}
    if(/agent|best|perform|team/.test(q)){const r=L.agents.slice().sort((a,b)=>b.conv-a.conv);return `<b>${esc(r[0].n)}</b> leads the team with a ${r[0].conv.toFixed(2)}% conversion rate and ${r[0].booked} bookings.<ul>${r.map(a=>`<li>${esc(a.n)}: ${a.booked} booked, ${a.conv.toFixed(2)}% conversion, ${a.deal} deal value</li>`).join('')}</ul>`}
    const src=L.srcN.find(s=>q.includes(s.toLowerCase()));if(src||/source|bayut|portal/.test(q)){const s=src||'Bayut',r=A.filter(l=>l.src===s),b=r.filter(l=>l.st==='Booked'||l.st==='Invoiced').length;return `<b>${s}</b> has brought <b>${r.length}</b> leads in this view, and ${b} of them booked or invoiced (${r.length?(b/r.length*100).toFixed(1):0}%). Average score: ${r.length?Math.round(r.reduce((a,l)=>a+l.score,0)/r.length):0}.`}
    if(/unit|under|cheap|budget|aed|million|m\b/.test(q)){const m=q.match(/(\d+(?:\.\d+)?)\s*m/);const cap=m?parseFloat(m[1])*1e6:1.5e6;const r=L.units.filter(u=>u.st==='Available'&&u.price<=cap).sort((a,b)=>a.price-b.price).slice(0,6);return r.length?`Found <b>${r.length}</b> available units under ${money(cap)}:<ul>${r.map(u=>`<li>${u.id} · ${esc(u.proj)} · ${u.type} · ${fmt(u.size)} sqft · <b>${money(u.price)}</b></li>`).join('')}</ul>`:`No available units under ${money(cap)} right now.`}
    if(/summar|pipeline|overview|how are/.test(q)){const c=STS.map(s=>[s,A.filter(l=>l.st===s).length]).filter(x=>x[1]);return `Your pipeline has <b>${A.length} leads</b>:<ul>${c.map(([s,n])=>`<li>${s}: ${n}</li>`).join('')}</ul>${A.filter(l=>l.score>=80).length} are hot (score 80+). Focus on the ${A.filter(l=>l.st==='Overdue').length} overdue ones first.`}
    const pj=L.props.find(p=>q.includes(p.n.toLowerCase().split(' ')[0]));if(pj){const r=A.filter(l=>l.proj===pj.n);return `<b>${esc(pj.n)}</b> in ${esc(pj.area)}: ${pj.units-pj.sold} units left from AED ${pj.from}M. ${r.length} leads are interested${r.length?', top one is '+lk(r.sort((a,b)=>b.score-a.score)[0]):''}.`}
    return `I can help with leads, agents, sources and inventory. Try asking “who should I call first?”, “show overdue follow-ups” or a lead's name, like “Khalid Mansoor”.`}
  function ask(q){if(!q.trim())return;add(esc(q),true);$('#aiQ').value='';const t=add('<div class="typing"><i></i><i></i><i></i></div>');
    setTimeout(()=>{const html=answer(q);const b=t.querySelector('.bub');b.innerHTML='';const tmp=document.createElement('div');tmp.innerHTML=html;b.appendChild(tmp);tmp.style.opacity=0;tmp.animate([{opacity:0,transform:'translateY(4px)'},{opacity:1,transform:'none'}],{duration:350,easing:'ease-out',fill:'forwards'});M.scrollTop=M.scrollHeight},700+Math.random()*500)}
  const greet=()=>{M.innerHTML='';add(`Hi Obaid. I've looked at your pipeline. You have <b>${L.leads.filter(l=>l.score>=80&&!['Booked','Invoiced'].includes(l.st)).length} hot leads</b> waiting and <b>${L.leads.filter(l=>l.st==='Overdue').length}</b> overdue follow-ups. What would you like to know?`)};
  greet();
  $('#aiIns').innerHTML=[['i-spark','#FFF3DC','#9A5B00','Hot leads respond best before noon. Call your top 5 this morning.'],['i-alert','var(--neg-bg)','var(--neg)',L.leads.filter(l=>l.st==='Overdue').length+' follow-ups are overdue across the team.'],['i-up','#E5F5EE','#12805C','Walk-in leads convert at the highest rate this month.']].map(i=>`<div><span class="d" style="background:${i[1]};color:${i[2]}">${icon(i[0])}</span>${i[3]}</div>`).join('');
  $('#aiF').addEventListener('submit',e=>{e.preventDefault();ask($('#aiQ').value)});
  $('#aiS').addEventListener('click',e=>{const b=e.target.closest('button');if(b)ask(b.textContent)});
  $('#aiClr').addEventListener('click',greet);
};

/* ---------- About ---------- */
pages.about=function(el){
  const V=`<svg viewBox="0 0 99 90" aria-hidden="true"><polygon class="l" points="0,0 29.5,0 44.7,28 36,48.3 50.5,48.3 41.7,76" fill="#4C9AFF"/><polygon class="rr" points="68.5,0 98.5,0 49,89.5 43,78.3 64.5,41 48.5,40.5" fill="#FFFFFF"/><path class="zl" pathLength="1" d="M45.8 30.5 L39.6 44.4 L57.6 44.4 L42.4 76.5"/></svg>`;
  el.innerHTML=`<div class="pg">
    <section class="ab-hero"><svg class="bg-v" viewBox="0 0 99 90" aria-hidden="true"><polygon points="0,0 29.5,0 44.7,28 36,48.3 50.5,48.3 41.7,76" fill="#fff"/><polygon points="68.5,0 98.5,0 49,89.5 43,78.3 64.5,41 48.5,40.5" fill="#fff"/></svg>
      <div class="lg">${V}</div><h1>The CRM that keeps your <span>leads charged</span>.</h1>
      <p>LeadVolt helps real estate teams in the UAE capture every enquiry, follow up on time and close more deals, from the first enquiry to a completed follow-up.</p>
      <div class="stats"><div><b class="num" data-v="15">0</b><small>screens designed</small></div><div><b class="num" data-v="60">0</b><small>animations and micro-interactions</small></div><div><b class="num" data-v="1">0</b><small>founder who would not stop</small></div></div></section>
    <div class="panel" style="margin-bottom:16px"><div class="founder"><div class="ph">OR</div><div><h2>Obaid Raza</h2><div class="rl">Founder, product designer and the person behind LeadVolt</div>
      <p>LeadVolt started as one person's frustration with clunky property CRMs. Obaid spent night after night studying how agents actually work: the calls, the WhatsApp follow-ups, the site visits and the paperwork. Then he shaped every screen of LeadVolt around that. The goal was simple: a CRM that agents enjoy opening, that managers trust, and that feels a generation ahead of what the market uses today.</p>
      <div class="sig">Obaid Raza</div></div></div></div>
    <div class="vals" style="margin-bottom:16px">${[['i-spark','Fast by default','Every common action is one or two clicks away, with Ctrl K to find anything.'],['i-users','Built for agents','Designed around real daily work: calls, visits, follow-ups and handovers.'],['i-pie','Clear numbers','Managers see what matters at a glance, with every chart one click from the leads behind it.'],['i-check','Made to feel good','Smooth motion and small celebrations make the daily grind feel rewarding.']].map((v,i)=>`<div style="--i:${i}"><span>${icon(v[0])}</span><b>${v[1]}</b><small>${v[2]}</small></div>`).join('')}</div>
    <div class="split2"><div class="panel"><h3>How LeadVolt was built</h3><ul class="btl">${[['The idea','Obaid maps out a CRM made for UAE property teams.'],['Research','Studying existing tools, screen by screen, to find what slows agents down.'],['Brand','The LeadVolt name and the split V logo with its lightning gap.'],['Dashboard','Today\'s focus, live clock, rocket, funnel and smooth motion.'],['Every page','Leads board, tasks, attendance, reports, projects, off plan, invoices, AI and more.'],['Next','Connecting the real backend and launching with the first teams.']].map((s,i)=>`<li><small>Step ${i+1}</small><i></i><div><b>${s[0]}</b><span>${s[1]}</span></div></li>`).join('')}</ul></div>
      <div class="panel"><h3>Product details</h3><div class="pf-grid" style="grid-template-columns:1fr"><div><small>Product</small>LeadVolt CRM</div><div><small>Version</small>1.0.0 · Front end preview</div><div><small>Founder and designer</small>Obaid Raza</div><div><small>Based in</small>Dubai, United Arab Emirates</div><div><small>Built for</small>Real estate brokerages and developers</div></div>
        <button class="btn-primary rip" id="abGo" style="width:100%;justify-content:center;margin-top:14px">${icon('i-grid')}Open the dashboard</button></div></div>
    <div class="dash-foot">© ${new Date().getFullYear()} LeadVolt · Designed and built by Obaid Raza</div></div>`;
  $$('.ab-hero b[data-v]').forEach(b=>L.countTo(b,+b.dataset.v,v=>Math.round(v)+(b.dataset.v==='60'?'+':''),1400));
  $('#abGo').onclick=()=>L.navTo('Dashboard');
};
['creditBtn','footCredit'].forEach(id=>{const b=document.getElementById(id);if(b)b.addEventListener('click',()=>L.navTo('About'))});
/* ---------- What's new ---------- */
(function(){const b=document.getElementById('wnBtn');if(!b)return;
  const N=[['i-spark','#FFF3DC','#9A5B00','LeadVolt AI','Ask about hot leads, overdue follow-ups, agents or units and get instant answers.','LeadVolt AI'],
    ['i-layout','var(--blue-50)','var(--blue)','Leads board','Drag leads between stages. Booking one fires a little celebration.','Leads'],
    ['i-cash','#E5F5EE','#12805C','Payment plan calculator','Build an off-plan payment schedule for any unit in seconds.','Off Plan'],
    ['i-cloud','#E3E5EA','#2B2F3A','CSV import','Drop a spreadsheet, match the columns and your leads are in.','Data'],
    ['i-bill','var(--neg-bg)','var(--neg)','Commission invoices','Admin-only manual invoice tracking. No automatic posting or invoice delivery.','Invoice']];
  if(L.store.get('lv-wn-seen'))document.getElementById('wnN').remove();
  b.addEventListener('click',()=>{L.setLast(b);const n=document.getElementById('wnN');if(n)n.remove();L.store.set('lv-wn-seen','1');
    L.layer.innerHTML=`<div class="veil" data-close></div><aside class="drawer" role="dialog" aria-modal="true" aria-label="What's new"><div class="wn-hero"><h3>What's new in LeadVolt</h3><small>Version 1.0 · Released by Obaid Raza</small><button class="x" data-close aria-label="Close">${icon('i-x')}</button></div>
      <ul class="wnl">${N.filter(x=>window.LV_FEATURES?.finance||x[5]!=='Invoice').map((x,i)=>`<li data-go="${x[5]}" style="animation-delay:${i*60}ms"><span class="ic" style="background:${x[1]};color:${x[2]}">${icon(x[0])}</span><div><b>${x[3]}<em>NEW</em></b><small>${x[4]}</small></div></li>`).join('')}</ul></aside>`;
    L.layer.querySelector('.x').focus();
    L.layer.querySelector('.wnl').addEventListener('click',e=>{const li=e.target.closest('[data-go]');if(li){L.closeLayer();L.navTo(li.dataset.go)}});
    const r=b.getBoundingClientRect();burst(r.left+r.width/2,r.bottom,40)});
})();
/* ===================== v1.1: sub-menus, roles, teams, ref IDs, report types ===================== */
const PARENT={'Ref. ID Management':'Listing','Manage Teams':'Team','Roles and Permissions':'Team','Audit Log':'Team'};
L.parentOf=n=>PARENT[n]||n;
const SUB={
  'Leads':[['Manage Leads',()=>L.navTo('Leads')],['Add Lead',()=>L.openAdd()]],
  'Data':[['Manage Data',()=>L.navTo('Data')],['Add Data',()=>L.subAddData()]],
  'Reports':[['Overview',()=>L.openReport('Overview')],['Activity',()=>L.openReport('Activity')],['Agency',()=>L.openReport('Agency')],['Data',null,[["Activity"], ["Agency"], ["Call"], ["Campaign vs Status"], ["Channel Partner vs Status"], ["Country"], ["Project"], ["Source"], ["Status"], ["Sub-Source"]].map(([x])=>[x,()=>L.openReport('Data: '+x)])],['Leads',null,[["Activity"], ["Call"], ["Campaign vs Substatus"], ["Channel Partner vs Substatus"], ["Country"], ["Project"], ["Revenue"], ["Source"], ["Status"], ["Sub-Source"], ["Sub-Status"], ["User vs Source"], ["User vs Sub-Source"]].map(([x])=>[x,()=>L.openReport('Leads: '+x)])],['Project vs User',()=>L.openReport('Project vs User')],['Project vs Sub-Status',()=>L.openReport('Project vs Sub-Status')],['Received Date vs Source',()=>L.openReport('Received Date vs Source')],['Sub-Status vs Sub-Source',()=>L.openReport('Sub-Status vs Sub-Source')],['Visit & Meeting',()=>L.openReport('Visit & Meeting')]],
  'Projects':[['Manage Projects',()=>L.navTo('Projects')],['Add Project',()=>{L.navTo('Projects');setTimeout(()=>L.addProject&&L.addProject(),60)}]],
  'Listing':[['Manage Listing',()=>L.navTo('Listing')],['Add Listing',()=>{L.navTo('Listing');setTimeout(()=>L.addListing&&L.addListing(),60)}],['Ref. ID Management',()=>L.navTo('Ref. ID Management')]],
  'Tasks':[['Manage Tasks',()=>L.navTo('Tasks')],['Add Task',()=>{L.navTo('Tasks');setTimeout(()=>L.addTask(),80)}]],
  'Team':[['Manage Users',()=>L.navTo('Team')],['Manage Teams',()=>L.navTo('Manage Teams')],['Roles and Permissions',()=>L.navTo('Roles and Permissions')],['Audit Log',()=>L.navTo('Audit Log')]]
};
(function subMenus(){
  let fly=null,hideT=null;
  const close=()=>{if(fly){if(fly._cl2)fly._cl2();fly.remove();fly=null}};
  $$('#nav > li').forEach(li=>{const b=li.querySelector('button'),name=b.querySelector('.lbl').textContent,items=SUB[name];if(!items)return;
    li.classList.add('has-sub');b.setAttribute('aria-haspopup','true');
    const flat=items.flatMap(it=>it[2]?it[2].map(c=>[it[0]+' · '+c[0],c[1]]):[it]);const inl=document.createElement('div');inl.className='subin';inl.innerHTML=flat.map((it,i)=>`<button data-i="${i}">${it[0]}</button>`).join('');li.appendChild(inl);
    inl.addEventListener('click',e=>{const x=e.target.closest('[data-i]');if(!x)return;e.stopPropagation();document.body.classList.remove('nav-open');flat[+x.dataset.i][1]()});
    const open=()=>{if(innerWidth<=900)return;clearTimeout(hideT);close();const r=li.getBoundingClientRect(),side=$('.side').getBoundingClientRect();
      fly=document.createElement('div');fly.className='subfly';fly.setAttribute('role','menu');fly.innerHTML=`<h5>${name}</h5>`+items.map((it,i)=>`<button role="menuitem" data-i="${i}" ${it[2]?'aria-haspopup="true"':''}><i></i>${it[0]}${it[2]?'<span class="chev"></span>':''}</button>`).join('');
      let fly2=null;const cl2=()=>{if(fly2){fly2.remove();fly2=null}fly&&fly.querySelectorAll('.open').forEach(x=>x.classList.remove('open'))};
      fly.addEventListener('mouseover',e=>{const x=e.target.closest('[data-i]');if(!x||!fly)return;const it=items[+x.dataset.i];if(!it[2]){if(fly2&&!x.classList.contains('open'))cl2();return}if(x.classList.contains('open'))return;cl2();x.classList.add('open');const r=x.getBoundingClientRect();fly2=document.createElement('div');fly2.className='subfly';fly2.innerHTML=`<h5>${it[0]} reports</h5>`+it[2].map((c,j)=>`<button data-j="${j}"><i></i>${c[0]}</button>`).join('');document.body.appendChild(fly2);const h=fly2.offsetHeight;fly2.style.left=(fly.getBoundingClientRect().right+4)+'px';fly2.style.top=Math.max(70,Math.min(r.top-8,innerHeight-h-12))+'px';fly2.addEventListener('mouseenter',()=>clearTimeout(hideT));fly2.addEventListener('mouseleave',()=>{hideT=setTimeout(()=>{cl2();close()},200)});fly2.addEventListener('click',ev=>{const y=ev.target.closest('[data-j]');if(!y)return;const fn=it[2][+y.dataset.j][1];cl2();close();fn()})});
      const oldClose=close;fly._cl2=cl2;
      document.body.appendChild(fly);const h=fly.offsetHeight;fly.style.left=(side.right+6)+'px';fly.style.top=Math.max(70,Math.min(r.top-6,innerHeight-h-12))+'px';
      fly.addEventListener('mouseenter',()=>clearTimeout(hideT));fly.addEventListener('mouseleave',()=>{hideT=setTimeout(close,180)});
      fly.addEventListener('click',e=>{const x=e.target.closest('[data-i]');if(!x)return;const it=items[+x.dataset.i];if(!it[1])return;close();it[1]()});
      fly.addEventListener('keydown',e=>{if(e.key==='Escape'){close();b.focus()}if(e.key==='ArrowDown'||e.key==='ArrowUp'){const bs=[...fly.querySelectorAll('button')],i=bs.indexOf(document.activeElement);bs[(i+(e.key==='ArrowDown'?1:-1)+bs.length)%bs.length].focus();e.preventDefault()}})};
    li.addEventListener('mouseenter',open);li.addEventListener('mouseleave',()=>{hideT=setTimeout(close,220)});
    b.addEventListener('keydown',e=>{if(e.key==='ArrowRight'){open();fly&&fly.querySelector('button').focus();e.preventDefault()}});
    b.addEventListener('click',e=>{if(innerWidth<=900){e.stopImmediatePropagation();li.classList.toggle('open')}},true);
  });
  addEventListener('scroll',close,true);addEventListener('resize',close);
})();
L.on('route',()=>{const cur=L.curName||'Dashboard',par=L.parentOf(cur);$$('#nav > li > button').forEach(x=>{if(x.querySelector('.lbl').textContent===par)x.setAttribute('aria-current','page');else x.removeAttribute('aria-current')})});

/* ---------- Roles and permissions ---------- */
const P=(s)=>s.split('|');
L.PERMS={
 'Attendance':P('Export All Users|Export Reportees|View All Users|View Reportees'),
 'Dashboard':P('View|View CPL Tracking|View Org|View Team'),
 'Data':P('Assign|Bulk Convert To Lead|Bulk Delete|Bulk Email|Bulk Project Assignment|Bulk Reassign|Bulk Restore|Bulk Update Agency|Bulk Update Campaign|Bulk Update Channel Partner|Bulk Update Source|Bulk Update Status|Bulk Upload|Bulk WhatsApp|Convert To Lead|Create|Create Duplicate Data|Delete|Export|Permanent Delete|Search|Update|Update Tags|View|View All Data|View Data Source|View Duplicate Tag|View Unassigned Data'),
 'Global Settings':P('Bulk Assignment|Bulk Delete|Bulk Reassign|Bulk Restore|Bulk Update|Update|View'),
 'Integration':P('Assign|Create|Delete|IVR Call|Update|View|Listen Call Recordings'),
 'Invoice':P('Assign|Bulk Delete|Bulk Email|Bulk Project Assignment|Bulk Reassign|Bulk Restore|Bulk Secondary Reassign|Bulk Update Agency|Bulk Update Campaign|Bulk Update Channel Partner|Bulk Update Source|Bulk WhatsApp|Delete|Export|Re Enquired Lead|Search|Update|View|View Brokerage Info'),
 'Leads':P('Assign|Bulk Delete|Bulk Email|Bulk Project Assignment|Bulk Reassign|Bulk Restore|Bulk Secondary Reassign|Bulk Update Agency|Bulk Update Campaign|Bulk Update Channel Partner|Bulk Update Source|Bulk Update Status|Bulk Upload|Bulk WhatsApp|Communications|Create|Create Duplicate Leads|Delete|Export|Permanent Delete|Re Enquired Lead|Search|Shuffle Leads|Update|Update Basic Info|Update Booked Lead|Update Documents|Update Lead Status|Update Notes|Update Source|Update Tags|View|View All Leads|View Call Recordings|View Confidential Notes|View Duplicate Tag|View Lead Source|View Pending Assignment|View Unassigned Lead'),
 'Listing':P('Assign|Bulk Delete|Bulk De List|Bulk Permanent Delete|Bulk Reassign|Bulk Restore|Bulk Share|Bulk Upload|Call|Clone Property|Create|Delete|Export|Manage Ref IDs|Permanent Delete|Publish|Search|Update|Update And Publish|Update Tags|View|View Assigned|View Unit Number'),
 'Org Profile':P('Create|Delete|Search|Update|View|View Subscription'),
 'Permissions':P('Update|View'),
 'Projects':P('Assign|Bulk Delete|Bulk Permanent Delete|Bulk Reassign|Bulk Restore|Bulk Share|Create|Update|Update Documents|Update Tags|View|View Assigned'),
 'Reports':P('Export All Users|Export Reportees|View All Users|View Reportees'),
 'Roles':P('Bulk Delete|Create|Delete|Update|View'),
 'Sources':P('Hide|Unhide'),
 'Status':P('Create|Delete|Update|View'),
 'Tasks':P('Create|Delete|Search|Update|View'),
 'Teams':P('Bulk Delete|Create|Delete|Export|Update|View'),
 'Templates':P('Create|Delete|Update|View'),
 'User Location':P('Update|View'),
 'User Roles':P('Update|View'),
 'Users':P('Assign To Any|Bulk Deactive|Bulk Role Update|Bulk Update|Create|Default Password|Delete|Export|Search|Update|View|View All Users|View For Filter|View Reportees')};
const ALL=()=>Object.fromEntries(Object.entries(L.PERMS).map(([m,ps])=>[m,new Set(ps)]));
const SET=o=>{const r=Object.fromEntries(Object.keys(L.PERMS).map(m=>[m,new Set()]));Object.entries(o).forEach(([m,ps])=>ps.forEach(p=>r[m].add(p)));return r};
L.roles=[
 {n:'Admin',d:'Full access to everything in LeadVolt',c:'#2B2F3A',perms:ALL(),sys:true},
 {n:'Manager',d:'Runs a sales team and its pipeline',c:'#0B6BE6',perms:SET({Attendance:['View Reportees'],Dashboard:['View','View Team'],Data:P('Assign|Bulk Convert To Lead|Bulk Upload|Convert To Lead|Create|Search|Update|Update Tags|View Data Source'),Invoice:['Assign','Search','Update'],Leads:P('Assign|Bulk Reassign|Shuffle Leads|Search|Update|Update Basic Info|Update Documents|Update Lead Status|Update Notes|Update Source|Update Tags|View|View Lead Source|View Call Recordings|View Unassigned Lead'),Listing:P('Assign|Bulk Upload|Clone Property|Create|Manage Ref IDs|Search|Update|Update Tags|View|View Assigned'),Projects:P('Update|Update Documents|Update Tags|View|View Assigned'),Reports:['View Reportees'],Tasks:P('Create|Search|Update|View'),Teams:P('Create|Export|Update|View'),Users:['View All Users','View Reportees']})},
 {n:'Basic',d:'Own leads and tasks only',c:'#8A91A2',perms:SET({Dashboard:['View'],Leads:P('Search|Update Lead Status|Update Notes|View'),Tasks:P('Create|Search|Update|View'),Attendance:['View Reportees']})},
 {n:'HR',d:'People, attendance and team setup',c:'#12805C',perms:SET({Attendance:P('Export All Users|Export Reportees|View All Users|View Reportees'),Dashboard:['View'],Users:P('Create|Search|Update|View|View All Users|Bulk Deactive'),Teams:P('Create|Update|View'),'User Location':['View'],'User Roles':['View']})},
 {n:'SalesExecutive',d:'Works leads, visits and bookings',c:'#4C9AFF',perms:SET({Dashboard:['View'],Leads:P('Create|Search|Update|Update Basic Info|Update Documents|Update Lead Status|Update Notes|Update Tags|View|View Call Recordings|Communications'),Listing:['View','Search'],Projects:['View'],Tasks:P('Create|Search|Update|View'),Attendance:['View Reportees']})},
 {n:'ListingManager',d:'Projects, listings and portal ads',c:'#E8A400',perms:SET({Dashboard:['View'],Listing:L.PERMS.Listing.filter(p=>!/Permanent/.test(p)),Projects:L.PERMS.Projects.filter(p=>!/Permanent/.test(p)),Leads:['View','Search']})}];
L.userRole={'Obaid Raza':'Admin','Ashfaq Haji Haroon':'Manager','Mariam Khan':'HR','Raish Ahmed':'SalesExecutive','Farwa Shah':'SalesExecutive','Daniel Costa':'SalesExecutive','Yara Saeed':'SalesExecutive','Bilal Ahmed':'SalesExecutive','Kevin Lee':'ListingManager','Anaya Singh':'Basic','Danyal Abid':'SalesExecutive'};
const RISKY=/Permanent|Delete|Default Password|Assign To Any|Bulk Deactive/;
L.viewAs=null;
L.can=(mod,p)=>{if(!L.viewAs)return true;const r=L.roles.find(x=>x.n===L.viewAs);return !!(r&&r.perms[mod]&&r.perms[mod].has(p))};
const NAVMOD={'Global Config':['Global Settings','View'],'Leads':['Leads','View'],'Data':['Data','View'],'Invoice':['Invoice','View'],'Reports':['Reports','View Reportees'],'Projects':['Projects','View'],'Listing':['Listing','View'],'Off Plan':['Projects','View'],'Attendance':['Attendance','View Reportees'],'Tasks':['Tasks','View'],'Team':['Users','View All Users'],'Org Profile':['Org Profile','View']};
function applyViewAs(){$$('#nav > li').forEach(li=>{const n=li.querySelector('.lbl').textContent,m=NAVMOD[n];li.hidden=!!(m&&!L.can(m[0],m[1]))});
  let bar=$('#viewAsBar');if(L.viewAs){if(!bar){bar=document.createElement('div');bar.id='viewAsBar';bar.className='viewas';$('.main').prepend(bar)}bar.innerHTML=`${icon('i-eye','style="width:16px;height:16px"')}Previewing LeadVolt as <b>${esc(L.viewAs)}</b>. Hidden menus are the ones this role cannot open.<button id="vaX">Exit preview</button>`;$('#vaX').onclick=()=>{L.viewAs=null;applyViewAs();toast('Back to your Admin view')}}else if(bar)bar.remove();
  $$('.bulk,[data-act="del"]').forEach(x=>x.hidden=!!L.viewAs&&!L.can('Leads','Bulk Reassign'))}
L.applyViewAs=applyViewAs;
pages.roles=function(el){
  let sel=L.roles[1].n,draft=null,q='';
  el.innerHTML=`<div class="pg">${head('Roles and Permissions','Decide exactly what each role can see and do. Changes apply to everyone with that role.',`<button class="btn-primary rip" id="roAdd">${icon('i-plus')}Add New Role</button>`,L.roles.length)}<div class="roles"><div class="panel rlist" id="roL"></div><div class="panel ped" id="roE"></div></div></div>`;
  const users=n=>Object.entries(L.userRole).filter(([,r])=>r===n).map(([u])=>u);
  const cnt=perms=>Object.values(perms).reduce((a,s)=>a+s.size,0),TOT=Object.values(L.PERMS).reduce((a,p)=>a+p.length,0);
  function list(){$('#roL').innerHTML=`<h3>Roles</h3>`+L.roles.map(r=>{const us=users(r.n);return `<div class="rrow" data-r="${esc(r.n)}" aria-current="${r.n===sel}" tabindex="0"><span class="ric" style="background:${r.c}">${r.n.slice(0,2).toUpperCase()}</span><div style="min-width:0"><b>${esc(r.n)}</b><small>${esc(r.d)} · ${cnt(r.perms)} of ${TOT} permissions</small></div><div class="avs">${us.slice(0,4).map(u=>{const t=L.team.find(x=>x.n===u)||{i:u[0],c:pal[0]};return av(t.i,t.c)}).join('')}${us.length>4?`<span class="avatar" style="width:26px;height:26px;font-size:9px;margin-left:-8px;background:var(--chip);color:var(--body)">+${us.length-4}</span>`:''}</div></div>`}).join('')}
  function editor(){const r=L.roles.find(x=>x.n===sel);draft=draft||Object.fromEntries(Object.entries(r.perms).map(([m,s])=>[m,new Set(s)]));
    const ql=q.toLowerCase(),hl=t=>ql?esc(t).replace(new RegExp('('+ql.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+')','ig'),'<mark>$1</mark>'):esc(t);
    $('#roE').innerHTML=`<div class="ph2"><div style="display:flex;gap:10px;align-items:center"><span class="ric" style="width:36px;height:36px;border-radius:10px;background:${r.c};color:#fff;display:grid;place-items:center;font-weight:700;font-size:12px">${r.n.slice(0,2).toUpperCase()}</span><div style="flex:1;min-width:0"><label class="fld" style="gap:2px">Role name<input id="roN" value="${esc(r.n)}" ${r.sys?'disabled':''}></label></div></div>
      <div style="display:flex;gap:8px;flex-wrap:wrap"><label class="field" style="flex:1;min-width:180px">${icon('i-search')}<input id="roQ" placeholder="Search permissions" value="${esc(q)}"></label><select class="sel" id="roCopy" aria-label="Copy from role"><option value="">Copy from…</option>${L.roles.filter(x=>x.n!==r.n).map(x=>`<option>${esc(x.n)}</option>`).join('')}</select></div></div>
      <div class="pbd">${Object.entries(L.PERMS).map(([m,ps])=>{const vis=ps.filter(p=>!ql||p.toLowerCase().includes(ql)||m.toLowerCase().includes(ql));if(!vis.length)return'';const n=draft[m].size;
        return `<div class="pmod"><h4><input type="checkbox" class="cb" data-mod="${esc(m)}" ${n===ps.length?'checked':''} aria-label="All ${esc(m)} permissions">${hl(m)}<em class="num">${n}/${ps.length}</em><span class="bar"><i style="width:${n/ps.length*100}%"></i></span></h4><div class="pgrid2">${vis.map(p=>`<label class="pchk ${RISKY.test(p)?'risk':''}"><input type="checkbox" class="cb" data-m="${esc(m)}" data-p="${esc(p)}" ${draft[m].has(p)?'checked':''} ${r.sys?'disabled':''}>${hl(p)}</label>`).join('')}</div></div>`}).join('')||'<div class="empty-st"><b>No permission matches</b>Try another word.</div>'}</div>
      <div class="pft"><small style="color:var(--muted);margin-right:auto">${r.sys?'Admin always has every permission.':'Red permissions can delete data or change accounts.'}</small><button class="ghost" id="roView">${icon('i-eye')}Preview as ${esc(r.n)}</button>${r.sys?'':`<button class="ghost" id="roClr">Clear</button><button class="btn-dark rip" id="roSave">Save</button>`}</div>`;
    $$('#roE .pmod h4 .cb').forEach(c=>{const m=c.dataset.mod,n=draft[m].size;c.indeterminate=n>0&&n<L.PERMS[m].length;if(r.sys)c.disabled=true})}
  function draw(){list();editor()}
  draw();
  $('#roL').addEventListener('click',e=>{const x=e.target.closest('[data-r]');if(!x)return;sel=x.dataset.r;draft=null;draw()});
  $('#roL').addEventListener('keydown',e=>{if(e.key==='Enter'){const x=e.target.closest('[data-r]');if(x){sel=x.dataset.r;draft=null;draw()}}});
  $('#roE').addEventListener('input',e=>{if(e.target.id==='roQ'){q=e.target.value;const pos=e.target.selectionStart;editor();const i=$('#roQ');i.focus();i.setSelectionRange(pos,pos)}});
  $('#roE').addEventListener('change',e=>{const t=e.target;
    if(t.dataset.mod){const m=t.dataset.mod;draft[m]=t.checked?new Set(L.PERMS[m]):new Set();editor();return}
    if(t.dataset.m){t.checked?draft[t.dataset.m].add(t.dataset.p):draft[t.dataset.m].delete(t.dataset.p);const h=t.closest('.pmod').querySelector('h4'),m=t.dataset.m,n=draft[m].size,ps=L.PERMS[m].length;h.querySelector('em').textContent=n+'/'+ps;h.querySelector('.bar i').style.width=(n/ps*100)+'%';const c=h.querySelector('.cb');c.checked=n===ps;c.indeterminate=n>0&&n<ps;return}
    if(t.id==='roCopy'&&t.value){const src=L.roles.find(x=>x.n===t.value);draft=Object.fromEntries(Object.entries(src.perms).map(([m,s])=>[m,new Set(s)]));editor();toast('Copied permissions from '+src.n+'. Save to keep them.')}});
  $('#roE').addEventListener('click',e=>{const r=L.roles.find(x=>x.n===sel);
    if(e.target.closest('#roClr')){draft=Object.fromEntries(Object.keys(L.PERMS).map(m=>[m,new Set()]));editor()}
    if(e.target.closest('#roSave')){const nn=$('#roN').value.trim();if(!nn){toast('Give the role a name');return}if(nn!==r.n&&L.roles.some(x=>x.n===nn)){toast('A role with that name already exists');return}
      Object.keys(L.userRole).forEach(u=>{if(L.userRole[u]===r.n)L.userRole[u]=nn});r.n=nn;r.perms=draft;draft=null;sel=nn;draw();toast(nn+' saved · '+cnt(r.perms)+' permissions');const b=$('#roL [aria-current="true"]');if(b){const rc=b.getBoundingClientRect();burst(rc.left+30,rc.top+20,40)}}
    if(e.target.closest('#roView')){L.viewAs=r.n;applyViewAs();toast('Previewing as '+r.n+'. Look at the sidebar.')}});
  $('#roAdd').addEventListener('click',()=>{let n='New Role',k=2;while(L.roles.some(x=>x.n===n))n='New Role '+k++;L.roles.push({n,d:'Custom role',c:pal[L.roles.length%5][1],perms:SET({Dashboard:['View'],Leads:['View','Search'],Tasks:['View','Create','Update']})});sel=n;draft=null;draw();$('#roN').focus();$('#roN').select();toast('Name your role, tick its permissions, then Save')});
};

/* ---------- Manage Teams ---------- */
L.teams=[{n:'Marina Sales',lead:'Ashfaq Haji Haroon',members:['Raish Ahmed','Farwa Shah','Yara Saeed'],c:'#0B6BE6'},{n:'Palm & Villas',lead:'Mariam Khan',members:['Daniel Costa','Bilal Ahmed'],c:'#12805C'},{n:'Listings Desk',lead:'Kevin Lee',members:['Anaya Singh'],c:'#E8A400'}];
pages.teams=function(el){
  el.innerHTML=`<div class="pg">${head('Manage Teams','Group agents under a team lead. Leads, reports and targets roll up by team.',`<button class="btn-primary rip" id="tsAdd">${icon('i-plus')}Create team</button>`,L.teams.length)}<div class="teams" id="tsG"></div></div>`;
  const tmm=n=>L.team.find(x=>x.n===n)||{i:n.split(' ').map(w=>w[0]).join(''),c:pal[1]};
  function draw(){$('#tsG').innerHTML=L.teams.map((t,i)=>{const all=[t.lead,...t.members],ls=L.leads.filter(l=>all.includes(l.ag)),bk=ls.filter(l=>l.st==='Booked'||l.st==='Invoiced').length;
    return `<div class="tcard" style="--i:${i}"><div class="top" style="background:${t.c}"></div><div class="in"><h3><span style="width:10px;height:10px;border-radius:50%;background:${t.c}"></span>${esc(t.n)}</h3><div class="lead">${av(tmm(t.lead).i,tmm(t.lead).c,'on')}<div><b style="font-weight:500;color:var(--ink)">${esc(t.lead)}</b><small style="display:block;color:var(--muted);font-size:var(--fs-xs)">Team lead</small></div></div>
      <div class="mem">${t.members.map(m=>`<span>${av(tmm(m).i,tmm(m).c)}${esc(m)}<button data-rm="${i}" data-m="${esc(m)}" aria-label="Remove ${esc(m)}">×</button></span>`).join('')||'<small style="color:var(--muted)">No members yet</small>'}</div>
      <div class="st3"><div><b class="num">${all.length}</b><small>People</small></div><div><b class="num">${ls.length}</b><small>Leads</small></div><div><b class="num">${ls.length?Math.round(bk/ls.length*100):0}%</b><small>Conversion</small></div></div>
      <div style="display:flex;gap:8px;margin-top:12px"><button class="ghost" style="flex:1;justify-content:center" data-edit="${i}">${icon('i-plus')}Add members</button><button class="ghost" data-ld="${esc(t.lead)}">${icon('i-users')}Leads</button></div></div></div>`}).join('')}
  function modal(i){const t=i!=null?L.teams[i]:{n:'',lead:'',members:[],c:pal[L.teams.length%5][1]};L.setLast(document.activeElement);
    L.layer.innerHTML=`<div class="veil" data-close></div><div class="modal" role="dialog" aria-modal="true" aria-label="Team"><header><h3>${i!=null?'Edit '+esc(t.n):'Create team'}</h3><button class="x" data-close aria-label="Close">${icon('i-x')}</button></header><form id="tsF" novalidate>
      <label class="fld full">Team name<input id="tsN" value="${esc(t.n)}" placeholder="e.g. Downtown Sales"><span class="err" id="tsNe"></span></label>
      <label class="fld full">Team lead<select id="tsL">${L.team.map(u=>`<option ${u.n===t.lead?'selected':''}>${esc(u.n)}</option>`).join('')}</select></label>
      <div class="fld full">Members<div class="mchecks">${L.team.map(u=>`<label class="pchk"><input type="checkbox" class="cb" value="${esc(u.n)}" ${t.members.includes(u.n)?'checked':''}>${esc(u.n)}</label>`).join('')}</div></div>
      <div class="actions"><button type="button" class="ghost" data-close>Cancel</button><button class="btn-primary rip" type="submit">${icon('i-check')}Save team</button></div></form></div>`;
    $('#tsN').focus();
    $('#tsF').addEventListener('submit',e=>{e.preventDefault();const n=$('#tsN').value.trim();if(!n){$('#tsNe').textContent='Give the team a name.';return}const lead=$('#tsL').value,mem=$$('#tsF .mchecks input:checked').map(x=>x.value).filter(m=>m!==lead);
      if(i!=null)Object.assign(L.teams[i],{n,lead,members:mem});else L.teams.push({n,lead,members:mem,c:t.c});L.closeLayer();draw();toast(n+' saved with '+(mem.length+1)+' people');burst(innerWidth/2,220,60)})}
  draw();
  $('#tsAdd').addEventListener('click',()=>modal(null));
  el.addEventListener('click',e=>{const r=e.target.closest('[data-rm]');if(r){const t=L.teams[+r.dataset.rm];t.members=t.members.filter(m=>m!==r.dataset.m);draw();toast(r.dataset.m+' removed from '+t.n);return}
    const ed=e.target.closest('[data-edit]');if(ed){modal(+ed.dataset.edit);return}const ld=e.target.closest('[data-ld]');if(ld)L.openLeadsFor(ld.dataset.ld)});
};

/* ---------- Ref. ID Management (ad owner rule) ---------- */
const PORTC={Bayut:'#21B573','Property Finder':'#EF5B4C','Dubizzle':'#E21B23','Facebook':'#1877F2'};
L.adRefs=[
 {ref:'16840693',portal:'Bayut',listing:'Marina Vista · 2BR sea view',posted:'Ashfaq Haji Haroon',owner:'Obaid Raza',how:'learned',leads:4,last:'Today 12:43 PM'},
 {ref:'16835120',portal:'Bayut',listing:'Creek Heights · 1BR',posted:'Ashfaq Haji Haroon',owner:'Ashfaq Haji Haroon',how:'set',leads:7,last:'Yesterday'},
 {ref:'PF-2207781',portal:'Property Finder',listing:'Palm Residences · 3BR',posted:'Ashfaq Haji Haroon',owner:'Farwa Shah',how:'set',leads:3,last:'2 days ago'},
 {ref:'16829004',portal:'Bayut',listing:'Hills Villas · 5BR',posted:'Raish Ahmed',owner:'Raish Ahmed',how:'learned',leads:2,last:'3 days ago'},
 {ref:'DZ-558120',portal:'Dubizzle',listing:'Downtown Loft · Studio',posted:'Ashfaq Haji Haroon',owner:'',how:'none',leads:1,last:'Today 9:05 AM'},
 {ref:'PF-2209935',portal:'Property Finder',listing:'Bay Square · Office',posted:'Kevin Lee',owner:'',how:'none',leads:0,last:'—'}];
L.routeByRef=(ref)=>{const a=L.adRefs.find(x=>x.ref===ref);return a&&a.owner?a.owner:''};
pages.refids=function(el){
  const S={q:'',portal:''};
  el.innerHTML=`<div class="pg">${head('Ref. ID Management','Ref IDs come from Bayut, Property Finder and Dubizzle. Set who really owns each ad, and its leads go to that person even if it was posted under someone else.',`<button class="ghost" id="riTest">${icon('i-spark')}Send a test lead</button><button class="btn-primary rip" id="riAdd">${icon('i-cloud')}Sync from portals</button>`,L.adRefs.length)}
    <div class="rule"><b style="font-weight:500">How routing works</b><div class="flow"><span>${icon('i-inbox')}Lead arrives on an ad</span><span class="ar">→</span><span class="hl">${icon('i-search')}LeadVolt checks the Ref ID</span><span class="ar">→</span><span>${icon('i-users')}Owner found: assign to owner</span><span class="ar">or</span><span>${icon('i-alert')}No owner: Unassigned, then learns from your first assignment</span></div></div>
    <div class="filters"><label class="field">${icon('i-search')}<input id="riQ" placeholder="Search ref ID or listing" autocomplete="off"></label><select class="sel" id="riP" aria-label="Portal"><option value="">All portals</option>${Object.keys(PORTC).map(p=>`<option>${p}</option>`).join('')}</select></div>
    <div class="panel" style="padding:8px"><div class="tbl-wrap"><table class="tbl" style="min-width:860px"><thead><tr><th>Ref ID</th><th>Portal</th><th>Listing</th><th>Posted under</th><th>Real owner</th><th>How it was set</th><th>Leads</th><th>Last lead</th></tr></thead><tbody id="riB"></tbody></table></div></div></div>`;
  const HOW={learned:['l','Learned automatically'],set:['s','Set by admin'],none:['n','Needs an owner']};
  function draw(){const q=S.q.toLowerCase(),r=L.adRefs.filter(a=>(!S.portal||a.portal===S.portal)&&(!q||(a.ref+a.listing).toLowerCase().includes(q)));
    $('#riB').innerHTML=r.map((a,i)=>`<tr style="--r:${i}"><td>${a.pending?'<span class="how n">Waiting for '+a.portal+'</span>':`<b class="num" style="font-weight:600">${esc(a.ref)}</b>`}</td><td><span class="portal" style="background:${PORTC[a.portal]||'#2B2F3A'}">${a.portal}</span></td><td>${esc(a.listing)}</td><td>${esc(a.posted)}</td>
      <td><select class="ownsel ${a.owner?'':'unset'}" data-ref="${esc(a.ref)}" aria-label="Owner of ${esc(a.ref)}"><option value="">Unassigned</option>${L.team.map(u=>`<option ${u.n===a.owner?'selected':''}>${esc(u.n)}</option>`).join('')}</select></td>
      <td><span class="how ${HOW[a.how][0]}">${HOW[a.how][1]}</span></td><td class="num">${a.leads}</td><td>${esc(a.last)}</td></tr>`).join('')||`<tr><td colspan="8"><div class="empty-st"><b>No ads match</b>Try another search.</div></td></tr>`}
  draw();el._refresh=draw;L.on('refs',()=>{if(el.isConnected)draw()});
  $('#riQ').addEventListener('input',e=>{S.q=e.target.value;draw()});$('#riP').addEventListener('change',e=>{S.portal=e.target.value;draw()});
  el.addEventListener('change',e=>{const s=e.target.closest('[data-ref]');if(!s)return;const a=L.adRefs.find(x=>x.ref===s.dataset.ref);a.owner=s.value;a.how=s.value?'set':'none';draw();toast(s.value?`Future leads from ${a.ref} will go to ${s.value}`:`${a.ref} leads will arrive Unassigned`)});
  $('#riAdd').addEventListener('click',()=>{const b=$('#riAdd');b.disabled=true;b.innerHTML=icon('i-cloud')+'Syncing…';setTimeout(()=>{const pend=L.adRefs.filter(a=>a.pending);pend.forEach(a=>{a.ref=a.portal==='Bayut'?String(16900000+Math.floor(Math.random()*99999)):(a.portal==='Property Finder'?'PF-':'DZ-')+(2210000+Math.floor(Math.random()*9999));a.pending=false});b.disabled=false;b.innerHTML=icon('i-cloud')+'Sync from portals';draw();toast(pend.length?`${pend.length} new Ref IDs received from the portals`:'Everything is up to date. Ref IDs arrive from Bayut, Property Finder and Dubizzle.')},1200)});
  $('#riTest').addEventListener('click',()=>L.simulateLead&&L.simulateLead());
};

/* ---------- Report types (pivots) ---------- */
L.reportType='Overview';
L.openReport=t=>{L.reportType=(t==='Data'||t==='Leads')?t+': '+L.REPFAM[t][0]:t;L.navTo('Reports');L.emit('rtype')};
function pivot(rows,cols,val,title,sub,uniq){const mx=Math.max(1,...rows.flatMap(r=>cols.map(c=>val(r,c))));const ct=cols.map(c=>rows.reduce((a,r)=>a+val(r,c),0));
  return `<div class="panel"><div class="ph"><h3>${esc(title)}</h3><small style="color:var(--muted)">${esc(sub)}</small><button class="ghost" data-csv style="height:32px">${icon('i-list')}Copy as CSV</button></div><div class="tbl-wrap"><table class="tbl pivot"><thead><tr><th></th>${cols.map(c=>`<th>${esc(c)}</th>`).join('')}<th>Total</th></tr></thead><tbody>${rows.map((r,i)=>{const vs=cols.map(c=>val(r,c)),t=vs.reduce((a,v)=>a+v,0);return `<tr style="--r:${i}"><td><b style="font-weight:500">${esc(r)}</b></td>${vs.map((v,ci)=>`<td class="c num" style="background:rgba(11,107,230,${v?(.08+v/mx*.6).toFixed(2):0});color:${v/mx>.55?'#fff':'var(--ink)'}">${v||'·'}${uniq&&v?`<small style="color:inherit;opacity:.75">unique ${uniq(r,cols[ci])}</small>`:''}</td>`).join('')}<td class="num" style="font-weight:600">${t}</td></tr>`}).join('')}<tr class="tot"><td>Total</td>${ct.map(v=>`<td class="num">${v}</td>`).join('')}<td class="num">${ct.reduce((a,v)=>a+v,0)}</td></tr></tbody></table></div></div>`}
const CAMPS=['Binghatti campaign','Generic campaign','Laraix','UK audience','Damac Lagoons push'],CPS=['Outsource leads','Prime Partners','Skyline Brokers','Direct'],CTRY=['UAE','India','UK','Russia','Pakistan','Saudi Arabia','Germany'];
const hash=(a,b)=>{let h=7;for(const c of a+'|'+b)h=(h*31+c.charCodeAt(0))%9973;return h};
function famReport(fam,rep,o){const leadsF=fam==='Leads',A=leadsF?L.leads.filter(x=>!x.del):L.dataRecs.filter(x=>!x.del),users=[...new Set(L.team.map(t=>t.n))].filter(u=>!o.q||u.toLowerCase().includes(o.q)),k=o.k||1;
  const ofU=(u)=>A.filter(x=>x.ag===u),stOf=x=>leadsF?x.st:x.st,subOf=x=>leadsF?(x.sub||'—'):(x.st),srcOf=x=>leadsF?x.src:'Data',ssOf=x=>leadsF?(x.subSrc||'Direct'):x.proj,
    campOf=x=>CAMPS[hash(x.n,'c')%CAMPS.length],cpOf=x=>CPS[hash(x.n,'p')%CPS.length],ctOf=x=>CTRY[hash(x.n,'k')%CTRY.length],sc=v=>Math.round(v*k);
  const STL=leadsF?STS:['New','Follow Ups','Backlog','Not Reachable','Not Answered','Converted'],SUBL=[...new Set(A.map(subOf))];
  const T=(rows,cols,val,t,sub,u)=>pivot(rows.filter(r=>!o.q||String(r).toLowerCase().includes(o.q)),cols,(r,c)=>sc(val(r,c)),fam+' · '+t,sub,u);
  switch(rep){
    case 'Activity':return T(users,['Calls','WhatsApp','Emails','Notes','Status updates'],(u,c)=>ofU(u).length*({Calls:3,WhatsApp:2,Emails:1,Notes:1,'Status updates':1}[c])+hash(u,c)%3,'Activity Report','What each user did. Small numbers show unique contacts.',(u,c)=>ofU(u).length);
    case 'Agency':return T(CPS,STL,(r,c)=>A.filter(x=>cpOf(x)===r&&stOf(x)===c).length,'Agency Report','Results for each agency or channel partner');
    case 'Call':return T(users,['Incoming','Outgoing','Answered','Missed','Not connected'],(u,c)=>ofU(u).length*({Incoming:2,Outgoing:4,Answered:3,Missed:1,'Not connected':1}[c])+hash(u,c)%4,'Call Report','Calls per user, from the dialler and Bayut call tracking');
    case 'Campaign vs Status':case 'Campaign vs Substatus':return T(CAMPS,rep.endsWith('Substatus')?SUBL:STL,(r,c)=>A.filter(x=>campOf(x)===r&&(rep.endsWith('Substatus')?subOf(x):stOf(x))===c).length,rep,'How each marketing campaign is converting');
    case 'Channel Partner vs Status':case 'Channel Partner vs Substatus':return T(CPS,rep.endsWith('Substatus')?SUBL:STL,(r,c)=>A.filter(x=>cpOf(x)===r&&(rep.endsWith('Substatus')?subOf(x):stOf(x))===c).length,rep,'Channel partner results by stage');
    case 'Country':return T(CTRY,STL,(r,c)=>A.filter(x=>ctOf(x)===r&&stOf(x)===c).length,'Country Report','Where your clients are from');
    case 'Project':return T([...new Set(A.map(x=>x.proj))],STL,(r,c)=>A.filter(x=>x.proj===r&&stOf(x)===c).length,'Project Report','Each project by stage');
    case 'Revenue':return T(users,['Booked deals','Booked value (AED M)','Invoiced','Commission (AED K)'],(u,c)=>{const b=ofU(u).filter(x=>x.st==='Booked'||x.st==='Invoiced');return c==='Booked deals'?b.length:c==='Invoiced'?b.filter(x=>x.st==='Invoiced').length:c.startsWith('Booked value')?Math.round(b.reduce((a,x)=>a+(x.bn||0),0)):Math.round(b.reduce((a,x)=>a+(x.bn||0),0)*20)},'Revenue Report','Bookings and commission per user');
    case 'Source':return T(leadsF?L.srcN:['Data'],STL,(r,c)=>A.filter(x=>srcOf(x)===r&&stOf(x)===c).length,'Source Report','Every source by stage');
    case 'Status':return T(users,STL,(u,c)=>ofU(u).filter(x=>stOf(x)===c).length,'Status Report','Each user\'s pipeline by status');
    case 'Sub-Source':return T([...new Set(A.map(ssOf))],STL,(r,c)=>A.filter(x=>ssOf(x)===r&&stOf(x)===c).length,'Sub-Source Report','Which sub-sources turn into which stages');
    case 'Sub-Status':return T(users,SUBL,(u,c)=>ofU(u).filter(x=>subOf(x)===c).length,'Sub-Status Report','Each user\'s leads by sub-status');
    case 'User vs Source':return T(users,leadsF?L.srcN:['Data'],(u,c)=>ofU(u).filter(x=>srcOf(x)===c).length,'User vs Source','Where each user\'s leads come from');
    case 'User vs Sub-Source':return T(users,[...new Set(A.map(ssOf))],(u,c)=>ofU(u).filter(x=>ssOf(x)===c).length,'User vs Sub-Source','Sub-source mix for every user');
  }return ''}
L.REPFAM={Data:['Activity','Agency','Call','Campaign vs Status','Channel Partner vs Status','Country','Project','Source','Status','Sub-Source'],Leads:['Activity','Call','Campaign vs Substatus','Channel Partner vs Substatus','Country','Project','Revenue','Source','Status','Sub-Source','Sub-Status','User vs Source','User vs Sub-Source']};
L.renderReport=function(type,o={}){const m=/^(Data|Leads): (.+)$/.exec(type);if(m)return famReport(m[1],m[2],o);const A=L.leads,ag=[...new Set(A.map(l=>l.ag||'Unassigned'))],pj=L.projects,src=L.srcN,sts=L.STS,ss=[...new Set(A.map(l=>l.subSrc||'Direct'))];
  const days=Array.from({length:7},(_,i)=>{const d=new Date();d.setDate(d.getDate()-6+i);return d.toLocaleDateString('en-GB',{day:'2-digit',month:'short'})});
  if(type==='Project vs User')return pivot(pj,ag,(r,c)=>A.filter(l=>l.proj===r&&(l.ag||'Unassigned')===c).length,'Project vs User','Leads per project for each agent');
  if(type==='Project vs Sub-Status')return pivot(pj,sts,(r,c)=>A.filter(l=>l.proj===r&&l.st===c).length,'Project vs Sub-Status','Where each project\'s leads stand');
  if(type==='Received Date vs Source')return pivot(days,src,(r,c)=>A.filter((l,i)=>l.src===c&&days[(i*3)%7]===r).length,'Received Date vs Source','Leads received in the last 7 days by source');
  if(type==='Sub-Status vs Sub-Source')return pivot(sts,ss,(r,c)=>A.filter(l=>l.st===r&&(l.subSrc||'Direct')===c).length,'Sub-Status vs Sub-Source','Which channels turn into which stages');
  if(type==='Visit & Meeting')return pivot(ag,['Meetings scheduled','Meetings done','Visits scheduled','Visits done'],(r,c)=>A.filter((l,i)=>(l.ag||'Unassigned')===r&&(c.startsWith('Meet')?l.st==='Meeting Done'||(i%5===0&&c.includes('sched')):l.st==='Site Visit Done'||(i%4===0&&c.includes('sched')))).length,'Visit & Meeting','Meetings and site visits per agent');
  if(type==='Activity')return pivot(ag,['Calls','WhatsApp','Notes','Status changes'],(r,c)=>A.filter(l=>(l.ag||'Unassigned')===r).length*({Calls:3,WhatsApp:2,Notes:1,'Status changes':1}[c])+(r.length%3),'Activity','What each agent did on their leads');
  if(type==='Agency')return pivot(src,['Leads','Booked','Invoiced'],(r,c)=>A.filter(l=>l.src===r&&(c==='Leads'||l.st===c)).length,'Agency','Leads and results by channel or agency');
  if(type==='Data')return pivot(src,['Imported','Converted to lead','Not interested'],(r,c)=>Math.round(A.filter(l=>l.src===r).length*({Imported:2.4,'Converted to lead':1,'Not interested':.6}[c])),'Data','Data contacts and how many became leads');
  if(type==='Leads')return pivot(ag,sts,(r,c)=>A.filter(l=>(l.ag||'Unassigned')===r&&l.st===c).length,'Leads','Every agent\'s leads by status');
  return ''};
/* ===================== v1.1: Lead Preview, tags, unassigned, shuffle, live Bayut leads ===================== */
const SUBSRC={Bayut:['bayut call','bayut whatsapp','bayut email'],'Property Finder':['PF call','PF email'],Facebook:['FB lead form'],Website:['Contact form'],'Walk-in':['Office visit']};
L.leads.forEach((l,i)=>{if(!l.tags)l.tags=i%5===0?['Hot']:i%7===0?['Cold']:i%4===0?['Warm']:[];if(!l.subSrc)l.subSrc=(SUBSRC[l.src]||['Direct'])[i%(SUBSRC[l.src]||['x']).length];if(!l.serial)l.serial='F4000000'+String(5000+i*7).padStart(4,'0');
  if(l.src==='Bayut'&&!l.ref)l.ref=['16840693','16835120','16829004'][i%3];if(!l.recs)l.recs=/call/.test(l.subSrc)?[{at:'Today, 12:4'+(i%10)+' PM',dur:62+i*7%140,from:'Bayut call · '+l.ph}]:[];if(!l.docs)l.docs=[];if(l.enq==null)l.enq=i%3?'Buy':'Rent';if(l.beds==null)l.beds=1+i%4});
['Vaibhav','Hessa Al Mansoori','Peter Novak'].forEach((n,k)=>L.leads.unshift({n,ini:n.split(' ').map(w=>w[0]).join('').slice(0,2),st:'New',src:'Bayut',subSrc:['bayut whatsapp','bayut call','bayut email'][k],ag:'',proj:L.projects[k],bud:'AED '+(1.2+k)+'M',ph:'+97156175539'+k,note:'Hi, I am interested in your property on Bayut: https://www.bayut.com/pm/'+['16840693','DZ-558120','16835120'][k],last:'Today',c:pal[k],tags:[],ref:['DZ-558120','PF-2209935','DZ-558120'][k],serial:'F400000050'+(68+k),recs:k===1?[{at:'Today, 12:43 PM',dur:94,from:'Bayut call · +971561755391'}]:[],docs:[],enq:'Buy',beds:2}));
normAll();
const TAGS=['Hot','Warm','Cold'],TAGI={Hot:'🔥',Warm:'♨',Cold:'❄'};
const tagIcon=t=>t==='Hot'?'<svg class="i" viewBox="0 0 24 24" style="width:13px;height:13px"><path d="M12 3c1 4 5 5 5 10a5 5 0 0 1-10 0c0-2 1-3.5 2-4.5 0 2 1 3 2 3 0-3-1-5 1-8.5z"/></svg>':t==='Warm'?'<svg class="i" viewBox="0 0 24 24" style="width:13px;height:13px"><path d="M8 4c-2 3 2 5 0 8s2 5 0 8M12 4c-2 3 2 5 0 8s2 5 0 8M16 4c-2 3 2 5 0 8s2 5 0 8"/></svg>':'<svg class="i" viewBox="0 0 24 24" style="width:13px;height:13px"><path d="M12 2v20M4 6l16 12M20 6L4 18"/></svg>';
L.tagDots=l=>l.tags&&l.tags.length?`<span class="tdot">${l.tags.map(t=>`<i class="${t}">${t}</i>`).join('')}</span>`:'';

/* ---- notifications + push banners ---- */
L.notes=[{t:'Rahul Verma booked a site visit',b:'Today, 1:45 PM at Creek Heights',when:'12 min ago',read:false},{t:'3 leads from Bayut were assigned to you',b:'Marina Vista campaign',when:'40 min ago',read:false},{t:'Ashfaq Haji Haroon closed a deal',b:'AED 1.1M · Hills Villas',when:'2 h ago',read:true}];
function drawNotes(){const box=$('#notes');if(!box)return;const un=L.notes.filter(n=>!n.read).length;
  box.innerHTML=`<h4>Notifications <button id="markRead2">Mark all as read</button></h4>`+L.notes.slice(0,8).map((n,i)=>`<div class="note ${n.read?'read':''}" data-ni="${i}" style="cursor:pointer"><span class="nd"></span><div><b>${esc(n.t)}</b> ${esc(n.b||'')}<small>${esc(n.when)}${n.status?' · '+n.status:''}</small></div></div>`).join('');
  let d=$('#bellDot');if(un&&!d){d=document.createElement('span');d.className='dot';d.id='bellDot';$('#bellBtn').appendChild(d)}if(!un&&d)d.remove();
  $('#markRead2').onclick=e=>{e.stopPropagation();L.notes.forEach(n=>n.read=true);drawNotes();toast('All notifications marked as read')}}
drawNotes();
document.addEventListener('click',e=>{const n=e.target.closest('[data-ni]');if(!n)return;const x=L.notes[+n.dataset.ni];x.read=true;drawNotes();if(x.lead){const l=L.findLead(x.lead);if(l){$('#notes').hidden=true;L.openProfile(l)}}});
let pushBox=null;
L.notify=(t,b,lead)=>{L.notes.unshift({t,b,when:'Just now',read:false,lead,status:'Delivered'});drawNotes();
  if(!pushBox){pushBox=document.createElement('div');pushBox.className='pushes';pushBox.setAttribute('aria-live','polite');document.body.appendChild(pushBox)}
  const p=document.createElement('div');p.className='push';p.innerHTML=`<span class="pi"><svg viewBox="0 0 99 90"><polygon points="0,0 29.5,0 44.7,28 36,48.3 50.5,48.3 41.7,76" fill="#fff"/><polygon points="68.5,0 98.5,0 49,89.5 43,78.3 64.5,41 48.5,40.5" fill="#FFC83D"/></svg></span><div><b>${esc(t)}</b><p>${esc(b)}</p><div class="pa">${lead?'<button class="o">Open lead</button>':''}<button class="d">Dismiss</button><span class="dl">${icon('i-check','style="width:12px;height:12px"')}Delivered</span></div></div>`;
  pushBox.prepend(p);const bye=()=>{p.classList.add('bye');setTimeout(()=>p.remove(),350)};const tm=setTimeout(bye,7000);
  p.querySelector('.d').onclick=bye;const o=p.querySelector('.o');if(o)o.onclick=()=>{clearTimeout(tm);bye();const l=L.findLead(lead);if(l)L.openProfile(l)}};

/* ---- simulate an incoming Bayut lead (shows the full API flow) ---- */
const NEWN=['Ahmed Al Suwaidi','Sophie Laurent','Imran Qadir','Natalia Ivanova','Omar Farouk','Priyanka Das','Lucas Meyer','Reem Haddad'];let simN=0;
L.simulateLead=function(refPick){const a=refPick?L.adRefs.find(x=>x.ref===refPick):L.adRefs[simN%L.adRefs.length];const n=NEWN[simN%NEWN.length]+(simN>=NEWN.length?' '+(simN+1):'');simN++;
  const owner=a&&a.owner?a.owner:'',sub=['bayut call','bayut whatsapp','bayut email'][simN%3];
  const l={n,ini:n.split(' ').map(w=>w[0]).join('').slice(0,2),st:'New',src:a?a.portal:'Bayut',subSrc:sub,ag:owner,proj:(a&&a.listing.split(' · ')[0])||L.projects[0],bud:'AED '+(1+simN%4)+'.5M',ph:'+97150'+(1000000+simN*7331),note:`Hi, I am interested in your property on ${a?a.portal:'Bayut'}, ref ${a?a.ref:'—'}.`,last:'Just now',c:pal[simN%5],tags:[],ref:a?a.ref:'',serial:'F400000051'+(10+simN),recs:sub==='bayut call'?[{at:'Just now',dur:45+simN*13%120,from:'Bayut call · +97150'+(1000000+simN*7331)}]:[],docs:[],enq:'Buy',beds:1+simN%4,notes:[],created:'Just now'};
  L.leads.unshift(l);normAll();if(a){a.leads++;a.last='Just now'}
  l.notes.unshift({text:owner?`Auto-assigned to ${owner} because ad ${a.ref} belongs to them`:`Arrived Unassigned: ad ${a?a.ref:''} has no owner yet`,when:'Just now'});
  L.notify(owner?`New ${l.src} lead for ${owner.split(' ')[0]}`:`New unassigned ${l.src} lead`,`${n} · ${l.proj}${l.recs.length?' · call recorded':''}${owner?' · routed by Ref ID '+a.ref:' · assign it to teach LeadVolt the owner'}`,n);
  L.emit('leads');L.emit('refs');return l};

/* ---- Lead Preview ---- */
const ago=()=>'Just now';
function wave(seed){let s=seed*131+7;const r=()=>(s=(s*9301+49297)%233280)/233280;return Array.from({length:48},(_,i)=>`<i style="height:${(18+r()*82*Math.abs(Math.sin(i/4+seed))).toFixed(0)}%"></i>`).join('')}
const fmtT=s=>Math.floor(s/60)+':'+String(Math.floor(s%60)).padStart(2,'0');
function preview(l){
  const idx=()=>{const list=L.curLeadList||L.leads;return list.indexOf(l)};
  let tab='Overview',stSel=null;L.setLast(document.activeElement);
  const TABS=()=>[['Overview'],['Status'],['History',timeline(l).length],['Notes',l.notes.length],['Documents',l.docs.length],['Calls',l.recs.length]];
  L.layer.innerHTML=`<div class="veil" data-close></div><aside class="lp" role="dialog" aria-modal="true" aria-label="Lead preview: ${esc(l.n)}"><div class="lp-bar" id="lpBar"></div><div class="lp-body" id="lpB"></div></aside>`;
  const A=[['prev','i-dbl','#EDEFF4','#2B2F3A','Previous lead'],['edit','i-pen','#E5F5EE','#12805C','Edit details'],['copy','i-list','#F3F8D9','#5E7A00','Copy details'],['hist','i-cal','#FBEBDD','#A05A1C','History'],['share','i-cloud','#E2F1FB','#0B6B9A','Share profile'],['link','i-arrow','#F0E6FB','#7A3DB8','Copy link'],['mail','i-inbox','#E8EAFD','#4450C9','Email'],['wa','i-msg','#E3F7EA','#1E8E4E','WhatsApp'],['call','i-phone','#E2F0FE','#0B6BE6','Call'],['del','i-x','#FDECEC','#C0262B','Delete lead'],['next','i-arrow','#2B2F3A','#fff','Next lead']];
  function bar(){$('#lpBar').innerHTML=`<button class="x" data-close aria-label="Close">${icon('i-x')}</button><h2>Lead Preview <small class="num">${idx()+1} of ${(L.curLeadList||L.leads).length}</small></h2><div class="lp-acts">${A.map(([k,ic,bg,fg,tip])=>`<button class="lpa" data-a="${k}" data-tip="${tip}" aria-label="${tip}" style="background:${bg};color:${fg}" ${k==='prev'?'style="transform:rotate(0)"':''}>${k==='prev'?'<svg class="i" viewBox="0 0 24 24"><path d="M15 6l-6 6 6 6"/></svg>':k==='next'?'<svg class="i" viewBox="0 0 24 24"><path d="M9 6l6 6-6 6"/></svg>':icon(ic)}</button>`).join('')}</div>`}
  function hero(){const r=L.adRefs.find(a=>a.ref===l.ref);return `<div class="lp-hero">${av(l.ini,l.c)}<div style="min-width:0"><h3>${esc(l.n)}${l.ag?'':'<span class="unas">Unassigned</span>'}</h3>
    <div class="ct"><span class="copy" data-cp="${esc(l.ph)}">${icon('i-phone')}<span class="num">${esc(l.ph)}</span></span><span>${icon('i-phone')}${esc(l.alt||'—')}</span><span class="copy" data-cp="${esc(l.email)}">${icon('i-inbox')}${esc(l.email)}</span><span>${icon('i-pin')}${esc(l.community||l.loc||'Dubai')}</span><span>${icon('i-build')}<b style="color:var(--blue);font-weight:500">${esc(l.proj)}</b></span></div>
    <div class="tagrow">${TAGS.map(t=>`<button class="tg ${t}" data-tg="${t}" aria-pressed="${l.tags.includes(t)}">${tagIcon(t)}${t}</button>`).join('')}${l.tags.filter(t=>!TAGS.includes(t)).map(t=>`<button class="tg" data-tg="${esc(t)}" aria-pressed="true">#${esc(t)}</button>`).join('')}<button class="tg" data-addtag>${icon('i-plus','style="width:12px;height:12px"')}Tag</button></div></div>
    <div class="score"><div class="ring" style="--p:${l.score}"><span class="num">${l.score}</span></div></div></div>`}
  function tabs(){return `<div class="lp-tabs" role="tablist"><span class="th"></span>${TABS().map(([t,c])=>`<button role="tab" data-t="${t}" aria-selected="${t===tab}">${t}${c!=null?`<em class="num">${c}</em>`:''}</button>`).join('')}</div>`}
  const stC=s=>STC[s]||'#4C9AFF';
  function pane(){
    if(tab==='Overview'){const r=L.adRefs.find(a=>a.ref===l.ref);return `<div class="lp-pane">
      <div class="card2"><h4>Lead Status<button class="btn-primary rip r" data-gotab="Status" style="height:32px">Change Status</button></h4><div class="stbox"><span class="ic" style="background:${stC(l.st)}">${icon('i-spark')}</span><div style="min-width:0"><b>${l.st}</b><p>${esc((l.notes[0]&&l.notes[0].text)||l.note||'')}</p></div></div></div>
      <div class="card2"><h4>Assigned To</h4><div class="asg"><div class="who2">${l.ag?av((L.team.find(t=>t.n===l.ag)||{i:l.ag[0]}).i,(L.team.find(t=>t.n===l.ag)||{c:pal[1]}).c,'on')+`<div><b style="font-weight:500">${esc(l.ag)}</b><small style="display:block;color:var(--muted);font-size:var(--fs-xs)">${esc(L.userRole[l.ag]||'Agent')}</small></div>`:'<span class="unas">Waiting for an owner</span>'}</div>
        <select class="sel" id="lpAs" aria-label="Re-assign lead" style="min-width:190px"><option value="__">Re-assign to…</option><option value="">Unassign lead (mark as unassigned)</option>${L.team.map(u=>`<option ${u.n===l.ag?'disabled':''}>${esc(u.n)}</option>`).join('')}</select>${l.ag?`<button class="ghost" id="lpShuf">${icon('i-users')}Shuffle</button>`:''}</div><div id="lpShufBox"></div>
        ${r&&!l.ag?`<p style="margin:10px 0 0;font-size:var(--fs-xs);color:var(--muted)">Assigning this lead teaches LeadVolt that ad <b>${esc(r.ref)}</b> belongs to that person. Future leads from it will be assigned automatically.</p>`:''}</div>
      <div class="card2"><h4>Lead Info</h4><div class="secT">${icon('i-alert','style="width:13px;height:13px"')}Enquiry info</div><div class="kvg"><div><small>Source</small><b>${esc(l.src)}</b></div><div><small>Sub source</small><b>${esc(l.subSrc||'—')}</b></div><div><small>Ad Ref ID</small><b class="num">${esc(l.ref||'—')}</b></div><div><small>Enquired for</small><b>${l.enq}</b></div><div><small>Beds</small><b>${l.beds||'—'}</b></div><div><small>Budget</small><b>${esc(l.bud)}</b></div></div>
        <div class="secT" style="margin-top:14px">${icon('i-list','style="width:13px;height:13px"')}Others</div><div class="kvg"><div><small>Serial number</small><b class="num">${esc(l.serial)}</b></div><div><small>Created</small><b>${esc(l.created)}</b></div><div><small>Last modified</small><b>${esc(l.last)}</b></div></div></div>
      ${l.recs.length?`<div class="card2"><h4>Latest call recording<button class="link r" data-gotab="Calls">All recordings</button></h4>${recHtml(l.recs[0],0)}</div>`:''}</div>`}
    if(tab==='Status'){const STG=[['New','Fresh enquiry'],['Callback','Call them back'],['Meeting Done','Met in person'],['Site Visit Done','Visited the property'],['Booked','Deal booked'],['Invoiced','Commission billed'],['Overdue','Follow-up is late']];stSel=stSel||l.st;
      return `<div class="lp-pane"><div class="card2"><h4>Move this lead to</h4><div class="stages">${STG.map(([s,d])=>`<button class="stg" data-stg="${s}" aria-pressed="${s===stSel}"><i style="background:${stC(s)}"></i><b style="font-weight:500">${s}</b><small>${d}</small></button>`).join('')}</div>
        <form class="form3" id="lpStF"><label class="fld">${stSel==='Booked'?'Booking date':'Next follow-up'}<input type="datetime-local" id="lpWhen"></label><label class="fld">${stSel==='Booked'?'Agreement value (AED)':'Reminder for'}<input id="lpX" ${stSel==='Booked'?'inputmode="numeric" placeholder="e.g. 2,100,000"':`value="${esc(l.ag||'Obaid Raza')}"`}></label>
        <label class="fld full">Note<textarea id="lpStN" placeholder="What happened? This shows on the timeline."></textarea></label><div class="full" style="display:flex;justify-content:flex-end;gap:8px"><button class="btn-primary rip" type="submit">${icon('i-check')}Save status</button></div></form></div></div>`}
    if(tab==='History')return `<div class="lp-pane"><div class="card2"><ul class="tl">${tlHtml(l)}</ul></div></div>`;
    if(tab==='Notes')return `<div class="lp-pane"><div class="card2"><h4>Add a note</h4><div class="note-box"><textarea id="lpNote" placeholder="What happened on the last call?"></textarea><button class="btn-primary rip" id="lpNoteAdd" style="align-self:flex-end">${icon('i-plus')}Add</button></div></div>${l.notes.map((n,i)=>`<div class="card2" style="animation:rise .35s var(--ease) both;animation-delay:${i*40}ms"><small style="color:var(--muted);font-size:var(--fs-xs)">${esc(n.when)} · Obaid Raza</small><p style="margin:6px 0 0;line-height:1.5">${esc(n.text)}</p></div>`).join('')||'<div class="card2 empty-st"><b>No notes yet</b>Notes you add appear here and on the timeline.</div>'}</div>`;
    if(tab==='Documents')return `<div class="lp-pane"><div class="card2"><label class="drop" id="lpDrop"><input type="file" id="lpFile" multiple><span class="di">${icon('i-cloud')}</span><b>Drop passport, Emirates ID or offer letter</b><small>Any file. Stays with this lead.</small></label><div class="docs">${l.docs.map((d,i)=>`<div class="doc"><span class="fi">${esc(d.ext)}</span><div style="min-width:0"><b style="font-weight:500">${esc(d.name)}</b><small>${d.size} · added ${esc(d.when)}</small></div><button class="rbtn" data-rmdoc="${i}" aria-label="Remove ${esc(d.name)}">${icon('i-x')}</button></div>`).join('')}</div></div></div>`;
    if(tab==='Calls')return `<div class="lp-pane">${l.recs.length?l.recs.map((r,i)=>`<div class="card2">${recHtml(r,i)}</div>`).join(''):'<div class="card2 empty-st"><b>No calls recorded yet</b>When a client calls this lead\'s Bayut number, the recording appears here.</div>'}<p style="font-size:var(--fs-xs);color:var(--muted);margin:0">Recordings are fetched from Bayut through the API connection. In this preview they play silently as a demo.</p></div>`}
  function recHtml(r,i){return `<div class="rec" data-rec="${i}"><button class="pp" data-play="${i}" aria-label="Play recording"><svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg></button><div style="min-width:0"><div class="meta"><b>${esc(r.from)}</b><span>${esc(r.at)}</span></div><div class="wave2" data-seek="${i}">${wave(i+l.n.length)}</div><div class="ctl"><span class="num" data-tm="${i}">0:00 / ${fmtT(r.dur)}</span><button data-spd="${i}">1x</button><span style="margin-left:auto">Recorded by Bayut</span></div></div></div>`}
  function draw(){bar();$('#lpB').innerHTML=hero()+tabs()+pane();const th=$('#lpB .lp-tabs .th'),b=$(`#lpB .lp-tabs [aria-selected="true"]`);if(th&&b){th.style.width=b.offsetWidth+'px';th.style.transform=`translateX(${b.offsetLeft-4}px)`}}
  draw();L.layer.querySelector('.x').focus();
  let play=null;
  const stopPlay=()=>{if(play){clearInterval(play.t);const pp=$(`[data-play="${play.i}"]`);if(pp)pp.innerHTML='<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>';const rc=$(`[data-rec="${play.i}"]`);if(rc)rc.classList.remove('on');play=null}};
  const paint=(i,pos)=>{const r=l.recs[i],bars=$$(`[data-seek="${i}"] i`),n=Math.round(pos/r.dur*bars.length);bars.forEach((b,k)=>b.classList.toggle('p',k<n));const t=$(`[data-tm="${i}"]`);if(t)t.textContent=fmtT(pos)+' / '+fmtT(r.dur)};
  const box=L.layer.querySelector('.lp');
  box.addEventListener('click',e=>{
    const a=e.target.closest('[data-a]');if(a){const k=a.dataset.a,list=L.curLeadList||L.leads;
      if(k==='prev'||k==='next'){stopPlay();const j=idx()+(k==='next'?1:-1);const nl=list[(j+list.length)%list.length];preview(nl);return}
      if(k==='hist'){tab='History';draw();return}if(k==='call')toast('Calling '+l.n+' (demo)');if(k==='wa')toast('WhatsApp opened for '+l.n+' (demo)');if(k==='mail')toast('Email draft opened for '+l.email+' (demo)');
      if(k==='copy'||k==='link'||k==='share'){const t=k==='copy'?`${l.n}\n${l.ph}\n${l.email}\n${l.proj} · ${l.bud}\nStatus: ${l.st}`:`LeadVolt lead ${l.serial}: ${l.n}`;try{navigator.clipboard.writeText(t).then(()=>toast(k==='copy'?'Lead details copied':'Lead link copied'),()=>toast('Copy blocked by the browser'))}catch(x){toast('Copy blocked by the browser')}}
      if(k==='edit'){tab='Overview';draw();toast('Edit mode: change status, owner and tags here. Full edit form arrives with the backend.')}
      if(k==='del'){if(a.dataset.sure){const i=L.leads.indexOf(l);L.leads.splice(i,1);L.closeLayer();toast(l.n+' deleted');L.emit('leads')}else{a.dataset.sure='1';a.dataset.tip='Click again to delete';a.style.background='#C0262B';a.style.color='#fff';setTimeout(()=>{if(a.isConnected){delete a.dataset.sure;a.dataset.tip='Delete lead';a.style.background='#FDECEC';a.style.color='#C0262B'}},2500)}}
      return}
    const t=e.target.closest('[data-t]');if(t){tab=t.dataset.t;stopPlay();draw();return}
    const g=e.target.closest('[data-gotab]');if(g){tab=g.dataset.gotab;stopPlay();draw();return}
    const tg=e.target.closest('[data-tg]');if(tg){const v=tg.dataset.tg;if(TAGS.includes(v))l.tags=l.tags.filter(x=>!TAGS.includes(x)||x===v);l.tags.includes(v)?l.tags=l.tags.filter(x=>x!==v):l.tags.push(v);draw();L.emit('leads');return}
    if(e.target.closest('[data-addtag]')){const ip=document.createElement('input');ip.className='tg';ip.placeholder='New tag, then Enter';ip.style.width='150px';e.target.closest('[data-addtag]').replaceWith(ip);ip.focus();ip.addEventListener('keydown',ev=>{if(ev.key==='Enter'&&ip.value.trim()){l.tags.push(ip.value.trim());draw();L.emit('leads')}if(ev.key==='Escape')draw()});return}
    const cp=e.target.closest('[data-cp]');if(cp){try{navigator.clipboard.writeText(cp.dataset.cp).then(()=>toast('Copied '+cp.dataset.cp),()=>{})}catch(x){}return}
    const s=e.target.closest('[data-stg]');if(s){stSel=s.dataset.stg;draw();return}
    if(e.target.closest('#lpShuf')){const sb=$('#lpShufBox');if(sb.innerHTML){sb.innerHTML='';return}sb.innerHTML=`<div class="shuf"><b style="font-weight:600;font-size:var(--fs-sm)">Shuffle ${esc(l.n)} to another agent</b><div class="form3"><label class="fld">Move to<select id="shTo">${L.team.filter(u=>u.n!==l.ag).map(u=>`<option>${esc(u.n)}</option>`).join('')}</select></label><label class="fld">Reason<select id="shWhy"><option>Agent is busy with too many leads</option><option>Agent is on leave or unavailable</option><option>Client prefers another language</option><option>Client asked for a different agent</option><option>Better fit for this project</option></select></label></div><div style="display:flex;justify-content:flex-end;gap:8px;margin-top:10px"><button class="ghost" id="shNo">Cancel</button><button class="btn-primary rip" id="shGo">${icon('i-users')}Shuffle lead</button></div></div>`;return}
    if(e.target.closest('#shNo')){$('#lpShufBox').innerHTML='';return}
    if(e.target.closest('#shGo')){const from=l.ag,to=$('#shTo').value,why=$('#shWhy').value;l.ag=to;l.last='Just now';l.notes.unshift({text:`Shuffled from ${from} to ${to}. Reason: ${why}`,when:'Just now'});draw();toast(`Shuffled to ${to}. Both agents notified.`);L.notify(`Lead shuffled to ${to.split(' ')[0]}`,`${l.n} moved from ${from}. ${why}.`,l.n);L.emit('leads');return}
    if(e.target.closest('#lpNoteAdd')){const t=$('#lpNote'),v=t.value.trim();if(!v){t.focus();return}l.notes.unshift({text:v,when:'Just now'});l.last='Just now';draw();toast('Note added');L.emit('leads');return}
    const rm=e.target.closest('[data-rmdoc]');if(rm){l.docs.splice(+rm.dataset.rmdoc,1);draw();return}
    const pl=e.target.closest('[data-play]');if(pl){const i=+pl.dataset.play;if(play&&play.i===i){stopPlay();return}stopPlay();const r=l.recs[i];play={i,pos:r.pos||0,spd:1};pl.innerHTML='<svg viewBox="0 0 24 24"><path d="M7 5h4v14H7zM13 5h4v14h-4z"/></svg>';$(`[data-rec="${i}"]`).classList.add('on');
      play.t=setInterval(()=>{const sp=+($(`[data-spd="${i}"]`)||{textContent:'1'}).textContent.replace('x','');play.pos+=0.1*sp;r.pos=play.pos;if(play.pos>=r.dur){r.pos=0;paint(i,r.dur);stopPlay();return}paint(i,play.pos)},100);return}
    const sk=e.target.closest('[data-seek]');if(sk){const i=+sk.dataset.seek,rc=sk.getBoundingClientRect(),r=l.recs[i];r.pos=Math.max(0,Math.min(1,(e.clientX-rc.left)/rc.width))*r.dur;if(play&&play.i===i)play.pos=r.pos;paint(i,r.pos);return}
    const sp=e.target.closest('[data-spd]');if(sp){const v={'1x':'1.5x','1.5x':'2x','2x':'1x'}[sp.textContent];sp.textContent=v;return}
  });
  box.addEventListener('change',e=>{
    if(e.target.id==='lpAs'&&e.target.value!=='__'){const to=e.target.value,from=l.ag,r=L.adRefs.find(a=>a.ref===l.ref);l.ag=to;l.last='Just now';
      l.notes.unshift({text:to?(from?`Re-assigned from ${from} to ${to}`:`Assigned to ${to}`):`Unassigned from ${from}`,when:'Just now'});
      if(to&&!from&&r&&!r.owner){r.owner=to;r.how='learned';toast(`Assigned. LeadVolt learned that ad ${r.ref} belongs to ${to}.`);L.emit('refs')}else toast(to?'Assigned to '+to:'Lead is now unassigned');
      if(to)L.notify(`New lead for ${to.split(' ')[0]}`,`${l.n} · ${l.proj}`,l.n);draw();L.emit('leads')}
    if(e.target.id==='lpFile'){[...e.target.files].forEach(f=>l.docs.push({name:f.name,ext:(f.name.split('.').pop()||'FILE').slice(0,4).toUpperCase(),size:f.size>1e6?(f.size/1e6).toFixed(1)+' MB':Math.max(1,Math.round(f.size/1e3))+' KB',when:'just now'}));tab='Documents';draw();toast('Document added to '+l.n)}});
  box.addEventListener('submit',e=>{if(e.target.id!=='lpStF')return;e.preventDefault();const old=l.st,to=stSel||l.st,when=$('#lpWhen').value,note=$('#lpStN').value.trim(),x=$('#lpX').value;
    l.st=to;l.last='Just now';l.days=0;l.notes.unshift({text:`Status ${old===to?'updated':'changed from '+old+' to '+to}${when?' · '+(to==='Booked'?'booked on ':'follow-up ')+when.replace('T',' '):''}${to==='Booked'&&x?' · agreement AED '+x:''}${note?' · '+note:''}`,when:'Just now'});
    if(when&&to!=='Booked'&&L.tasks){const d=new Date(when),t0=new Date();t0.setHours(0,0,0,0);L.tasks.unshift({id:'T'+Date.now(),t:to+' with '+l.n,lead:l.n,type:/Visit/.test(to)?'Site visit':/Meeting/.test(to)?'Meeting':'Call',off:Math.round((new Date(d.getFullYear(),d.getMonth(),d.getDate())-t0)/864e5),pri:'High',ag:l.ag||'Obaid Raza',at:d.toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit'}),done:false});L.emit('tasks')}
    stSel=null;tab='Overview';draw();toast(`${l.n} moved to ${to}${when&&to!=='Booked'?' · reminder added to Tasks':''}`);if(to==='Booked'){burst(innerWidth-320,160,140)}L.emit('leads')});
  const drop=()=>$('#lpDrop');box.addEventListener('dragover',e=>{if(drop()&&e.target.closest('#lpDrop')){e.preventDefault();drop().classList.add('over')}});box.addEventListener('drop',e=>{if(!e.target.closest('#lpDrop'))return;e.preventDefault();const f=$('#lpFile');[...e.dataTransfer.files].forEach(fl=>l.docs.push({name:fl.name,ext:(fl.name.split('.').pop()||'FILE').slice(0,4).toUpperCase(),size:Math.max(1,Math.round(fl.size/1e3))+' KB',when:'just now'}));draw()});
}
L.openProfile=preview;
/* ---------- Add Project / Add Listing (open on the same page) ---------- */
/* ---------- Add Project wizard (opens on the Projects page) ---------- */
(function(){
const SPR={
  'a-pool':'<path d="M3 17c1.5 0 1.5 1 3 1s1.5-1 3-1 1.5 1 3 1 1.5-1 3-1 1.5 1 3 1 1.5-1 3-1"/><path d="M8 14V5a2 2 0 0 1 4 0M16 14V5a2 2 0 0 0-4 0M8 9h8"/>',
  'a-gym':'<path d="M6 8v8M3 10v4M18 8v8M21 10v4M6 12h12"/>',
  'a-park':'<path d="M12 21v-6"/><path d="M12 3a5 5 0 0 1 5 5 4 4 0 0 1-1 7H8a4 4 0 0 1-1-7 5 5 0 0 1 5-5z"/>',
  'a-car':'<path d="M5 16l1.5-5h11L19 16"/><rect x="3" y="16" width="18" height="3" rx="1"/><circle cx="7" cy="19" r="1"/><circle cx="17" cy="19" r="1"/>',
  'a-shield':'<path d="M12 3l8 3v6c0 4.5-3.4 8-8 9-4.6-1-8-4.5-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
  'a-lift':'<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 9l3-3 3 3M9 15l3 3 3-3"/>',
  'a-kids':'<circle cx="12" cy="6" r="2"/><path d="M12 8v6M8 11h8M10 21l2-7 2 7"/>',
  'a-bbq':'<path d="M4 10h16a8 8 0 0 1-16 0z"/><path d="M8 18l-2 3M16 18l2 3M9 6c0-1 1-1 1-2M14 6c0-1 1-1 1-2"/>',
  'a-wifi':'<path d="M3 9a14 14 0 0 1 18 0M6 12.5a9 9 0 0 1 12 0M9 16a4 4 0 0 1 6 0"/><circle cx="12" cy="19" r="1"/>',
  'a-spa':'<path d="M12 20c-5 0-8-3-8-7 3 0 6 1 8 4 2-3 5-4 8-4 0 4-3 7-8 7z"/><path d="M12 17c-2-3-2-7 0-11 2 4 2 8 0 11z"/>',
  'a-shop':'<path d="M4 9l1-5h14l1 5M4 9v11h16V9M4 9h16"/><path d="M10 20v-6h4v6"/>',
  'a-beach':'<path d="M4 20h16M12 20l-3-12"/><path d="M4 9a8 8 0 0 1 14-3z"/>',
  'a-golf':'<path d="M9 21V3l8 4-8 4"/><path d="M5 21h10"/>',
  'a-power':'<path d="M13 3L5 14h6l-1 7 8-11h-6z"/>',
  'a-water':'<path d="M12 3c4 5 6 8 6 11a6 6 0 0 1-12 0c0-3 2-6 6-11z"/>',
  'a-pray':'<path d="M5 21V11l7-6 7 6v10M9 21v-5a3 3 0 0 1 6 0v5"/>',
  'a-con':'<path d="M4 18h16M6 18a6 6 0 0 1 12 0M12 9V7M10 7h4"/>',
  'a-home':'<path d="M4 11l8-7 8 7v9H4z"/><path d="M9 20v-5h6v5"/>',
  'a-cine':'<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M10 9.5v5l4-2.5z"/>',
  'a-run':'<circle cx="14" cy="5" r="2"/><path d="M10 21l2-6 3 2v4M7 12l3-3h4l2 4h3"/>',
  'a-pet':'<circle cx="8" cy="8" r="1.6"/><circle cx="16" cy="8" r="1.6"/><circle cx="5" cy="13" r="1.4"/><circle cx="19" cy="13" r="1.4"/><path d="M12 12c-3 0-5 4-5 6s2 2 5 2 5 0 5-2-2-6-5-6z"/>',
  'a-cam':'<rect x="3" y="7" width="13" height="10" rx="2"/><path d="M16 11l5-3v8l-5-3"/>',
  'a-up':'<path d="M12 19V5M6 11l6-6 6 6"/>','a-star':'<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
  'a-img':'<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-9 9"/>',
  'a-vid':'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M10 9v6l5-3z"/>',
  'a-pdf':'<path d="M6 3h9l4 4v14H6z"/><path d="M14 3v5h5M9 13h6M9 17h4"/>',
  'a-link':'<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
  'a-grip':'<circle cx="9" cy="6" r="1"/><circle cx="15" cy="6" r="1"/><circle cx="9" cy="12" r="1"/><circle cx="15" cy="12" r="1"/><circle cx="9" cy="18" r="1"/><circle cx="15" cy="18" r="1"/>',
  'a-trash':'<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>','a-back':'<path d="M15 6l-6 6 6 6"/>','a-blocks':'<rect x="3" y="10" width="7" height="11"/><rect x="14" y="4" width="7" height="17"/><path d="M6 14h1M6 17h1M17 8h1M17 11h1M17 14h1"/>',
  'a-minus':'<path d="M6 12h12"/>'
};
const sp=document.querySelector('svg[style*="display:none"],svg.sprite')||document.querySelector('svg symbol')?.parentNode;
if(sp)sp.insertAdjacentHTML('beforeend',Object.entries(SPR).map(([k,v])=>`<symbol id="${k}" viewBox="0 0 24 24">${v}</symbol>`).join(''));
const ic=(id,a='')=>`<svg class="i" ${a}><use href="#${id}"/></svg>`;
const {$,$$,esc,burst,fmt}=L;
const SUBT={Residential:['Apartment','Villa','Townhouse','Penthouse','Duplex','Plot'],Commercial:['Office','Shop','Showroom','Warehouse','Hotel Apartment','Building'],Agricultural:['Farm House','Farm Land','Land']};
const STAT=['Off Plan','Under Construction','Ready to Move','New Launch'];
const CERT=['Freehold','Leasehold','Oqood','Title Deed','Usufruct'];
const FACE=['East','West','North','South','North-East','North-West','South-East','South-West'];
const UTYPE=['Studio','1 BR','2 BR','3 BR','4 BR','5 BR+','Shop','Office'];
const AM={Basic:[['Covered parking','a-car'],['24/7 security','a-shield'],['Elevators','a-lift'],['Power backup','a-power'],['Water supply','a-water'],['CCTV','a-cam'],['Wi-Fi ready','a-wifi'],['Prayer room','a-pray'],['Pet friendly','a-pet'],['Concierge','a-con']],
  Featured:[['Swimming pool','a-pool'],['Gym','a-gym'],['Landscaped park','a-park'],['Kids play area','a-kids'],['BBQ area','a-bbq'],['Spa & sauna','a-spa'],['Retail podium','a-shop'],['Beach access','a-beach'],['Golf view','a-golf'],['Smart home','a-home'],['Cinema room','a-cine'],['Jogging track','a-run']]};
const STEPS=[['Basic Details','Name, type, pricing and dates'],['Units / Shops','Unit types and inventory'],['Blocks Info','Towers, phases and floors'],['Amenities','What the project offers'],['Gallery','Photos, videos and brochures']];
const LIM={photo:[10,'image/jpeg,image/png,image/bmp,image/webp'],video:[200,'video/mp4'],doc:[25,'application/pdf']};
const blank=()=>({n:'',type:'Residential',sub:'Apartment',st:'Off Plan',area:'',land:'',unit:'Sq. Ft',cert:'Freehold',face:[],blocks:0,floors:0,desc:'',notes:'',dev:'',pocs:[],rera:[''],min:'',max:'',brok:'',brokT:'%',start:'',end:'',poss:'',units:[],blks:[],am:[],photos:[],videos:[],docs:[],urls:[]});
const DK='lv-proj-draft';
const saveDraft=W=>{try{const c={...W,photos:[],videos:[],docs:[]};localStorage.setItem(DK,JSON.stringify(c))}catch(e){}};
const loadDraft=()=>{try{const d=JSON.parse(localStorage.getItem(DK)||'null');return d&&d.n!==undefined?d:null}catch(e){return null}};
const clearDraft=()=>{try{localStorage.removeItem(DK)}catch(e){}};
const mb=b=>b>1048576?(b/1048576).toFixed(1)+' MB':Math.max(1,Math.round(b/1024))+' KB';

L.addProject=function(){
  if(L.curName!=='Projects'){L.navTo('Projects');return setTimeout(L.addProject,80)}
  const el=$('#pages > .page[data-page="projects"]');if(!el)return;
  if(el.querySelector('.wiz'))return el.querySelector('.wiz input')?.focus();
  const pg=el.querySelector('.pg');const d=loadDraft();const W=blank();let step=0,done=new Set();
  const wz=document.createElement('div');wz.className='wiz';el.appendChild(wz);if(pg)pg.hidden=true;window.scrollTo(0,0);
  wz.innerHTML=`<div class="wz-top"><button class="rbtn" id="wzBack" aria-label="Back to projects">${ic('a-back')}</button><div style="flex:1;min-width:0"><h2>Add project</h2><small id="wzSaved">Fill in the steps below. Your text is saved as a draft as you type.</small></div>${d&&d.n?`<button class="ghost" id="wzDraft">${ic('i-pen')}Continue draft “${esc(d.n)}”</button>`:''}</div>
    <ol class="wz-steps" id="wzSt"></ol>
    <div class="wz-grid"><div class="wz-body panel" id="wzB"></div>
      <aside class="wz-side"><div class="panel wz-prev" id="wzP"></div></aside></div>
    <div class="wz-foot"><button class="ghost" id="wzCancel">Cancel</button><span class="sp"></span><button class="ghost" id="wzPrev">${ic('a-back')}Back</button><button class="btn-primary rip" id="wzNext"></button></div>`;
  const B=$('#wzB',wz);
  const close=(msg)=>{wz.remove();if(pg)pg.hidden=false;window.scrollTo(0,0);if(msg)toastA(msg)};
  const toastA=m=>{L.toast(m);L.audit&&L.audit(m,'','Projects')};
  function steps(){$('#wzSt',wz).innerHTML=STEPS.map((s,i)=>`<li class="${i===step?'on':''} ${done.has(i)&&i!==step?'ok':''}"><button data-step="${i}" ${i>step&&!done.has(i-1)&&!done.has(i)?'disabled':''} aria-current="${i===step?'step':'false'}"><span class="dot">${done.has(i)&&i!==step?ic('i-check'):i+1}</span><span class="tx"><b>${s[0]}</b><small>${s[1]}</small></span></button></li>`).join('');
    $('#wzPrev',wz).hidden=step===0;$('#wzNext',wz).innerHTML=step===4?`${ic('i-check')}Save and finish`:`Save and go to next${ic('i-arrow')}`}
  function pct(){const f=[W.n,W.type,W.sub,W.st,W.area,W.dev,W.min,W.max,W.poss,W.desc,W.rera.some(Boolean),W.units.length,W.blks.length,W.am.length,W.photos.length,W.docs.length];return Math.round(f.filter(Boolean).length/f.length*100)}
  function prev(){const c=W.photos.find(p=>p.cover)||W.photos[0];const p=pct();
    $('#wzP',wz).innerHTML=`<h3>Live preview</h3><div class="pv-img">${c?`<img src="${c.url}" alt="">`:`<div class="pv-ph">${ic('a-img')}<small>Cover photo shows here</small></div>`}<span class="ptag ${W.st==='Ready to Move'?'rd':'op'}">${esc(W.st)}</span></div>
      <b class="pv-n">${esc(W.n||'Project name')}</b><div class="pv-l">${ic('i-pin')}${esc(W.area||'Location')} · ${esc(W.dev||'Developer')}</div>
      <div class="pv-pr">${W.min?'AED '+fmt(+W.min):'AED —'}${W.max?' – '+fmt(+W.max):''}</div>
      <div class="pv-f"><span>${esc(W.sub)}</span><span>${W.units.reduce((a,u)=>a+(+u.qty||1),0)} units</span><span>${W.blks.length} blocks</span><span>${W.am.length} amenities</span><span>${W.photos.length} photos</span></div>
      <div class="pv-c"><div style="display:flex;justify-content:space-between"><span>Listing quality</span><b class="num">${p}%</b></div><div class="bar"><i style="width:${p}%;${p>=80?'background:var(--pos)':''}"></i></div><small>${p>=80?'Great. Portals rank complete projects higher.':'Add photos, units and a brochure to reach 80%.'}</small></div>`}
  const fld=(lab,inner,cls='',req)=>`<label class="fld ${cls}"><span>${lab}${req?'<i class="rq">*</i>':''}</span>${inner}</label>`;
  const sel=(id,arr,v)=>`<select id="${id}">${arr.map(o=>`<option ${o===v?'selected':''}>${o}</option>`).join('')}</select>`;
  const ctr=(k,lab)=>`<div class="fld"><span>${lab}</span><div class="ctr" data-ctr="${k}"><button type="button" data-d="-1" aria-label="Fewer ${lab}">${ic('a-minus')}</button><input inputmode="numeric" value="${W[k]}" data-k="${k}" aria-label="${lab}"><button type="button" data-d="1" aria-label="More ${lab}">${ic('i-plus')}</button></div></div>`;
  const R={
  0(){B.innerHTML=`<h3 class="wz-h">Basic details</h3>
    <div class="wz-f">${fld('Project name',`<input data-k="n" value="${esc(W.n)}" placeholder="e.g. Silicon Heights">`,'full',1)}<span class="err full" id="eN"></span>
    <div class="fld full"><span>Project type<i class="rq">*</i></span><div class="chips2" id="wzT">${Object.keys(SUBT).map(t=>`<button type="button" data-t="${t}" aria-pressed="${W.type===t}">${t}</button>`).join('')}</div></div>
    <div class="fld full"><span>Sub-type</span><div class="chips2 sm" id="wzS">${SUBT[W.type].map(t=>`<button type="button" data-s="${t}" aria-pressed="${W.sub===t}">${t}</button>`).join('')}</div></div>
    ${fld('Status',sel('wzStat',STAT,W.st),'',1)}${fld('Location / community',`<input data-k="area" value="${esc(W.area)}" placeholder="e.g. Dubai Silicon Oasis" list="wzAl"><datalist id="wzAl">${[...new Set(L.props.map(p=>p.area))].map(a=>`<option>${esc(a)}</option>`).join('')}</datalist>`)}
    <div class="fld"><span>Land area</span><div class="two-in"><input data-k="land" inputmode="decimal" value="${esc(W.land)}" placeholder="e.g. 45000">${sel('wzU',['Sq. Ft','Sq. M','Acre','Hectare'],W.unit)}</div></div>
    ${fld('Certificate',sel('wzC',CERT,W.cert))}
    <div class="fld full"><span>Facing</span><div class="chips2 sm" id="wzFc">${FACE.map(f=>`<button type="button" data-f="${f}" aria-pressed="${W.face.includes(f)}">${f}</button>`).join('')}</div></div>
    ${ctr('blocks','Total blocks')}${ctr('floors','Total floors')}
    ${fld('Description',`<textarea data-k="desc" rows="3" maxlength="2000" placeholder="What makes this project special. Shown on the project page and shared brochures.">${esc(W.desc)}</textarea><small class="cnt2">${W.desc.length}/2000</small>`,'full')}
    ${fld('Internal notes',`<textarea data-k="notes" rows="2" placeholder="Only your team sees this.">${esc(W.notes)}</textarea>`,'full')}
    </div><h3 class="wz-h">Builder / developer</h3><div class="wz-f">
    ${fld('Builder name',`<input data-k="dev" value="${esc(W.dev)}" placeholder="e.g. Northgate Estates" list="wzDl"><datalist id="wzDl">${[...new Set(L.props.map(p=>p.dev))].map(a=>`<option>${esc(a)}</option>`).join('')}</datalist>`,'full')}
    <div class="full" id="wzPoc">${W.pocs.map((p,i)=>`<div class="poc"><input data-poc="${i}" data-pk="n" value="${esc(p.n)}" placeholder="Contact name" aria-label="Contact name"><input data-poc="${i}" data-pk="ph" value="${esc(p.ph)}" inputmode="tel" placeholder="+971 5x xxx xxxx" aria-label="Phone"><button type="button" class="rbtn" data-rmpoc="${i}" aria-label="Remove contact">${ic('a-trash')}</button></div>`).join('')}<button type="button" class="lnk" id="wzAddPoc">${ic('i-plus')}Add point of contact</button></div>
    </div><h3 class="wz-h">RERA &amp; pricing</h3><div class="wz-f">
    <div class="fld full"><span>RERA / permit numbers</span><div id="wzRera">${W.rera.map((r,i)=>`<div class="poc"><input data-rera="${i}" value="${esc(r)}" placeholder="e.g. 0123456789" aria-label="RERA number ${i+1}">${W.rera.length>1?`<button type="button" class="rbtn" data-rmrera="${i}" aria-label="Remove">${ic('a-trash')}</button>`:''}</div>`).join('')}</div><button type="button" class="lnk" id="wzAddRera">${ic('i-plus')}Add another number</button></div>
    ${fld('Minimum price (AED)',`<input data-k="min" inputmode="numeric" value="${esc(W.min)}" placeholder="e.g. 850000">`,'',1)}${fld('Maximum price (AED)',`<input data-k="max" inputmode="numeric" value="${esc(W.max)}" placeholder="e.g. 3200000">`)}
    <span class="err full" id="eP"></span>
    <div class="fld"><span>Brokerage</span><div class="two-in"><input data-k="brok" inputmode="decimal" value="${esc(W.brok)}" placeholder="${W.brokT==='%'?'e.g. 2':'e.g. 25000'}"><div class="seg-in" id="wzBT">${['%','AED'].map(t=>`<button type="button" data-bt="${t}" aria-pressed="${W.brokT===t}">${t}</button>`).join('')}</div></div></div>
    <div class="fld"><span>Brokerage on min price</span><div class="calc-o" id="wzBc">—</div></div>
    </div><h3 class="wz-h">Dates</h3><div class="wz-f three">
    ${fld('Start date',`<input type="date" data-k="start" value="${W.start}">`)}${fld('End date',`<input type="date" data-k="end" value="${W.end}">`)}${fld('Possession / handover',`<input type="date" data-k="poss" value="${W.poss}">`)}<span class="err full" id="eD"></span></div>`;
    brokCalc()},
  1(){const types=[...new Set(W.units.map(u=>u.type))];
    B.innerHTML=`<div class="wz-hr"><h3 class="wz-h">Units / shops <em class="num">${W.units.reduce((a,u)=>a+(+u.qty||1),0)}</em></h3><button type="button" class="ghost" id="wzBulk">${ic('i-list')}Bulk add by floor</button></div>
    <form class="unitf" id="wzUf" novalidate>${fld('Unit name / no.',`<input id="uN" placeholder="e.g. SH-1204 or Type A">`,'',1)}${fld('Type',sel('uT',UTYPE,'1 BR'))}${fld('Size (sq ft)',`<input id="uS" inputmode="numeric" placeholder="750">`)}${fld('Price (AED)',`<input id="uP" inputmode="numeric" placeholder="1,250,000">`)}${fld('Block',`<select id="uB"><option value="">—</option>${W.blks.map(b=>`<option>${esc(b.n)}</option>`).join('')}</select>`)}${fld('Quantity',`<input id="uQ" inputmode="numeric" value="1">`)}${fld('Furnishing',sel('uF',['Unfurnished','Semi furnished','Furnished'],'Unfurnished'))}${fld('View',sel('uV',['—','Community','Lake','Sea','Burj Khalifa','Golf','Park'],'—'))}<button class="btn-primary rip" type="submit">${ic('i-plus')}Add new shop / unit</button><span class="err full" id="eU"></span></form>
    <div id="wzBulkF" hidden class="bulkf"><b>Bulk add</b><small>Creates one unit per floor, named prefix + floor + number (e.g. SH-1204).</small><div class="wz-f four">${fld('Prefix',`<input id="bkP" value="${esc((W.n||'U').split(' ').map(w=>w[0]).join('').toUpperCase())}-">`)}${fld('Floors from',`<input id="bkF" inputmode="numeric" value="1">`)}${fld('to',`<input id="bkT" inputmode="numeric" value="${W.floors||10}">`)}${fld('Units per floor',`<input id="bkN" inputmode="numeric" value="4">`)}</div><button type="button" class="btn-primary" id="bkGo">Generate units</button></div>
    ${W.units.length?`<div class="tblw"><table class="utbl"><thead><tr><th>Unit</th><th>Type</th><th>Size</th><th>Price</th><th>Block</th><th>Qty</th><th>Status</th><th></th></tr></thead><tbody>${W.units.slice(0,200).map((u,i)=>`<tr><td><b>${esc(u.n)}</b></td><td>${esc(u.type)}</td><td>${u.size?fmt(+u.size)+' sq ft':'—'}</td><td>${u.price?'AED '+fmt(+u.price):'—'}</td><td>${esc(u.blk||'—')}</td><td class="num">${u.qty}</td><td><span class="bdg ok">Available</span></td><td><button type="button" class="rbtn" data-rmu="${i}" aria-label="Remove ${esc(u.n)}">${ic('a-trash')}</button></td></tr>`).join('')}</tbody></table>${W.units.length>200?`<small class="muted">Showing 200 of ${W.units.length}.</small>`:''}</div>
      <div class="umix">${types.map(t=>{const c=W.units.filter(u=>u.type===t).reduce((a,u)=>a+(+u.qty||1),0);return `<span><b class="num">${c}</b>${esc(t)}</span>`}).join('')}</div>`
    :`<div class="empty2">${ic('a-blocks')}<b>No units added yet</b><small>Add unit types one by one, or use bulk add to create a whole tower in seconds. You can also skip this and add units later.</small></div>`}`},
  2(){B.innerHTML=`<div class="wz-hr"><h3 class="wz-h">Blocks <em class="num">${W.blks.length}</em></h3></div>
    <form class="unitf" id="wzBf" novalidate>${fld('Block / tower name',`<input id="bN" placeholder="e.g. Tower A">`,'',1)}${fld('Floors',`<input id="bF" inputmode="numeric" placeholder="${W.floors||20}">`)}${fld('Units per floor',`<input id="bU" inputmode="numeric" placeholder="6">`)}${fld('Phase',sel('bP',['Phase 1','Phase 2','Phase 3'],'Phase 1'))}${fld('Handover',`<input id="bH" type="date" value="${W.poss}">`)}${fld('Construction %',`<input id="bC" inputmode="numeric" placeholder="0–100">`)}<button class="btn-primary rip" type="submit">${ic('i-plus')}Add new block</button><span class="err full" id="eB"></span></form>
    ${W.blks.length?`<div class="bcards">${W.blks.map((b,i)=>`<div class="bcard" style="--i:${i}"><div class="bv">${Array.from({length:Math.min(b.f||1,14)},(_,k)=>`<i style="opacity:${.35+.65*((k+1)/Math.min(b.f||1,14))}"></i>`).join('')}</div><div style="min-width:0;flex:1"><b>${esc(b.n)}</b><small>${b.f||'—'} floors · ${b.u||'—'} per floor · ${esc(b.ph)}</small><small>${b.h?'Handover '+new Date(b.h).toLocaleDateString('en-GB',{month:'short',year:'numeric'}):'Handover not set'}</small><div class="bar"><i style="width:${b.c||0}%"></i></div><small>${b.c||0}% built</small></div><button type="button" class="rbtn" data-rmb="${i}" aria-label="Remove ${esc(b.n)}">${ic('a-trash')}</button></div>`).join('')}</div>`
    :`<div class="empty2">${ic('a-blocks')}<b>No blocks added yet</b><small>Split the project into towers or phases so agents can filter units and track construction for each one.</small></div>`}`},
  3(){B.innerHTML=`<div class="wz-hr"><h3 class="wz-h">Amenities <em class="num" id="amC">${W.am.length}</em></h3><label class="field sm">${ic('i-search')}<input id="amQ" placeholder="Search amenities" autocomplete="off"></label></div>
    ${Object.entries(AM).map(([g,arr])=>`<div class="amg" data-g="${g}"><div class="amh"><b>${g}</b><label class="ck"><input type="checkbox" data-all="${g}" ${arr.every(a=>W.am.includes(a[0]))?'checked':''}>Select all</label></div><div class="amt">${arr.map(a=>`<button type="button" class="amb" data-am="${esc(a[0])}" aria-pressed="${W.am.includes(a[0])}"><span class="ai">${ic(a[1])}</span><span>${esc(a[0])}</span><span class="tick">${ic('i-check')}</span></button>`).join('')}</div></div>`).join('')}
    <div class="amg"><div class="amh"><b>Custom</b></div><form class="poc" id="amAdd"><input id="amN" placeholder="Add your own, e.g. Padel court" aria-label="Custom amenity"><button class="ghost" type="submit">${ic('i-plus')}Add</button></form><div class="amt" id="amCu">${W.am.filter(a=>!Object.values(AM).flat().some(x=>x[0]===a)).map(a=>`<button type="button" class="amb" data-am="${esc(a)}" aria-pressed="true"><span class="ai">${ic('a-star')}</span><span>${esc(a)}</span><span class="tick">${ic('i-check')}</span></button>`).join('')}</div></div>`},
  4(){const zone=(k,t,sub,icn,acc)=>`<div class="gz" data-z="${k}"><div class="gzh"><span class="ai">${ic(icn)}</span><div><b>${t}</b><small>${sub}</small></div><span class="num cnt3">${W[k==='photo'?'photos':k==='video'?'videos':'docs'].length}</span></div>
      <label class="drop" data-drop="${k}"><input type="file" multiple accept="${acc}" data-in="${k}" hidden>${ic('a-up')}<b>Drop files here or <u>browse</u></b><small>${sub}</small></label><div class="gl ${k}" id="gl-${k}"></div></div>`;
    B.innerHTML=`<h3 class="wz-h">Gallery</h3><p class="muted" style="margin:-4px 0 14px">The first photo is the cover. Drag photos to reorder, or tap the star to choose a different cover.</p>
    ${zone('photo','Photos','JPG, PNG or BMP · up to 10 MB each','a-img',LIM.photo[1])}${zone('video','Videos','MP4 · up to 200 MB each','a-vid',LIM.video[1])}${zone('doc','Brochures & floor plans','PDF · up to 25 MB each','a-pdf',LIM.doc[1])}
    <div class="gz"><div class="gzh"><span class="ai">${ic('a-link')}</span><div><b>Third-party links</b><small>YouTube, Vimeo, Matterport 3D tour, Google Drive</small></div></div><form class="poc" id="urF"><input id="urI" inputmode="url" placeholder="https://" aria-label="Link"><button class="ghost" type="submit">${ic('i-plus')}Add link</button></form><span class="err" id="eL"></span><div id="urL" class="url-l"></div></div>`;
    gal()}
  };
  function gal(){const ph=$('#gl-photo',B);if(!ph)return;
    ph.innerHTML=W.photos.map((p,i)=>`<div class="gph ${p.cover?'cv':''}" draggable="true" data-i="${i}"><img src="${p.url}" alt="${esc(p.name)}"><span class="grip">${ic('a-grip')}</span>${p.cover?'<span class="cvt">Cover</span>':''}<div class="gact"><button type="button" data-cov="${i}" aria-label="Make cover" title="Make cover">${ic('a-star')}</button><button type="button" data-rm="photos:${i}" aria-label="Remove ${esc(p.name)}">${ic('i-x')}</button></div><small>${esc(p.name)} · ${mb(p.size)}</small></div>`).join('');
    $('#gl-video',B).innerHTML=W.videos.map((v,i)=>`<div class="gvd"><video src="${v.url}" muted preload="metadata" controls></video><div class="gm"><span>${esc(v.name)}<small>${mb(v.size)}</small></span><button type="button" class="rbtn" data-rm="videos:${i}" aria-label="Remove ${esc(v.name)}">${ic('a-trash')}</button></div></div>`).join('');
    $('#gl-doc',B).innerHTML=W.docs.map((v,i)=>`<div class="gdc"><span class="ai pdf">PDF</span><span class="gm2"><b>${esc(v.name)}</b><small>${mb(v.size)}</small></span><a class="rbtn" href="${v.url}" target="_blank" rel="noopener" aria-label="Open ${esc(v.name)}">${ic('i-eye')}</a><button type="button" class="rbtn" data-rm="docs:${i}" aria-label="Remove ${esc(v.name)}">${ic('a-trash')}</button></div>`).join('');
    $('#urL',B).innerHTML=W.urls.map((u,i)=>{const h=(()=>{try{return new URL(u).hostname.replace('www.','')}catch(e){return u}})();const k=/youtu/.test(h)?'YouTube':/vimeo/.test(h)?'Vimeo':/matterport/.test(h)?'3D tour':/drive\.google|dropbox/.test(h)?'Cloud folder':'Link';return `<div class="gdc"><span class="ai">${ic('a-link')}</span><span class="gm2"><b>${k}</b><small>${esc(u)}</small></span><button type="button" class="rbtn" data-rm="urls:${i}" aria-label="Remove link">${ic('a-trash')}</button></div>`}).join('');
    $$('.gz .cnt3',B).forEach((c,i)=>c.textContent=[W.photos,W.videos,W.docs][i].length);prev()}
  function addFiles(kind,files){const [max,acc]=LIM[kind],key=kind==='photo'?'photos':kind==='video'?'videos':'docs';let bad=0,big=0,dup=0;
    [...files].forEach(f=>{if(!acc.split(',').includes(f.type)){bad++;return}if(f.size>max*1048576){big++;return}if(W[key].some(x=>x.name===f.name&&x.size===f.size)){dup++;return}W[key].push({name:f.name,size:f.size,type:f.type,url:URL.createObjectURL(f),cover:false})});
    if(kind==='photo'&&W.photos.length&&!W.photos.some(p=>p.cover))W.photos[0].cover=true;
    const msg=[bad&&bad+' skipped (wrong file type)',big&&big+' skipped (over '+max+' MB)',dup&&dup+' already added'].filter(Boolean).join(', ');
    L.toast(msg||files.length+' file'+(files.length>1?'s':'')+' added');gal()}
  function brokCalc(){const o=$('#wzBc',B);if(!o)return;const b=parseFloat(W.brok),m=+W.min;o.textContent=b>0&&m>0?'AED '+fmt(Math.round(W.brokT==='%'?m*b/100:b))+(W.brokT==='AED'?' ('+(b/m*100).toFixed(2)+'%)':''):'—'}
  function valid(s){if(s!==0)return true;let ok=true;const e=(id,m)=>{const x=$('#'+id,B);if(x)x.textContent=m;if(m)ok=false};
    const n=W.n.trim();e('eN',!n?'Enter the project name.':L.props.some(p=>p.n.toLowerCase()===n.toLowerCase())?'A project with this name already exists.':'');
    const mn=+W.min,mx=+W.max;e('eP',!(mn>0)?'Enter a minimum price in AED, e.g. 850000.':mx&&mx<mn?'Maximum price must be higher than the minimum.':'');
    e('eD',W.start&&W.end&&W.end<W.start?'End date must be after the start date.':W.start&&W.poss&&W.poss<W.start?'Handover must be after the start date.':'');
    if(!ok){const f=B.querySelector('.err:not(:empty)');f&&f.scrollIntoView({behavior:'smooth',block:'center'});B.animate([{transform:'translateX(0)'},{transform:'translateX(-6px)'},{transform:'translateX(6px)'},{transform:'translateX(0)'}],{duration:260})}
    return ok}
  function go(s){step=s;R[s]();steps();prev();B.classList.remove('in');void B.offsetWidth;B.classList.add('in');const f=B.querySelector('input:not([type=checkbox]):not([type=file])');f&&f.focus({preventScroll:true});wz.scrollIntoView({block:'start'})}
  function finish(){const n=W.n.trim(),k=L.props.length,cols=[['#0B6BE6','#9DC2F7'],['#5B3FD1','#F4A6B5'],['#12805C','#BDEBD3'],['#2B2F3A','#7DB4FF'],['#0957C3','#FFD38A']][k%5];
    const units=W.units.reduce((a,u)=>a+(+u.qty||1),0)||W.blks.reduce((a,b)=>a+(+b.f||0)*(+b.u||0),0)||100,op=W.st!=='Ready to Move',cov=W.photos.find(p=>p.cover)||W.photos[0];
    const bt=[...new Set(W.units.map(u=>u.type))];
    L.props.unshift({n,area:W.area||'Dubai',dev:W.dev||'—',st:op?'Off Plan':'Ready',from:+(+W.min/1e6).toFixed(2),to:+W.max||null,units,sold:0,beds:bt.length?bt.join(', '):W.sub,size:W.land?fmt(+W.land)+' '+W.unit:'—',c:cols,seed:20+k,water:0,prog:op?5:100,hand:op?(W.poss||new Date(Date.now()+730*864e5).toISOString().slice(0,10)):null,plan:[20,30,50],am:[...W.am],about:W.desc||'New project added by '+(L.me||'Obaid Raza')+'.',cover:cov?cov.url:null,type:W.type,sub:W.sub,cert:W.cert,face:W.face,rera:W.rera.filter(Boolean),brok:W.brok?W.brok+(W.brokT==='%'?'%':' AED'):'',pocs:W.pocs,blocks:W.blks,unitList:W.units,photos:W.photos,videos:W.videos,docs:W.docs,urls:W.urls,start:W.start,end:W.end});
    if(L.projects&&!L.projects.includes(n))L.projects.push(n);clearDraft();
    close();L.audit&&L.audit('Project created',`${n} · ${units} units · ${W.blks.length} blocks · ${W.am.length} amenities · ${W.photos.length} photos · ${W.docs.length} brochures`,'Projects');L.toast(n+' added to Projects');burst(innerWidth/2,200,140);L.emit('props')}
  // events
  wz.addEventListener('input',e=>{const t=e.target;
    if(t.dataset.k){let v=t.value;if(['min','max'].includes(t.dataset.k)){v=v.replace(/[^\d]/g,'');if(t.value!==fmt(+v)&&v){const c=t.selectionStart;t.value=fmt(+v)}}if(['blocks','floors'].includes(t.dataset.k))v=Math.max(0,parseInt(v)||0);W[t.dataset.k]=v;if(t.dataset.k==='desc'){const c=t.parentNode.querySelector('.cnt2');if(c)c.textContent=v.length+'/2000'}brokCalc()}
    if(t.dataset.poc!=null)W.pocs[+t.dataset.poc][t.dataset.pk]=t.value;
    if(t.dataset.rera!=null)W.rera[+t.dataset.rera]=t.value;
    if(t.id==='amQ'){const q=t.value.toLowerCase();$$('.amb',B).forEach(b=>b.hidden=q&&!b.dataset.am.toLowerCase().includes(q));$$('.amg',B).forEach(g=>{const t2=g.querySelector('.amt');g.hidden=!!q&&t2&&![...t2.children].some(b=>!b.hidden)})}
    prev();clearTimeout(wz._t);wz._t=setTimeout(()=>{saveDraft(W);const s=$('#wzSaved',wz);s.textContent='Draft saved '+new Date().toLocaleTimeString([],{hour:'numeric',minute:'2-digit'})},500)});
  wz.addEventListener('change',e=>{const t=e.target;
    if(t.id==='wzStat')W.st=t.value;if(t.id==='wzU')W.unit=t.value;if(t.id==='wzC')W.cert=t.value;
    if(t.dataset.in){addFiles(t.dataset.in,t.files);t.value=''}
    if(t.dataset.all){const g=AM[t.dataset.all].map(a=>a[0]);W.am=t.checked?[...new Set([...W.am,...g])]:W.am.filter(a=>!g.includes(a));$$(`.amg[data-g="${t.dataset.all}"] .amb`,B).forEach(b=>b.setAttribute('aria-pressed',W.am.includes(b.dataset.am)));$('#amC',B).textContent=W.am.length}
    prev();saveDraft(W)});
  wz.addEventListener('click',e=>{const c=k=>e.target.closest(k);let b;
    if(c('#wzBack')||c('#wzCancel')){const dirty=W.n||W.photos.length||W.units.length;if(dirty&&!wz._sure){wz._sure=1;const x=c('#wzCancel')||c('#wzBack');L.toast('Tap again to leave. Your text stays saved as a draft.');setTimeout(()=>wz._sure=0,2500);return}close();return}
    if(c('#wzDraft')){Object.assign(W,blank(),loadDraft());c('#wzDraft').remove();go(0);L.toast('Draft restored');return}
    if(c('#wzNext')){if(!valid(step))return;done.add(step);if(step===4)return finish();go(step+1);return}
    if(c('#wzPrev')){go(Math.max(0,step-1));return}
    if(b=c('[data-step]')){const s=+b.dataset.step;if(s>step&&!valid(step))return;if(s>step)for(let i=step;i<s;i++)done.add(i);go(s);return}
    if(b=c('[data-t]')){W.type=b.dataset.t;W.sub=SUBT[W.type][0];R[0]();prev();return}
    if(b=c('[data-s]')){W.sub=b.dataset.s;$$('#wzS button',B).forEach(x=>x.setAttribute('aria-pressed',x===b));prev();return}
    if(b=c('[data-f]')){const f=b.dataset.f;W.face=W.face.includes(f)?W.face.filter(x=>x!==f):[...W.face,f];b.setAttribute('aria-pressed',W.face.includes(f));return}
    if(b=c('[data-ctr] button')){const k=b.closest('[data-ctr]').dataset.ctr;W[k]=Math.max(0,(+W[k]||0)+ +b.dataset.d);b.parentNode.querySelector('input').value=W[k];prev();return}
    if(b=c('[data-bt]')){W.brokT=b.dataset.bt;$$('#wzBT button',B).forEach(x=>x.setAttribute('aria-pressed',x===b));brokCalc();return}
    if(c('#wzAddPoc')){W.pocs.push({n:'',ph:''});R[0]();$$('[data-pk="n"]',B).pop().focus();return}
    if(b=c('[data-rmpoc]')){W.pocs.splice(+b.dataset.rmpoc,1);R[0]();return}
    if(c('#wzAddRera')){W.rera.push('');R[0]();$$('[data-rera]',B).pop().focus();return}
    if(b=c('[data-rmrera]')){W.rera.splice(+b.dataset.rmrera,1);R[0]();return}
    if(c('#wzBulk')){$('#wzBulkF',B).hidden=!$('#wzBulkF',B).hidden;return}
    if(c('#bkGo')){const p=$('#bkP',B).value,f=+$('#bkF',B).value||1,t=+$('#bkT',B).value||f,n=+$('#bkN',B).value||1;if(t<f||(t-f+1)*n>2000){L.toast('Check the floor range (max 2,000 units at once).');return}
      const ty=$('#uT',B).value;for(let fl=f;fl<=t;fl++)for(let u=1;u<=n;u++)W.units.push({n:p+fl+String(u).padStart(2,'0'),type:ty,size:$('#uS',B).value.replace(/\D/g,''),price:$('#uP',B).value.replace(/\D/g,''),blk:$('#uB',B).value,qty:1});
      R[1]();prev();L.toast(((t-f+1)*n)+' units generated');return}
    if(b=c('[data-rmu]')){W.units.splice(+b.dataset.rmu,1);R[1]();prev();return}
    if(b=c('[data-rmb]')){W.blks.splice(+b.dataset.rmb,1);R[2]();prev();return}
    if(b=c('.amb')){const a=b.dataset.am;W.am=W.am.includes(a)?W.am.filter(x=>x!==a):[...W.am,a];b.setAttribute('aria-pressed',W.am.includes(a));$('#amC',B).textContent=W.am.length;
      Object.keys(AM).forEach(g=>{const x=B.querySelector(`[data-all="${g}"]`);if(x)x.checked=AM[g].every(y=>W.am.includes(y[0]))});prev();return}
    if(b=c('[data-cov]')){W.photos.forEach((p,i)=>p.cover=i===+b.dataset.cov);gal();L.toast('Cover photo updated');return}
    if(b=c('[data-rm]')){const [k,i]=b.dataset.rm.split(':');const it=W[k].splice(+i,1)[0];if(it&&it.url&&it.url.startsWith('blob:'))URL.revokeObjectURL(it.url);if(k==='photos'&&W.photos.length&&!W.photos.some(p=>p.cover))W.photos[0].cover=true;gal();return}
  });
  wz.addEventListener('submit',e=>{e.preventDefault();const f=e.target;
    if(f.id==='wzUf'){const n=$('#uN',B).value.trim();$('#eU',B).textContent=n?'':'Enter a unit name or number.';if(!n)return;
      W.units.push({n,type:$('#uT',B).value,size:$('#uS',B).value.replace(/\D/g,''),price:$('#uP',B).value.replace(/\D/g,''),blk:$('#uB',B).value,qty:Math.max(1,parseInt($('#uQ',B).value)||1),furn:$('#uF',B).value,view:$('#uV',B).value});R[1]();prev();$('#uN',B).focus()}
    if(f.id==='wzBf'){const n=$('#bN',B).value.trim();$('#eB',B).textContent=!n?'Enter a block name.':W.blks.some(b=>b.n.toLowerCase()===n.toLowerCase())?'That block already exists.':'';if($('#eB',B).textContent)return;
      W.blks.push({n,f:parseInt($('#bF',B).value)||W.floors||0,u:parseInt($('#bU',B).value)||0,ph:$('#bP',B).value,h:$('#bH',B).value,c:Math.min(100,Math.max(0,parseInt($('#bC',B).value)||0))});W.blocks=Math.max(W.blocks,W.blks.length);R[2]();prev();$('#bN',B).focus()}
    if(f.id==='amAdd'){const v=$('#amN',B).value.trim();if(v&&!W.am.includes(v)){W.am.push(v);R[3]();prev()}}
    if(f.id==='urF'){const v=$('#urI',B).value.trim();let ok=false;try{ok=/^https?:$/.test(new URL(v).protocol)}catch(x){}$('#eL',B).textContent=ok?'':'Enter a full link starting with https://';if(!ok)return;if(!W.urls.includes(v))W.urls.push(v);$('#urI',B).value='';gal()}
    saveDraft(W)});
  // drag & drop files + reorder photos
  wz.addEventListener('dragover',e=>{const d=e.target.closest('[data-drop]');if(d){e.preventDefault();d.classList.add('ov')}const g=e.target.closest('.gph');if(g&&wz._drag!=null)e.preventDefault()});
  wz.addEventListener('dragleave',e=>{const d=e.target.closest('[data-drop]');if(d)d.classList.remove('ov')});
  wz.addEventListener('dragstart',e=>{const g=e.target.closest('.gph');if(g){wz._drag=+g.dataset.i;g.classList.add('dg');e.dataTransfer.effectAllowed='move'}});
  wz.addEventListener('dragend',()=>{wz._drag=null;$$('.gph.dg',wz).forEach(x=>x.classList.remove('dg'))});
  wz.addEventListener('drop',e=>{const d=e.target.closest('[data-drop]');if(d){e.preventDefault();d.classList.remove('ov');if(e.dataTransfer.files.length)addFiles(d.dataset.drop,e.dataTransfer.files);return}
    const g=e.target.closest('.gph');if(g&&wz._drag!=null){e.preventDefault();const to=+g.dataset.i,it=W.photos.splice(wz._drag,1)[0];W.photos.splice(to,0,it);wz._drag=null;gal()}});
  go(0);
};
})();

L.addListing=function(){L.setLast(document.activeElement);
  L.layer.innerHTML=`<div class="veil" data-close></div><div class="modal" style="width:min(620px,calc(100% - 32px))" role="dialog" aria-modal="true" aria-label="Add listing"><header><h3>Add listing</h3><button class="x" data-close aria-label="Close">${icon('i-x')}</button></header><form id="alF" novalidate>
    <label class="fld">Project<select id="alP">${L.props.map(p=>`<option>${esc(p.n)}</option>`).join('')}</select></label><label class="fld">Unit number<input id="alU" placeholder="e.g. MV-1804"><span class="err" id="alUe"></span></label>
    <label class="fld">Type<select id="alT">${['Studio','1BR','2BR','3BR','4BR','Villa','Office'].map(t=>`<option ${t==='2BR'?'selected':''}>${t}</option>`).join('')}</select></label><label class="fld">Size (sqft)<input id="alS" inputmode="numeric" placeholder="1,180"></label>
    <label class="fld">Floor<input id="alF2" placeholder="18"></label><label class="fld">View<select id="alV"><option>Sea</option><option>Marina</option><option>City</option><option>Park</option><option>Golf</option><option>Burj</option></select></label>
    <label class="fld">Price (AED)<input id="alPr" inputmode="numeric" placeholder="1,950,000"><span class="err" id="alPre"></span></label><label class="fld">Real owner (for leads)<select id="alO">${L.team.map(u=>`<option ${u.n==='Obaid Raza'?'selected':''}>${esc(u.n)}</option>`).join('')}</select></label>
    <div class="fld full">Publish to portals<div style="display:grid;gap:8px;margin-top:4px">${['Bayut','Property Finder','Dubizzle'].map(p=>`<div style="display:grid;grid-template-columns:auto 130px minmax(0,1fr) minmax(0,1fr);gap:8px;align-items:center"><label class="sw"><input type="checkbox" data-pub="${p}" aria-label="Publish on ${p}"><span></span></label><span class="portal" style="background:${PORTC[p]};justify-self:start">${p}</span><span style="font-size:var(--fs-xs);color:var(--muted)">Ref ID comes from ${p}</span><select data-under="${p}" style="height:34px;border:1px solid var(--line);border-radius:8px;min-width:0">${L.team.map(u=>`<option ${u.n==='Ashfaq Haji Haroon'?'selected':''}>${esc(u.n)}</option>`).join('')}</select></div>`).join('')}</div><small style="color:var(--muted)">Posted under is whose portal account the ad uses. Leads still go to the real owner.</small></div>
    <div class="actions"><button type="button" class="ghost" data-close>Cancel</button><button class="btn-primary rip" type="submit">${icon('i-check')}Add listing</button></div></form></div>`;
  $('#alU').focus();
  $('#alF').addEventListener('submit',e=>{e.preventDefault();const id=$('#alU').value.trim(),pr=parseFloat($('#alPr').value.replace(/[^\d.]/g,''));$('#alUe').textContent=id?(L.units.some(u=>u.id===id)?'That unit number already exists.':''):'Enter the unit number.';$('#alPre').textContent=pr>0?'':'Enter the price.';if(!id||$('#alUe').textContent||!(pr>0))return;
    const proj=$('#alP').value,owner=$('#alO').value,size=+$('#alS').value.replace(/[^\d]/g,'')||1000;L.units.unshift({id,proj,type:$('#alT').value,size,fl:$('#alF2').value||'—',view:$('#alV').value,price:pr,st:'Available',for:''});
    let pubs=0;$$('#alF [data-pub]').forEach(c=>{if(!c.checked)return;const p=c.dataset.pub;L.adRefs.unshift({ref:'pending-'+Date.now()+p,pending:true,portal:p,listing:proj+' · '+$('#alT').value,posted:$(`#alF [data-under="${p}"]`).value,owner,how:'set',leads:0,last:'—'});pubs++});
    L.closeLayer();toast(`${id} added${pubs?'. Sent to '+pubs+' portal'+(pubs>1?'s':'')+'; Ref IDs will arrive from the portal. Leads route to '+owner:''}`);burst(innerWidth/2,200,100);L.emit('units');L.emit('refs')})};
/* ===================== v1.1: shared list engine for Leads and Data ===================== */
['Not Interested','Dropped','Booking Cancel'].forEach(s=>{if(!STS.includes(s))STS.push(s)});
Object.assign(STC,{'Not Interested':'#C0262B',Dropped:'#8A91A2','Booking Cancel':'#9A5B00'});
L.SUBST={New:['Fresh enquiry'],Callback:['Follow Up','Not Reachable','Switch off','Busy'],'Meeting Done':['Meeting Done','Meeting Scheduled'],'Site Visit Done':['Visit Done','Visit Scheduled'],Overdue:['Follow Up'],'Not Interested':['Did not inquire','Different Requirements','Unmatched Budget','Different Location'],Dropped:['Dropped'],Booked:['Booked'],'Booking Cancel':['Booking Cancel'],Invoiced:['Invoiced']};
L.leads.forEach((l,i)=>{if(l.st!=='New'&&!l.ag){} if(i%9===4)l.st='Not Interested';if(i%13===6)l.st='Dropped';if(i===27)l.st='Booking Cancel';
  if(!l.sub){const o=L.SUBST[l.st]||[l.st];l.sub=o[i%o.length]}if(l.del==null)l.del=i%17===9;if(l.dup==null)l.dup=i%11===5?1:0;if(l.reenq==null)l.reenq=i%8===3?1+i%3:0;if(l.eoi==null)l.eoi=i%6===2&&['New','Callback','Meeting Done','Site Visit Done'].includes(l.st)});
const daysOf=s=>/just|today/i.test(s||'')?0:/yesterday/i.test(s||'')?1:parseInt(s)||0;
function listEngine(el,C){
  const S={scope:C.scopes[0][0],grp:Object.keys(C.groups)[0],sub:'',q:'',when:'',sort:C.sort||'days',dir:1,page:0,per:+(L.store.get('lv-per-'+C.key)||10),sel:new Set(),view:C.board?(L.store.get('lv-view-'+C.key)||'table'):'table',
    cols:new Set(JSON.parse(L.store.get('lv-cols-'+C.key)||'null')||C.cols.filter(c=>c.def!==false).map(c=>c.k))};
  if(C.preset)C.preset(S);
  el.innerHTML=`<div class="pg">${head(C.title,C.sub,C.headActs||'')}${C.kpis?'<div class="kpis" id="kp"></div>':''}<div id="callout"></div>
    <div class="scopes" id="scp"></div><div class="grps" id="grp"></div>
    <div class="tbar"><label class="field">${icon('i-search')}<input id="q" placeholder="${C.searchPh||'Type to search'}" autocomplete="off"></label>
      <select class="sel" id="when" aria-label="Received"><option value="">Any time</option><option value="0">Today</option><option value="7">Last 7 days</option><option value="30">Last 30 days</option></select>
      <button class="ghost" id="exp">${icon('i-cloud')}Export</button>
      <div class="colpick"><button class="ghost" id="colB" aria-expanded="false">${icon('i-layout')}Manage Columns</button><div class="pop" id="colP" hidden><h4>Show columns</h4>${C.cols.filter(c=>!c.fixed).map(c=>`<label><input type="checkbox" class="cb" data-col="${c.k}" ${S.cols.has(c.k)?'checked':''}>${c.label}</label>`).join('')}</div></div>
      ${C.board?`<div class="seg2" id="vw"><span class="th"></span><button data-v="table" aria-pressed="${S.view==='table'}">${icon('i-list')}Table</button><button data-v="board" aria-pressed="${S.view==='board'}">${icon('i-layout')}Board</button></div>`:''}
      <select class="sel" id="per" aria-label="Rows per page">${[10,25,50].map(n=>`<option ${n===S.per?'selected':''}>${n}</option>`).join('')}</select></div>
    <div id="bulk"></div><div id="body"></div></div>`;
  const base=()=>C.rows();
  const inScope=r=>{const f=C.scopes.find(x=>x[0]===S.scope);return f[1](r)};
  const inGrp=r=>{const g=C.groups[S.grp];if(!g.match(r))return false;if(!S.sub)return true;const sb=(g.subs||[]).find(x=>x[0]===S.sub);return sb?sb[1](r):true};
  function list(){const q=S.q.toLowerCase().replace(/\s/g,'');let r=base().filter(x=>inScope(x)&&(S.view==='board'||inGrp(x))&&(!q||C.search(x).toLowerCase().replace(/\s/g,'').includes(q))&&(S.when===''||daysOf(x.created)<=+S.when));
    const col=C.cols.find(c=>c.k===S.sort);if(col&&col.sv)r=r.slice().sort((a,b)=>{const A=col.sv(a),B=col.sv(b);return (typeof A==='string'?A.localeCompare(B):A-B)*S.dir});return r}
  function scopes(){$('#scp',el)?0:0;el.querySelector('#scp').innerHTML=C.scopes.map(([n,f,ic])=>`<button data-sc="${n}" aria-pressed="${S.scope===n}">${icon(ic||'i-users')}${n}<em class="num">${base().filter(f).length}</em></button>`).join('')+`<div class="sr">${C.scopeRight||''}</div>`}
  function grps(){const g=C.groups[S.grp],pool=base().filter(inScope);el.querySelector('#grp').innerHTML=`<select id="gs" aria-label="Status group">${Object.keys(C.groups).map(k=>`<option ${k===S.grp?'selected':''}>${k}</option>`).join('')}</select><span class="num" style="font-size:var(--fs-xs);color:var(--muted);margin:0 6px">${pool.filter(g.match).length}</span>${(g.subs||[]).map(([n,f])=>`<button class="sb" data-sb="${n}" aria-pressed="${S.sub===n}">${n}<em class="num">${pool.filter(x=>g.match(x)&&f(x)).length}</em></button>`).join('')}${S.sub?`<button class="sb" data-sb="" title="Clear">${icon('i-x','style="width:13px;height:13px"')}</button>`:''}`;el.querySelector('#grp').style.display=S.view==='board'?'none':'flex'}
  function bulk(){const n=S.sel.size;el.querySelector('#bulk').innerHTML=n?`<div class="bulk"><b class="num">${n} selected</b>${C.bulk?C.bulk():''}<button class="link" id="bClr">Clear selection</button></div>`:''}
  function table(){const r=list();L.curLeadList=C.key==='leads'?r:L.curLeadList;const pages=Math.max(1,Math.ceil(r.length/S.per));S.page=Math.min(S.page,pages-1);const rows=r.slice(S.page*S.per,(S.page+1)*S.per),cols=C.cols.filter(c=>c.fixed||S.cols.has(c.k));
    const all=rows.length&&rows.every(x=>S.sel.has(x.id)),some=rows.some(x=>S.sel.has(x.id));
    el.querySelector('#body').innerHTML=`<div class="panel" style="padding:8px 8px 12px"><div class="tbl-wrap"><table class="tbl"><thead><tr><th style="width:36px"><input type="checkbox" class="cb" id="cAll" aria-label="Select all on page" ${all?'checked':''}></th>${cols.map(c=>c.sv?`<th class="sort ${S.sort===c.k?'on':''} ${S.sort===c.k&&S.dir<0?'desc':''}" data-k="${c.k}">${c.label}<span class="ar">▲</span></th>`:`<th>${c.label}</th>`).join('')}<th style="text-align:right">Actions</th></tr></thead><tbody>
      ${rows.map((x,i)=>`<tr style="--r:${i}" class="${S.sel.has(x.id)?'sel':''}"><td><input type="checkbox" class="cb" data-cb="${x.id}" aria-label="Select" ${S.sel.has(x.id)?'checked':''}></td>${cols.map(c=>`<td>${c.html(x)}</td>`).join('')}<td><div class="ia">${C.actions(x)}</div></td></tr>`).join('')}</tbody></table>
      ${r.length?'':`<div class="empty-st"><b>Nothing here</b>${C.empty||'Try another tab, status or search.'}</div>`}</div>
      <div class="pager"><span class="num">Showing ${r.length?S.page*S.per+1:0} – ${Math.min(r.length,(S.page+1)*S.per)} of ${r.length} entries</span><div class="pb"><button data-pg="first" ${S.page===0?'disabled':''} aria-label="First page">«</button><button data-pg="prev" ${S.page===0?'disabled':''} aria-label="Previous page">‹</button>${[...new Set([0,S.page-1,S.page,S.page+1,pages-1])].filter(p=>p>=0&&p<pages).map(p=>`<button data-pg="${p}" ${p===S.page?'aria-current="page"':''}>${p+1}</button>`).join('')}<button data-pg="next" ${S.page>=pages-1?'disabled':''} aria-label="Next page">›</button><button data-pg="last" ${S.page>=pages-1?'disabled':''} aria-label="Last page">»</button></div><label class="goto">Go to<input id="goto" inputmode="numeric" placeholder="${S.page+1}" aria-label="Go to page">of ${pages}</label></div></div>`;
    const ca=el.querySelector('#cAll');if(ca)ca.indeterminate=some&&!all}
  function draw(){if(C.kpis)C.kpis(el.querySelector('#kp'));if(C.callout)el.querySelector('#callout').innerHTML=C.callout(S);scopes();grps();bulk();if(S.view==='board'&&C.board)C.board(el.querySelector('#body'),list());else table()}
  el._refresh=()=>{if(C.preset)C.preset(S);draw()};L.on(C.key,()=>{if(el.isConnected)draw()});if(C.key==='leads')L.on('leads',()=>{});
  draw();
  const g=s=>el.querySelector(s);
  g('#q').addEventListener('input',e=>{S.q=e.target.value;S.page=0;S.view==='board'?draw():table()});
  g('#when').addEventListener('change',e=>{S.when=e.target.value;S.page=0;draw()});
  g('#per').addEventListener('change',e=>{S.per=+e.target.value;L.store.set('lv-per-'+C.key,String(S.per));S.page=0;table()});
  g('#colB').addEventListener('click',e=>{e.stopPropagation();const p=g('#colP');p.hidden=!p.hidden;g('#colB').setAttribute('aria-expanded',String(!p.hidden))});
  document.addEventListener('click',e=>{if(!e.target.closest('.colpick')&&g('#colP'))g('#colP').hidden=true});
  g('#colP').addEventListener('change',e=>{const k=e.target.dataset.col;e.target.checked?S.cols.add(k):S.cols.delete(k);L.store.set('lv-cols-'+C.key,JSON.stringify([...S.cols]));table()});
  g('#exp').addEventListener('click',()=>{const r=list(),cols=C.cols.filter(c=>c.fixed||S.cols.has(c.k));L.tracker.unshift({type:'Export',what:C.title+' · '+r.length+' rows',at:new Date(),by:'Obaid Raza',status:'Completed'});const csv=[cols.map(c=>c.label).join(','),...r.map(x=>cols.map(c=>'"'+String(c.csv?c.csv(x):'').replace(/"/g,'""')+'"').join(','))].join('\n');try{navigator.clipboard.writeText(csv).then(()=>toast(`${r.length} rows copied. Paste into Excel or Google Sheets.`),()=>toast('Copy blocked by the browser'))}catch(x){toast('Copy blocked by the browser')}});
  if(C.board)g('#vw').addEventListener('click',e=>{const b=e.target.closest('[data-v]');if(!b)return;S.view=b.dataset.v;L.store.set('lv-view-'+C.key,S.view);$$('#vw button',el).forEach(x=>x.setAttribute('aria-pressed',x===b));segPos(g('#vw'));draw()});
  el.addEventListener('change',e=>{const t=e.target;
    if(t.id==='gs'){S.grp=t.value;S.sub='';S.page=0;draw();return}
    if(t.id==='cAll'){list().slice(S.page*S.per,(S.page+1)*S.per).forEach(x=>t.checked?S.sel.add(x.id):S.sel.delete(x.id));bulk();table();return}
    const cb=t.closest('[data-cb]');if(cb){cb.checked?S.sel.add(cb.dataset.cb):S.sel.delete(cb.dataset.cb);bulk();cb.closest('tr').classList.toggle('sel',cb.checked);return}
    if(t.id==='goto'){const n=parseInt(t.value)-1,pages=Math.ceil(list().length/S.per);if(n>=0&&n<pages){S.page=n;table()}else{t.value='';toast('Enter a page between 1 and '+pages)}return}
    if(C.onBulk&&t.closest('.bulk')&&t.value){L.tracker.unshift({type:'Bulk Operation',what:`${C.title} · ${t.options[t.selectedIndex].text} · ${S.sel.size} records`,at:new Date(),by:'Obaid Raza',status:'Completed'});C.onBulk(t.id,t.value,[...S.sel]);S.sel.clear();L.emit(C.key)}});
  el.addEventListener('click',e=>{const t=e.target;
    const sc=t.closest('[data-sc]');if(sc){S.scope=sc.dataset.sc;S.page=0;draw();return}
    const sb=t.closest('[data-sb]');if(sb){S.sub=sb.dataset.sb;S.page=0;draw();return}
    const th=t.closest('th.sort');if(th){const k=th.dataset.k;S.dir=S.sort===k?-S.dir:1;S.sort=k;table();return}
    const pg=t.closest('[data-pg]');if(pg){const v=pg.dataset.pg,pages=Math.ceil(list().length/S.per);S.page=v==='first'?0:v==='last'?pages-1:v==='prev'?S.page-1:v==='next'?S.page+1:+v;table();return}
    if(t.id==='bClr'){S.sel.clear();draw();return}
    const ac=t.closest('[data-ia]');if(ac&&C.onAction){C.onAction(ac.dataset.ia,base().find(x=>x.id===ac.dataset.id),ac);return}
    if(C.onClick)C.onClick(e,S,draw)});
  return S;
}
L.listEngine=listEngine;
const iaBtn=(k,id,ic,bg,fg,tip)=>`<button data-ia="${k}" data-id="${id}" style="background:${bg};color:${fg}" title="${tip}" aria-label="${tip}">${icon(ic)}</button>`;
const agCell=x=>x.ag?`<span style="font-weight:500">${esc(x.ag)}</span>`:'<span class="unas-s">Unassigned</span>';

/* ---------- Leads page (rebuilt) ---------- */
pages.leads=function(el){
  const ME='Obaid Raza',act=x=>['New','Callback','Meeting Done','Site Visit Done','Overdue'].includes(x.st),live=x=>!x.del;
  const st1=x=>`<div class="two"><b class="s1" style="color:${STC[x.st]||'var(--blue)'}">${x.st}</b><small>${esc(x.sub||'')}</small></div>`;
  const S=listEngine(el,{key:'leads',title:'Manage Leads',sub:'Every enquiry from every portal, routed to the right agent.',
    headActs:`<div class="colpick"><button class="ghost" id="trB" aria-expanded="false">${icon('i-list')}Tracker</button><div class="pop" id="trP" hidden><h4>Tracker</h4><button class="note" style="width:100%;border:0;background:none;text-align:left" data-tr="Bulk Upload">${icon('i-cloud')}<div><b>Bulk Upload</b><small>Imports and their results</small></div></button><button class="note" style="width:100%;border:0;background:none;text-align:left" data-tr="Export">${icon('i-inbox')}<div><b>Export Tracker</b><small>Every export, who and when</small></div></button><button class="note" style="width:100%;border:0;background:none;text-align:left" data-tr="Bulk Operation">${icon('i-layout')}<div><b>Bulk Operation</b><small>Mass assigns, shuffles and status changes</small></div></button></div></div><button class="ghost" id="lSim">${icon('i-spark')}Test Bayut lead</button><button class="ghost" id="lImp">${icon('i-cloud')}Import</button><button class="btn-primary rip" id="lAdd">${icon('i-plus')}Add Lead</button>`,
    searchPh:'Search name, phone, project or ref ID',board:true,
    preset:S=>{if(L.leadsPreset){if(L.leadsPreset==='__unassigned')S.scope='Unassigned';else{S.scope='All';S.q=L.leadsPreset;setTimeout(()=>{const q=el.querySelector('#q');if(q)q.value=S.q},0)}L.leadsPreset=null}},
    rows:()=>L.leads,
    scopes:[['All',live,'i-grid'],['My Leads',x=>live(x)&&x.ag===ME,'i-users'],["Team's",x=>live(x)&&!!x.ag&&x.ag!==ME,'i-team'],['Unassigned',x=>live(x)&&!x.ag,'i-alert'],['Deleted',x=>x.del,'i-x'],['Duplicate',x=>live(x)&&x.dup>0,'i-list'],['Re Enquired',x=>live(x)&&x.reenq>0,'i-arrow']],
    scopeRight:'',
    groups:{'All Leads':{match:()=>true},'Active Leads':{match:act,subs:[['New',x=>x.st==='New'],['Pending',x=>x.st==='Callback'],['Scheduled',x=>/Scheduled/.test(x.sub)],['Overdue',x=>x.st==='Overdue'],['Expression Of Interest',x=>x.eoi]]},
      'Not Interested':{match:x=>x.st==='Not Interested',subs:L.SUBST['Not Interested'].map(s=>[s,x=>x.sub===s])},'Dropped':{match:x=>x.st==='Dropped'},'Booked':{match:x=>x.st==='Booked'},'Booking Cancel':{match:x=>x.st==='Booking Cancel'},'Invoiced':{match:x=>x.st==='Invoiced'}},
    search:x=>x.n+x.ph+x.proj+(x.ref||'')+(x.email||''),
    cols:[{k:'n',label:'Lead name',fixed:1,sv:x=>x.n,csv:x=>x.n,html:x=>`<div class="who">${av(x.ini,x.c)}<div style="min-width:0"><button class="lead-link" data-lead="${esc(x.n)}">${esc(x.n)}</button>${x.dup?'<span class="bdg d">D'+x.dup+'</span>':''}${x.reenq?'<span class="bdg re">RE-'+x.reenq+'</span>':''}${x.eoi?'<span class="bdg eoi">EOI</span>':''}${L.tagDots(x)}<small class="num">${esc(x.ph)}</small></div></div>`},
      {k:'ag',label:'Assigned to',sv:x=>x.ag||'~',csv:x=>x.ag||'Unassigned',html:agCell},
      {k:'src',label:'Source',sv:x=>x.src,csv:x=>x.src+' / '+(x.subSrc||''),html:x=>`<div class="two"><b>${esc(x.src)}</b><small>${esc(x.subSrc||'')}</small></div>`},
      {k:'st',label:'Status',sv:x=>x.st,csv:x=>x.st+' / '+(x.sub||''),html:st1},
      {k:'proj',label:'Project',sv:x=>x.proj,csv:x=>x.proj,html:x=>esc(x.proj)},
      {k:'bn',label:'Budget',sv:x=>x.bn,csv:x=>x.bud,html:x=>`<span class="num">${esc(x.bud)}</span>`},
      {k:'score',label:'Score',def:false,sv:x=>x.score,csv:x=>x.score,html:x=>`<b class="num" style="color:${x.score>=80?'var(--pos)':x.score>=60?'var(--warn)':'var(--muted)'}">${x.score}</b>`},
      {k:'ref',label:'Ad Ref ID',def:false,sv:x=>x.ref||'',csv:x=>x.ref||'',html:x=>`<span class="num">${esc(x.ref||'—')}</span>`},
      {k:'days',label:'Last contact',sv:x=>x.days,csv:x=>x.last,html:x=>esc(x.last)}],
    actions:x=>iaBtn('open',x.id,'i-pen','#E5F5EE','#12805C','Open lead')+iaBtn('hist',x.id,'i-cal','#FBEBDD','#A05A1C','History')+iaBtn('wa',x.id,'i-msg','#E3F7EA','#1E8E4E','WhatsApp')+iaBtn('call',x.id,'i-phone','#E2F0FE','#0B6BE6','Call')+(x.recs&&x.recs.length?iaBtn('rec',x.id,'i-bellring','#FFF3DC','#9A5B00','Call recording'):'')+iaBtn(x.del?'restore':'del',x.id,x.del?'i-arrow':'i-x',x.del?'#E5F5EE':'#FDECEC',x.del?'#12805C':'#C0262B',x.del?'Restore':'Delete'),
    kpis:box=>{const A=L.leads.filter(live),hot=A.filter(l=>l.tags.includes('Hot')||l.score>=80).length,un=A.filter(l=>!l.ag).length,bk=A.filter(l=>l.st==='Booked'||l.st==='Invoiced').length;
      box.innerHTML=[['i-users','var(--blue-50)','var(--blue)','Total leads',A.length],['i-spark','#FFF3DC','#9A5B00','Hot leads',hot],['i-alert','var(--warn-bg)','var(--warn)','Unassigned',un],['i-check','#E3E5EA','#2B2F3A','Booked or invoiced',bk]].map((k,i)=>`<div class="kpi" style="--i:${i}"><span class="ki" style="background:${k[1]};color:${k[2]}">${icon(k[0])}</span><div><small>${k[3]}</small><b class="num" data-v="${k[4]}">0</b></div></div>`).join('');box.querySelectorAll('b').forEach(b=>L.countTo(b,+b.dataset.v))},
    callout:S=>{const un=L.leads.filter(l=>live(l)&&!l.ag).length;return un&&S.scope!=='Unassigned'?`<div class="callout">${icon('i-alert')}<span><b>${un} leads are waiting for an owner.</b> Assign them once and leads from the same ads will route automatically.</span><button data-sc="Unassigned">Show unassigned</button></div>`:''},
    bulk:()=>`<select id="bAg" aria-label="Assign selected"><option value="">Assign to…</option>${L.team.map(a=>`<option>${esc(a.n)}</option>`).join('')}</select><select id="bSh" aria-label="Shuffle selected"><option value="">Shuffle…</option><option value="__even">Spread evenly across agents</option>${L.team.map(a=>`<option>${esc(a.n)}</option>`).join('')}</select><select id="bSt" aria-label="Change status"><option value="">Change status…</option>${STS.map(s=>`<option>${s}</option>`).join('')}</select><select id="bTg" aria-label="Tag"><option value="">Tag as…</option><option>Hot</option><option>Warm</option><option>Cold</option></select>`,
    onBulk:(id,v,ids)=>{const ls=ids.map(i=>L.leads.find(x=>x.id===i)).filter(Boolean),ags=L.team.filter(t=>!/Manager/.test(t.role)&&t.n!=='Obaid Raza').map(t=>t.n);
      if(id==='bAg'||id==='bSh'){ls.forEach((l,k)=>{const from=l.ag,to=v==='__even'?ags[k%ags.length]:v;l.ag=to;l.notes.unshift({text:`${id==='bSh'?'Shuffled':'Assigned'} from ${from||'Unassigned'} to ${to}`,when:'Just now'});const r=L.adRefs.find(a=>a.ref===l.ref);if(!from&&r&&!r.owner){r.owner=to;r.how='learned'}});toast(v==='__even'?`${ls.length} leads spread across ${ags.length} agents`:`${ls.length} leads ${id==='bSh'?'shuffled':'assigned'} to ${v}`);L.notify(id==='bSh'?'Leads shuffled':'Leads assigned',`${ls.length} leads → ${v==='__even'?'whole team':v}`);L.emit('refs')}
      if(id==='bSt'){ls.forEach(l=>{l.st=v;l.sub=(L.SUBST[v]||[v])[0];l.last='Just now'});toast(`${ls.length} leads moved to ${v}`);if(v==='Booked')burst(innerWidth/2,160,140)}
      if(id==='bTg'){ls.forEach(l=>{l.tags=l.tags.filter(t=>!TAGS.includes(t));l.tags.push(v)});toast(`${ls.length} leads tagged ${v}`)}
      L.emit('leads')},
    onAction:(k,x,btn)=>{if(!x)return;if(k==='open')L.openProfile(x);if(k==='hist'){L.openProfile(x);setTimeout(()=>{const t=$('.lp [data-t="History"]');if(t)t.click()},50)}if(k==='rec'){L.openProfile(x);setTimeout(()=>{const t=$('.lp [data-t="Calls"]');if(t)t.click()},50)}
      if(k==='wa')toast('WhatsApp opened for '+x.n+' (demo)');if(k==='call')toast('Calling '+x.n+' (demo)');
      if(k==='del'){x.del=true;toast(x.n+' moved to Deleted. You can restore it from the Deleted tab.');L.emit('leads')}if(k==='restore'){x.del=false;toast(x.n+' restored');L.emit('leads')}},
    board:(box,r)=>{const cols=STS;box.innerHTML=`<div class="board">${cols.map((s,i)=>{const c=r.filter(l=>l.st===s),sum=c.reduce((a,l)=>a+l.bn,0);return `<div class="col" data-col="${s}" style="--i:${i}"><h4><i style="background:${STC[s]}"></i>${s}<em class="num">${c.length} · ${moneyM(sum)}</em></h4><div class="stack">${c.map(l=>`<div class="kcard" draggable="true" data-id="${l.id}" style="border-left-color:${STC[s]}"><div class="h">${av(l.ini,l.c)}<div style="min-width:0"><button class="lead-link" data-lead="${esc(l.n)}">${esc(l.n)}</button>${L.tagDots(l)}</div></div><div class="m"><span>${esc(l.proj)}</span><strong class="num">${esc(l.bud)}</strong></div><div class="m"><span>${l.ag?esc(l.ag):'<span class="unas-s">Unassigned</span>'}</span><span>${esc(l.sub||'')}</span></div></div>`).join('')}</div></div>`}).join('')}</div>`}
  });
  el.querySelector('#trB').addEventListener('click',e=>{e.stopPropagation();const p=el.querySelector('#trP');p.hidden=!p.hidden});
  document.addEventListener('click',e=>{if(!e.target.closest('#trP')&&!e.target.closest('#trB')){const p=el.querySelector('#trP');if(p)p.hidden=true}});
  el.querySelector('#trP').addEventListener('click',e=>{const b=e.target.closest('[data-tr]');if(!b)return;el.querySelector('#trP').hidden=true;L.openTracker(b.dataset.tr)});
  el.querySelector('#lAdd').addEventListener('click',()=>L.openAdd());el.querySelector('#lImp').addEventListener('click',()=>L.navTo('Data'));el.querySelector('#lSim').addEventListener('click',()=>L.simulateLead());
  let dragId=null;
  el.addEventListener('dragstart',e=>{const k=e.target.closest('.kcard');if(!k)return;dragId=k.dataset.id;k.classList.add('drag');e.dataTransfer.effectAllowed='move';try{e.dataTransfer.setData('text/plain',dragId)}catch(x){}});
  el.addEventListener('dragend',e=>{const k=e.target.closest('.kcard');if(k)k.classList.remove('drag');$$('.col.over').forEach(c=>c.classList.remove('over'))});
  el.addEventListener('dragover',e=>{const c=e.target.closest('.col');if(!c||!dragId)return;e.preventDefault();$$('.col.over').forEach(x=>x!==c&&x.classList.remove('over'));c.classList.add('over')});
  el.addEventListener('drop',e=>{const c=e.target.closest('.col');if(!c||!dragId)return;e.preventDefault();const l=L.leads.find(x=>x.id===dragId),to=c.dataset.col;dragId=null;if(!l||l.st===to){c.classList.remove('over');return}const from=l.st;l.st=to;l.sub=(L.SUBST[to]||[to])[0];l.last='Just now';l.days=0;l.notes.unshift({text:'Moved from '+from+' to '+to+' on the board',when:'Just now'});L.emit('leads');const nk=el.querySelector(`.kcard[data-id="${l.id}"]`);if(nk){nk.classList.add('drop-in');if(to==='Booked'||to==='Invoiced'){const r=nk.getBoundingClientRect();burst(r.left+r.width/2,r.top+20,110)}}toast(l.n+' moved to '+to)});
};

/* ---------- Data page (Manage Data list + Add Data import) ---------- */
const importWizard=pages.data;
const DNAMES=['Shaymaa Mohammed Mahmoud','Nellya Samatova','Inciser Akat','Brayden Ainzuain','Antonella Pietrocola','Renu Mukesh Pandey','Vani Sharma Gidwani','Masoud Saeed Mohamed','Zhixing Li','Biji Scaria Abraham','Karan Malhotra','Leila Ahmadi','Tomasz Nowak','Grace Chen','Faisal Al Zarooni','Olga Petrenko','Hamid Rezaei','Sana Iqbal','Martin Weber','Aaliyah Brooks','Rohan Kapoor','Dalia Mansour','Yusuf Kaya','Ines Moreau'];
const DST=['New','Follow Ups','Backlog','Not Reachable','Not Answered'],DCOL={New:'#4C9AFF','Follow Ups':'#0B6BE6',Backlog:'#8A91A2','Not Reachable':'#C77700','Not Answered':'#D13438',Converted:'#12805C'};
L.dataRecs=DNAMES.map((n,i)=>({id:'D'+(2001+i),n,ini:n.split(' ').map(w=>w[0]).join('').slice(0,2),ag:i%7===3?'':['Danyal Abid','Danyal Abid','Raish Ahmed','Farwa Shah','Obaid Raza'][i%5],src:'Data',proj:['Damac Lagoons','Emaar Beachfront','Sobha Hartland','Damac Lagoons'][i%4],unit:['DL-B177','DL-J270','DL-J557','DL-L498','DL-M404','DL-M302','DL-J315','DL-M349','DL-BL345','DL-K561'][i%10],st:i%9===8?'Converted':DST[i%5],ph:'+971 5'+(i%9)+' '+(500+i*23)+' '+String(3000+i*411).slice(0,4),c:pal[i%5],del:i===20,dup:i%10===6?1:0,created:(i%12)+' days ago'}));
pages.data=function(el){
  const ME='Obaid Raza',live=x=>!x.del;
  listEngine(el,{key:'data',title:'Manage Data',sub:'Contact databases you call through. Qualified contacts become leads in one click.',
    headActs:`<button class="btn-primary rip" id="dAdd">${icon('i-plus')}Add Data</button>`,searchPh:'Search name, phone or unit',
    rows:()=>L.dataRecs,
    scopes:[['All Data',live,'i-grid'],['My Data',x=>live(x)&&x.ag===ME,'i-users'],['Team',x=>live(x)&&!!x.ag&&x.ag!==ME,'i-team'],['Converted',x=>live(x)&&x.st==='Converted','i-check'],['Deleted',x=>x.del,'i-x'],['Unassigned',x=>live(x)&&!x.ag,'i-alert'],['Duplicate Data',x=>live(x)&&x.dup>0,'i-list']],
    groups:{'Active Data':{match:x=>x.st!=='Converted',subs:DST.map(s=>[s,x=>x.st===s])},'All Data':{match:()=>true},'Converted':{match:x=>x.st==='Converted'}},
    search:x=>x.n+x.ph+x.unit+x.proj,
    cols:[{k:'n',label:'Name',fixed:1,sv:x=>x.n,csv:x=>x.n,html:x=>`<div class="who">${av(x.ini,x.c)}<div style="min-width:0"><b style="font-weight:500;text-transform:uppercase;font-size:var(--fs-sm)">${esc(x.n)}</b>${x.dup?'<span class="bdg d">D'+x.dup+'</span>':''}<small class="num">${esc(x.ph)}</small></div></div>`},
      {k:'ag',label:'Assigned to',sv:x=>x.ag||'~',csv:x=>x.ag||'Unassigned',html:agCell},
      {k:'src',label:'Source',sv:x=>x.proj,csv:x=>'Data / '+x.proj,html:x=>`<div class="two"><b>Data</b><small>${esc(x.proj)}</small></div>`},
      {k:'st',label:'Status',sv:x=>x.st,csv:x=>x.st,html:x=>`<span class="dstat" style="color:${DCOL[x.st]}">${x.st}</span>`},
      {k:'unit',label:'Unit number / name',sv:x=>x.unit,csv:x=>x.unit,html:x=>`<b class="num" style="font-weight:600">${esc(x.unit)}</b>`},
      {k:'days',label:'Added',def:false,sv:x=>daysOf(x.created),csv:x=>x.created,html:x=>esc(x.created)}],
    actions:x=>(x.st!=='Converted'?iaBtn('conv',x.id,'i-arrow','#E2F0FE','#0B6BE6','Convert to lead'):'')+iaBtn('wa',x.id,'i-msg','#E3F7EA','#1E8E4E','WhatsApp')+iaBtn('call',x.id,'i-phone','#E2F0FE','#0B6BE6','Call')+iaBtn('nr',x.id,'i-alert','#FFF3DC','#9A5B00','Mark not reachable')+iaBtn(x.del?'restore':'del',x.id,x.del?'i-arrow':'i-x',x.del?'#E5F5EE':'#FDECEC',x.del?'#12805C':'#C0262B',x.del?'Restore':'Delete'),
    bulk:()=>`<select id="dbAg" aria-label="Assign selected"><option value="">Assign to…</option>${L.team.map(a=>`<option>${esc(a.n)}</option>`).join('')}</select><select id="dbSt" aria-label="Status"><option value="">Change status…</option>${DST.map(s=>`<option>${s}</option>`).join('')}</select><select id="dbCv" aria-label="Convert"><option value="">Convert…</option><option value="1">Convert selected to leads</option></select>`,
    onBulk:(id,v,ids)=>{const rs=ids.map(i=>L.dataRecs.find(x=>x.id===i)).filter(Boolean);if(id==='dbAg'){rs.forEach(r=>r.ag=v);toast(rs.length+' contacts assigned to '+v)}if(id==='dbSt'){rs.forEach(r=>r.st=v);toast(rs.length+' contacts set to '+v)}if(id==='dbCv'){rs.filter(r=>r.st!=='Converted').forEach(conv);toast(rs.length+' contacts converted to leads');burst(innerWidth/2,180,120)}},
    onAction:(k,x,btn)=>{if(!x)return;if(k==='conv'){conv(x);toast(x.n+' is now a lead');const r=btn.getBoundingClientRect();burst(r.left,r.top,60)}if(k==='wa')toast('WhatsApp opened for '+x.n+' (demo)');if(k==='call')toast('Calling '+x.n+' (demo)');if(k==='nr'){x.st='Not Reachable';toast(x.n+' marked not reachable')}if(k==='del'){x.del=true;toast(x.n+' deleted')}if(k==='restore'){x.del=false;toast(x.n+' restored')}L.emit('data')}});
  function conv(x){x.st='Converted';L.leads.unshift({n:x.n.replace(/\b\w+/g,w=>w[0].toUpperCase()+w.slice(1).toLowerCase()),ini:x.ini,st:'New',sub:'Fresh enquiry',src:'Data',subSrc:x.proj,ag:x.ag,proj:x.proj,bud:'Not set',ph:x.ph,note:'Converted from data · unit '+x.unit,last:'Just now',c:x.c,tags:[],recs:[],docs:[],created:'Just now',enq:'Buy',beds:null});normAll();L.emit('leads')}
  el.querySelector('#dAdd').addEventListener('click',()=>{const ov=document.createElement('div');ov.className='page';el.appendChild(ov);el.firstElementChild.hidden=true;importWizard(ov);const bk=document.createElement('button');bk.className='ghost';bk.innerHTML=icon('i-dbl')+'Back to Manage Data';bk.style.margin='16px 24px 0';ov.prepend(bk);bk.onclick=()=>{ov.remove();el.firstElementChild.hidden=false;L.emit('data')}});
};
L.subAddData=()=>{L.navTo('Data');setTimeout(()=>{const b=$('#dAdd');if(b)b.click()},80)};

/* ---------- Tracker + Audit Log ---------- */
L.tracker.push({type:'Bulk Upload',what:'bayut-october.csv · 124 added, 3 skipped',at:new Date(Date.now()-3*864e5),by:'Ashfaq Haji Haroon',status:'Completed'},{type:'Export',what:'Manage Leads · 373 rows',at:new Date(Date.now()-2*864e5),by:'Obaid Raza',status:'Completed'},{type:'Bulk Operation',what:'Manage Leads · Spread evenly · 18 records',at:new Date(Date.now()-864e5),by:'Mariam Khan',status:'Completed'});
const fdt=d=>d.toLocaleDateString('en-GB',{day:'2-digit',month:'short'})+' '+d.toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit'});
L.openTracker=type=>{L.setLast(document.activeElement);const rows=L.tracker.filter(t=>t.type===type);
  L.layer.innerHTML=`<div class="veil" data-close></div><div class="modal" style="width:min(680px,calc(100% - 32px))" role="dialog" aria-modal="true" aria-label="${type}"><header><h3>${type==='Export'?'Export Tracker':type}</h3><button class="x" data-close aria-label="Close">${icon('i-x')}</button></header><div style="padding:8px 20px 20px"><div class="tbl-wrap"><table class="tbl" style="min-width:520px"><thead><tr><th>What</th><th>By</th><th>When</th><th>Status</th></tr></thead><tbody>${rows.map((t,i)=>`<tr style="--r:${i}"><td>${esc(t.what)}</td><td>${esc(t.by)}</td><td>${fdt(t.at)}</td><td><span class="pill-st ps-Present">${t.status}</span></td></tr>`).join('')||'<tr><td colspan="4"><div class="empty-st"><b>Nothing yet</b>It will show here as soon as someone runs one.</div></td></tr>'}</tbody></table></div></div></div>`};
L.auditLog.push(...[['Assigned lead Vaibhav to Danyal Abid','Leads','Ashfaq Haji Haroon',40],['Changed Manager role permissions','Roles and Permissions','Obaid Raza',180],['Connected Bayut integration','Global Config','Obaid Raza',1440],['Set owner of ad 16835120 to Ashfaq Haji Haroon','Ref. ID Management','Obaid Raza',2000],['Marked INV-2026-0041 as paid','Invoice','Mariam Khan',2900]].map(([a,ar,u,m])=>({at:new Date(Date.now()-m*6e4),user:u,area:ar,action:a,detail:''})));
pages.audit=function(el){const S={q:'',u:'',a:''};
  el.innerHTML=`<div class="pg">${head('Audit Log','Every change made in LeadVolt: who did it, what changed and when. Entries cannot be edited or deleted.',`<button class="ghost" id="auX">${icon('i-cloud')}Export</button>`)}
    <div class="filters"><label class="field">${icon('i-search')}<input id="auQ" placeholder="Search actions, e.g. Booked or Bayut"></label><select class="sel" id="auU" aria-label="User"><option value="">All users</option>${L.team.map(t=>`<option>${esc(t.n)}</option>`).join('')}</select><select class="sel" id="auA" aria-label="Area"><option value="">All areas</option></select></div>
    <div class="panel" style="padding:8px"><div class="tbl-wrap"><table class="tbl" style="min-width:720px"><thead><tr><th>When</th><th>User</th><th>Area</th><th>Action</th></tr></thead><tbody id="auB"></tbody></table></div></div></div>`;
  function draw(){const areas=[...new Set(L.auditLog.map(a=>a.area))];const sel=$('#auA');const cur=sel.value;sel.innerHTML='<option value="">All areas</option>'+areas.map(a=>`<option ${a===cur?'selected':''}>${esc(a)}</option>`).join('');
    const q=S.q.toLowerCase(),r=L.auditLog.filter(a=>(!S.u||a.user.startsWith(S.u))&&(!S.a||a.area===S.a)&&(!q||(a.action+a.area).toLowerCase().includes(q)));
    $('#auB').innerHTML=r.map((a,i)=>`<tr style="--r:${Math.min(i,20)}"><td class="num" style="white-space:nowrap">${fdt(a.at)}</td><td><div class="who">${av(a.user.split(' ').map(w=>w[0]).join('').slice(0,2),pal[a.user.length%5])}${esc(a.user)}</div></td><td><span class="st">${esc(a.area)}</span></td><td>${esc(a.action)}</td></tr>`).join('')||'<tr><td colspan="4"><div class="empty-st"><b>No matching entries</b></div></td></tr>'}
  draw();el._refresh=draw;L.on('audit',()=>{if(el.isConnected&&!el.hidden)draw()});
  $('#auQ').addEventListener('input',e=>{S.q=e.target.value;draw()});$('#auU').addEventListener('change',e=>{S.u=e.target.value;draw()});$('#auA').addEventListener('change',e=>{S.a=e.target.value;draw()});
  $('#auX').addEventListener('click',()=>{const t=['When,User,Area,Action',...L.auditLog.map(a=>[fdt(a.at),a.user,a.area,a.action].map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(','))].join('\n');try{navigator.clipboard.writeText(t).then(()=>L.toast('Audit log copied'),()=>L.toast('Copy blocked by the browser'))}catch(x){L.toast('Copy blocked by the browser')}})};
/* ===================== Global Config hub ===================== */
L.cfg={general:{company:'Fortune4 Real Estate',domain:'fortune4.leadvolt.com',tz:'Asia/Dubai',currency:'AED',cc:'+971',date:'DD-MM-YYYY'},
 security:{tfa:true,timeout:'8 hours',ip:false,minpw:'10'},attendance:{start:'09:00',end:'18:00',lateAfter:'10:30',askReason:true,reasonReq:true,geofence:true,radius:'150',selfie:false,offices:[{n:'Fortune4 Office, Business Bay',lat:25.1857,lng:55.2727,r:150}]},
 leads:{auto:true,method:'Round robin',reassign:true,mins:'30',dup:true,reenq:'30',noteReq:true,learn:true,recRoles:'Admin, Manager, SalesExecutive'},
 data:{dup:true,convertTo:'New'},projects:{commission:'2',showUnit:true},locality:['Dubai Marina','Palm Jumeirah','Business Bay','Downtown Dubai','Dubai Hills Estate','Dubai Creek Harbour','Damac Lagoons','JVC'],
 tags:[['Hot','#C0262B'],['Warm','#C77700'],['Cold','#0957C3'],['VIP','#2B2F3A'],['Investor','#12805C']],
 marketing:[['Binghatti campaign','Facebook','AED 12,000','AED 41'],['Generic campaign','Facebook','AED 8,500','AED 37'],['Bayut featured','Bayut','AED 20,000','AED 85'],['Google search','Google Ads','AED 6,000','AED 58']],
 listing:{learn:true,requireOwner:false,defaultUnder:'Ashfaq Haji Haroon'},
 automation:[[1,'When a portal lead arrives and its <b>Ref ID has an owner</b>, assign it to the owner'],[1,'When a lead arrives with <b>no owner</b>, keep it Unassigned and alert admins instantly'],[1,'When a lead is <b>not opened in 5 minutes</b>, push again and SMS the agent'],[1,'When a lead is <b>not contacted in 30 minutes</b>, alert the team lead and offer Shuffle'],[1,'When a <b>Bayut call is missed</b>, create a callback task for the owner'],[0,'When a lead is <b>Booked</b>, create a draft commission invoice']],
 sources:[['Bayut',1,['bayut call','bayut whatsapp','bayut email']],['Property Finder',1,['PF call','PF email']],['Dubizzle',1,['DZ call','DZ chat']],['Facebook',1,['FB lead form']],['Website',1,['Contact form']],['Walk-in',1,['Office visit']],['IVR',1,['Inbound call']],['Channel Partner',0,['Outsource leads']]],
 dev:{key:'lv_live_9f3c2a71e4b84d0c8a1f',secret:'whsec_5b7e1c9a2f'},
 integ:{Webhook:true,Skyloov:false,Bayut:true,Dubizzle:false,'Property Finder':true,Gmail:false,'Google ads landing page':false,'Google ads leads form':false,'Google Campaign':false,'Microsoft Ads':false,WhatsApp:true,Facebook:true,Website:true},
 comm:{templates:[['Welcome','WhatsApp','Hi {name}, thanks for your interest in {project}. I am {agent} from Fortune4 Real Estate.'],['Site visit reminder','WhatsApp','Hi {name}, reminder of your visit to {project} tomorrow at {time}.'],['Brochure','Email','Dear {name}, please find the {project} brochure attached.']],ivr:{provider:'Exotel',number:'+971 4 555 0199',record:true},email:{host:'smtp.office365.com',port:'587',user:'hello@fortune4.ae',from:'Fortune4 Real Estate'}}};
const ICOL={General:'#22B07D',Security:'#F2A541',Attendance:'#2D9CDB',Leads:'#22B07D',Data:'#C47A2C','Projects and Properties':'#0B6B9A',Locality:'#E2574C','QR Code':'#4C9AFF',Tags:'#6FBF4B','Manage Marketing':'#1F5F4A',Migration:'#F2742B','Listing Management':'#7A3DB8',Automation:'#7B7FE0','Manage Source':'#0D4F63','Dev Resources':'#5B7CFA'};
const MODS=[['General','Common platform configuration','i-cog'],['Security','2FA security settings can be done','i-alert'],['Attendance','Manage your shift timings','i-cal'],['Leads','Customized lead features','i-funnel'],['Data','Customized data features','i-card'],['Projects and Properties','Customized property & project features','i-build'],['Locality','Customized locality feature','i-pin'],['QR Code','Customize the QR enquiry form','i-grid'],['Tags','Customized tags','i-spark'],['Manage Marketing','Customized marketing efforts','i-pie'],['Migration','Migrate Leads/Data from Leadrat','i-cloud'],['Listing Management','Portal ads, Ref IDs and owners','i-list'],['Automation','Automate the setting','i-bellring'],['Manage Source','Manage Source','i-users'],['Dev Resources','API credentials & developer tools','i-layout']];
const INTG={'3rd Parties':[['Webhook','#2B2F3A','WH'],['Skyloov','#1E6FD9','SK'],['Bayut','#21B573','B'],['Dubizzle','#E21B23','DZ'],['Property Finder','#EF5B4C','PF']],'Social Platforms':[['Gmail','#EA4335','G'],['Google ads landing page','#4285F4','GA'],['Google ads leads form','#FBBC05','GF'],['Google Campaign','#34A853','GC'],['Microsoft Ads','#00A4EF','MS'],['WhatsApp','#25D366','WA'],['Facebook','#1877F2','f']],'Others':[['Website','#22B07D','WEB']]};
const sw2=(k,v)=>`<label class="sw"><input type="checkbox" data-k="${k}" ${v?'checked':''} aria-label="${k}"><span></span></label>`;
const row2=(t,s,c)=>`<div class="setrow"><div class="t"><b>${t}</b><small>${s}</small></div>${c}</div>`;
const inp=(k,v,l,t='text')=>`<label class="fld">${l}<input data-k="${k}" type="${t}" value="${esc(v)}"></label>`;
const selc=(k,v,opts)=>`<select class="sel" data-k="${k}">${opts.map(o=>`<option ${o===v?'selected':''}>${o}</option>`).join('')}</select>`;
const copyF=(v,lbl)=>`<div class="fld">${lbl}<div class="copyf"><input readonly value="${esc(v)}"><button class="ghost" data-copy="${esc(v)}">Copy</button></div></div>`;
function qrSvg(seed){let s=seed;const r=()=>(s=(s*9301+49297)%233280)/233280,n=25;let h='';const fin=(x,y)=>`<rect x="${x}" y="${y}" width="7" height="7" fill="#1A1F2C"/><rect x="${x+1}" y="${y+1}" width="5" height="5" fill="#fff"/><rect x="${x+2}" y="${y+2}" width="3" height="3" fill="#1A1F2C"/>`;
  for(let y=0;y<n;y++)for(let x=0;x<n;x++){if((x<8&&y<8)||(x>16&&y<8)||(x<8&&y>16))continue;if(r()>.52)h+=`<rect x="${x}" y="${y}" width="1" height="1" fill="#1A1F2C"/>`}
  return `<svg viewBox="0 0 25 25" class="qr" role="img" aria-label="QR code for the enquiry form">${fin(0,0)}${fin(18,0)}${fin(0,18)}${h}<rect x="10" y="10" width="5" height="5" rx="1" fill="#0B6BE6"/></svg>`}
function panelHtml(name){const C=L.cfg,base=`https://${C.general.domain}`;
  switch(name){
  case 'General':return inp('general.company',C.general.company,'Company name')+copyF(base,'Your LeadVolt address (web and mobile app)')+`<div class="form3">${'<label class="fld">Time zone'+selc('general.tz',C.general.tz,['Asia/Dubai','Asia/Riyadh','Asia/Karachi','Asia/Kolkata','Europe/London'])+'</label><label class="fld">Currency'+selc('general.currency',C.general.currency,['AED','SAR','USD','EUR','GBP'])+'</label><label class="fld">Default country code'+selc('general.cc',C.general.cc,['+971','+966','+92','+91','+44'])+'</label><label class="fld">Date format'+selc('general.date',C.general.date,['DD-MM-YYYY','MM-DD-YYYY','YYYY-MM-DD'])+'</label>'}</div>`;
  case 'Security':return row2('Two-factor sign-in','Everyone confirms sign-in with a code on their phone.',sw2('security.tfa',C.security.tfa))+row2('Sign out after inactivity','Web and mobile app.',selc('security.timeout',C.security.timeout,['1 hour','8 hours','24 hours','7 days']))+row2('Office network only','Sign in only from office IP addresses.',sw2('security.ip',C.security.ip))+row2('Minimum password length','Applies to new passwords.',selc('security.minpw',C.security.minpw,['8','10','12','14']))+row2('Active sessions','Signed in on 3 devices.','<button class="ghost" data-act="signout">Sign out other devices</button>');
  case 'Attendance':{const A=C.attendance;return `<div class="form3">${inp('attendance.start',A.start,'Shift starts','time')}${inp('attendance.end',A.end,'Shift ends','time')}</div>`+row2('Late after','Anyone clocking in after this time is marked Late.',`<input class="sel" type="time" data-k="attendance.lateAfter" value="${A.lateAfter}" aria-label="Late after" style="width:130px">`)+row2('Ask for a reason when late','Clock-in shows a dialog asking why. The reason goes to the manager.',sw2('attendance.askReason',A.askReason))+row2('Reason is required','Agents cannot clock in late without writing a reason.',sw2('attendance.reasonReq',A.reasonReq))+row2('Clock in only at the office','Uses the phone\'s GPS. Clock-in is blocked outside the radius.',sw2('attendance.geofence',A.geofence))+row2('Office radius','How close they must be (metres).',selc('attendance.radius',A.radius,['50','100','150','300','500']))+`<b style="font-weight:600;font-size:var(--fs-sm)">Office locations</b><div id="offL">${A.offices.map((o,i)=>`<div class="rulec">${icon('i-pin')}<div class="t"><b>${esc(o.n)}</b><br><span style="color:var(--muted)">${o.lat.toFixed(5)}, ${o.lng.toFixed(5)} · ${o.r} m</span></div>${A.offices.length>1?`<button class="ghost" data-rmoff="${i}">Remove</button>`:''}</div>`).join('')}</div><form data-form="off" class="form3"><label class="fld">Office name<input id="ofN" placeholder="e.g. JLT branch"></label><label class="fld">Latitude<input id="ofA" inputmode="decimal" placeholder="25.07"></label><label class="fld">Longitude<input id="ofO" inputmode="decimal" placeholder="55.14"></label><div style="display:flex;gap:8px;align-items:flex-end"><button type="button" class="ghost" data-act="here" style="flex:1;justify-content:center">${icon('i-pin')}Use my location</button><button class="btn-primary rip" type="submit">Add</button></div></form><small style="color:var(--muted)">Tip: open this page on a phone while standing in the office and tap Use my location. Paste coordinates from Google Maps for other branches.</small>`+row2('Selfie on clock-in','Stops buddy clock-ins from the mobile app.',sw2('attendance.selfie',A.selfie));}
  case 'Leads':return row2('Auto-assign new leads','Leads go to an agent the moment they arrive.',sw2('leads.auto',C.leads.auto))+row2('Assignment method','When the ad has no owner yet.',selc('leads.method',C.leads.method,['Round robin','By source','By lowest workload','By project','Keep unassigned']))+row2('Learn ad owners','The first time an admin assigns a lead from an ad, future leads from that ad go to the same person.',sw2('leads.learn',C.leads.learn))+row2('Reassign untouched leads','Shuffle to the next agent if nobody acts in time.',sw2('leads.reassign',C.leads.reassign))+row2('Time before reassigning','Working hours only.',selc('leads.mins',C.leads.mins,['5','15','30','60']))+row2('Detect duplicates by phone','Mark repeat numbers as duplicates (D1, D2).',sw2('leads.dup',C.leads.dup))+row2('Re-enquiry window','A lead coming back within this many days counts as Re Enquired.',selc('leads.reenq',C.leads.reenq,['7','30','90','365']))+row2('Note required on status change','Agents must say what happened.',sw2('leads.noteReq',C.leads.noteReq))+inp('leads.recRoles',C.leads.recRoles,'Roles that can listen to call recordings');
  case 'Data':return row2('Detect duplicate data','Flag the same phone number in two lists.',sw2('data.dup',C.data.dup))+row2('Status when converted to lead','New leads from data start at this status.',selc('data.convertTo',C.data.convertTo,['New','Callback']));
  case 'Projects and Properties':return row2('Show unit numbers to agents','Hide them for agents without the View Unit Number permission.',sw2('projects.showUnit',C.projects.showUnit));
  case 'Locality':return `<div class="chipset">${C.locality.map((x,i)=>`<span>${esc(x)}<button data-rmloc="${i}" aria-label="Remove ${esc(x)}">×</button></span>`).join('')}</div><form data-form="loc" style="display:flex;gap:8px"><label class="field" style="flex:1">${icon('i-pin')}<input id="locN" placeholder="Add a community, e.g. Dubai South"></label><button class="btn-primary rip" type="submit">Add</button></form>`;
  case 'QR Code':return `<div style="display:flex;gap:18px;align-items:center;flex-wrap:wrap">${qrSvg(7)}<div style="flex:1;min-width:200px"><b style="font-weight:600">Scan to enquire</b><p style="color:var(--body);font-size:var(--fs-sm);line-height:1.5">Print this on brochures, boards and the office door. Every scan opens a short enquiry form and the lead lands in LeadVolt with source <b>QR Code</b>.</p>${copyF(base+'/enquire?src=qr','Form link')}</div></div>`+row2('Ask for budget','Show a budget field on the form.',sw2('qr.budget',true))+row2('Assign QR leads to','Who gets leads from this code.',selc('qr.owner','Obaid Raza',L.team.map(t=>t.n)));
  case 'Tags':return `<div class="chipset">${C.tags.map(([t,c],i)=>`<span><i style="background:${c}"></i>${esc(t)}${i>2?`<button data-rmtag="${i}" aria-label="Remove ${esc(t)}">×</button>`:''}</span>`).join('')}</div><form data-form="tag" style="display:flex;gap:8px"><label class="field" style="flex:1">${icon('i-spark')}<input id="tagN" placeholder="New tag, e.g. Cash buyer"></label><input type="color" id="tagC" value="#7A3DB8" aria-label="Tag colour" style="width:44px;height:38px;border:1px solid var(--line);border-radius:10px;padding:2px"><button class="btn-primary rip" type="submit">Add</button></form><small style="color:var(--muted)">Hot, Warm and Cold are built in. Agents tag leads from the Lead Preview.</small>`;
  case 'Manage Marketing':return `<div class="tbl-wrap"><table class="tbl" style="min-width:460px"><thead><tr><th>Campaign</th><th>Source</th><th>Budget</th><th>Cost per lead</th></tr></thead><tbody>${C.marketing.map((m,i)=>`<tr style="--r:${i}">${m.map(v=>`<td>${esc(v)}</td>`).join('')}</tr>`).join('')}</tbody></table></div><form data-form="camp" class="form3"><label class="fld">Campaign name<input id="cpN" placeholder="e.g. Ramadan offer"></label><label class="fld">Source<select id="cpS">${C.sources.map(s=>`<option>${s[0]}</option>`).join('')}</select></label><label class="fld">Budget (AED)<input id="cpB" inputmode="numeric" placeholder="10,000"></label><div style="display:flex;align-items:flex-end"><button class="btn-primary rip" type="submit" style="width:100%;justify-content:center">Add campaign</button></div></form>`;
  case 'Migration':return `<p style="margin:0;color:var(--body);line-height:1.55">Move your company's own leads and data from Leadrat (or any CRM) into LeadVolt. Export them from Leadrat as CSV or Excel, then import here. Owners, statuses, sources and notes are matched automatically, and nothing is imported twice.</p><div class="rulec">${icon('i-cloud')}<div class="t"><b>Step 1</b> Export leads from Leadrat (Leads → Export).<br><b>Step 2</b> Open Data → Add Data and drop the file.<br><b>Step 3</b> Check the matched columns and import.</div></div><button class="btn-primary rip" data-act="migrate" style="align-self:flex-start">${icon('i-cloud')}Start migration</button>`;
  case 'Listing Management':return row2('Learn owners automatically','After an admin assigns the first lead from a new Ref ID, LeadVolt routes that ad\'s leads to the same person.',sw2('listing.learn',C.listing.learn))+row2('Require an owner before publishing','Listings can\'t go live without a real owner.',sw2('listing.requireOwner',C.listing.requireOwner))+row2('Default portal account','Whose Bayut/Dubizzle account new ads are posted under.',selc('listing.defaultUnder',C.listing.defaultUnder,L.team.map(t=>t.n)))+'<button class="ghost" data-act="refs" style="align-self:flex-start">'+icon('i-list')+'Open Ref. ID Management</button>';
  case 'Automation':return C.automation.map(([on,t],i)=>/commission invoice/i.test(t)?'':`<div class="rulec">${sw2('auto.'+i,on)}<div class="t">${t}</div></div>`).join('');
  case 'Manage Source':return C.sources.map(([n,on,subs],i)=>`<div class="rulec">${sw2('src.'+i,on)}<div class="t"><b>${n}</b> <span style="color:var(--muted)">${on?'Visible':'Hidden'}</span><div class="chipset" style="margin-top:6px">${subs.map(x=>`<span>${esc(x)}</span>`).join('')}</div></div></div>`).join('');
  case 'Dev Resources':return copyF(C.dev.key,'API key (keep it secret)')+copyF(base+'/api','API base URL')+copyF(base+'/api/integrations/bayut/webhook','Bayut webhook URL')+copyF(C.dev.secret,'Webhook signing secret')+`<button class="ghost" data-act="regen" style="align-self:flex-start">Generate a new API key</button><pre class="code">curl ${base}/api/leads \\\n  -H "Authorization: Bearer ${C.dev.key.slice(0,12)}…"</pre><small style="color:var(--muted)">The full API reference ships with the backend (API.md).</small>`;
  }return ''}
function integHtml(n){const C=L.cfg,on=C.integ[n],base=`https://${C.general.domain}`,portal=['Bayut','Dubizzle','Property Finder','Skyloov'].includes(n);
  const ev=`<b style="font-weight:600;font-size:var(--fs-sm)">Recent activity</b><div class="evlog">${on?[['Lead received','2 min ago'],['Call recording saved','14 min ago'],['Ref ID 16900812 synced','1 h ago']].map(([a,t])=>`<div><i></i>${a}<span class="t">${t}</span></div>`).join(''):'<div style="background:var(--warn-bg);color:var(--warn)">Not connected yet</div>'}</div>`;
  if(portal)return `<p style="margin:0;color:var(--body);line-height:1.55">Leads, call recordings and listing Ref IDs from ${n} arrive in LeadVolt in real time through the API.</p>`+inp('i.key',on?'••••••••••••3f9a':'',n+' API key')+inp('i.acc',on?'FORTUNE4-RE':'','Agency / account ID')+copyF(`${base}/api/integrations/${n.toLowerCase().replace(/\s+/g,'-')}/webhook`,'Paste this webhook URL in your '+n+' account')+row2('Import call recordings','Recordings appear in the lead\'s Calls tab.',sw2('i.rec',true))+row2('Route by Ref ID owner','Use Ref. ID Management to choose the agent.',sw2('i.route',true))+row2('Sync listings and Ref IDs','New ads and their Ref IDs come back automatically.',sw2('i.sync',true))+ev;
  if(n==='Webhook')return `<p style="margin:0;color:var(--body)">Send leads from any system with one POST request.</p>`+copyF(base+'/api/integrations/webhook','Endpoint')+copyF(C.dev.secret,'Signing secret')+`<pre class="code">POST /api/integrations/webhook\n{\n  "name": "Maya Collins",\n  "phone": "+971501234567",\n  "source": "Website",\n  "ref_id": "16840693",\n  "notes": "Wants a 2BR"\n}</pre>`+ev;
  if(n==='Website')return `<p style="margin:0;color:var(--body)">Add this to your website and every form becomes a LeadVolt lead.</p><pre class="code">&lt;script src="${base}/embed.js" data-key="${C.dev.key.slice(0,12)}…"&gt;&lt;/script&gt;</pre><button class="ghost" data-copy='<script src="${base}/embed.js" data-key="${C.dev.key}"></script>' style="align-self:flex-start">Copy code</button>`+ev;
  if(n==='WhatsApp')return inp('i.num',on?'+971 50 555 0142':'','WhatsApp Business number')+inp('i.tok',on?'••••••••••••••••':'','Access token')+row2('Log chats on leads','Messages appear on the lead timeline.',sw2('i.log',true))+row2('New chat creates a lead','Unknown numbers become New leads.',sw2('i.new',true))+ev;
  return `<p style="margin:0;color:var(--body)">Sign in to ${n} and choose which forms or campaigns send leads to LeadVolt.</p><button class="btn-primary rip" data-act="oauth" style="align-self:flex-start">${on?'Reconnect':'Sign in with '+n.split(' ')[0]}</button>`+(on?row2('Lead forms','3 forms connected','<button class="ghost">Choose forms</button>'):'')+ev}
function commHtml(n){const C=L.cfg.comm;
  if(n==='Templates')return C.templates.map(([t,ch,b],i)=>`<div class="rulec"><span class="portal" style="background:${ch==='WhatsApp'?'#25D366':'#4450C9'}">${ch}</span><div class="t"><b>${esc(t)}</b><br><span style="color:var(--body)">${esc(b)}</span></div></div>`).join('')+`<form data-form="tpl" class="form3"><label class="fld">Name<input id="tpN" placeholder="e.g. Price update"></label><label class="fld">Channel<select id="tpC"><option>WhatsApp</option><option>Email</option><option>SMS</option></select></label><label class="fld full">Message<textarea id="tpB" placeholder="Use {name}, {project}, {agent}, {time}"></textarea></label><div class="full" style="display:flex;justify-content:flex-end"><button class="btn-primary rip" type="submit">Add template</button></div></form>`;
  if(n==='IVR')return `<label class="fld">Provider${selc('ivr.provider',C.ivr.provider,['Exotel','Twilio','Etisalat Cloud Talk','du Smart Voice'])}</label>`+inp('ivr.number',C.ivr.number,'IVR number')+row2('Record calls','Recordings attach to the lead.',sw2('ivr.record',C.ivr.record))+row2('Missed call creates a lead','Unknown callers become New leads with source IVR.',sw2('ivr.miss',true));
  if(n==='Email')return `<div class="form3">${inp('email.host',C.email.host,'SMTP server')}${inp('email.port',C.email.port,'Port')}${inp('email.user',C.email.user,'Username')}${inp('email.from',C.email.from,'From name')}</div><button class="ghost" data-act="testmail" style="align-self:flex-start">${icon('i-inbox')}Send a test email</button>`;
  return ''}
function openCfg(title,sub,html,kind){L.setLast(document.activeElement);
  L.layer.innerHTML=`<div class="veil" data-close></div><aside class="drawer cpanel" style="width:min(560px,100%)" role="dialog" aria-modal="true" aria-label="${esc(title)}"><header><div style="flex:1;min-width:0"><h3>${esc(title)}</h3><small>${esc(sub)}</small></div><button class="x" data-close aria-label="Close">${icon('i-x')}</button></header><div class="body" id="cfgB">${html}</div><div class="foot"><button class="ghost" data-close>Cancel</button>${kind==='integ'?`<button class="ghost" data-act="test">${icon('i-spark')}Test connection</button><button class="btn-primary rip" data-act="connect">${L.cfg.integ[title]?'Save':'Connect'}</button>`:`<button class="btn-primary rip" data-act="save">${icon('i-check')}Save</button>`}</div></aside>`;
  const box=L.layer.querySelector('.cpanel');box.querySelector('.x').focus();let dirty=false;
  box.addEventListener('change',e=>{const k=e.target.dataset.k;if(!k)return;dirty=true;const v=e.target.type==='checkbox'?e.target.checked:e.target.value;const [a,b]=k.split('.');
    if(a==='auto')L.cfg.automation[+b][0]=v?1:0;else if(a==='src'){L.cfg.sources[+b][1]=v?1:0;e.target.closest('.rulec').querySelector('.t span').textContent=v?'Visible':'Hidden'}else if(L.cfg[a]&&typeof L.cfg[a]==='object'&&!Array.isArray(L.cfg[a]))L.cfg[a][b]=v;else if(L.cfg.comm[a])L.cfg.comm[a][b]=v});
  box.addEventListener('click',e=>{const c=e.target.closest('[data-copy]');if(c){try{navigator.clipboard.writeText(c.dataset.copy).then(()=>L.toast('Copied'),()=>L.toast('Copy blocked by the browser'))}catch(x){}return}
    const a=e.target.closest('[data-act]');if(!a)return;const k=a.dataset.act;
    if(k==='save'){L.closeLayer();toast(title+' settings saved');return}
    if(k==='connect'){L.cfg.integ[title]=true;L.closeLayer();toast(title+' connected');burst(innerWidth/2,innerHeight/2,90);L.emit('cfg');return}
    if(k==='test'){a.disabled=true;a.innerHTML=icon('i-spark')+'Testing…';setTimeout(()=>{a.disabled=false;a.innerHTML=icon('i-check')+'Connection OK';L.toast(title+' responded in 184 ms')},900);return}
    if(k==='oauth'){L.cfg.integ[title]=true;L.closeLayer();toast(title+' connected');L.emit('cfg');return}
    if(k==='here'){a.disabled=true;navigator.geolocation?navigator.geolocation.getCurrentPosition(p=>{a.disabled=false;$('#ofA').value=p.coords.latitude.toFixed(6);$('#ofO').value=p.coords.longitude.toFixed(6);if(!$('#ofN').value)$('#ofN').value='Main office';L.toast('Location filled in (±'+Math.round(p.coords.accuracy)+' m)')},()=>{a.disabled=false;L.toast('Location blocked. Allow location access or paste coordinates.')},{enableHighAccuracy:true,timeout:12000}):L.toast('This browser has no location service');return}
    if(k==='signout')toast('Other devices signed out');if(k==='regen'){L.cfg.dev.key='lv_live_'+Math.random().toString(16).slice(2,22);$('#cfgB').innerHTML=panelHtml('Dev Resources');toast('New API key generated. Update your integrations.')}
    if(k==='migrate'){L.closeLayer();L.subAddData()}if(k==='refs'){L.closeLayer();L.navTo('Ref. ID Management')}if(k==='testmail')toast('Test email sent to '+L.cfg.comm.email.user);
    const rl=e.target.closest('[data-rmloc]');});
  box.addEventListener('click',e=>{const r=e.target.closest('[data-rmloc]');if(r){L.cfg.locality.splice(+r.dataset.rmloc,1);$('#cfgB').innerHTML=panelHtml('Locality')}const ro=e.target.closest('[data-rmoff]');if(ro){L.cfg.attendance.offices.splice(+ro.dataset.rmoff,1);$('#cfgB').innerHTML=panelHtml('Attendance');toast('Office removed')}const t=e.target.closest('[data-rmtag]');if(t){L.cfg.tags.splice(+t.dataset.rmtag,1);$('#cfgB').innerHTML=panelHtml('Tags')}});
  box.addEventListener('submit',e=>{e.preventDefault();const f=e.target.dataset.form;
    if(f==='off'){const n=$('#ofN').value.trim(),la=parseFloat($('#ofA').value),lo=parseFloat($('#ofO').value);if(!n||!(Math.abs(la)<=90)||!(Math.abs(lo)<=180)||isNaN(la)||isNaN(lo)){L.toast('Enter an office name and valid latitude/longitude');return}L.cfg.attendance.offices.push({n,lat:la,lng:lo,r:+L.cfg.attendance.radius});$('#cfgB').innerHTML=panelHtml('Attendance');toast('Office '+n+' added')}
    if(f==='loc'){const v=$('#locN').value.trim();if(v){L.cfg.locality.push(v);$('#cfgB').innerHTML=panelHtml('Locality');toast(v+' added')}}
    if(f==='tag'){const v=$('#tagN').value.trim();if(v){L.cfg.tags.push([v,$('#tagC').value]);$('#cfgB').innerHTML=panelHtml('Tags');toast('Tag '+v+' added')}}
    if(f==='camp'){const v=$('#cpN').value.trim();if(v){L.cfg.marketing.push([v,$('#cpS').value,'AED '+($('#cpB').value||'0'),'—']);$('#cfgB').innerHTML=panelHtml('Manage Marketing');toast('Campaign '+v+' added')}}
    if(f==='tpl'){const v=$('#tpN').value.trim(),b=$('#tpB').value.trim();if(v&&b){L.cfg.comm.templates.push([v,$('#tpC').value,b]);$('#cfgB').innerHTML=commHtml('Templates');toast('Template '+v+' added')}else L.toast('Give the template a name and a message')}})}
pages.config=function(el){let tab='3rd Parties';
  el.innerHTML=`<div class="pg"><div class="orgbar"><span class="lg">F4</span><div><b>${esc(L.cfg.general.company)}</b><small>https://${esc(L.cfg.general.domain)}</small></div></div>
    <div class="hsec">${icon('i-cog')}Module Settings</div><div class="mods">${MODS.map(([n,d,ic],i)=>`<button class="mod" data-mod="${n}" style="--i:${i}"><span class="mi" style="background:${ICOL[n]}">${icon(ic)}</span><div><b>${n}</b><small>${d}</small></div></button>`).join('')}</div>
    <div class="hsec" style="flex-wrap:wrap">${icon('i-spark')}Integration<div class="itabs" id="itab">${Object.keys(INTG).map(t=>`<button data-it="${t}" aria-pressed="${t===tab}">${t}</button>`).join('')}</div></div><div class="icards" id="icd"></div>
    <div class="hsec">${icon('i-phone')}Communication</div><div class="mods">${[['Templates','Add / Edit Templates','i-list','#E8A06B'],['IVR','IVR Caller System Setup','i-phone','#7A3DB8'],['Email','Email Configuration','i-inbox','#4450C9']].map(([n,d,ic,c],i)=>`<button class="mod" data-comm="${n}" style="--i:${i}"><span class="mi" style="background:${c}">${icon(ic)}</span><div><b>${n}</b><small>${d}</small></div></button>`).join('')}</div></div>`;
  function cards(){$('#icd').innerHTML=INTG[tab].map(([n,c,ab],i)=>{const on=L.cfg.integ[n];return `<div class="icard ${on?'on':''}" style="--i:${i}"><span class="lgo" style="background:${c}">${ab}</span><b>${n}</b>${on?'<span class="lv">Connected · live</span>':'<small style="color:var(--muted);font-size:10px">Not connected</small>'}<button class="cn" data-in="${n}">${on?'Manage':'Connect Now'}<span>›</span></button></div>`}).join('')}
  cards();L.on('cfg',()=>{if(el.isConnected)cards()});
  $('#itab').addEventListener('click',e=>{const b=e.target.closest('[data-it]');if(!b)return;tab=b.dataset.it;$$('#itab button').forEach(x=>x.setAttribute('aria-pressed',x===b));cards()});
  el.addEventListener('click',e=>{const m=e.target.closest('[data-mod]');if(m){const d=MODS.find(x=>x[0]===m.dataset.mod);openCfg(d[0],d[1],panelHtml(d[0]),'mod');return}
    const i=e.target.closest('[data-in]');if(i){openCfg(i.dataset.in,L.cfg.integ[i.dataset.in]?'Connected':'Not connected yet',integHtml(i.dataset.in),'integ');return}
    const c=e.target.closest('[data-comm]');if(c){openCfg(c.dataset.comm,'Communication',commHtml(c.dataset.comm),'comm')}});
};
/*PAGES*/






/* ---------- Boot ---------- */
const h=location.hash.replace('#','');
if(NAME[h]&&h!=='dashboard')L.navTo(NAME[h]);
})();

/* ---------- Theme toggle (light / dark) ---------- */
(function(){const L=window.LV||{};const root=document.documentElement,btn=document.getElementById('themeBtn');
  const sys=()=>{try{return matchMedia('(prefers-color-scheme: dark)').matches}catch(e){return false}};
  let pref='light';try{pref=localStorage.getItem('lv-theme')||'light'}catch(e){}if(!['light','dark','auto'].includes(pref))pref='light';
  const apply=()=>{const t=pref==='auto'?(sys()?'dark':'light'):pref;root.setAttribute('data-theme',t);if(btn)btn.setAttribute('aria-label','Appearance: '+(pref==='auto'?'Auto':pref==='dark'?'Dark':'Light'));L.emit&&L.emit('theme')};
  apply();try{matchMedia('(prefers-color-scheme: dark)').addEventListener('change',()=>{if(pref==='auto')apply()})}catch(e){}
  if(!btn)return;btn.setAttribute('aria-haspopup','menu');btn.setAttribute('aria-expanded','false');btn.title='Appearance';
  const m=document.createElement('div');m.className='thm';m.setAttribute('role','menu');m.hidden=true;if(getComputedStyle(btn.parentNode).position==='static')btn.parentNode.style.position='relative';btn.insertAdjacentElement('afterend',m);
  const OPTS=[['light','Light','i-sun','Always light. Default for everyone.'],['dark','Dark','i-moon','Easier on the eyes at night.'],['auto','Auto','i-layout','Match this phone or computer.']];
  const draw=()=>{m.innerHTML='<b>Appearance</b>'+OPTS.map(o=>`<button role="menuitemradio" aria-checked="${pref===o[0]}" data-th="${o[0]}"><svg class="i"><use href="#${o[2]}"/></svg><span><span class="tl">${o[1]}</span><small>${o[3]}</small></span><svg class="i ck"><use href="#i-check"/></svg></button>`).join('')};
  const close=()=>{m.hidden=true;btn.setAttribute('aria-expanded','false')};
  btn.addEventListener('click',e=>{e.stopPropagation();if(!m.hidden)return close();draw();m.hidden=false;btn.setAttribute('aria-expanded','true');m.querySelector('[aria-checked="true"]').focus()});
  m.addEventListener('click',e=>{e.stopPropagation();const b=e.target.closest('[data-th]');if(!b)return;pref=b.dataset.th;try{localStorage.setItem('lv-theme',pref)}catch(x){}close();
    const target=pref==='auto'?(sys()?'dark':'light'):pref;const r=btn.getBoundingClientRect(),x=r.left+r.width/2,y=r.top+r.height/2;
    const still=(()=>{try{return matchMedia('(prefers-reduced-motion: reduce)').matches}catch(e){return false}})();
    if(target===root.getAttribute('data-theme')||still){apply();return}
    const rad=Math.hypot(Math.max(x,innerWidth-x),Math.max(y,innerHeight-y)),d=rad*2;
    const ov=document.createElement('div');ov.className='thov';ov.style.cssText=`width:${d}px;height:${d}px;left:${x-rad}px;top:${y-rad}px;background:${target==='dark'?'#0E1117':'#F4F6FA'}`;document.body.appendChild(ov);
    const grow=ov.animate([{transform:'scale(0)'},{transform:'scale(1)'}],{duration:380,easing:'cubic-bezier(.4,0,.2,1)',fill:'forwards'});
    grow.finished.then(()=>{root.classList.add('thsw');apply();const raf=f=>requestAnimationFrame(()=>requestAnimationFrame(f));raf(()=>{root.classList.remove('thsw');raf(()=>{const f=ov.animate([{opacity:1},{opacity:0}],{duration:280,easing:'ease-out',fill:'forwards'});f.finished.then(()=>ov.remove())})})});L.toast&&L.toast((pref==='auto'?'Auto':pref==='dark'?'Dark':'Light')+' mode on')});
  document.addEventListener('click',e=>{if(!m.hidden&&!m.contains(e.target))close()});document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!m.hidden){close();btn.focus()}});
})();
