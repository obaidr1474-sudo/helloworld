# LeadVolt backend 3.1 — single-company release candidate

An upgraded backend for the supplied LeadVolt Kit. The existing CRM design is retained with explicit v1 finance visibility gates added. This is a tested development/release candidate, not a published service or a guarantee of zero defects.

## Confirmed v1 scope

23 users: 10 iPhone, 9 Android, 4 desktop/web. Finance is hidden and invoice/deal/journal APIs are disabled by default, even for Admin. Automatic device call-log upload is deferred and disabled by default. Lead closure and manual contact notes remain in scope. `FEATURE_FINANCE_ENABLED=false` and `FEATURE_CALL_SYNC_ENABLED=false` are the launch defaults, not optional production examples to turn on during setup.

See `docs/LAUNCH-TRACKER.md` for proposed owners/dependency-based targets, `docs/AGENT-ONBOARDING-V1.md` for both mobile platforms and `docs/NGINX-SYSTEMD.md` for the tested deployment templates. The launch owner's actual name, staging host/domain and monitoring/backup recipients remain unassigned.

## Runtime and install

Use Node.js **22 LTS** (validated with 22.23.3), Linux x64 and a local persistent disk. SQLite WAL and the durable job queue are intended for **one company on one server**. Do not place the database on NFS or run replicas on different hosts. PostgreSQL/Redis migration is a separate change, not something this package pretends to include.

```sh
npm ci
npm test
node test/load.js
```

On the Codex workspace, whose default Node is 24 and home directory is read-only:

```sh
npm_config_devdir=/tmp/leadvolt-node-gyp npm exec --yes --package=node@22.23.3 -- npm ci --cache /workspace/.npm-cache
npm exec --yes --package=node@22.23.3 -- npm test
```

No TLS, package integrity, or signature verification needs to be disabled. A frozen `package-lock.json` is included. The latest locked SQLite package contains native prebuilds; incompatible architectures need their supported build toolchain.

## Local preview

With no `.env`, `npm start` runs a local development instance and seeds sample data only into an empty database. It binds to loopback by default. Sample sign-in: `obaid@leadvolt.ae` / `leadvolt123`. These credentials do not exist in a clean production database.

- `/` — original CRM design preview. Its sample-data UI is **not automatically wired** to this API.
- `/backend-status.html` — working administrator status page with authenticated database, portal and queue information.
- `/api/capabilities` — public launch feature availability (not provider readiness).
- `/leadvolt-api.js` — tested optional client adapter for connecting the existing frontend. See `docs/MOBILE-AND-FRONTEND.md`.

For a separate sample database, run `python scripts/run-preview.py` while Node 22 is active. The script uses port 4100 and a temporary data directory. Do not use this sample instance for customer data.

## Production bootstrap

1. Install dependencies with Node 22. Create `.env` from `.env.example`, protect it with owner-only permissions, and generate a unique random signing secret of at least 32 characters. Set persistent database/storage paths and the real frontend origin if it differs from the API origin.
2. Supply `ADMIN_EMAIL`, `ADMIN_NAME` and `ADMIN_PASSWORD` securely through your deployment environment; use a unique password of at least 16 characters. Run `npm run admin:create`. This command supports an empty database only. Remove the bootstrap variables after use.
3. Run `npm start` under a process supervisor. Put a trusted HTTPS reverse proxy in front of it; configure trusted proxy hops/IPs to match your deployment. Keep port 4000 private.
4. Sign in and invite agents through `POST /api/team/invite`. Temporary passwords must be changed before business APIs can be used. Deliver them securely; no invitation email provider is configured.
5. Connect the existing UI using the API adapter and validate the actual user journeys. Connect real portals and test their confirmed payload/signature formats before enabling lead delivery.
6. Exercise backup and restore with the real storage volume before launch. Monitor failed jobs, failed portal events and notification delivery.

`NODE_ENV=production` rejects empty/example signing secrets, disables automatic sample seeding, and rejects the test-only synchronous webhook adapter.

See `docs/DEPLOYMENT.md` for release gates, recovery and Docker status. See `docs/API-V3.md` for changed contracts. The original `API.md` documents v2 endpoints; the v3 document overrides changed behavior.

## What changed

- Default-deny module permission gates and record access checks; agent/team scoping for leads, AI, dashboard, reports, invoices and mobile reads.
- Server-side revocable JWT sessions; logout/logout-all, password-change revocation, temporary-password enforcement and administrator recovery tools.
- Durable asynchronous webhook ingestion with request/event deduplication, retries, expired lease recovery, failed-job inspection and replay.
- Durable notification outbox with stable notification identities. Push delivery is at least once; network failures can cause repeated provider requests. Clients should deduplicate by notification ID.
- Chunked CSV imports, explicit job progress and idempotency keys. The old synchronous CSV endpoint is retired.
- Per-user write token buckets, login throttling and bounded pending queues.
- Idempotent historical call uploads and offline note/status changes with revision conflict detection.
- Balanced integer-minor-unit financial journals, immutable sealed lines, idempotent posting and reversal entries. This is a journal foundation, **not a complete accounting, PDC, NOC or commission-split product**.
- Recording fetch allowlists, DNS destination checks, bounded downloads, no redirects and TLS verification.
- Checksummed backups and isolated restore verification; non-root Docker recipe and health checks.
- Dependency updates and additional API/browser/production/workload checks.

## Explicit remaining work before launch

The original frontend still needs integration. No native Android/iOS application, native call recorder, FCM/APNs native push connector, outbound WhatsApp/email provider, external LLM, payment processor, or live portal credentials are supplied. Web Push exists for supported browsers/PWAs. Email password recovery is not implemented; recovery is through an administrator/server operator. No public hosting/domain/TLS deployment has occurred. See the validation report for exactly what was exercised.
