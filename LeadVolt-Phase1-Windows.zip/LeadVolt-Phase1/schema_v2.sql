-- LeadVolt v2: portals, recordings, ad owners, notifications, roles, audit, attendance geofence, project wizard
CREATE TABLE IF NOT EXISTS roles (
  name TEXT PRIMARY KEY,                          -- Admin | Manager | SalesExecutive | Basic | HR | ListingManager | custom
  description TEXT, perms TEXT NOT NULL DEFAULT '{}' -- JSON: { "Leads": ["View","Create",...], ... }
);
CREATE TABLE IF NOT EXISTS teams (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, lead_id INTEGER REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS team_members (
  team_id INTEGER NOT NULL REFERENCES teams(id) ON DELETE CASCADE, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  PRIMARY KEY (team_id, user_id)
);
-- One row per portal advert. The owner is who the leads belong to, even if the ad is posted under someone else.
CREATE TABLE IF NOT EXISTS ad_refs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  portal TEXT NOT NULL, ref TEXT NOT NULL,        -- Ref ID comes from the portal, never typed in by us
  listing TEXT, posted_under TEXT,                -- portal account / agent the ad is published under
  owner_id INTEGER REFERENCES users(id),
  how TEXT NOT NULL DEFAULT 'none',               -- none | learned (first manual assign) | set (admin chose)
  leads_count INTEGER NOT NULL DEFAULT 0, last_lead_at TEXT, created_at TEXT DEFAULT (datetime('now')),
  UNIQUE (portal, ref)
);
-- Every inbound portal call, raw, for replay and audit. (portal, external_id) makes webhooks idempotent.
CREATE TABLE IF NOT EXISTS portal_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  portal TEXT NOT NULL, external_id TEXT NOT NULL, kind TEXT NOT NULL, -- lead | call | whatsapp | email
  payload TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'processed',   -- processed | duplicate | error
  error TEXT, lead_id INTEGER REFERENCES leads(id), received_at TEXT DEFAULT (datetime('now')),
  UNIQUE (portal, external_id)
);
CREATE TABLE IF NOT EXISTS recordings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lead_id INTEGER NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
  portal TEXT, external_id TEXT, source_url TEXT, -- never sent to the browser; streamed through /api/recordings/:id/stream
  stored_path TEXT,                               -- set when the file is copied into our own storage
  duration_sec INTEGER, direction TEXT, caller TEXT, agent_phone TEXT, answered INTEGER DEFAULT 1,
  started_at TEXT, created_at TEXT DEFAULT (datetime('now')),
  UNIQUE (portal, external_id)
);
CREATE TABLE IF NOT EXISTS shuffles (
  id INTEGER PRIMARY KEY AUTOINCREMENT, lead_id INTEGER NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
  from_id INTEGER REFERENCES users(id), to_id INTEGER REFERENCES users(id), by_id INTEGER REFERENCES users(id),
  reason TEXT, auto INTEGER DEFAULT 0, created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id), lead_id INTEGER REFERENCES leads(id) ON DELETE CASCADE,
  kind TEXT NOT NULL DEFAULT 'lead', title TEXT NOT NULL, body TEXT,
  status TEXT NOT NULL DEFAULT 'queued',          -- queued | sent | delivered | seen | failed
  attempts INTEGER NOT NULL DEFAULT 0, channels TEXT,
  created_at TEXT DEFAULT (datetime('now')), sent_at TEXT, delivered_at TEXT, seen_at TEXT, escalated INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_notif_user ON notifications(user_id, id DESC);
CREATE TABLE IF NOT EXISTS push_subs (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  endpoint TEXT NOT NULL UNIQUE, p256dh TEXT NOT NULL, auth TEXT NOT NULL, ua TEXT,
  created_at TEXT DEFAULT (datetime('now')), last_ok_at TEXT, fails INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, user_name TEXT,
  method TEXT, path TEXT, status INTEGER, action TEXT, detail TEXT, ip TEXT, at TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_audit_at ON audit_log(id DESC);
CREATE TABLE IF NOT EXISTS project_blocks (
  id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  name TEXT NOT NULL, floors INTEGER, units_per_floor INTEGER, phase TEXT, handover_date TEXT, progress INTEGER DEFAULT 0,
  UNIQUE (project_id, name)
);
CREATE TABLE IF NOT EXISTS media (
  id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
  kind TEXT NOT NULL,                              -- photo | video | brochure | link
  file_name TEXT, stored_path TEXT, url TEXT, mime TEXT, bytes INTEGER, is_cover INTEGER DEFAULT 0, sort INTEGER DEFAULT 0,
  uploaded_by INTEGER REFERENCES users(id), created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS login_attempts ( key TEXT PRIMARY KEY, count INTEGER NOT NULL, first_at INTEGER NOT NULL );
