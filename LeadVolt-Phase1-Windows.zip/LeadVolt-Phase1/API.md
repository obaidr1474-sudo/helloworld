# LeadVolt API reference · v1.0
Base URL: `http://localhost:4000/api` · All bodies are JSON · Designed for LeadVolt by Obaid Raza

## Authentication
Every endpoint except `/health` and `/auth/login` needs a header:
`Authorization: Bearer <token>`. Tokens last 8 hours.
Errors always look like `{ "error": "Readable message" }` with status 400, 401, 403, 404 or 500.

| Method | Path | Body / query | Returns |
|---|---|---|---|
| GET | `/health` | | `{ ok, name, version }` |
| POST | `/auth/login` | `{ email, password }` | `{ token, user }` |
| GET | `/auth/me` | | the signed-in user |

## Dashboard
| GET | `/dashboard?range=today\|week\|month\|quarter\|all` | | totals, `byStatus`, top 5 `sources`, `revenue`, `funnel`, today's `reminders`, top `closers`, `focus` (callbacks, overdue, next visit) |
|---|---|---|---|

## Leads
| Method | Path | Body / query | Notes |
|---|---|---|---|
| GET | `/leads` | `q, status, source, agent_id, tab=all\|deleted\|duplicate, sort=name\|budget\|score\|last_contact\|created, dir=asc\|desc, page, limit` | `{ data, page, limit, total, counts }`. Agents only see their own leads; managers and team leads see all. |
| POST | `/leads` | `{ name, phone, email?, source?, budget?, project_id?, agent_id? }` | Validates name and phone, flags duplicates by phone, auto-assigns by round robin if no agent. |
| GET | `/leads/:id` | | Lead plus `activity` timeline |
| PATCH | `/leads/:id` | any of `status, agent_id, score, budget, project_id, email, phone, name` | Status changes are logged to the timeline |
| DELETE | `/leads/:id` | | Soft delete (appears under the Deleted tab) |
| POST | `/leads/bulk` | `{ ids:[], agent_id?, status? }` | Assign or move many leads at once |
| POST | `/leads/:id/notes` | `{ text }` | Adds a note to the timeline |
| POST | `/leads/:id/activity` | `{ kind: call\|whatsapp\|visit\|note, text }` | Logs a call or message |

Statuses: `New, Callback, Meeting Done, Site Visit Done, Booked, Invoiced, Overdue`.

**Extra lead fields** (create and update): `alternate_phone, landline, country_code, sub_source, budget_min, budget_max, currency, enquired_for (Buy|Rent), property_type, beds, baths, community, city, country, referral_name, referral_phone, referral_email, notes`.

**Smart behaviour**
- Same phone number again: the new lead is flagged as a repeat enquiry and linked to the original (`root_id`).
- Round robin: the agent in the rotation who was assigned least recently gets the lead; safe when many leads arrive at once.
- `PATCH` with a new `status` writes a `status_history` row. Add `scheduled_at` (`YYYY-MM-DDTHH:MM`) to create the follow-up task automatically, and `status_notes` for context.
- Moving a lead to `Booked` creates a deal. Optional: `agreement_value, booked_under_name, purchased_from, booked_date, unit_id`.
- `GET /leads/:id` returns `status_history` and `deals` as well as `activity`.

## Deals
| GET | `/deals?agent_id=&from=YYYY-MM-DD` | | `{ data, total_value, count }` |
|---|---|---|---|

## Tasks
| GET | `/tasks?filter=all\|today\|upcoming\|overdue\|done&date=YYYY-MM-DD` | | `{ data, progress:{ total, done } }` for today |
|---|---|---|---|
| POST | `/tasks` | `{ title, due_date, type?, lead_id?, assignee_id?, due_time?, priority? }` | |
| PATCH | `/tasks/:id` | `{ done?, due_date?, priority?, title?, assignee_id? }` | "Move to tomorrow" = change `due_date` |
| DELETE | `/tasks/:id` | | |

## Attendance
| GET | `/attendance/today` | | `{ me, team, summary:{ present, late, leave } }` |
|---|---|---|---|
| POST | `/attendance/clock-in` | `{ location? }` | Marks Late after 9:15 AM |
| POST | `/attendance/clock-out` | | |
| GET | `/attendance/month?month=YYYY-MM` | | `[ { day, rate } ]` for the calendar |

## Team
| GET | `/team` | | Members with `leads, booked, conversion, target_progress` |
|---|---|---|---|
| POST | `/team/invite` | `{ name, email, role?, access? }` | Managers only. Returns a `temporary_password` to share. |

## Projects, units and off plan
| GET | `/projects?status=Ready\|Off Plan&area=&q=` | | Projects with `units_left`, amenities |
|---|---|---|---|
| GET | `/projects/:id` | | Project plus `interested_leads` |
| GET | `/projects/:id/payment-plan?price=&installments=` | | Booking, installments and handover schedule with dates |
| GET | `/units?project_id=&type=&status=&max_price=&q=&sort=price\|size&dir=` | | Units with `price_per_sqft` and `reserved_for` |
| POST | `/units/:id/reserve` | `{ lead_id, hold_days }` | Reserves an available unit and logs it on the lead |

## Invoices
| GET | `/invoices?status=Paid\|Pending\|Overdue\|Draft` | | `{ data, totals:{ paid, pending, overdue, count } }`. Pending invoices past due become Overdue automatically. Each invoice includes `subtotal, vat, total`. |
|---|---|---|---|
| GET | `/invoices/:id` | | |
| POST | `/invoices` | `{ lead_id, property_price, commission_pct?, unit_id?, due_in_days?, draft? }` | Number continues the INV-YYYY-0000 sequence |
| PATCH | `/invoices/:id` | `{ status: Paid\|Pending\|Draft }` | |

## Data import
| POST | `/imports/preview` | `{ csv }` | `{ headers, mapping, rows, total_rows }` with columns matched automatically |
|---|---|---|---|
| POST | `/imports` | `{ csv, file_name, mapping?, agent_id? }` | `{ added, skipped }`. Rows without name or phone are skipped. |
| GET | `/imports` | | Import history |
| POST | `/imports/leadrat` | `{ leads:[ ... ], file_name? }` | Moves your own company's leads from Leadrat's format (`contactNo`, `lowerBudget`, `upperBudget`, `enquiredCommunity`, `assignedUser`, status names...) into LeadVolt. Leads already moved (same id) are skipped. Returns `{ added, skipped, already_imported, errors }`. |

## Reports
| GET | `/reports/summary?range=` | | `kpis`, daily `trend` (leads, booked, visits), `sources` with conversion, `agents` leaderboard, `best_time_to_call` |
|---|---|---|---|

## Settings (Global Config + Org Profile)
| GET | `/settings` | | All sections |
|---|---|---|---|
| GET | `/settings/:section` | | One section |
| PUT | `/settings/:section` | section values | Managers only |

Sections: `assignment, notifications, integrations, security, org, branding, working_days`.

## LeadVolt AI
| POST | `/ai/ask` | `{ question }` | `{ answer, items }` |
|---|---|---|---|

Today it answers from the database with rules (hot leads, overdue, best agent, units under a budget, a lead by name, pipeline summary). To use a real AI model, send the question and the same data to your AI provider inside `src/routes/ai.js`.

## Quick test with curl
```
curl -X POST localhost:4000/api/auth/login -H "Content-Type: application/json" \
  -d '{"email":"obaid@leadvolt.ae","password":"leadvolt123"}'
curl localhost:4000/api/leads -H "Authorization: Bearer <token>"
```

---
# v2 endpoints
All need `Authorization: Bearer <token>` unless marked **public**. Errors are `{ "error": "message" }`, some with a `code`.

## Portal webhooks
| Method | Path | Notes |
|---|---|---|
| POST **public** | `/api/integrations/:portal/webhook` | portal = bayut, dubizzle, property-finder, skyloov, website, webhook. Header `X-LeadVolt-Signature: sha256=<hmac of raw body>` or `?token=<secret>`. Body: one event, an array, or `{data|leads|events:[...]}`. Returns `{ results:[{external_id, kind, status: created|updated|duplicate|error, lead_id}] }` |
| GET | `/api/integrations/status` | Per portal: configured, enabled, webhook path, events and errors in the last 7 days |
| GET | `/api/integrations/events?portal=&status=` | Raw inbound events |
| POST | `/api/integrations/events/:id/replay` | Re-run a failed event after fixing the mapping |

## Ref IDs (ad owners)
| GET | `/api/ad-refs?pending=1&portal=` | pending = no owner yet |
|---|---|---|
| PATCH | `/api/ad-refs/:id` | `{ owner_id \| null, route_existing?: true }` |

## Leads (new / changed)
| GET | `/api/leads?scope=all\|my\|team\|unassigned\|deleted\|duplicate\|reenquired&tag=&portal=&ad_ref=&sub_status=` | |
|---|---|---|
| POST | `/api/leads/:id/assign` | `{ agent_id \| null, learn?: true }` → `{ learned: {portal, ref, owner} \| null }` |
| POST | `/api/leads/:id/shuffle` | `{ to_id?, reason }` |
| PUT | `/api/leads/:id/tags` | `{ tags: ["Hot","Investor"] }` |
| POST | `/api/leads/bulk` | `{ ids, agent_id?, status?, tags_add? }` (assigning teaches ad owners too) |
| POST | `/api/leads/:id/restore` | |
| GET | `/api/leads/:id` | now includes `recordings`, `shuffles`, `ad_owner`; opening it as the agent marks alerts seen |

## Recordings
| GET | `/api/recordings?lead_id=` | list (no portal URLs) |
|---|---|---|
| GET | `/api/recordings/:id/link` | `{ url, expires_at }` for `<audio src>` (10 min) |
| GET **public, signed** | `/api/recordings/:id/stream?u&exp&sig` | audio, supports `Range` |

## Notifications & push
| GET | `/api/notifications?unseen=1` | `{ data, unseen }` |
|---|---|---|
| POST | `/api/notifications/:id/seen` · `/:id/delivered` · `/api/notifications/seen-all` | |
| GET | `/api/notifications/report?days=7` | managers: per-agent reached / delivered / seen / failed / minutes to seen / devices |
| GET | `/api/push/key` | VAPID public key |
| POST/DELETE | `/api/push/subscribe` | browser PushSubscription JSON |
| POST | `/api/push/test` | sends a test alert to your devices |
| GET | `/api/stream?token=` | Server-Sent Events: `notification` events |
| POST **public** | `/api/notifications/ack` | `{id,u,t}` from the service worker |

## Attendance
| GET | `/api/attendance/rules` | start, end, late_after, offices, radius |
|---|---|---|
| POST | `/api/attendance/clock-in` | `{ lat, lng, accuracy, late_reason? }`. Codes: LOCATION_REQUIRED, LOW_ACCURACY, OUTSIDE_OFFICE (with distance_m), REASON_REQUIRED (with minutes_late), NO_OFFICE |
| POST | `/api/attendance/clock-out` | |
| POST | `/api/attendance/mark` | managers/HR: `{ user_id, status: Present\|On site\|Remote\|Leave\|Absent\|Late, note }` |
| GET | `/api/attendance/late?from=&to=` | late arrivals with reasons |
| PUT | `/api/settings/attendance` | `{ start, end, late_after:"10:30", ask_reason, reason_required, geofence, radius_m, max_accuracy_m, offices:[{name,lat,lng,radius_m}], remote_roles:[] }` |

## Tasks (changed)
`POST /api/tasks { title, assignee_id, due_date, due_time, description, priority: Critical|High|Medium|Low, type?, lead_id?, reminder? }` — the assignee gets a push. `GET /api/tasks` returns `counts` (today, upcoming, overdue, completed, total).

## Projects wizard & media
| POST | `/api/projects` | name, type, sub_type, status, area, land_area, certificate, facing[], total_blocks, total_floors, description, notes, developer, pocs[], rera[], price_min, price_max, brokerage, start_date, end_date, handover_date, amenities[], blocks[{name,floors,units_per_floor,phase,handover_date,progress}], units[{name,type,size,price,block,qty,furnishing,view}] |
|---|---|---|
| POST | `/api/projects/:id/media?kind=photo\|video\|brochure` | multipart `files[]` (jpg/png/bmp/webp ≤10 MB, mp4 ≤200 MB, pdf ≤25 MB; content is checked) → `{ saved, rejected }` |
| POST | `/api/projects/:id/media?kind=link` | `{ url }` (https only) |
| PATCH/DELETE/GET | `/api/media/:id` | `{ is_cover, sort }` |

## Roles, users, teams, audit
| GET | `/api/roles/catalog` · `/api/roles` | |
|---|---|---|
| POST/PUT/DELETE | `/api/roles` · `/api/roles/:name` | `{ name, description, perms: { "Leads": ["View", ...] } }` (validated against the catalog) |
| PATCH | `/api/users/:id` | `{ role_name, active, phone }` (keeps at least one Admin; deactivating clears their devices and ad ownership) |
| GET/POST/PUT | `/api/teams` · `/api/teams/:id` | `{ name, lead_id, member_ids }` |
| GET | `/api/audit?q=&user_id=&from=&limit=` | |
| POST | `/api/auth/password` | `{ current, next }` |

## Settings sections
assignment (`auto, method, reassign, minutes, pool`) · listing (`learn, unknown_ref: unassigned|round_robin`) · leads (`reenq_days, note_required`) · escalation (`resend_min, escalate_min`) · attendance · portals (secrets masked as •••) · integrations_cfg (`store_recordings`) · plus the v1 sections.
