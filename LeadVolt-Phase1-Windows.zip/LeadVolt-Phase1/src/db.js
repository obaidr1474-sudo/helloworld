require('./config');
// Database connection, schema bootstrap and safe column migrations
const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');
if(process.env.DB_FILE&&process.env.DB_FILE!==':memory:')fs.mkdirSync(path.dirname(path.resolve(process.env.DB_FILE)),{recursive:true,mode:0o700});
const db = new Database(process.env.DB_FILE || path.join(__dirname, '..', 'leadvolt.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.pragma('busy_timeout = 5000');
db.exec(fs.readFileSync(path.join(__dirname, '..', 'schema.sql'), 'utf8'));
db.exec(fs.readFileSync(path.join(__dirname, '..', 'schema_v2.sql'), 'utf8'));
// Add a column only if it is missing, so old databases upgrade in place.
const addCol = (t, c, def) => { if (!db.prepare(`PRAGMA table_info(${t})`).all().some(x => x.name === c)) db.exec(`ALTER TABLE ${t} ADD COLUMN ${c} ${def}`); };
[['leads', 'portal', 'TEXT'], ['leads', 'ad_ref', 'TEXT'], ['leads', 'external_id', 'TEXT'], ['leads', 'tags', "TEXT DEFAULT '[]'"], ['leads', 'sub_status', 'TEXT'],
 ['leads', 'assigned_at', 'TEXT'], ['leads', 'first_opened_at', 'TEXT'], ['leads', 'first_contact_at', 'TEXT'], ['leads', 'is_reenquired', 'INTEGER DEFAULT 0'],
 ['users', 'role_name', 'TEXT'], ['users', 'phone_ext', 'TEXT'],
 ['attendance', 'late_reason', 'TEXT'], ['attendance', 'lat', 'REAL'], ['attendance', 'lng', 'REAL'], ['attendance', 'accuracy_m', 'REAL'], ['attendance', 'distance_m', 'REAL'],
 ['attendance', 'office', 'TEXT'], ['attendance', 'marked_by', 'INTEGER'], ['attendance', 'note', 'TEXT'], ['attendance', 'device', 'TEXT'],
 ['tasks', 'description', 'TEXT'], ['tasks', 'reminder', 'TEXT'], ['tasks', 'created_by', 'INTEGER'],
 ['projects', 'type', 'TEXT'], ['projects', 'sub_type', 'TEXT'], ['projects', 'certificate', 'TEXT'], ['projects', 'facing', "TEXT DEFAULT '[]'"], ['projects', 'land_area', 'TEXT'],
 ['projects', 'total_blocks', 'INTEGER'], ['projects', 'total_floors', 'INTEGER'], ['projects', 'notes', 'TEXT'], ['projects', 'rera', "TEXT DEFAULT '[]'"], ['projects', 'price_max', 'REAL'],
 ['projects', 'brokerage', 'TEXT'], ['projects', 'pocs', "TEXT DEFAULT '[]'"], ['projects', 'start_date', 'TEXT'], ['projects', 'end_date', 'TEXT'], ['projects', 'created_by', 'INTEGER'],
 ['units', 'block', 'TEXT'], ['units', 'furnishing', 'TEXT']
].forEach(([t, c, d]) => addCol(t, c, d));
db.exec(`CREATE INDEX IF NOT EXISTS idx_leads_adref ON leads(portal, ad_ref);
CREATE UNIQUE INDEX IF NOT EXISTS idx_leads_ext ON leads(portal, external_id) WHERE external_id IS NOT NULL;`);
addCol('notifications','dedupe_key','TEXT');
addCol('users','password_reset_required','INTEGER NOT NULL DEFAULT 0');
addCol('leads','revision','INTEGER NOT NULL DEFAULT 1');
// CRM deal commission metadata only; no journal/accounting schema changes.
addCol('deals','commission_pct','REAL CHECK(commission_pct IS NULL OR (commission_pct>=0 AND commission_pct<=100))');
addCol('deals','commission_override_minor','INTEGER CHECK(commission_override_minor IS NULL OR (commission_override_minor>=0 AND commission_override_minor<=9007199254740991))');
addCol('deals','commission_status',"TEXT NOT NULL DEFAULT 'pending' CHECK(commission_status IN ('pending','paid'))");
addCol('deals','commission_paid_at','TEXT');
addCol('deals','commission_paid_by','INTEGER REFERENCES users(id)');
addCol('deals','revision','INTEGER NOT NULL DEFAULT 1');
db.exec(fs.readFileSync(path.join(__dirname, '..', 'schema_v3.sql'), 'utf8'));
module.exports = db;
