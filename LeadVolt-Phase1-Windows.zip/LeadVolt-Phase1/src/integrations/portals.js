// Inbound portal integrations: Bayut, Dubizzle, Property Finder, Skyloov, Website, generic Webhook.
//
// IMPORTANT: each portal publishes its own payload format to agencies with API access. Field names below are
// tolerant guesses that cover the common shapes; confirm them against the portal's API documents and, if needed,
// set an exact mapping in settings.portals[<Portal>].map (dot paths) without touching code.
const crypto = require('crypto');
const db = require('../db');
const { getSetting, normPhone, parseBudget } = require('../util');
const A = require('../services/assign');
const PORTALS = { bayut: 'Bayut', dubizzle: 'Dubizzle', 'property-finder': 'Property Finder', propertyfinder: 'Property Finder', skyloov: 'Skyloov', website: 'Website', webhook: 'Webhook' };
const get = (o, path) => path.split('.').reduce((v, k) => (v == null ? v : v[k]), o);
const pick = (o, paths) => { for (const p of paths) { const v = get(o, p); if (v != null && v !== '') return v; } return null; };
const F = {
  id: ['id', 'event_id', 'lead_id', 'leadId', 'enquiry_id', 'inquiry_id', 'call_id', 'uuid'],
  kind: ['type', 'event', 'event_type', 'kind', 'channel'],
  name: ['name', 'full_name', 'client_name', 'customer_name', 'contact.name', 'lead.name', 'user.name', 'caller_name'],
  phone: ['phone', 'mobile', 'phone_number', 'contact.phone', 'contact.mobile', 'lead.phone', 'user.phone', 'caller_number', 'caller', 'from'],
  email: ['email', 'contact.email', 'lead.email', 'user.email'],
  ref: ['ref', 'reference', 'ref_id', 'refId', 'property_reference', 'property_ref', 'listing_reference', 'listing.reference', 'listing.ref', 'property.reference', 'ad_id', 'listing_id', 'property_id'],
  listing: ['listing_title', 'listing.title', 'property.title', 'property_title', 'title'],
  posted_under: ['agent_name', 'agent.name', 'listing.agent.name', 'broker_name', 'posted_by'],
  message: ['message', 'comment', 'notes', 'enquiry', 'inquiry', 'text', 'body'],
  budget: ['budget', 'price', 'listing.price', 'property.price'],
  recording: ['recording_url', 'recording', 'recordingUrl', 'call.recording_url', 'audio_url', 'call_recording'],
  duration: ['duration', 'call_duration', 'duration_sec', 'call.duration', 'billsec'],
  direction: ['direction', 'call.direction'],
  status: ['call_status', 'status', 'call.status', 'disposition'],
  started: ['started_at', 'start_time', 'call_time', 'call.started_at', 'created_at', 'timestamp'],
  agent_phone: ['agent_phone', 'agent_number', 'to', 'tracking_number'],
};
function normalize(portal, body) {
  const map = (getSetting('portals', {})[portal] || {}).map || {};
  const items = Array.isArray(body) ? body : Array.isArray(body.data) ? body.data : Array.isArray(body.leads) ? body.leads : Array.isArray(body.events) ? body.events : [body];
  if(items.length>1000||items.some(o=>!o||typeof o!=='object'||Array.isArray(o)))throw Object.assign(new Error('Expected at most 1,000 event objects'),{status:400});
  return items.map(o => {
    const f = k => map[k] ? get(o, map[k]) : pick(o, F[k]);
    const kindRaw = String(f('kind') || '').toLowerCase(), rec = f('recording');
    const kind = /call|phone|voice/.test(kindRaw) || rec || f('duration') != null ? 'call' : /whats|chat|sms/.test(kindRaw) ? 'whatsapp' : 'lead';
    const st = String(f('status') || '').toLowerCase();
    const extId = f('id') || require('../services/ingest').hash(o).slice(0,32); // no id -> content hash keeps retries idempotent
    return { kind, external_id: String(extId), name: f('name'), phone: f('phone') ? normPhone(f('phone')) : null, email: f('email'), ad_ref: f('ref') != null ? String(f('ref')) : null,
      listing: f('listing'), posted_under: f('posted_under'), message: f('message'), budget: f('budget'), raw: o,
      call: kind === 'call' ? { recording_url: rec, duration: parseInt(f('duration')) || null, direction: f('direction') || 'inbound', answered: !/miss|no.?answer|unanswered|busy|fail/.test(st), started_at: f('started'), agent_phone: f('agent_phone') } : null };
  });
}
// Verify the request really came from the portal: HMAC-SHA256 of the raw body, or a per-portal token in the URL/header.
function verify(portal, req) {
  const cfg = getSetting('portals', {})[portal] || {};
  const envKey = portal.toUpperCase().replace(/\s+/g, '_') + '_WEBHOOK_SECRET';
  const secret = process.env[envKey] || cfg.secret;
  if (!secret) return { ok: false, why: `No secret configured for ${portal}. Set ${envKey} or settings.portals.${portal}.secret` };
  if (cfg.enabled === false) return { ok: false, why: `${portal} integration is switched off` };
  const sig = req.get('x-leadvolt-signature') || req.get('x-signature') || req.get('x-hub-signature-256') || '';
  if (sig) {
    const want = 'sha256=' + crypto.createHmac('sha256', secret).update(req.rawBody || '').digest('hex');
    const a = Buffer.from(sig.startsWith('sha256=') ? sig : 'sha256=' + sig), b = Buffer.from(want);
    return { ok: a.length === b.length && crypto.timingSafeEqual(a, b), why: 'Bad signature' };
  }
  const tok = req.query.token || req.get('x-webhook-token') || '';
  const a = Buffer.from(String(tok)), b = Buffer.from(secret);
  return { ok: a.length === b.length && crypto.timingSafeEqual(a, b), why: 'Missing or wrong token' };
}
const act = (lead, kind, text) => db.prepare('INSERT INTO activities (lead_id,user_id,kind,text) VALUES (?,?,?,?)').run(lead, null, kind, text);
// Process one normalized event inside a transaction. Returns { status, lead_id, announce? }.
function processEvent(portal, ev) {
  return db.transaction(() => {
    const ins = db.prepare('INSERT OR IGNORE INTO portal_events (portal,external_id,kind,payload) VALUES (?,?,?,?)').run(portal, ev.external_id, ev.kind, JSON.stringify(ev.raw));
    if (!ins.changes) return { status: 'duplicate' };
    const evId = ins.lastInsertRowid;
    if (!ev.phone && !ev.email) { db.prepare("UPDATE portal_events SET status='error', error=? WHERE id=?").run('No phone or email in payload', evId); return { status: 'error', error: 'No phone or email in payload' }; }
    const ad = A.touchAd(portal, ev.ad_ref, ev);
    let lead = ev.phone ? db.prepare("SELECT * FROM leads WHERE is_deleted=0 AND REPLACE(phone,' ','')=? ORDER BY id DESC LIMIT 1").get(ev.phone) : db.prepare('SELECT * FROM leads WHERE is_deleted=0 AND email=? ORDER BY id DESC LIMIT 1').get(ev.email);
    let announce = null, created = false;
    const reenqDays = +(getSetting('leads', {}).reenq_days || 30);
    const recent = lead && (Date.now() - new Date(lead.created_at + 'Z').getTime()) / 864e5 <= reenqDays;
    const sameAd = lead && lead.ad_ref && ev.ad_ref && lead.ad_ref === ev.ad_ref && lead.portal === portal;
    if (!lead || !(recent && (sameAd || ev.kind === 'call'))) {
      // New lead (or the same person on a different ad = re-enquiry with its own routing)
      const { agent_id, why } = A.route({ portal, ad_ref: ev.ad_ref });
      const name = ev.name || (ev.kind === 'call' ? 'Caller ' + (ev.phone || '').slice(-4) : 'Portal lead');
      const id = db.prepare(`INSERT INTO leads (name,phone,email,source,sub_source,portal,ad_ref,external_id,notes,budget,budget_value,status,agent_id,assigned_at,is_duplicate,is_reenquired,root_id,last_contact_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,'New',?,CASE WHEN ? IS NULL THEN NULL ELSE datetime('now') END,?,?,?,datetime('now'))`).run(name, ev.phone || '', ev.email || null, portal, portal + ' ' + ev.kind, portal, ev.ad_ref, ev.external_id, ev.message || null,
        ev.budget != null ? String(ev.budget) : null, parseBudget(ev.budget), agent_id, agent_id, lead ? 1 : 0, lead ? 1 : 0, lead ? (lead.root_id || lead.id) : null).lastInsertRowid;
      db.prepare('INSERT INTO lead_status_history (lead_id,to_status,notes) VALUES (?,?,?)').run(id, 'New', `From ${portal}${ev.ad_ref ? ' · Ref ' + ev.ad_ref : ''} · ${why === 'ad_owner' ? 'routed to ad owner' : why === 'unknown_ad' ? 'new ad, waiting for an admin' : 'round robin'}`);
      act(id, 'portal', `${portal} ${ev.kind}${ev.ad_ref ? ' on Ref ' + ev.ad_ref : ''}${ev.listing ? ' (' + ev.listing + ')' : ''}${ev.message ? ': ' + ev.message : ''}`);
      lead = db.prepare('SELECT * FROM leads WHERE id=?').get(id); created = true; announce = why;
    } else {
      act(lead.id, ev.kind === 'call' ? 'call' : 'portal', `${portal} ${ev.kind} again${ev.ad_ref ? ' on Ref ' + ev.ad_ref : ''}${ev.message ? ': ' + ev.message : ''}`);
      db.prepare("UPDATE leads SET last_contact_at=datetime('now') WHERE id=?").run(lead.id);
    }
    if (ev.call) {
      if (ev.call.recording_url || ev.call.duration) db.prepare('INSERT OR IGNORE INTO recordings (lead_id,portal,external_id,source_url,duration_sec,direction,caller,agent_phone,answered,started_at) VALUES (?,?,?,?,?,?,?,?,?,?)')
        .run(lead.id, portal, ev.external_id, ev.call.recording_url || null, ev.call.duration, ev.call.direction, ev.phone, ev.call.agent_phone || null, ev.call.answered ? 1 : 0, ev.call.started_at || null);
      act(lead.id, 'call', `${ev.call.answered ? 'Call' : 'Missed call'} via ${portal}${ev.call.duration ? ', ' + Math.round(ev.call.duration / 60 * 10) / 10 + ' min' : ''}${ev.call.recording_url ? ' · recording saved' : ''}`);
      if (!ev.call.answered) { const d = new Date(); const day = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
        db.prepare("INSERT INTO tasks (title,type,lead_id,assignee_id,due_date,due_time,priority,description) VALUES (?,?,?,?,?,?,'Critical',?)").run('Call back ' + lead.name + ' (missed ' + portal + ' call)', 'Call', lead.id, lead.agent_id, day, String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'), 'Missed call from ' + ev.phone); }
    }
    db.prepare('UPDATE portal_events SET lead_id=? WHERE id=?').run(lead.id, evId);
    if(process.env.NODE_ENV!=='test'||process.env.WEBHOOK_SYNC!=='1'){if(announce)require('../services/jobs').enqueue('announce',`announce:${portal}:${ev.external_id}`,{lead,why:announce});else if(lead.agent_id)require('../services/notify').persist(lead.agent_id,{title:`${lead.name} contacted you again on ${portal}`,body:ev.message||'',lead_id:lead.id,dedupe_key:`portal-update:${portal}:${ev.external_id}`});}
    return { status: created ? 'created' : 'updated', lead_id: lead.id, ad_owner: ad && ad.owner_id || null, announce, lead };
  }).immediate();
}
module.exports = { PORTALS, normalize, verify, processEvent };
