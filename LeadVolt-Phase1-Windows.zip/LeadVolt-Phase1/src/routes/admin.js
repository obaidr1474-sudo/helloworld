// Roles & permissions, ad Ref IDs, audit log, users' roles, teams
const r = require('express').Router();
const db = require('../db');
const { wrap, bad, need, clearUserCache } = require('../util');
const CAT = require('../perms.json').catalog;
const role = x => x && ({ ...x, perms: JSON.parse(x.perms), users: db.prepare('SELECT COUNT(*) c FROM users WHERE role_name=? AND active=1').get(x.name).c });
function cleanPerms(p) { const o = {}; for (const [m, list] of Object.entries(p || {})) { if (!CAT[m]) throw Object.assign(new Error('Unknown module: ' + m), { status: 400 }); const bad = list.filter(x => !CAT[m].includes(x)); if (bad.length) throw Object.assign(new Error(`Unknown permission in ${m}: ${bad.join(', ')}`), { status: 400 }); if (list.length) o[m] = [...new Set(list)]; } return o; }
// Roles
r.get('/roles/catalog', wrap((req, res) => res.json(CAT)));
r.get('/roles', need('Roles', 'View'), wrap((req, res) => res.json(db.prepare('SELECT * FROM roles ORDER BY name').all().map(role))));
r.post('/roles', need('Roles', 'Create'), wrap((req, res) => {
  const { name, description, perms } = req.body || {}; if (!/^[A-Za-z][\w ]{1,30}$/.test(name || '')) return bad(res, 'Role name: letters, numbers and spaces, up to 30');
  if (db.prepare('SELECT 1 FROM roles WHERE name=?').get(name)) return bad(res, 'That role already exists');
  db.prepare('INSERT INTO roles (name,description,perms) VALUES (?,?,?)').run(name, description || '', JSON.stringify(cleanPerms(perms)));
  res.status(201).json(role(db.prepare('SELECT * FROM roles WHERE name=?').get(name)));
}));
r.put('/roles/:name', need('Roles', 'Update'), wrap((req, res) => {
  const x = db.prepare('SELECT * FROM roles WHERE name=?').get(req.params.name); if (!x) return res.status(404).json({ error: 'Role not found' });
  if (x.name === 'Admin') return bad(res, 'Admin always has every permission');
  const b = req.body || {}; db.prepare('UPDATE roles SET description=COALESCE(?,description), perms=COALESCE(?,perms) WHERE name=?').run(b.description ?? null, b.perms ? JSON.stringify(cleanPerms(b.perms)) : null, x.name);
  clearUserCache(); res.json(role(db.prepare('SELECT * FROM roles WHERE name=?').get(x.name)));
}));
r.delete('/roles/:name', need('Roles', 'Delete'), wrap((req, res) => {
  if (['Admin', 'Manager', 'Basic', 'HR', 'SalesExecutive', 'ListingManager'].includes(req.params.name)) return bad(res, 'Built-in roles cannot be deleted');
  if (db.prepare('SELECT COUNT(*) c FROM users WHERE role_name=? AND active=1').get(req.params.name).c) return bad(res, 'Move the people in this role to another role first');
  db.prepare('DELETE FROM roles WHERE name=?').run(req.params.name); res.status(204).end();
}));
// Admin directory includes disabled accounts; no password hashes or session tokens.
r.get('/users',wrap((req,res)=>{
  if(req.user.role_name!=='Admin')return res.status(403).json({error:'Admin only'});
  const status=req.query.status||'all';
  if(!['all','active','inactive'].includes(status))return bad(res,'Status must be all, active or inactive');
  const data=db.prepare(`SELECT id,name,email,role,role_name,access,active,phone,initials,password_reset_required FROM users ${status==='all'?'':'WHERE active='+ (status==='active'?1:0)} ORDER BY name,id`).all();
  res.json({data,count:data.length});
}));
// PATCH /api/users/:id { role_name?, active?, phone? }
r.patch('/users/:id', need('Users', 'Update'), wrap((req, res) => {
  if(req.user.role_name!=='Admin')return res.status(403).json({error:'Only Admin can change user accounts'});
  const b = req.body || {}, id = +req.params.id, u = db.prepare('SELECT * FROM users WHERE id=?').get(id); if (!u) return res.status(404).json({ error: 'User not found' });
  if(Object.keys(b).some(k=>!['role_name','active','phone'].includes(k))||!Object.keys(b).length)return bad(res,'Unsupported or empty user update');
  if(b.active!==undefined&&typeof b.active!=='boolean')return bad(res,'active must be true or false');
  if(b.role_name!==undefined&&(typeof b.role_name!=='string'||!b.role_name))return bad(res,'Invalid role');
  if(b.phone!==undefined&&(typeof b.phone!=='string'||b.phone.length>40))return bad(res,'Invalid phone');
  if (b.role_name && !db.prepare('SELECT 1 FROM roles WHERE name=?').get(b.role_name)) return bad(res, 'Unknown role');
  if (id === req.user.id && (b.active === false || (b.role_name && b.role_name !== 'Admin' && u.role_name === 'Admin'))) return bad(res, 'You cannot remove your own admin access');
  if (u.role_name === 'Admin' && (b.active === false || (b.role_name && b.role_name !== 'Admin')) && db.prepare("SELECT COUNT(*) c FROM users WHERE role_name='Admin' AND active=1").get().c < 2) return bad(res, 'Keep at least one active Admin');
  db.prepare('UPDATE users SET role_name=COALESCE(?,role_name), active=COALESCE(?,active), phone=COALESCE(?,phone) WHERE id=?').run(b.role_name || null, b.active == null ? null : (b.active ? 1 : 0), b.phone || null, id);
  if (b.active === false || b.role_name) db.prepare('UPDATE sessions SET revoked=1 WHERE user_id=?').run(id);
  if (b.active === false) { db.prepare('DELETE FROM push_subs WHERE user_id=?').run(id); db.prepare("UPDATE ad_refs SET owner_id=NULL, how='none' WHERE owner_id=?").run(id); }
  clearUserCache(); res.json(db.prepare('SELECT id,name,email,role,role_name,active FROM users WHERE id=?').get(id));
}));
// Teams
r.get('/teams', need('Teams', 'View'), wrap((req, res) => res.json(db.prepare('SELECT t.*, u.name lead FROM teams t LEFT JOIN users u ON u.id=t.lead_id ORDER BY t.name').all().map(t => ({ ...t, members: db.prepare('SELECT u.id,u.name FROM team_members m JOIN users u ON u.id=m.user_id WHERE m.team_id=?').all(t.id) })))));
r.post('/teams', need('Teams', 'Create'), wrap((req, res) => {
  const { name, lead_id, member_ids = [] } = req.body || {}; if (!String(name || '').trim()) return bad(res, 'Name the team');
  const id = db.transaction(() => { const id = db.prepare('INSERT INTO teams (name,lead_id) VALUES (?,?)').run(name.trim(), lead_id || null).lastInsertRowid; [...new Set([lead_id, ...member_ids].filter(Boolean))].forEach(u => db.prepare('INSERT OR IGNORE INTO team_members VALUES (?,?)').run(id, u)); return id; })();
  res.status(201).json(db.prepare('SELECT * FROM teams WHERE id=?').get(id));
}));
r.put('/teams/:id', need('Teams', 'Update'), wrap((req, res) => {
  const id = +req.params.id, { name, lead_id, member_ids } = req.body || {};
  db.transaction(() => { db.prepare('UPDATE teams SET name=COALESCE(?,name), lead_id=COALESCE(?,lead_id) WHERE id=?').run(name || null, lead_id || null, id); if (Array.isArray(member_ids)) { db.prepare('DELETE FROM team_members WHERE team_id=?').run(id); [...new Set([lead_id, ...member_ids].filter(Boolean))].forEach(u => db.prepare('INSERT OR IGNORE INTO team_members VALUES (?,?)').run(id, u)); } })();
  res.json({ ok: true });
}));
// Ad Ref IDs (come from the portals, never typed in by us)
r.get('/ad-refs', need('Listing', 'View'), wrap((req, res) => {
  const w = []; if (req.query.pending) w.push('a.owner_id IS NULL'); if (req.query.portal) w.push('a.portal=@portal');
  res.json(db.prepare(`SELECT a.*, u.name owner FROM ad_refs a LEFT JOIN users u ON u.id=a.owner_id ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY a.owner_id IS NOT NULL, a.last_lead_at DESC`).all(req.query.portal ? { portal: req.query.portal } : {}));
}));
// PATCH /api/ad-refs/:id { owner_id | null, route_existing?: true }  -> admin sets the owner; optionally hand over unassigned leads already on that ad
r.patch('/ad-refs/:id', need('Listing', 'Manage Ref IDs'), wrap((req, res) => {
  const a = db.prepare('SELECT * FROM ad_refs WHERE id=?').get(+req.params.id); if (!a) return res.status(404).json({ error: 'Ref ID not found' });
  const b = req.body || {}; if (!('owner_id' in b)) return bad(res, 'owner_id is required');
  if (b.owner_id && !db.prepare('SELECT 1 FROM users WHERE id=? AND active=1').get(b.owner_id)) return bad(res, 'That user is not active');
  db.prepare('UPDATE ad_refs SET owner_id=?, how=? WHERE id=?').run(b.owner_id || null, b.owner_id ? 'set' : 'none', a.id);
  let moved = 0; if (b.owner_id && b.route_existing) { const A = require('../services/assign'); db.prepare('SELECT id FROM leads WHERE portal=? AND ad_ref=? AND agent_id IS NULL AND is_deleted=0').all(a.portal, a.ref).forEach(l => { A.assign(l.id, b.owner_id, req.user.id, { learn: false, reason: 'Ad owner set' }); moved++; }); }
  res.json({ ...db.prepare('SELECT a.*, u.name owner FROM ad_refs a LEFT JOIN users u ON u.id=a.owner_id WHERE a.id=?').get(a.id), leads_moved: moved });
}));
// Audit log
r.get('/audit', need('Global Settings', 'View'), wrap((req, res) => {
  if(req.user.role_name!=='Admin')return res.status(403).json({error:'Audit logs are restricted to Admin'});
  const w = [], p = []; if (req.query.user_id) { w.push('user_id=?'); p.push(+req.query.user_id); } if (req.query.q) { w.push('(action LIKE ? OR path LIKE ? OR detail LIKE ?)'); const s = `%${req.query.q}%`; p.push(s, s, s); }
  if (req.query.from) { w.push('at>=?'); p.push(req.query.from); }
  res.json(db.prepare(`SELECT * FROM audit_log ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY id DESC LIMIT ?`).all(...p, Math.min(1000, +req.query.limit || 200)).map(x => ({ ...x, detail: x.detail ? JSON.parse(x.detail) : null })));
}));
r.post('/users/:id/reset-password',wrap((req,res)=>{
 if(req.user.role_name!=='Admin')return res.status(403).json({error:'Admin only'});
 const id=+req.params.id,password=req.body?.temporary_password===undefined?require('crypto').randomBytes(18).toString('base64url'):req.body.temporary_password;
 if(typeof password!=='string'||password.length<16||password.length>1024)return bad(res,'Temporary password must contain 16–1024 characters');
 if(!db.prepare('SELECT 1 FROM users WHERE id=?').get(id))return res.status(404).json({error:'User not found'});
 db.transaction(()=>{db.prepare('UPDATE users SET password_hash=?,password_reset_required=1 WHERE id=?').run(require('bcryptjs').hashSync(password,12),id);db.prepare('UPDATE sessions SET revoked=1 WHERE user_id=?').run(id);})();clearUserCache();res.json({ok:true,password_change_required:true,temporary_password:password});
}));
module.exports = r;
