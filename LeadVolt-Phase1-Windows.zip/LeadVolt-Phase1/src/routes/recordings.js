// Call recordings. Portal URLs never reach the browser: the player gets a short-lived signed link to our own stream.
const express = require('express');
const crypto = require('crypto');
const fs = require('fs'), path = require('path');
const db = require('../db');
const { wrap, can, seesAll, auth } = require('../util');
const SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';
const r = express.Router();
const sig = (id, exp, uid) => crypto.createHmac('sha256', SECRET).update(`rec:${id}:${exp}:${uid}`).digest('hex');
const allowed = (u, lead) => (can(u, 'Leads', 'View Call Recordings') || can(u, 'Integration', 'Listen Call Recordings')) && (seesAll(u) || lead.agent_id === u.id);
// GET /api/recordings?lead_id=   -> list for a lead
r.get('/', auth, wrap((req, res) => {
  const lead = db.prepare('SELECT id,agent_id FROM leads WHERE id=?').get(+req.query.lead_id); if (!lead) return res.status(404).json({ error: 'Lead not found' });
  if (!require('../util').can(req.user,'Leads','View') || !allowed(req.user, lead)) return res.status(403).json({ error: 'You are not allowed to listen to call recordings' });
  res.json(db.prepare('SELECT id,portal,duration_sec,direction,caller,agent_phone,answered,started_at,created_at,(source_url IS NOT NULL OR stored_path IS NOT NULL) has_audio FROM recordings WHERE lead_id=? ORDER BY id DESC').all(lead.id));
}));
// GET /api/recordings/:id/link  -> { url } valid 10 minutes, for <audio src>
r.get('/:id/link', auth, wrap((req, res) => {
  const rec = db.prepare('SELECT r.id, l.agent_id FROM recordings r JOIN leads l ON l.id=r.lead_id WHERE r.id=?').get(+req.params.id); if (!rec) return res.status(404).json({ error: 'Recording not found' });
  if (!require('../util').can(req.user,'Leads','View') || !allowed(req.user, rec)) return res.status(403).json({ error: 'You are not allowed to listen to call recordings' });
  const exp = Date.now() + 600000;
  db.prepare('INSERT INTO audit_log (user_id,user_name,method,path,status,action,detail) VALUES (?,?,?,?,?,?,?)').run(req.user.id, req.user.name, 'GET', req.path, 200, 'Played call recording', JSON.stringify({ recording_id: rec.id }));
  res.json({ url: `/api/recordings/${rec.id}/stream?u=${req.user.id}&exp=${exp}&sig=${sig(rec.id, exp, req.user.id)}`, expires_at: new Date(exp).toISOString() });
}));
// GET /api/recordings/:id/stream?u&exp&sig   (no bearer token, so an <audio> tag can play it; supports seeking via Range)
r.get('/:id/stream', wrap(async (req, res) => {
  const id = +req.params.id, exp = +req.query.exp, u = +req.query.u, s = String(req.query.sig || '');
  const want = sig(id, exp, u);
  if (!exp || exp < Date.now() || s.length !== want.length || !crypto.timingSafeEqual(Buffer.from(s), Buffer.from(want))) return res.status(403).json({ error: 'Link expired. Press play again.' });
  const user=require('../util').loadUser(u);const access=db.prepare('SELECT l.agent_id FROM recordings r JOIN leads l ON l.id=r.lead_id WHERE r.id=?').get(id);if(!user||!access||!allowed(user,access))return res.status(403).json({error:'Recording access revoked'});
  const rec = db.prepare('SELECT * FROM recordings WHERE id=?').get(id); if (!rec) return res.status(404).end();
  res.set('Cache-Control', 'private, no-store');
  if (rec.stored_path && fs.existsSync(rec.stored_path)) return res.sendFile(path.resolve(rec.stored_path));
  if (!rec.source_url) return res.status(404).json({ error: 'No audio for this call' });
  const headers = {}; if (req.headers.range) headers.Range = req.headers.range;
  let up;try{up=await require('../services/network').safeFetch(rec.source_url,{headers});}catch{return res.status(502).json({error:'Recording is unavailable or its host is not approved'});}
  if (!up.ok && up.status !== 206) return res.status(502).json({ error: `Portal returned ${up.status} for this recording` });
  res.status(up.status);
  ['content-type', 'content-length', 'content-range', 'accept-ranges'].forEach(h => { const v = up.headers.get(h); if (v) res.set(h, v); });
  if (!up.headers.get('content-type')) res.set('content-type', 'audio/mpeg');
  const { Readable } = require('stream'); Readable.fromWeb(up.body).on('error', () => res.end()).pipe(res);
}));
module.exports = r;
