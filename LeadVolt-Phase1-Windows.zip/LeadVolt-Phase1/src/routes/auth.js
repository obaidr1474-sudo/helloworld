const r = require('express').Router();
const bcrypt = require('bcryptjs');
const db = require('../db');
const { sign, auth, wrap, bad, loadUser } = require('../util');
const { loginLimit } = require('../middleware');
const DUMMY = bcrypt.hashSync('not-a-real-password', 10);
// POST /api/auth/login  { email, password }
r.post('/login',(req,res,next)=>{const r=require('../services/limits').take('login:'+req.ip,{capacity:30,perSecond:0.5});if(!r.allowed){res.set('Retry-After',String(r.retryAfter));return res.status(429).json({error:'Sign-in rate limit reached'});}next();}, loginLimit, wrap((req, res) => {
  const { email, password } = req.body || {};
  if (typeof email!=='string'||typeof password!=='string'||email.length>254||password.length>1024||!email||!password) return bad(res, 'Email and password are required');
  const u = db.prepare('SELECT * FROM users WHERE email = ? AND active = 1').get(String(email).toLowerCase().trim());
  const ok = bcrypt.compareSync(String(password), u ? u.password_hash : DUMMY); // same timing whether or not the email exists
  if (!u || !ok) return res.status(401).json({ error: 'Wrong email or password' });
  res.locals.loginUser = u;
  const full = loadUser(u.id);
  res.json({ token: sign(u), user: { id: u.id, name: u.name, role: u.role, role_name: u.role_name, email: u.email, initials: u.initials, perms: full.perms, password_reset_required:!!full.password_reset_required } });
}));
// GET /api/auth/me
r.get('/me', auth, wrap((req, res) => {
  const u = db.prepare('SELECT id,name,email,role,role_name,access,initials,phone,password_reset_required FROM users WHERE id = ?').get(req.user.id);
  res.json({ ...u, perms: req.user.role_name === 'Admin' ? require('../perms.json').catalog : req.user.perms });
}));
// POST /api/auth/password { current, next }
r.post('/password', auth, wrap((req, res) => {
  const { current, next } = req.body || {}; const u = db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id);
  if (!bcrypt.compareSync(String(current || ''), u.password_hash)) return res.status(400).json({ error: 'Current password is wrong' });
  const min = +((JSON.parse((db.prepare("SELECT value FROM settings WHERE key='security'").get() || { value: '{}' }).value).min_password) || 10);
  if (typeof next!=='string'||next.length>1024||next.length < min) return bad(res, `New password must be at least ${min} characters`);
  db.transaction(()=>{db.prepare('UPDATE users SET password_hash=?,password_reset_required=0 WHERE id=?').run(bcrypt.hashSync(next, 12), u.id);db.prepare('UPDATE sessions SET revoked=1 WHERE user_id=?').run(u.id);})();require('../util').clearUserCache(); res.json({ ok: true });
}));
r.post('/logout',auth,wrap((req,res)=>{db.prepare('UPDATE sessions SET revoked=1 WHERE id=?').run(req.sessionId);res.json({ok:true});}));
r.post('/logout-all',auth,wrap((req,res)=>{db.prepare('UPDATE sessions SET revoked=1 WHERE user_id=?').run(req.user.id);res.json({ok:true});}));
r.post('/logout-others',auth,wrap((req,res)=>{
  const result=db.prepare('UPDATE sessions SET revoked=1 WHERE user_id=? AND id<>? AND revoked=0 AND expires_at>?').run(req.user.id,req.sessionId,Date.now());
  res.json({ok:true,revoked:result.changes});
}));
module.exports = r;
