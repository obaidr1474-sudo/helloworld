const r = require('express').Router();
const db = require('../db');
const { wrap, bad, can } = require('../util');
const get = k => { const s = db.prepare('SELECT value FROM settings WHERE key=?').get(k); return s ? JSON.parse(s.value) : null; };
const put = (k, v) => db.prepare('INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(k, JSON.stringify(v));
const SECTIONS = ['assignment', 'notifications', 'integrations', 'security', 'org', 'branding', 'working_days', 'attendance', 'listing', 'leads', 'escalation', 'portals', 'integrations_cfg'];
const hhmm = /^([01]\d|2[0-3]):[0-5]\d$/;
// Validate the sections that drive server rules, so a typo can't break clock-in or routing
function check(section, v) {
  if (section === 'attendance') {
    for (const k of ['start', 'end', 'late_after']) if (v[k] != null && !hhmm.test(v[k])) return `${k} must be HH:MM (24h), e.g. 10:30`;
    if (v.radius_m != null && !(+v.radius_m >= 20 && +v.radius_m <= 5000)) return 'radius_m must be between 20 and 5000';
    if (v.offices != null) { if (!Array.isArray(v.offices)) return 'offices must be a list'; for (const o of v.offices) if (!o.name || !(Math.abs(+o.lat) <= 90) || !(Math.abs(+o.lng) <= 180) || (+o.lat === 0 && +o.lng === 0)) return 'Each office needs a name, lat and lng'; }
  }
  if (section === 'assignment' && v.minutes != null && !(+v.minutes >= 1 && +v.minutes <= 1440)) return 'minutes must be 1–1440';
  if (section === 'portals') for (const [p, c] of Object.entries(v)) if (c.secret && c.secret !== '•••' && String(c.secret).length < 16) return `${p} secret must be at least 16 characters`;
  return null;
}
const mask = (k, v) => k !== 'portals' || !v ? v : Object.fromEntries(Object.entries(v).map(([p, c]) => [p, { ...c, secret: c.secret ? '•••' : null }]));
r.get('/', wrap((req, res) => res.json(Object.fromEntries(SECTIONS.filter(s => s !== 'portals' || can(req.user, 'Integration', 'View')).map(s => [s, mask(s, get(s))])))));
r.get('/:section', wrap((req, res) => { if (!SECTIONS.includes(req.params.section)) return res.status(404).json({ error: 'Unknown section' }); res.json(mask(req.params.section, get(req.params.section))); }));
// PUT /api/settings/:section  — merges into the saved section
r.put('/:section', wrap((req, res) => {
  const s = req.params.section; if (!SECTIONS.includes(s)) return bad(res, 'Unknown section');
  const okPerm = s === 'portals' || s === 'integrations_cfg' ? can(req.user, 'Integration', 'Update') : can(req.user, 'Global Settings', 'Update');
  if (!okPerm) return res.status(403).json({ error: 'You need permission to change company settings' });
  const body = req.body || {}; if(typeof body!=='object'||body===null)return bad(res,'Settings must be an object'); const err = check(s, body); if (err) return bad(res, err);
  const cur = get(s); let next = Array.isArray(body) ? body : { ...(cur && !Array.isArray(cur) ? cur : {}), ...body };
  if (s === 'portals') for (const [p, c] of Object.entries(body)) if (c.secret === '•••') next[p] = { ...c, secret: (cur || {})[p]?.secret };
  put(s, next); res.json(mask(s, get(s)));
}));
module.exports = { router: r, put, get };
