// Notifications, Web Push subscriptions and the live event stream
const express = require('express');
const crypto = require('crypto');
const db = require('../db');
const { wrap, bad, isManager } = require('../util');
const N = require('../services/notify');
const SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';
const r = express.Router();
const ackTok = (id, uid) => crypto.createHmac('sha256', SECRET).update(`ack:${id}:${uid}`).digest('hex').slice(0, 32);
// GET /api/notifications?unseen=1
r.get('/notifications', wrap((req, res) => {
  const rows = db.prepare(`SELECT * FROM notifications WHERE user_id=? ${req.query.unseen ? "AND status!='seen'" : ''} ORDER BY id DESC LIMIT 100`).all(req.user.id);
  res.json({ data: rows, unseen: db.prepare("SELECT COUNT(*) c FROM notifications WHERE user_id=? AND status!='seen'").get(req.user.id).c });
}));
r.post('/notifications/:id/seen', wrap((req, res) => res.json({ ok: N.mark(+req.params.id, req.user.id, 'seen') })));
r.post('/notifications/:id/delivered', wrap((req, res) => res.json({ ok: N.mark(+req.params.id, req.user.id, 'delivered') })));
r.post('/notifications/seen-all', wrap((req, res) => { db.prepare("UPDATE notifications SET status='seen', seen_at=COALESCE(seen_at,datetime('now')), delivered_at=COALESCE(delivered_at,datetime('now')) WHERE user_id=? AND status!='seen'").run(req.user.id); res.json({ ok: true }); }));
// GET /api/notifications/report?days=7  -> delivery health per agent (managers). This is how you prove alerts are reaching phones.
r.get('/notifications/report', wrap((req, res) => {
  if (!isManager(req.user)) return res.status(403).json({ error: 'Managers only' });
  const d = Math.min(90, +req.query.days || 7);
  res.json(db.prepare(`SELECT u.id,u.name, COUNT(n.id) total, SUM(n.status IN ('sent','delivered','seen')) reached, SUM(n.status IN ('delivered','seen')) delivered, SUM(n.status='seen') seen, SUM(n.status='failed') failed,
    ROUND(AVG(CASE WHEN n.seen_at IS NOT NULL THEN (julianday(n.seen_at)-julianday(n.created_at))*1440 END),1) avg_minutes_to_seen,
    (SELECT COUNT(*) FROM push_subs p WHERE p.user_id=u.id) devices
    FROM users u LEFT JOIN notifications n ON n.user_id=u.id AND n.created_at>datetime('now', ?) WHERE u.active=1 GROUP BY u.id ORDER BY u.id`).all(`-${d} days`));
}));
// Web Push
r.get('/push/key', wrap((req, res) => res.json({ publicKey: N.keys().publicKey })));
r.post('/push/subscribe', wrap((req, res) => {
  const s = req.body || {}; if (!s.endpoint || !s.keys || !s.keys.p256dh || !s.keys.auth) return bad(res, 'Send the PushSubscription object from the browser');
  if (!/^https:\/\//.test(s.endpoint)) return bad(res, 'Push endpoint must be https');
  let endpoint;try{endpoint=new URL(s.endpoint);}catch{return bad(res,'Invalid push endpoint');}
  const trusted=['fcm.googleapis.com','updates.push.services.mozilla.com','web.push.apple.com',...(process.env.PUSH_ALLOWED_HOSTS||'').split(',').filter(Boolean)];if(process.env.NODE_ENV!=='test'&&(!trusted.includes(endpoint.hostname)||(endpoint.port&&endpoint.port!=='443')||endpoint.username||endpoint.password))return bad(res,'Unapproved push provider');
  db.prepare('INSERT INTO push_subs (user_id,endpoint,p256dh,auth,ua) VALUES (?,?,?,?,?) ON CONFLICT(endpoint) DO UPDATE SET user_id=excluded.user_id, p256dh=excluded.p256dh, auth=excluded.auth, fails=0').run(req.user.id, s.endpoint, s.keys.p256dh, s.keys.auth, String(req.get('user-agent') || '').slice(0, 200));
  res.status(201).json({ ok: true, devices: db.prepare('SELECT COUNT(*) c FROM push_subs WHERE user_id=?').get(req.user.id).c });
}));
r.delete('/push/subscribe', wrap((req, res) => { db.prepare('DELETE FROM push_subs WHERE endpoint=? AND user_id=?').run((req.body || {}).endpoint || '', req.user.id); res.json({ ok: true }); }));
r.post('/push/test', wrap(async (req, res) => res.json(await N.notify(req.user.id, { title: 'Test notification', body: 'If you can see this, LeadVolt alerts reach this device.', kind: 'test' }))));
// GET /api/stream?token=   Server-Sent Events: notifications + lead updates, live in every open tab
r.get('/stream', (req, res) => {
  res.set({ 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
  res.flushHeaders(); res.write(`retry: 3000\nevent: hello\ndata: ${JSON.stringify({ user: req.user.name })}\n\n`);
  N.addStream(req.user.id, res);
  const ka = setInterval(() => {const session=db.prepare('SELECT 1 FROM sessions WHERE id=? AND revoked=0 AND expires_at>?').get(req.sessionId,Date.now());if(!session)return res.end();res.write(': ping\n\n');}, 25000); res.on('close', () => clearInterval(ka));
});
// Public ack used by the service worker when a push arrives (it has no login token): POST /api/notifications/ack { id, u, t }
const ack = express.Router();
ack.post('/notifications/ack', express.json(), (req, res) => {
  const { id, u, t } = req.body || {}; if (!id || !u || t !== ackTok(id, u)) return res.status(403).json({ error: 'Bad token' });
  res.json({ ok: N.mark(+id, +u, 'delivered') });
});
module.exports = { router: r, ack, ackTok };
