const r = require('express').Router();
const db = require('../db');
const { wrap, bad, need, can, isManager, seesAll, parseBudget, STATUSES, today, getSetting } = require('../util');
const A = require('../services/assign');
const N = require('../services/notify');
const SEL = `SELECT l.*, u.name AS agent, p.name AS project, ar.owner_id AS ad_owner_id, ow.name AS ad_owner, ar.how AS ad_owner_how FROM leads l LEFT JOIN users u ON u.id=l.agent_id LEFT JOIN projects p ON p.id=l.project_id LEFT JOIN ad_refs ar ON ar.portal=l.portal AND ar.ref=l.ad_ref LEFT JOIN users ow ON ow.id=ar.owner_id`;
const out = l => l && ({ ...l, tags: JSON.parse(l.tags || '[]') });
const log = (lead, user, kind, text) => db.prepare('INSERT INTO activities (lead_id,user_id,kind,text) VALUES (?,?,?,?)').run(lead, user, kind, text);
const teamIds = (u) => db.prepare('SELECT DISTINCT m2.user_id id FROM team_members m1 JOIN team_members m2 ON m2.team_id=m1.team_id WHERE m1.user_id=? UNION SELECT ? ').all(u.id, u.id).map(x => x.id);
function visible(u,l) {const ids=require('../access').agentIds(u);return ids===null||ids.includes(l.agent_id)||(l.agent_id===null&&can(u,'Leads','View Unassigned Lead'));}
const getLead = (req) => { const l = db.prepare(`${SEL} WHERE l.id=?`).get(+req.params.id); if (!l) throw Object.assign(new Error('Lead not found'), { status: 404 }); if (!visible(req.user, l)) throw Object.assign(new Error('This lead is not assigned to you'), { status: 403 }); return l; };
// GET /api/leads?scope=all|my|team|unassigned|deleted|duplicate|reenquired&q=&status=&sub_status=&source=&portal=&ad_ref=&tag=&agent_id=&sort=&dir=&page=&limit=
r.get('/', wrap((req, res) => {
  const { q, status, sub_status, source, portal, ad_ref, tag, agent_id, scope = req.query.tab || 'all', sort = 'last_contact', dir = 'desc' } = req.query;
  const page = Math.max(1, +req.query.page || 1), limit = Math.max(1, Math.min(200, Math.floor(+req.query.limit || 25)));
  const w = [], p = [];
  w.push(scope === 'deleted' ? 'l.is_deleted=1' : 'l.is_deleted=0');
  if (scope === 'deleted' && !can(req.user, 'Leads', 'Bulk Restore') && !isManager(req.user)) return res.status(403).json({ error: 'You cannot see deleted leads' });
  if (scope === 'duplicate') w.push('l.is_duplicate=1'); if (scope === 'reenquired') w.push('l.is_reenquired=1');
  if (scope === 'unassigned') { if (!isManager(req.user) && !can(req.user, 'Leads', 'View Unassigned Lead')) return res.status(403).json({ error: 'Only admins and managers see unassigned leads' }); w.push('l.agent_id IS NULL'); }
  if (scope === 'my') { w.push('l.agent_id=?'); p.push(req.user.id); }
  if (scope === 'team') { const ids = require('../access').agentIds(req.user) || teamIds(req.user); w.push(`l.agent_id IN (${ids.map(() => '?').join(',')})`); p.push(...ids); }
  if (!seesAll(req.user) && !['my', 'unassigned'].includes(scope)) { const ids = require('../access').agentIds(req.user) || [req.user.id]; w.push(`l.agent_id IN (${ids.map(() => '?').join(',')})`); p.push(...ids); }
  for (const [k, c] of [[status, 'l.status'], [sub_status, 'l.sub_status'], [source, 'l.source'], [portal, 'l.portal'], [ad_ref, 'l.ad_ref']]) if (k) { w.push(c + '=?'); p.push(k); }
  if (agent_id) { w.push('l.agent_id=?'); p.push(+agent_id); }
  if (tag) { w.push("EXISTS (SELECT 1 FROM json_each(l.tags) WHERE value=?)"); p.push(tag); }
  if (q) { w.push("(l.name LIKE ? OR REPLACE(l.phone,' ','') LIKE ? OR p.name LIKE ? OR l.ad_ref=? OR l.email LIKE ?)"); const s = `%${q}%`; p.push(s, `%${String(q).replace(/\s/g, '')}%`, s, String(q), s); }
  const col = { name: 'l.name', budget: 'l.budget_value', score: 'l.score', last_contact: 'l.last_contact_at', created: 'l.created_at', status: 'l.status' }[sort] || 'l.last_contact_at';
  const where = 'WHERE ' + w.join(' AND ');
  const total = db.prepare(`SELECT COUNT(*) c FROM leads l LEFT JOIN projects p ON p.id=l.project_id ${where}`).get(...p).c;
  const rows = db.prepare(`${SEL} ${where} ORDER BY ${col} ${dir === 'asc' ? 'ASC' : 'DESC'}, l.id DESC LIMIT ? OFFSET ?`).all(...p, limit, (page - 1) * limit);
  const counts = Object.fromEntries(db.prepare(`SELECT l.status, COUNT(*) c FROM leads l LEFT JOIN projects p ON p.id=l.project_id ${where} GROUP BY l.status`).all(...p).map(x => [x.status, x.c]));
  res.json({ data: rows.map(out), page, limit, total, counts });
}));
const EXTRA = ['alternate_phone', 'landline', 'country_code', 'sub_source', 'budget_min', 'budget_max', 'currency', 'enquired_for', 'property_type', 'beds', 'baths', 'community', 'city', 'country', 'referral_name', 'referral_phone', 'referral_email', 'notes', 'external_ref', 'sub_status'];
function createLead(b, userId) {
  if (!b.name || !String(b.name).trim()) throw Object.assign(new Error("Enter the lead's name"), { status: 400 });
  if (!/^[+\d][\d\s-]{6,}$/.test(b.phone || '')) throw Object.assign(new Error('Enter a phone number with at least 7 digits'), { status: 400 });
  if(b.name!==undefined&&(typeof b.name!=='string'||!b.name.trim()||b.name.length>200))throw Object.assign(new Error('Name must contain 1–200 characters'),{status:400});
  if(b.email&&(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(b.email)||b.email.length>254))throw Object.assign(new Error('Invalid email'),{status:400});
  if(b.score!==undefined&&(!Number.isInteger(b.score)||b.score<0||b.score>100))throw Object.assign(new Error('Score must be 0–100'),{status:400});
  if(b.status==='Invoiced')throw Object.assign(new Error('Finance is unavailable for this release'),{status:400});
  if (b.status && !STATUSES.includes(b.status)) throw Object.assign(new Error('Unknown status'), { status: 400 });
  return db.transaction(() => {
    const dup = db.prepare("SELECT id FROM leads WHERE REPLACE(phone,' ','')=? AND is_deleted=0 ORDER BY id LIMIT 1").get(String(b.phone).replace(/\s/g, ''));
    const agent = b.agent_id === null ? null : (b.agent_id || A.nextAgent());
    const ex = EXTRA.filter(k => b[k] != null);
    const cols = ['name', 'phone', 'email', 'source', 'budget', 'budget_value', 'project_id', 'status', 'agent_id', 'score', 'is_duplicate', 'root_id', 'tags', ...ex];
    const vals = [String(b.name).trim(), String(b.phone).trim(), b.email || null, b.source || 'Manual', b.budget || null, parseBudget(b.budget) || b.budget_max || null, b.project_id || null, b.status || 'New', agent, b.score || 50, dup ? 1 : 0, dup ? dup.id : null, JSON.stringify(Array.isArray(b.tags) ? b.tags : []), ...ex.map(k => b[k])];
    const info = db.prepare(`INSERT INTO leads (${cols.join(',')},last_contact_at,assigned_at) VALUES (${cols.map(() => '?').join(',')},datetime('now'),${agent ? "datetime('now')" : 'NULL'})`).run(...vals);
    log(info.lastInsertRowid, userId, 'status', dup ? 'Lead created (repeat enquiry)' : 'Lead created');
    db.prepare('INSERT INTO lead_status_history (lead_id,to_status,user_id) VALUES (?,?,?)').run(info.lastInsertRowid, b.status || 'New', userId);
    return info.lastInsertRowid;
  }).immediate();
}
r.post('/', need('Leads', 'Create'), wrap(async (req, res) => {
  const b={...(req.body||{})};if(!can(req.user,'Leads','Assign')){if(b.agent_id!=null&&Number(b.agent_id)!==req.user.id)return res.status(403).json({error:'Cannot assign another agent'});b.agent_id=req.user.id;}
  const id = createLead(b, req.user.id); const l = out(db.prepare(`${SEL} WHERE l.id=?`).get(id));
  if (l.agent_id && l.agent_id !== req.user.id) N.notify(l.agent_id, { title: `New lead: ${l.name}`, body: [l.source, l.budget, l.phone].filter(Boolean).join(' · '), lead_id: l.id }).catch(() => {});
  res.status(201).json(l);
}));
r.createLead = createLead;
// POST /api/leads/bulk  { ids:[], agent_id?, status?, tags_add?:[] }
r.post('/bulk', wrap((req, res) => {
  const { ids, agent_id, status, tags_add } = req.body || {};
  if (!Array.isArray(ids) || !ids.length || ids.some(id=>!Number.isSafeInteger(id)||id<1)) return bad(res, 'Select at least one lead'); if (ids.length > 1000) return bad(res, 'At most 1,000 leads at a time');
  if (agent_id !== undefined && !can(req.user, 'Leads', 'Bulk Reassign') && !can(req.user, 'Leads', 'Assign')) return res.status(403).json({ error: 'You need the Leads › Bulk Reassign permission' });
  if (status && !can(req.user, 'Leads', 'Bulk Update Status')) return res.status(403).json({ error: 'You need the Leads › Bulk Update Status permission' });
  if(status==='Invoiced'&&!require('../features').canFinance(req.user))return bad(res,'Finance is unavailable for this release');
  if (status && !STATUSES.includes(status)) return bad(res, 'Unknown status');
  if(tags_add!==undefined&&(!can(req.user,'Leads','Update Tags')||!Array.isArray(tags_add)||tags_add.some(t=>typeof t!=='string'||t.length>30)))return res.status(403).json({error:'Tags not permitted or invalid'});
  const learned = [];
  db.transaction(()=>{ids.forEach(id=>getLead({...req,params:{id}}));
  ids.forEach(id => {
    if (agent_id !== undefined) { const x = A.assign(+id, agent_id || null, req.user.id); if (x.learned) learned.push(x.learned); }
    if (status) { db.prepare("UPDATE leads SET status=?, last_contact_at=datetime('now') WHERE id=?").run(status, id); log(id, req.user.id, 'status', 'Status changed to ' + status); }
    if (Array.isArray(tags_add) && tags_add.length) { const l = db.prepare('SELECT tags FROM leads WHERE id=?').get(id); if(l){const merged=[...new Set([...JSON.parse(l.tags||'[]'),...tags_add])];if(merged.length>12||merged.filter(t=>['Hot','Warm','Cold'].includes(t)).length>1)throw Object.assign(new Error('Invalid combined tags'),{status:400});db.prepare('UPDATE leads SET tags=? WHERE id=?').run(JSON.stringify(merged),id);} }
  });
  })();
  if (agent_id) N.notify(agent_id, { title: `${ids.length} lead${ids.length > 1 ? 's' : ''} assigned to you`, body: `By ${req.user.name}`, kind: 'lead' }).catch(() => {});
  res.json({ updated: ids.length, ad_owners_learned: learned });
}));
// GET /api/leads/:id  (opening it as the assigned agent counts as "seen" for escalation)
r.get('/:id', wrap((req, res) => {
  const l = out(getLead(req));
  if (l.agent_id === req.user.id && !l.first_opened_at) { db.prepare("UPDATE leads SET first_opened_at=datetime('now') WHERE id=?").run(l.id); db.prepare("UPDATE notifications SET status='seen', seen_at=COALESCE(seen_at,datetime('now')) WHERE lead_id=? AND user_id=? AND status!='seen'").run(l.id, req.user.id); }
  l.revision=db.prepare('SELECT revision FROM leads WHERE id=?').get(l.id).revision;
  l.status_history = db.prepare('SELECT h.*, u.name AS by FROM lead_status_history h LEFT JOIN users u ON u.id=h.user_id WHERE lead_id=? ORDER BY h.id DESC').all(l.id);
  l.deals = []; // Financial records are only exposed through the Admin finance APIs.
  l.shuffles = db.prepare('SELECT s.*, f.name from_name, t.name to_name, b.name by_name FROM shuffles s LEFT JOIN users f ON f.id=s.from_id LEFT JOIN users t ON t.id=s.to_id LEFT JOIN users b ON b.id=s.by_id WHERE lead_id=? ORDER BY s.id DESC').all(l.id);
  l.recordings = (can(req.user, 'Leads', 'View Call Recordings') || can(req.user, 'Integration', 'Listen Call Recordings')) ? db.prepare('SELECT id,portal,duration_sec,direction,answered,started_at,created_at FROM recordings WHERE lead_id=? ORDER BY id DESC').all(l.id) : null;
  l.activity = db.prepare('SELECT a.*, u.name AS by FROM activities a LEFT JOIN users u ON u.id=a.user_id WHERE lead_id=? ORDER BY a.id DESC').all(l.id);
  res.json(l);
}));
// POST /api/leads/:id/assign  { agent_id | null, learn?: true }  -> the first manual assignment on a portal ad sets the ad owner
r.post('/:id/assign', need('Leads', 'Assign'), wrap(async (req, res) => {
  const l = getLead(req), b = req.body || {}; if (!('agent_id' in b)) return bad(res, 'agent_id is required (null to unassign)');
  const x = A.assign(l.id, b.agent_id ? +b.agent_id : null, req.user.id, { learn: b.learn !== false });
  if (b.agent_id && +b.agent_id !== req.user.id) await N.notify(+b.agent_id, { title: `Lead assigned to you: ${l.name}`, body: x.learned ? `You now own ${x.learned.portal} Ref ${x.learned.ref}. Future leads on it come to you.` : `By ${req.user.name}`, lead_id: l.id });
  res.json({ ...x, lead: out(db.prepare(`${SEL} WHERE l.id=?`).get(l.id)) });
}));
// POST /api/leads/:id/shuffle  { to_id?, reason }   (no to_id = next agent in the round robin)
r.post('/:id/shuffle', wrap(async (req, res) => {
  const l = getLead(req), b = req.body || {};
  if (!can(req.user, 'Leads', 'Shuffle Leads') && !can(req.user, 'Leads', 'Assign') && l.agent_id !== req.user.id) return res.status(403).json({ error: 'You can only shuffle your own leads' });
  if (!can(req.user,'Leads','Shuffle Leads') && !can(req.user,'Leads','Assign'))return res.status(403).json({error:'Shuffle permission required'});
  if (!String(b.reason || '').trim()) return bad(res, 'Say why, e.g. "Client prefers Arabic speaker"');
  const x = A.shuffle(l.id, b.to_id ? +b.to_id : null, req.user.id, String(b.reason).slice(0, 300));
  await N.notify(x.to_id, { title: `Lead shuffled to you: ${l.name}`, body: `From ${l.agent || 'Unassigned'} — ${b.reason}`, lead_id: l.id });
  res.json({ ...x, lead: out(db.prepare(`${SEL} WHERE l.id=?`).get(l.id)) });
}));
// PUT /api/leads/:id/tags  { tags: ["Hot","Investor"] }
r.put('/:id/tags', need('Leads', 'Update Tags'), wrap((req, res) => {
  const l = getLead(req), tags = (req.body || {}).tags; if (!Array.isArray(tags) || tags.some(t => typeof t !== 'string' || t.length > 30)) return bad(res, 'tags must be a list of short words');
  const clean = [...new Set(tags.map(t => t.trim()).filter(Boolean))].slice(0, 12);
  const temp = clean.filter(t => ['Hot', 'Warm', 'Cold'].includes(t)); if (temp.length > 1) return bad(res, 'Pick only one of Hot, Warm or Cold');
  db.prepare('UPDATE leads SET tags=? WHERE id=?').run(JSON.stringify(clean), l.id); log(l.id, req.user.id, 'tags', 'Tags: ' + (clean.join(', ') || 'none'));
  res.json(out(db.prepare(`${SEL} WHERE l.id=?`).get(l.id)));
}));
// PATCH /api/leads/:id
r.patch('/:id', wrap((req, res) => db.transaction(() => {
  const old = getLead(req), id = old.id, b = req.body || {};
  if(b.status && !can(req.user,'Leads','Update Lead Status')&&!can(req.user,'Leads','Update'))return res.status(403).json({error:'Status update permission required'});
  if(b.name!==undefined&&(typeof b.name!=='string'||!b.name.trim()||b.name.length>200))return bad(res,'Invalid name');
  if(b.phone!==undefined&&(typeof b.phone!=='string'||!/^\+?\d[\d -]{6,25}$/.test(b.phone)))return bad(res,'Invalid phone');
  if(b.email&&(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(b.email)||b.email.length>254))return bad(res,'Invalid email');
  if(b.score!==undefined&&(!Number.isInteger(b.score)||b.score<0||b.score>100))return bad(res,'Invalid score');
  if(b.status==='Invoiced'&&!require('../features').canFinance(req.user))return bad(res,'Finance is unavailable for this release');
  if (b.status && !STATUSES.includes(b.status)) return bad(res, 'Unknown status');
  if ('agent_id' in b) return bad(res, 'Use POST /api/leads/:id/assign or /shuffle to change the agent');
  if(b.scheduled_at&&(typeof b.scheduled_at!=='string'||!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(b.scheduled_at)||!Number.isFinite(Date.parse(b.scheduled_at))))return bad(res,'Invalid scheduled_at');
  if (b.status && b.status !== old.status && getSetting('leads', {}).note_required && !String(b.status_notes || '').trim()) return bad(res, 'Add a note saying what happened');
  const f = ['status', 'sub_status', 'score', 'budget', 'project_id', 'email', 'phone', 'name', ...EXTRA].filter((k, i, a) => k in b && a.indexOf(k) === i);
  if (!f.length) return bad(res, 'Nothing to update');
  if(f.some(k=>k!=='status'&&k!=='sub_status')&&!can(req.user,'Leads','Update')&&!can(req.user,'Leads','Update Basic Info'))return res.status(403).json({error:'Basic-info permission required'});
  if(req.get('If-Match')!==String(old.revision))return res.status(409).json({error:'Lead changed or If-Match revision missing',revision:old.revision});
  db.prepare(`UPDATE leads SET ${f.map(k => k + '=?').join(',')}, last_contact_at=datetime('now'), first_contact_at=COALESCE(first_contact_at, CASE WHEN ? THEN datetime('now') END) ${'budget' in b ? ', budget_value=' + (parseBudget(b.budget) || 'NULL') : ''} WHERE id=?`).run(...f.map(k => b[k]), b.status ? 1 : 0, id);
  if (b.status && b.status !== old.status) {
    log(id, req.user.id, 'status', `Status changed from ${old.status} to ${b.status}${b.sub_status ? ' (' + b.sub_status + ')' : ''}`);
    db.prepare('INSERT INTO lead_status_history (lead_id,from_status,to_status,user_id,scheduled_at,notes) VALUES (?,?,?,?,?,?)').run(id, old.status, b.status, req.user.id, b.scheduled_at || null, b.status_notes || null);
    if (b.scheduled_at) db.prepare('INSERT INTO tasks (title,type,lead_id,assignee_id,due_date,due_time,priority,created_by) VALUES (?,?,?,?,?,?,?,?)').run(`${b.status} with ${old.name}`, /visit/i.test(b.status) ? 'Site visit' : /meeting/i.test(b.status) ? 'Meeting' : 'Call', id, old.agent_id, b.scheduled_at.slice(0, 10), b.scheduled_at.slice(11, 16) || null, 'High', req.user.id);
  }
  res.json(out(db.prepare(`${SEL} WHERE l.id=?`).get(id)));
}).immediate()));
r.delete('/:id', need('Leads', 'Delete'), wrap((req, res) => { const l = getLead(req); db.prepare('UPDATE leads SET is_deleted=1 WHERE id=?').run(l.id); log(l.id, req.user.id, 'status', 'Lead deleted'); res.status(204).end(); }));
r.post('/:id/restore', need('Leads', 'Bulk Restore'), wrap((req, res) => { const l=getLead(req);db.prepare('UPDATE leads SET is_deleted=0 WHERE id=?').run(l.id); res.json({ ok: true }); }));
r.post('/:id/notes', wrap((req, res) => {
  const l = getLead(req), t = String(req.body?.text||'').trim();if(t.length>5000)return bad(res,'Note exceeds 5,000 characters'); if (!t) return bad(res, 'Write a note first');
  log(l.id, req.user.id, 'note', t); db.prepare("UPDATE leads SET last_contact_at=datetime('now') WHERE id=?").run(l.id);
  res.status(201).json({ ok: true });
}));
r.post('/:id/activity', wrap((req, res) => {
  const l = getLead(req), { kind, text } = req.body || {}; if (!['call', 'whatsapp', 'visit', 'note', 'email'].includes(kind)) return bad(res, 'kind must be call, whatsapp, email, visit or note');
  log(l.id, req.user.id, kind, text || ''); db.prepare("UPDATE leads SET last_contact_at=datetime('now'), first_contact_at=COALESCE(first_contact_at, CASE WHEN ? IN ('call','whatsapp','email','visit') THEN datetime('now') END) WHERE id=?").run(kind, l.id);
  res.status(201).json({ ok: true });
}));
module.exports = r;
