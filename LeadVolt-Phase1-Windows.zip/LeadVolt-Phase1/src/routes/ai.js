// Deterministic, permission-scoped assistant. No external LLM or cross-user context.
const r=require('express').Router(), db=require('../db');
const {wrap,bad}=require('../util');
const {scope}=require('../access');
r.post('/ask',wrap((req,res)=>{
 const question=String(req.body?.question||'').trim();if(!question||question.length>1000)return bad(res,'Ask a question of at most 1,000 characters');
 const s=scope(req.user),q=question.toLowerCase();let items,answer;
 const named=db.prepare(`SELECT l.id,l.name,l.status,l.score,l.budget FROM leads l WHERE l.is_deleted=0 AND ${s.sql} AND ? LIKE '%'||lower(l.name)||'%' LIMIT 1`).get(...s.params,q);
 if(named){items=[named];answer=`${named.name}: ${named.status}, score ${named.score}.`;}
 else if(/overdue|late|follow/.test(q)){items=db.prepare(`SELECT l.id,l.name,l.status,l.last_contact_at FROM leads l WHERE l.is_deleted=0 AND ${s.sql} AND l.status='Overdue' LIMIT 100`).all(...s.params);answer=`${items.length} accessible overdue leads (up to 100).`;}
 else if(/call|first|hot|priority/.test(q)){items=db.prepare(`SELECT l.id,l.name,l.status,l.score FROM leads l WHERE l.is_deleted=0 AND ${s.sql} AND l.status NOT IN ('Booked','Invoiced') ORDER BY l.score DESC LIMIT 5`).all(...s.params);answer='Highest-scoring open leads you can access.';}
 else{items=db.prepare(`SELECT l.status,COUNT(*) count FROM leads l WHERE l.is_deleted=0 AND ${s.sql} GROUP BY l.status`).all(...s.params);answer='Your accessible pipeline by status.';}
 res.json({answer,items,engine:'rules',scope:'authorized-leads'});
}));module.exports=r;
