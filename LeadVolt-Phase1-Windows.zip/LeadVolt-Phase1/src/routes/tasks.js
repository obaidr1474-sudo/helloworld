const r = require('express').Router();
const db = require('../db');
const { wrap, bad, need, seesAll, today } = require('../util');
const N = require('../services/notify');
const PRI = ['Critical', 'High', 'Medium', 'Low'];
const SEL = `SELECT t.*, l.name AS lead, u.name AS assignee, c.name AS created_by_name FROM tasks t LEFT JOIN leads l ON l.id=t.lead_id LEFT JOIN users u ON u.id=t.assignee_id LEFT JOIN users c ON c.id=t.created_by`;
const ORDER = "ORDER BY t.done, t.due_date, COALESCE(t.due_time,'23:59'), CASE t.priority WHEN 'Critical' THEN 0 WHEN 'High' THEN 1 WHEN 'Medium' THEN 2 ELSE 3 END";
// GET /api/tasks?filter=all|today|upcoming|overdue|done&q=&assignee_id=&priority=
r.get('/', need('Tasks', 'View'), wrap((req, res) => {
  const f = req.query.filter || 'all', d = today(), w = [], p = [];
  if (!seesAll(req.user)) { w.push('(t.assignee_id=? OR t.created_by=?)'); p.push(req.user.id, req.user.id); }
  if (f === 'today') { w.push('t.due_date=? AND t.done=0'); p.push(d); } if (f === 'upcoming') { w.push('t.due_date>? AND t.done=0'); p.push(d); }
  if (f === 'overdue') { w.push('t.due_date<? AND t.done=0'); p.push(d); } if (f === 'done') w.push('t.done=1');
  if (req.query.assignee_id) { w.push('t.assignee_id=?'); p.push(+req.query.assignee_id); } if (req.query.priority) { w.push('t.priority=?'); p.push(req.query.priority); }
  if (req.query.q) { w.push('(t.title LIKE ? OR t.description LIKE ? OR l.name LIKE ?)'); const s = `%${req.query.q}%`; p.push(s, s, s); }
  const rows = db.prepare(`${SEL} ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ${ORDER} LIMIT 500`).all(...p);
  const scope = seesAll(req.user) ? '' : 'AND (assignee_id=@u OR created_by=@u)';
  const c = db.prepare(`SELECT SUM(due_date=@d AND done=0) today, SUM(due_date>@d AND done=0) upcoming, SUM(due_date<@d AND done=0) overdue, SUM(done=1) completed, COUNT(*) total FROM tasks WHERE 1=1 ${scope}`).get({ d, u: req.user.id });
  res.json({ data: rows, counts: c });
}));
// POST /api/tasks { title, assignee_id, due_date, due_time, description, priority: Critical|High|Medium|Low, type?, lead_id?, reminder? }
r.post('/', need('Tasks', 'Create'), wrap(async (req, res) => {
  const b = req.body || {};
  if (!String(b.title || '').trim()) return bad(res, 'Give the task a title');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(b.due_date || '')) return bad(res, 'Pick a date (YYYY-MM-DD)');
  if (b.due_time && !/^\d{2}:\d{2}$/.test(b.due_time)) return bad(res, 'Time must be HH:MM');
  if (!String(b.description || '').trim()) return bad(res, 'Add a short description');
  if (b.priority && !PRI.includes(b.priority)) return bad(res, 'Priority must be Critical, High, Medium or Low');
  if(b.lead_id)require('../access').lead(req.user,b.lead_id);
  const assignee = b.assignee_id ? +b.assignee_id : req.user.id;
  if(assignee!==req.user.id&&!seesAll(req.user))return res.status(403).json({error:'Cannot assign tasks to another user'});
  if (!db.prepare('SELECT 1 FROM users WHERE id=? AND active=1').get(assignee)) return bad(res, 'That person is not active');
  const i = db.prepare('INSERT INTO tasks (title,type,lead_id,assignee_id,due_date,due_time,priority,description,reminder,created_by) VALUES (?,?,?,?,?,?,?,?,?,?)').run(b.title.trim(), b.type || 'Call', b.lead_id || null, assignee, b.due_date, b.due_time || null, b.priority || 'Medium', b.description.trim(), b.reminder || null, req.user.id);
  if (assignee !== req.user.id) await N.notify(assignee, { title: `New task from ${req.user.name}: ${b.title}`, body: `${b.priority || 'Medium'} priority · ${b.due_date}${b.due_time ? ' ' + b.due_time : ''}`, lead_id: b.lead_id || null, kind: 'task' });
  res.status(201).json(db.prepare(`${SEL} WHERE t.id=?`).get(i.lastInsertRowid));
}));
r.patch('/:id', need('Tasks', 'Update'), wrap((req, res) => {
  const t = db.prepare('SELECT * FROM tasks WHERE id=?').get(+req.params.id); if (!t) return res.status(404).json({ error: 'Task not found' });
  if (!seesAll(req.user) && t.assignee_id !== req.user.id && t.created_by !== req.user.id) return res.status(403).json({ error: 'Not your task' });
  const b = req.body || {}; if(b.assignee_id&&Number(b.assignee_id)!==req.user.id&&!seesAll(req.user))return res.status(403).json({error:'Cannot reassign tasks'}); if (b.priority && !PRI.includes(b.priority)) return bad(res, 'Unknown priority');
  const f = ['done', 'due_date', 'due_time', 'priority', 'title', 'assignee_id', 'description', 'reminder', 'type'].filter(k => k in b);
  if (!f.length) return bad(res, 'Nothing to update');
  db.prepare(`UPDATE tasks SET ${f.map(k => k + '=?').join(',')} WHERE id=?`).run(...f.map(k => k === 'done' ? (b[k] ? 1 : 0) : b[k]), t.id);
  res.json(db.prepare(`${SEL} WHERE t.id=?`).get(t.id));
}));
r.delete('/:id', need('Tasks', 'Delete'), wrap((req, res) => { const t=db.prepare('SELECT * FROM tasks WHERE id=?').get(+req.params.id);if(!t)return res.status(404).json({error:'Task not found'});if(!seesAll(req.user)&&t.assignee_id!==req.user.id&&t.created_by!==req.user.id)return res.status(403).json({error:'Not your task'});db.prepare('DELETE FROM tasks WHERE id=?').run(t.id); res.status(204).end(); }));
module.exports = r;
