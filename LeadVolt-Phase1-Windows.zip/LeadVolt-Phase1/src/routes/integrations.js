// Portal webhooks (public, signed) + integration admin endpoints (signed-in)
const express = require('express');
const db = require('../db');
const { wrap, bad, need, auth } = require('../util');
const P = require('../integrations/portals');
const A = require('../services/assign');
const pub = express.Router(), adm = express.Router();
// POST /api/integrations/:portal/webhook   (Bayut, Dubizzle, Property Finder, Skyloov, Website, Webhook)
pub.post('/:portal/webhook', express.raw({ type: '*/*', limit: '1mb' }), wrap(async (req, res) => {
  const portal = P.PORTALS[req.params.portal.toLowerCase()]; if (!portal) return res.status(404).json({ error: 'Unknown portal' });
  req.rawBody = req.body && req.body.length ? req.body.toString('utf8') : '';
  const v = P.verify(portal, req); if (!v.ok) { db.prepare('INSERT INTO audit_log (method,path,status,action,detail,ip) VALUES (?,?,?,?,?,?)').run('POST', req.originalUrl.split('?')[0], 401, 'Webhook rejected', JSON.stringify({ portal, why: v.why }), req.ip); return res.status(401).json({ error: v.why }); }
  let body; try { body = JSON.parse(req.rawBody || '{}'); } catch { return bad(res, 'Body must be JSON'); }
  if(!(process.env.NODE_ENV==='test' && process.env.WEBHOOK_SYNC==='1')){
    if(!body||typeof body!=='object')return bad(res,'Payload must be an object or array');
    const j=require('../services/ingest').ingest(portal,body);return res.status(202).json({ok:true,receipt_id:j.id,status:j.status});
  }
  const out = [];
  for (const ev of P.normalize(portal, body)) {
    const r = P.processEvent(portal, ev); out.push({ external_id: ev.external_id, kind: ev.kind, status: r.status, lead_id: r.lead_id || null, error: r.error });
    if (r.announce) A.announce(r.lead, r.announce).catch(e => console.error('announce', e));
    else if (r.status === 'updated' && r.lead && r.lead.agent_id) require('../services/notify').notify(r.lead.agent_id, { title: `${r.lead.name} contacted you again on ${portal}`, body: ev.kind === 'call' ? (ev.call.answered ? 'Call received' : 'Missed call, callback task created') : (ev.message || ''), lead_id: r.lead.id }).catch(() => {});
  }
  res.json({ ok: true, received: out.length, results: out }); // 200 fast, so the portal doesn't retry
}));
// --- signed-in admin ---
adm.use(auth);
// GET /api/integrations/events?portal=&status=&limit=
adm.get('/events', need('Integration', 'View'), wrap((req, res) => {
  const w = [], p = []; if (req.query.portal) { w.push('portal=?'); p.push(req.query.portal); } if (req.query.status) { w.push('status=?'); p.push(req.query.status); }
  res.json(db.prepare(`SELECT id,portal,external_id,kind,status,error,lead_id,received_at FROM portal_events ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY id DESC LIMIT ?`).all(...p, Math.min(500, +req.query.limit || 100)));
}));
// GET /api/integrations/status -> per-portal health for the Integrations page
adm.get('/status', need('Integration', 'View'), wrap((req, res) => {
  const cfg = require('../util').getSetting('portals', {});
  res.json(['Bayut', 'Dubizzle', 'Property Finder', 'Skyloov', 'Website', 'Webhook'].map(n => {
    const s = db.prepare("SELECT COUNT(*) total, SUM(status='error') errors, MAX(received_at) last FROM portal_events WHERE portal=? AND received_at>datetime('now','-7 days')").get(n);
    const env = n.toUpperCase().replace(/\s+/g, '_') + '_WEBHOOK_SECRET';
    return { portal: n, configured: !!(process.env[env] || (cfg[n] || {}).secret), enabled: (cfg[n] || {}).enabled !== false, webhook_path: `/api/integrations/${n.toLowerCase().replace(/\s+/g, '-')}/webhook`, last_7_days: s.total, errors: s.errors || 0, last_event_at: s.last };
  }));
}));
// POST /api/integrations/events/:id/replay  -> re-run a stored payload (after fixing a mapping)
adm.post('/events/:id/replay', need('Integration', 'Update'), wrap((req, res) => {
  const e = db.prepare('SELECT * FROM portal_events WHERE id=?').get(+req.params.id); if (!e) return res.status(404).json({ error: 'Event not found' });
  if (e.status !== 'error') return bad(res, 'Only failed events can be replayed');
  const r=db.transaction(()=>{db.prepare('DELETE FROM portal_events WHERE id=?').run(e.id);return P.normalize(e.portal,JSON.parse(e.payload)).map(ev=>P.processEvent(e.portal,ev));}).immediate();
  r.forEach(x => x.announce && A.announce(x.lead, x.announce).catch(() => {}));
  res.json(r.map(x => ({ status: x.status, lead_id: x.lead_id, error: x.error })));
}));
module.exports = { pub, adm };
