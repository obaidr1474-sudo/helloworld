const r = require('express').Router();
const db = require('../db');
const { wrap, bad, money } = require('../util');
const calc = v => { if(!v)throw Object.assign(new Error('Invoice not found'),{status:404}); const sub = v.property_price * v.commission_pct / 100, vat = sub * v.vat_pct / 100; return { ...v, subtotal: money(sub), vat: money(vat), total: money(sub + vat) }; };
const SEL = `SELECT i.*, l.name AS client, p.name AS project FROM invoices i LEFT JOIN leads l ON l.id=i.lead_id LEFT JOIN units u ON u.id=i.unit_id LEFT JOIN projects p ON p.id=u.project_id`;
const markOverdue = () => db.prepare("UPDATE invoices SET status='Overdue' WHERE status='Pending' AND due_at < date('now')").run();
// GET /api/invoices?status=
r.get('/', wrap((req, res) => {
  markOverdue(); const s = req.query.status;
  const scope=require('../access').scope(req.user);const rows=db.prepare(`${SEL} WHERE ${scope.sql} ${s?'AND i.status=?':''} ORDER BY i.id DESC`).all(...scope.params,...(s?[s]:[])).map(calc);
  const sum = st => money(rows.filter(r => r.status === st).reduce((a, r) => a + r.total, 0));
  res.json({ data: rows, totals: { paid: sum('Paid'), pending: sum('Pending'), overdue: sum('Overdue'), count: rows.length } });
}));
r.get('/:id', wrap((req, res) => { const v = db.prepare(`${SEL} WHERE i.id=?`).get(+req.params.id); if (!v) return res.status(404).json({ error: 'Invoice not found' }); require('../access').lead(req.user,v.lead_id);res.json(calc(v)); }));
// POST /api/invoices { lead_id, unit_id?, property_price, commission_pct?, due_in_days? }
r.post('/', wrap((req, res) => db.transaction(() => {
  const b = req.body || {};const key=req.get('Idempotency-Key');if(!key||!/^[\w:.-]{8,128}$/.test(key))return bad(res,'Idempotency-Key is required');const requestKey='invoice:'+key,payloadHash=require('../services/ingest').hash(b);const prior=db.prepare('SELECT * FROM finance_requests WHERE key=?').get(requestKey);if(prior){if(prior.payload_hash!==payloadHash)return res.status(409).json({error:'Idempotency key conflict'});return res.status(201).json({...calc(db.prepare(`${SEL} WHERE i.id=?`).get(prior.resource_id)),duplicate:true});} if (!b.lead_id) return bad(res, 'Choose a client'); if (!Number.isFinite(b.property_price)||!(b.property_price > 0)) return bad(res, 'Enter the property price');
  if(b.commission_pct!==undefined&&(!Number.isFinite(b.commission_pct)||b.commission_pct<0||b.commission_pct>100))return bad(res,'Invalid commission percentage');if(b.due_in_days!==undefined&&(!Number.isInteger(b.due_in_days)||b.due_in_days<1||b.due_in_days>3650))return bad(res,'Invalid due period');
  if(b.unit_id&&!db.prepare('SELECT id FROM units WHERE id=?').get(b.unit_id))return bad(res,'Unknown unit');
  if(!Number.isSafeInteger(Math.round(b.property_price*100))||Math.abs(b.property_price*100-Math.round(b.property_price*100))>0.00001)return bad(res,'Price must fit integer minor units with at most two decimals');
  require('../access').lead(req.user,b.lead_id);
  const prefix=`INV-${new Date().getFullYear()}-`;const n=1+(db.prepare('SELECT MAX(CAST(SUBSTR(number,?) AS INTEGER)) n FROM invoices WHERE number LIKE ?').get(prefix.length+1,prefix+'%').n||0);const num=prefix+String(n).padStart(4,'0');
  const due = new Date(Date.now() + (b.due_in_days || 14) * 864e5).toISOString().slice(0, 10);
  const i = db.prepare('INSERT INTO invoices (number,lead_id,unit_id,property_price,commission_pct,status,due_at) VALUES (?,?,?,?,?,?,?)').run(num, b.lead_id, b.unit_id || null, +b.property_price, b.commission_pct ?? 2, b.draft ? 'Draft' : 'Pending', due);
  db.prepare('INSERT INTO finance_requests(key,payload_hash,resource_type,resource_id,created_by) VALUES(?,?,?,?,?)').run(requestKey,payloadHash,'invoice',i.lastInsertRowid,req.user.id);
  res.status(201).json(calc(db.prepare(`${SEL} WHERE i.id=?`).get(i.lastInsertRowid)));
}).immediate()));
// PATCH /api/invoices/:id { status: Paid|Pending|Draft }
r.patch('/:id', wrap((req, res) => {
  const old=db.prepare('SELECT * FROM invoices WHERE id=?').get(+req.params.id);if(!old)return res.status(404).json({error:'Invoice not found'});require('../access').lead(req.user,old.lead_id);
  const st = (req.body || {}).status; if (!['Paid', 'Pending', 'Draft'].includes(st)) return bad(res, 'status must be Paid, Pending or Draft');
  db.prepare(`UPDATE invoices SET status=?, paid_at=${st === 'Paid' ? "date('now')" : 'NULL'} WHERE id=?`).run(st, +req.params.id);
  res.json(calc(db.prepare(`${SEL} WHERE i.id=?`).get(+req.params.id)));
}));
module.exports = r;
