// Attendance with office geofence and late reasons. Rules come from settings.attendance (editable by admins).
const r = require('express').Router();
const db = require('../db');
const { wrap, bad, today, isManager, getSetting, can } = require('../util');
const DEF = { start: '09:00', end: '18:00', late_after: '10:30', ask_reason: true, reason_required: true, geofence: true, radius_m: 150, max_accuracy_m: 100, offices: [], remote_roles: [] };
const cfg = () => ({ ...DEF, ...getSetting('attendance', {}) });
const hm = s => { const [h, m] = String(s).split(':').map(Number); return h * 60 + (m || 0); };
const dist = (a, b) => { const R = 6371e3, t = x => x * Math.PI / 180, dLa = t(b.lat - a.lat), dLo = t(b.lng - a.lng), h = Math.sin(dLa / 2) ** 2 + Math.cos(t(a.lat)) * Math.cos(t(b.lat)) * Math.sin(dLo / 2) ** 2; return 2 * R * Math.asin(Math.sqrt(h)); };
const nowIso = () => new Date().toISOString();
// GET /api/attendance/rules  -> what the app needs to show (late cut-off, offices, radius)
r.get('/rules', wrap((req, res) => { const c = cfg(); res.json({ ...c, offices: c.offices.map(o => ({ name: o.name, lat: o.lat, lng: o.lng, radius_m: o.radius_m || c.radius_m })) }); }));
// GET /api/attendance/today
r.get('/today', wrap((req, res) => {
  const d = today();
  const me = db.prepare('SELECT * FROM attendance WHERE user_id=? AND day=?').get(req.user.id, d) || null;
  const team = isManager(req.user) || can(req.user, 'Attendance', 'View All Users') ? db.prepare(`SELECT u.id,u.name,u.role,u.initials,a.clock_in,a.clock_out,COALESCE(a.status,'Absent') status,a.late_reason,a.office,a.distance_m,a.note FROM users u LEFT JOIN attendance a ON a.user_id=u.id AND a.day=? WHERE u.active=1 ORDER BY u.id`).all(d) : [];
  res.json({ me, team, rules: { late_after: cfg().late_after, start: cfg().start, end: cfg().end }, summary: { present: team.filter(t => ['Present', 'Remote', 'Late', 'On site'].includes(t.status)).length, late: team.filter(t => t.status === 'Late').length, leave: team.filter(t => t.status === 'Leave').length } });
}));
// POST /api/attendance/clock-in  { lat, lng, accuracy, late_reason?, device? }
// Errors tell the app exactly what to do next: code = OUTSIDE_OFFICE | LOCATION_REQUIRED | LOW_ACCURACY | REASON_REQUIRED
r.post('/clock-in', wrap((req, res) => {
  const c = cfg(), b = req.body || {}, d = today(), t = new Date();
  const ex = db.prepare('SELECT * FROM attendance WHERE user_id=? AND day=?').get(req.user.id, d);
  if (ex && ex.clock_in && !ex.clock_out) return bad(res, 'You are already clocked in');
  let office = null, distance = null;
  const remoteOk = (c.remote_roles || []).includes(req.user.role_name);
  if (c.geofence && !remoteOk) {
    const lat = +b.lat, lng = +b.lng, acc = +b.accuracy || 0;
    if (!isFinite(lat) || !isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180 || (lat === 0 && lng === 0)) return res.status(400).json({ error: 'Turn on location to clock in', code: 'LOCATION_REQUIRED' });
    if (!c.offices.length) return res.status(400).json({ error: 'No office location is set up yet. Ask an admin to add one in Global Config → Attendance.', code: 'NO_OFFICE' });
    if (acc > c.max_accuracy_m) return res.status(400).json({ error: `GPS is not accurate enough (±${Math.round(acc)} m). Move near a window and try again.`, code: 'LOW_ACCURACY' });
    const best = c.offices.map(o => ({ o, d: dist({ lat, lng }, o) })).sort((a, b) => a.d - b.d)[0];
    const lim = (best.o.radius_m || c.radius_m) + Math.min(acc, 50);
    if (best.d > lim) {
      db.prepare('INSERT INTO audit_log (user_id,user_name,method,path,status,action,detail,ip) VALUES (?,?,?,?,?,?,?,?)').run(req.user.id, req.user.name, 'POST', '/api/attendance/clock-in', 403, 'Clock-in blocked (outside office)', JSON.stringify({ distance_m: Math.round(best.d), office: best.o.name, lat, lng, acc }), req.ip);
      return res.status(403).json({ error: `You are ${best.d >= 1000 ? (best.d / 1000).toFixed(1) + ' km' : Math.round(best.d) + ' m'} from ${best.o.name}. Clock-in works within ${best.o.radius_m || c.radius_m} m.`, code: 'OUTSIDE_OFFICE', distance_m: Math.round(best.d), office: best.o.name });
    }
    office = best.o.name; distance = Math.round(best.d);
  }
  const late = t.getHours() * 60 + t.getMinutes() > hm(c.late_after), reason = String(b.late_reason || '').trim().slice(0, 500);
  if (late && c.ask_reason && c.reason_required && reason.length < 3) return res.status(400).json({ error: `You are late (after ${c.late_after}). Tell your manager why.`, code: 'REASON_REQUIRED', minutes_late: t.getHours() * 60 + t.getMinutes() - hm(c.late_after) });
  db.prepare(`INSERT INTO attendance (user_id,day,clock_in,status,location,late_reason,lat,lng,accuracy_m,distance_m,office,device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
    ON CONFLICT(user_id,day) DO UPDATE SET clock_in=excluded.clock_in, clock_out=NULL, status=excluded.status, late_reason=excluded.late_reason, lat=excluded.lat, lng=excluded.lng, accuracy_m=excluded.accuracy_m, distance_m=excluded.distance_m, office=excluded.office, device=excluded.device`)
    .run(req.user.id, d, nowIso(), late ? 'Late' : remoteOk && !office ? 'Remote' : 'Present', office || (remoteOk ? 'Remote' : 'Office'), late ? reason || null : null, +b.lat || null, +b.lng || null, +b.accuracy || null, distance, office, String(b.device || req.get('user-agent') || '').slice(0, 120));
  if (late) require('../services/notify').notifyManagers({ title: `Late clock-in: ${req.user.name}`, body: reason || 'No reason given', kind: 'attendance' }).catch(() => {});
  res.json(db.prepare('SELECT * FROM attendance WHERE user_id=? AND day=?').get(req.user.id, d));
}));
r.post('/clock-out', wrap((req, res) => {
  const d = today(), ex = db.prepare('SELECT * FROM attendance WHERE user_id=? AND day=?').get(req.user.id, d);
  if (!ex || !ex.clock_in) return bad(res, 'You have not clocked in today'); if (ex.clock_out) return bad(res, 'You already clocked out');
  db.prepare('UPDATE attendance SET clock_out=? WHERE id=?').run(nowIso(), ex.id);
  res.json(db.prepare('SELECT * FROM attendance WHERE id=?').get(ex.id));
}));
// POST /api/attendance/mark  { user_id, day?, status: Present|On site|Remote|Leave|Absent, note }   (managers / HR) — e.g. agent at a site visit
r.post('/mark', wrap((req, res) => {
  if (!isManager(req.user) && !can(req.user, 'Attendance', 'View All Users')) return res.status(403).json({ error: 'Only managers or HR can mark attendance' });
  const b = req.body || {}, day = b.day || today();
  if (!['Present', 'On site', 'Remote', 'Leave', 'Absent', 'Late'].includes(b.status)) return bad(res, 'Unknown status');
  if (!String(b.note || '').trim()) return bad(res, 'Add a note, e.g. "Site visit at Damac Lagoons"');
  db.prepare(`INSERT INTO attendance (user_id,day,clock_in,status,location,marked_by,note) VALUES (?,?,?,?,?,?,?) ON CONFLICT(user_id,day) DO UPDATE SET status=excluded.status, marked_by=excluded.marked_by, note=excluded.note, clock_in=COALESCE(attendance.clock_in, excluded.clock_in)`)
    .run(+b.user_id, day, ['Present', 'On site', 'Remote', 'Late'].includes(b.status) ? nowIso() : null, b.status, b.status, req.user.id, String(b.note).slice(0, 300));
  res.json(db.prepare('SELECT * FROM attendance WHERE user_id=? AND day=?').get(+b.user_id, day));
}));
// GET /api/attendance/month?month=YYYY-MM
r.get('/month', wrap((req, res) => {
  const m = req.query.month || today().slice(0, 7), users = db.prepare('SELECT COUNT(*) c FROM users WHERE active=1').get().c || 1;
  const rows = db.prepare(`SELECT day, SUM(CASE WHEN status IN ('Present','Late','Remote','On site') THEN 1 ELSE 0 END) present, SUM(status='Late') late FROM attendance WHERE day LIKE ? GROUP BY day`).all(m + '%');
  res.json(rows.map(r => ({ day: r.day, rate: Math.round(r.present / users * 100), late: r.late })));
}));
// GET /api/attendance/late?from=&to=  -> late arrivals with reasons (managers)
r.get('/late', wrap((req, res) => {
  if (!isManager(req.user)) return res.status(403).json({ error: 'Managers only' });
  res.json(db.prepare("SELECT a.day,u.name,a.clock_in,a.late_reason,a.office,a.distance_m FROM attendance a JOIN users u ON u.id=a.user_id WHERE a.status='Late' AND a.day BETWEEN ? AND ? ORDER BY a.day DESC, a.clock_in").all(req.query.from || '1970-01-01', req.query.to || '9999-12-31'));
}));
module.exports = r;
