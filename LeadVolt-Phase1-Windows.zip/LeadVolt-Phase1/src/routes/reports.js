const r=require('express').Router(),db=require('../db');
const {wrap,rangeStart,today}=require('../util');
const {scope,agentIds}=require('../access');
function data(u,range){
 const s=scope(u),from=rangeStart(range||'month');
 const leads=db.prepare(`SELECT l.* FROM leads l WHERE l.is_deleted=0 AND ${s.sql} AND date(l.created_at)>=?`).all(...s.params,from);
 const byStatus={};for(const l of leads)byStatus[l.status]=(byStatus[l.status]||0)+1;
 const sources=Object.entries(leads.reduce((a,l)=>(a[l.source]=(a[l.source]||0)+1,a),{})).map(([source,c])=>({source,c,leads:c}));
 const revenue=require('../features').canFinance(u)?db.prepare(`SELECT COALESCE(SUM(i.property_price*i.commission_pct/100),0) value FROM invoices i JOIN leads l ON l.id=i.lead_id WHERE ${s.sql} AND i.status='Paid' AND date(i.issued_at)>=?`).get(...s.params,from).value:undefined;
 const ids=agentIds(u);const users=db.prepare(`SELECT id,name FROM users WHERE active=1 ${ids===null?'':`AND id IN (${ids.map(()=>'?').join(',')})`}`).all(...(ids||[]));
 const agents=users.map(a=>({...a,leads:leads.filter(l=>l.agent_id===a.id).length,booked:leads.filter(l=>l.agent_id===a.id&&['Booked','Invoiced'].includes(l.status)).length}));
 return {leads,byStatus,sources,revenue,agents,scope:s,from};
}
r.get('/dashboard',wrap((req,res)=>{
 const d=data(req.user,req.query.range||'all'),ids=agentIds(req.user);
 const reminders=db.prepare(`SELECT t.id,t.title,t.type,t.due_time,l.name lead,u.name agent FROM tasks t LEFT JOIN leads l ON l.id=t.lead_id LEFT JOIN users u ON u.id=t.assignee_id WHERE t.due_date=? AND t.done=0 ${ids===null?'':`AND t.assignee_id IN (${ids.map(()=>'?').join(',')})`} ORDER BY t.due_time LIMIT 100`).all(today(),...(ids||[]));
 const total=d.leads.length,bs=d.byStatus,booked=(bs.Booked||0)+(bs.Invoiced||0);
 res.json({total,active:total-(bs.Invoiced||0),byStatus:bs,sources:d.sources,revenue:d.revenue,reminders,closers:d.agents.sort((a,b)=>b.booked-a.booked).slice(0,5),funnel:[{stage:'Leads',count:total},{stage:'Booked',count:booked},{stage:'Invoiced',count:bs.Invoiced||0}],focus:{callbacks:bs.Callback||0,overdue:bs.Overdue||0,next_visit:reminders.find(r=>r.type!=='Call')||null}});
}));
r.get('/reports/summary',wrap((req,res)=>{
 const d=data(req.user,req.query.range),s=d.scope,days={};for(const l of d.leads){const day=l.created_at.slice(0,10),v=days[day]||(days[day]={day,leads:0,booked:0,visits:0});v.leads++;if(['Booked','Invoiced'].includes(l.status))v.booked++;if(l.status==='Site Visit Done')v.visits++;}
 const agents=d.agents.map(a=>({...a,revenue:require('../features').canFinance(req.user)?db.prepare(`SELECT COALESCE(SUM(i.property_price*i.commission_pct/100),0) value FROM invoices i JOIN leads l ON l.id=i.lead_id WHERE i.status='Paid' AND l.agent_id=? AND date(i.issued_at)>=?`).get(a.id,d.from).value:undefined}));
 const booked=d.leads.filter(l=>['Booked','Invoiced'].includes(l.status)).length;
 const calls=db.prepare(`SELECT CAST(strftime('%w',a.created_at) AS INT) dow,CAST(strftime('%H',a.created_at) AS INT) hour,COUNT(*) c FROM activities a JOIN leads l ON l.id=a.lead_id WHERE a.kind='call' AND ${s.sql} AND date(a.created_at)>=? GROUP BY dow,hour`).all(...s.params,d.from);
 res.json({kpis:{leads:d.leads.length,booked,conversion:d.leads.length?+(100*booked/d.leads.length).toFixed(2):0},trend:Object.values(days).sort((a,b)=>a.day.localeCompare(b.day)),sources:d.sources.map(x=>{const booked=d.leads.filter(l=>l.source===x.source&&['Booked','Invoiced'].includes(l.status)).length;return {...x,booked,conversion:+(100*booked/x.leads).toFixed(2)};}),agents,best_time_to_call:calls});
}));
// CRM revenue is closed-deal commission, grouped separately for each currency.
r.get('/reports/closed-deals-summary',wrap((req,res)=>{
 if(!require('../features').canFinance(req.user))return res.status(403).json({error:'Revenue Summary is restricted to Admin'});
 const rows=require('./deals').closedRows(),groups={month:new Map(),agent:new Map(),project:new Map()},totals=new Map();
 function add(map,key,label,d){
  const id=JSON.stringify([key,d.currency]);let g=map.get(id);
  if(!g){g={key,label,currency:d.currency,count:0,deal_value_minor:0,commission_minor:0,pending_minor:0,paid_minor:0,commission_unset:0};map.set(id,g);}
  g.count++;g.deal_value_minor+=d.deal_value_minor;
  if(d.commission_minor===null)g.commission_unset++;else{g.commission_minor+=d.commission_minor;g[d.commission_status==='paid'?'paid_minor':'pending_minor']+=d.commission_minor;}
  for(const field of ['deal_value_minor','commission_minor','pending_minor','paid_minor'])if(!Number.isSafeInteger(g[field]))throw Error('Summary exceeds safe monetary range');
 }
 for(const d of rows){add(totals,d.currency,d.currency,d);add(groups.month,d.booked_date?.slice(0,7)||'Undated',d.booked_date?.slice(0,7)||'Undated',d);add(groups.agent,d.agent_id,d.agent||'Unassigned',d);add(groups.project,d.project_id,d.project||'No project',d);}
 res.json({totals:[...totals.values()],month:[...groups.month.values()].sort((a,b)=>b.label.localeCompare(a.label)),agent:[...groups.agent.values()],project:[...groups.project.values()]});
}));module.exports=r;
