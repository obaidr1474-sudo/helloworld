const r = require('express').Router();
const db = require('../db');
const { wrap, bad, need } = require('../util');
const fs = require('fs'), path = require('path'), multer = require('multer'), crypto = require('crypto');
const STORE = process.env.STORAGE_DIR || path.join(__dirname, '..', '..', 'storage');
const J = (v, d) => { try { return v ? JSON.parse(v) : d; } catch { return d; } };
const P = p => p && ({ ...p, amenities: J(p.amenities, []), facing: J(p.facing, []), rera: J(p.rera, []), pocs: J(p.pocs, []), units_left: p.total_units - p.sold_units,
  cover: (db.prepare("SELECT id FROM media WHERE project_id=? AND kind='photo' ORDER BY is_cover DESC, sort LIMIT 1").get(p.id) || {}).id || null });
// GET /api/projects?status=Ready|Off Plan&area=&q=
r.get('/projects', wrap((req, res) => {
  const w = [], p = []; const { status, area, q } = req.query;
  if (status) { w.push('status=?'); p.push(status); } if (area) { w.push('area=?'); p.push(area); } if (q) { w.push('(name LIKE ? OR area LIKE ? OR developer LIKE ?)'); p.push(`%${q}%`, `%${q}%`, `%${q}%`); }
  res.json(db.prepare(`SELECT * FROM projects ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY id`).all(...p).map(P));
}));
// GET /api/projects/:id  -> project + interested leads
r.get('/projects/:id', wrap((req, res) => {
  const p = P(db.prepare('SELECT * FROM projects WHERE id=?').get(+req.params.id)); if (!p) return res.status(404).json({ error: 'Project not found' });
  p.blocks = db.prepare('SELECT * FROM project_blocks WHERE project_id=? ORDER BY id').all(p.id);
  p.media = db.prepare('SELECT id,kind,file_name,url,mime,bytes,is_cover,sort FROM media WHERE project_id=? ORDER BY kind, is_cover DESC, sort').all(p.id);
  const scope=require('../access').scope(req.user);p.interested_leads = db.prepare(`SELECT id,name,status,budget,score FROM leads l WHERE project_id=? AND is_deleted=0 AND ${scope.sql} ORDER BY score DESC`).all(p.id,...scope.params);
  res.json(p);
}));
// GET /api/units?project_id=&type=&status=&max_price=&q=&sort=price|size&dir=
r.get('/units', wrap((req, res) => {
  const w = [], p = []; const { project_id, type, status, max_price, q, sort = 'price', dir = 'asc' } = req.query;
  if (project_id) { w.push('u.project_id=?'); p.push(+project_id); } if (type) { w.push('u.type=?'); p.push(type); } if (status) { w.push('u.status=?'); p.push(status); }
  if (max_price) { w.push('u.price<=?'); p.push(+max_price); } if (q) { w.push('u.id LIKE ?'); p.push(`%${q}%`); }
  const rows = db.prepare(`SELECT u.*, pr.name AS project, NULL AS reserved_for FROM units u JOIN projects pr ON pr.id=u.project_id LEFT JOIN leads l ON l.id=u.reserved_for_lead_id ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY ${sort === 'size' ? 'u.size_sqft' : 'u.price'} ${dir === 'desc' ? 'DESC' : 'ASC'}`).all(...p);
  res.json(rows.map(u => ({ ...u, price_per_sqft: Math.round(u.price / u.size_sqft) })));
}));
// POST /api/units/:id/reserve { lead_id, hold_days }
r.post('/units/:id/reserve', wrap((req, res) => {
  const u = db.prepare('SELECT * FROM units WHERE id=?').get(req.params.id); if (!u) return res.status(404).json({ error: 'Unit not found' });
  if (u.status !== 'Available') return bad(res, 'This unit is already ' + u.status.toLowerCase());
  const { lead_id, hold_days = 2 } = req.body || {}; if (!lead_id) return bad(res, 'Choose a lead');
  require('../access').lead(req.user,lead_id);if(!Number.isInteger(hold_days)||hold_days<1||hold_days>30)return bad(res,'hold_days must be 1–30');
  const until = new Date(Date.now() + hold_days * 864e5).toISOString();
  db.prepare("UPDATE units SET status='Reserved', reserved_for_lead_id=?, reserved_until=? WHERE id=?").run(lead_id, until, u.id);
  db.prepare("INSERT INTO activities (lead_id,user_id,kind,text) VALUES (?,?,'reservation',?)").run(lead_id, req.user.id, `Unit ${u.id} reserved for ${hold_days} days`);
  res.json(db.prepare('SELECT * FROM units WHERE id=?').get(u.id));
}));
// GET /api/projects/:id/payment-plan?price=&installments=6  -> booking, installments, handover schedule
r.get('/projects/:id/payment-plan', wrap((req, res) => {
  const p = db.prepare('SELECT * FROM projects WHERE id=?').get(+req.params.id); if (!p) return res.status(404).json({ error: 'Project not found' });
  if (!p.handover_date) return bad(res, 'This project is ready, there is no construction plan');
  const price = +req.query.price || p.price_from * 1e6, n = Math.max(1, Math.min(24, +req.query.installments || 6));
  const start = Date.now(), end = new Date(p.handover_date).getTime(), gap = (end - start) / (n + 1);
  const rows = [{ label: 'Booking payment', date: new Date(start).toISOString().slice(0, 10), amount: price * p.plan_booking / 100 }];
  for (let k = 1; k <= n; k++) rows.push({ label: 'Installment ' + k, date: new Date(start + gap * k).toISOString().slice(0, 10), amount: price * p.plan_construction / 100 / n });
  rows.push({ label: 'On handover', date: p.handover_date, amount: price * p.plan_handover / 100 });
  res.json({ project: p.name, price, plan: [p.plan_booking, p.plan_construction, p.plan_handover], schedule: rows.map(r => ({ ...r, amount: Math.round(r.amount) })) });
}));
// POST /api/projects  — the Add Project wizard (steps 1–4 in one call; photos etc. via /media)
const TYPES = { Residential: ['Apartment', 'Villa', 'Townhouse', 'Penthouse', 'Duplex', 'Plot'], Commercial: ['Office', 'Shop', 'Showroom', 'Warehouse', 'Hotel Apartment', 'Building'], Agricultural: ['Farm House', 'Farm Land', 'Land'] };
r.post('/projects', need('Projects', 'Create'), wrap((req, res) => {
  const b = req.body || {}, name = String(b.name || '').trim();
  if (!name) return bad(res, 'Enter the project name');
  if (db.prepare('SELECT 1 FROM projects WHERE lower(name)=lower(?)').get(name)) return bad(res, 'A project with this name already exists');
  if (b.type && !TYPES[b.type]) return bad(res, 'Type must be Residential, Commercial or Agricultural');
  if (b.type && b.sub_type && !TYPES[b.type].includes(b.sub_type)) return bad(res, `${b.sub_type} is not a ${b.type} sub-type`);
  const min = +b.price_min, max = b.price_max ? +b.price_max : null;
  if (!(min > 0)) return bad(res, 'Enter a minimum price in AED'); if (max && max < min) return bad(res, 'Maximum price must be higher than the minimum');
  if (b.start_date && b.end_date && b.end_date < b.start_date) return bad(res, 'End date must be after the start date');
  if (b.start_date && b.handover_date && b.handover_date < b.start_date) return bad(res, 'Handover must be after the start date');
  const units = Array.isArray(b.units) ? b.units : [], blocks = Array.isArray(b.blocks) ? b.blocks : [];
  if (units.length > 5000) return bad(res, 'At most 5,000 units per request');
  const id = db.transaction(() => {
    const off = !/ready/i.test(b.status || '');
    const pid = db.prepare(`INSERT INTO projects (name,area,developer,status,price_from,price_max,total_units,sold_units,beds,size_range,construction_progress,handover_date,plan_booking,plan_construction,plan_handover,amenities,about,
      type,sub_type,certificate,facing,land_area,total_blocks,total_floors,notes,rera,brokerage,pocs,start_date,end_date,created_by) VALUES (?,?,?,?,?,?,?,0,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
      .run(name, b.area || null, b.developer || null, off ? 'Off Plan' : 'Ready', min / 1e6, max, units.reduce((a, u) => a + (+u.qty || 1), 0) || blocks.reduce((a, x) => a + (+x.floors || 0) * (+x.units_per_floor || 0), 0) || null,
        [...new Set(units.map(u => u.type).filter(Boolean))].join(', ') || b.sub_type || null, b.land_area || null, off ? 0 : 100, b.handover_date || null, ...(Array.isArray(b.plan) && b.plan.length === 3 ? b.plan : [20, 30, 50]),
        JSON.stringify(b.amenities || []), b.description || null, b.type || null, b.sub_type || null, b.certificate || null, JSON.stringify(b.facing || []), b.land_area || null, b.total_blocks || blocks.length || null, b.total_floors || null,
        b.notes || null, JSON.stringify((b.rera || []).filter(Boolean)), b.brokerage || null, JSON.stringify(b.pocs || []), b.start_date || null, b.end_date || null, req.user.id).lastInsertRowid;
    const ib = db.prepare('INSERT INTO project_blocks (project_id,name,floors,units_per_floor,phase,handover_date,progress) VALUES (?,?,?,?,?,?,?)');
    blocks.forEach(x => { if (!String(x.name || '').trim()) throw Object.assign(new Error('Every block needs a name'), { status: 400 }); ib.run(pid, x.name.trim(), x.floors || null, x.units_per_floor || null, x.phase || null, x.handover_date || null, Math.max(0, Math.min(100, +x.progress || 0))); });
    const iu = db.prepare('INSERT INTO units (id,project_id,type,size_sqft,floor,view,price,status,block,furnishing) VALUES (?,?,?,?,?,?,?,?,?,?)');
    const code = name.split(/\s+/).map(w => w[0]).join('').toUpperCase();
    units.forEach((u, k) => { const qty = Math.max(1, Math.min(500, +u.qty || 1)); for (let q = 0; q < qty; q++) { const uid = code + '-' + pid + '-' + (qty > 1 ? `${u.name || 'U'}-${q + 1}` : (u.name || 'U' + (k + 1))); iu.run(uid, pid, u.type || null, +u.size || null, u.floor || null, u.view || null, +u.price || null, 'Available', u.block || null, u.furnishing || null); } });
    return pid;
  })();
  res.status(201).json(P(db.prepare('SELECT * FROM projects WHERE id=?').get(id)));
}));
// POST /api/projects/:id/media  (multipart: files[] + kind=photo|video|brochure)   |  { kind:'link', url }
const LIM = { photo: [10, /^image\/(jpeg|png|bmp|webp)$/], video: [50, /^video\/mp4$/], brochure: [25, /^application\/pdf$/] };
const MAGIC = { 'image/jpeg': [0xFF, 0xD8, 0xFF], 'image/png': [0x89, 0x50, 0x4E, 0x47], 'image/bmp': [0x42, 0x4D], 'application/pdf': [0x25, 0x50, 0x44, 0x46] };
const up = multer({ storage: multer.diskStorage({ destination: (req, f, cb) => { const d = path.join(STORE, 'projects', String(+req.params.id)); fs.mkdirSync(d, { recursive: true }); cb(null, d); }, filename: (req, f, cb) => cb(null, crypto.randomBytes(12).toString('hex') + path.extname(f.originalname).toLowerCase().replace(/[^.a-z0-9]/g, '')) }),
  limits: { fileSize: 50 * 1048576, files: 10 }, fileFilter: (req, f, cb) => { const L = LIM[req.query.kind || req.body.kind]; cb(L && L[1].test(f.mimetype) ? null : Object.assign(new Error(`Wrong file type for ${req.query.kind || 'this section'}: ${f.originalname}`), { status: 400 }), true); } });
r.post('/projects/:id/media', need('Projects', 'Update Documents'), (req, res, next) => {
  const p = db.prepare('SELECT id FROM projects WHERE id=?').get(+req.params.id); if (!p) return res.status(404).json({ error: 'Project not found' });
  if ((req.query.kind || '') === 'link' || req.is('application/json')) return next();
  up.array('files', 10)(req, res, err => { if (err) return res.status(err.status || (err.code === 'LIMIT_FILE_SIZE' ? 413 : 400)).json({ error: err.code === 'LIMIT_FILE_SIZE' ? 'File too large' : err.message }); next(); });
}, wrap((req, res) => {
  const pid = +req.params.id, kind = req.query.kind || (req.body || {}).kind;
  if (kind === 'link') { const u = String((req.body || {}).url || ''); let ok = false; try { ok = /^https?:$/.test(new URL(u).protocol); } catch {} if (!ok) return bad(res, 'Enter a full link starting with https://'); const id = db.prepare("INSERT INTO media (project_id,kind,url,uploaded_by) VALUES (?,'link',?,?)").run(pid, u, req.user.id).lastInsertRowid; return res.status(201).json([{ id, kind, url: u }]); }
  const L = LIM[kind]; if (!L) return bad(res, 'kind must be photo, video, brochure or link');
  const files = req.files || []; if (!files.length) return bad(res, 'Choose at least one file');
  const saved = [], rejected = [];
  for (const f of files) {
    const head=Buffer.alloc(12),fd=fs.openSync(f.path,'r');try{fs.readSync(fd,head,0,12,0);}finally{fs.closeSync(fd);}const m=MAGIC[f.mimetype];
    const webp=f.mimetype!=='image/webp'||(head.subarray(0,4).toString()==='RIFF'&&head.subarray(8,12).toString()==='WEBP');
    const mp4 = f.mimetype === 'video/mp4' && head.subarray(4, 8).toString() === 'ftyp';
    if (!webp || f.size > L[0] * 1048576 || (m && !m.every((b, i) => head[i] === b)) || (f.mimetype === 'video/mp4' && !mp4)) { fs.unlinkSync(f.path); rejected.push({ file: f.originalname, why: f.size > L[0] * 1048576 ? `Over ${L[0]} MB` : 'File content does not match its type' }); continue; }
    const sort = (db.prepare('SELECT MAX(sort) m FROM media WHERE project_id=? AND kind=?').get(pid, kind).m || 0) + 1;
    const cover = kind === 'photo' && !db.prepare("SELECT 1 FROM media WHERE project_id=? AND kind='photo'").get(pid) ? 1 : 0;
    const id = db.prepare('INSERT INTO media (project_id,kind,file_name,stored_path,mime,bytes,is_cover,sort,uploaded_by) VALUES (?,?,?,?,?,?,?,?,?)').run(pid, kind, f.originalname.slice(0, 200), f.path, f.mimetype, f.size, cover, sort, req.user.id).lastInsertRowid;
    saved.push({ id, kind, file_name: f.originalname, bytes: f.size, is_cover: cover, url: `/api/media/${id}` });
  }
  res.status(saved.length ? 201 : 400).json({ saved, rejected });
}));
// PATCH /api/media/:id { is_cover?, sort? }  DELETE /api/media/:id  GET /api/media/:id
r.patch('/media/:id', need('Projects', 'Update Documents'), wrap((req, res) => {
  const m = db.prepare('SELECT * FROM media WHERE id=?').get(+req.params.id); if (!m) return res.status(404).json({ error: 'Not found' });
  if ((req.body || {}).is_cover) db.transaction(() => { db.prepare("UPDATE media SET is_cover=0 WHERE project_id=? AND kind='photo'").run(m.project_id); db.prepare('UPDATE media SET is_cover=1 WHERE id=?').run(m.id); })();
  if (Number.isInteger((req.body || {}).sort)) db.prepare('UPDATE media SET sort=? WHERE id=?').run(req.body.sort, m.id);
  res.json(db.prepare('SELECT id,kind,is_cover,sort FROM media WHERE id=?').get(m.id));
}));
r.delete('/media/:id', need('Projects', 'Update Documents'), wrap((req, res) => { const m = db.prepare('SELECT * FROM media WHERE id=?').get(+req.params.id); if (!m) return res.status(404).json({ error: 'Not found' }); if (m.stored_path) fs.rmSync(m.stored_path, { force: true }); db.prepare('DELETE FROM media WHERE id=?').run(m.id); res.status(204).end(); }));
r.get('/media/:id', wrap((req, res) => { const m = db.prepare('SELECT * FROM media WHERE id=?').get(+req.params.id); if (!m || !m.stored_path || !fs.existsSync(m.stored_path)) return res.status(404).json({ error: 'Not found' }); res.set({ 'Content-Type': m.mime, 'Cache-Control': 'private, max-age=86400', 'Content-Disposition': `inline; filename="${m.file_name.replace(/[^\w.\- ]/g, '_')}"` }); res.sendFile(path.resolve(m.stored_path)); }));
module.exports = r;
