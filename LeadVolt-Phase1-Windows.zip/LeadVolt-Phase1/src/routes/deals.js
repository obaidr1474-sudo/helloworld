const r = require('express').Router();
const db = require('../db');
const { wrap } = require('../util');
const closed = "d.stage IN ('Booked','Invoiced')";
function money(value) {
  const text=String(value);
  if(!/^\d+(?:\.\d{1,2})?$/.test(text))throw Error('Use a non-negative amount with at most two decimal places');
  const [whole,fraction='']=text.split('.'),minor=Number(whole)*100+Number(fraction.padEnd(2,'0'));
  if(!Number.isSafeInteger(minor)||minor>1000000000000)throw Error('Amount exceeds the supported range');
  return minor;
}
function present(row){
  const value=money(row.agreement_value||0),basis=row.commission_pct==null?null:Math.round(row.commission_pct*100);
  const commission=row.commission_override_minor??(basis==null?null:Number((BigInt(value)*BigInt(basis)+5000n)/10000n));
  return {...row,deal_value_minor:value,commission_minor:commission};
}
function rows(owner){return db.prepare(`SELECT d.*,l.name AS lead,u.name AS agent,pr.name AS project
 FROM deals d JOIN leads l ON l.id=d.lead_id LEFT JOIN users u ON u.id=d.agent_id
 LEFT JOIN projects pr ON pr.id=d.project_id WHERE ${closed}${owner===undefined?'':' AND d.agent_id=?'}
 ORDER BY d.booked_date DESC,d.id DESC`).all(...(owner===undefined?[]:[owner])).map(present);}
// The sole non-Admin finance endpoint; ownership comes only from the session.
r.get('/my-closed',wrap((req,res)=>{
 if(Object.keys(req.query).length)return res.status(403).json({error:'Ownership filters are not accepted on my closed deals'});
 const data=rows(req.user.id);res.json({data,count:data.length});
}));
r.get('/',wrap((req,res)=>{
 const data=rows().filter(d=>(!req.query.agent_id||d.agent_id===Number(req.query.agent_id))&&(!req.query.from||d.booked_date>=req.query.from));
 res.json({data,count:data.length,total_value:data.reduce((sum,d)=>sum+d.agreement_value,0)});
}));
function fields(body,existing={}){
 const allowed=['agreement_value','commission_pct','commission_override','commission_status','revision','lead_id','booked_date'];
 if(Object.keys(body).some(k=>!allowed.includes(k)))throw Error('Unsupported deal field');
 const value=body.agreement_value===undefined?existing.agreement_value:money(body.agreement_value)/100;
 if(value===undefined)throw Error('Deal value is required');
 let pct=existing.commission_pct??null;
 if(body.commission_pct!==undefined){pct=body.commission_pct;if(pct!==null){if(typeof pct!=='number'||!Number.isFinite(pct)||pct<0||pct>100||Math.abs(pct*100-Math.round(pct*100))>0.000001)throw Error('Commission percentage must be between 0 and 100, with at most two decimals');}}
 const override=body.commission_override===undefined?(existing.commission_override_minor??null):body.commission_override===null?null:money(body.commission_override);
 const status=body.commission_status??existing.commission_status??'pending';
 if(!['pending','paid'].includes(status))throw Error('Commission status must be pending or paid');
 if(status==='paid'&&pct===null&&override===null)throw Error('Set a commission before marking it paid');
 const date=body.booked_date??existing.booked_date;
 if(typeof date!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(date)||Number.isNaN(Date.parse(date))||new Date(date).toISOString().slice(0,10)!==date)throw Error('A valid closed date is required');
 return {value,pct,override,status,date};
}
r.post('/',wrap((req,res)=>{
 try{
  const b=req.body;if(!b||!Number.isSafeInteger(b.lead_id))throw Error('An existing closed lead ID is required');
  const lead=db.prepare("SELECT * FROM leads WHERE id=? AND is_deleted=0 AND status IN ('Booked','Invoiced')").get(b.lead_id);
  if(!lead)return res.status(400).json({error:'Choose an existing Booked or Invoiced lead'});
  const f=fields(b);
  const result=db.transaction(()=>{
   if(db.prepare(`SELECT id FROM deals d WHERE lead_id=? AND ${closed}`).get(lead.id))return null;
   return db.prepare(`INSERT INTO deals(lead_id,agent_id,project_id,booked_date,agreement_value,currency,stage,commission_pct,commission_override_minor,commission_status,commission_paid_at,commission_paid_by)
    VALUES(?,?,?,?,?,'AED','Booked',?,?,?,?,?)`).run(lead.id,lead.agent_id,lead.project_id,f.date,f.value,f.pct,f.override,f.status,f.status==='paid'?new Date().toISOString():null,f.status==='paid'?req.user.id:null);
  })();
  if(!result)return res.status(409).json({error:'This lead already has a closed deal'});
  res.status(201).json({id:Number(result.lastInsertRowid)});
 }catch(e){if(e.code)throw e;res.status(400).json({error:e.message});}
}));
r.patch('/:id',wrap((req,res)=>{
 try{
  const old=db.prepare(`SELECT * FROM deals d WHERE id=? AND ${closed}`).get(req.params.id);
  if(!old)return res.status(404).json({error:'Closed deal not found'});
  if(old.currency!=='AED')return res.status(400).json({error:'Only AED deal editing is supported in v1'});
  if(req.body.lead_id!==undefined)return res.status(400).json({error:'Deal ownership cannot be changed here'});
  if(!Number.isSafeInteger(req.body.revision)||req.body.revision!==old.revision)return res.status(409).json({error:'Deal changed; refresh before saving'});
  const f=fields(req.body,old),paid=f.status==='paid';
  const result=db.prepare(`UPDATE deals SET agreement_value=?,commission_pct=?,commission_override_minor=?,commission_status=?,booked_date=?,commission_paid_at=?,commission_paid_by=?,revision=revision+1 WHERE id=? AND revision=?`)
   .run(f.value,f.pct,f.override,f.status,f.date,paid?(old.commission_paid_at||new Date().toISOString()):null,paid?(old.commission_paid_by||req.user.id):null,old.id,old.revision);
  if(!result.changes)return res.status(409).json({error:'Deal changed; refresh before saving'});
  res.json({id:old.id,revision:old.revision+1});
 }catch(e){if(e.code)throw e;res.status(400).json({error:e.message});}
}));
r.closedRows=rows;
module.exports=r;
