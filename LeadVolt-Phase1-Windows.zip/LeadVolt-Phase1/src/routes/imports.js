const r = require('express').Router();
const db = require('../db');
const { wrap, bad, parseBudget } = require('../util');
function parseCSV(t) { const rows = []; let row = [], cur = '', q = false; for (let i = 0; i < t.length; i++) { const c = t[i]; if (q) { if (c === '"') { if (t[i + 1] === '"') { cur += '"'; i++; } else q = false; } else cur += c; } else if (c === '"') q = true; else if (c === ',') { row.push(cur); cur = ''; } else if (c === '\n' || c === '\r') { if (c === '\r' && t[i + 1] === '\n') i++; row.push(cur); cur = ''; if (row.some(x => x.trim())) rows.push(row); row = []; } else cur += c; } row.push(cur); if (row.some(x => x.trim())) rows.push(row); return rows; }
const guess = h => { h = h.toLowerCase(); return /name/.test(h) ? 'name' : /phone|mobile|tel/.test(h) ? 'phone' : /mail/.test(h) ? 'email' : /source|channel/.test(h) ? 'source' : /budget|price/.test(h) ? 'budget' : /project|interest|property/.test(h) ? 'project' : null; };
// POST /api/imports/preview  { csv }  -> headers, guessed mapping, first rows
r.post('/preview', wrap((req, res) => {
  const all = parseCSV(String((req.body || {}).csv || '')); if (all.length < 2) return bad(res, 'That file has no data rows');
  res.json({ headers: all[0], mapping: all[0].map(guess), rows: all.slice(1, 6), total_rows: all.length - 1 });
}));
// POST /api/imports  { csv, file_name, mapping:[field|null per column], agent_id? }
r.post('/',(req,res)=>res.status(410).json({error:'Use POST /api/imports/jobs with an Idempotency-Key; synchronous CSV imports have been retired'}));
r.get('/', wrap((req, res) => res.json(db.prepare('SELECT i.*, u.name AS imported_by FROM imports i LEFT JOIN users u ON u.id=i.user_id ORDER BY i.id DESC').all())));
// POST /api/imports/leadrat  { leads:[...Leadrat-format lead objects], file_name? }
// Moves your own company's leads from Leadrat into LeadVolt. Skips leads already imported (same external id).
r.post('/leadrat', wrap((req, res) => {
  if(req.user.role_name!=='Admin')return res.status(403).json({error:'Only Admin can run legacy migrations'});
  const { mapLeadratLead } = require('../migrate/leadrat-map');
  const { createLead } = require('./leads');
  const list = (req.body || {}).leads; if (!Array.isArray(list) || !list.length || list.length>1000) return bad(res, 'Send { leads: [...] }');
  const users = db.prepare('SELECT id,name FROM users').all();
  let added = 0, skipped = 0, already = 0; const errors = [];
  list.forEach((raw, i) => {
    const m = mapLeadratLead(raw);
    if (m.external_ref && db.prepare('SELECT 1 FROM leads WHERE external_ref=?').get(m.external_ref)) { already++; return; }
    const u = m.agent_name && users.find(x => x.name.toLowerCase() === m.agent_name.toLowerCase()); delete m.agent_name;
    try { const id = createLead({ ...m, agent_id: u ? u.id : undefined }, req.user.id); db.prepare("INSERT INTO activities (lead_id,user_id,kind,text) VALUES (?,?,'import','Migrated from Leadrat')").run(id, req.user.id); added++; }
    catch (e) { skipped++; if (errors.length < 10) errors.push({ row: i + 1, error: e.message }); }
  });
  db.prepare('INSERT INTO imports (file_name,user_id,added,skipped) VALUES (?,?,?,?)').run((req.body.file_name || 'leadrat-migration.json'), req.user.id, added, skipped);
  res.status(201).json({ added, skipped, already_imported: already, errors });
}));
module.exports = r;
