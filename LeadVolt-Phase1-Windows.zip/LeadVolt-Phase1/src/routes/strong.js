const r=require('express').Router(),db=require('../db'),crypto=require('crypto');
const {wrap,bad,can}=require('../util'),Access=require('../access'),J=require('../services/jobs');
const {hash}=require('../services/ingest'),Imports=require('../services/imports');
const key=req=>{const k=req.get('Idempotency-Key');if(!k||!/^[\w:.-]{8,128}$/.test(k))throw Object.assign(new Error('Idempotency-Key must contain 8–128 letters, digits, :, ., _ or -'),{status:400});return k;};
const view=j=>({id:j.id,type:j.type,status:j.status,attempts:j.attempts,max_attempts:j.max_attempts,result:j.result?JSON.parse(j.result):null,error:j.error,created_at:j.created_at,finished_at:j.finished_at});
r.post('/imports/jobs',wrap((req,res)=>{
 const p=Imports.prepare(req.body||{});
 if(p.agent_id!==null){if(!can(req.user,'Leads','Assign'))return res.status(403).json({error:'Assignment permission required'});if(!db.prepare('SELECT 1 FROM users WHERE id=? AND active=1').get(p.agent_id))return bad(res,'Invalid agent');}
 const j=J.enqueue('import',`import:${req.user.id}:${key(req)}`,p,req.user.id);res.status(202).json({...view(j),status_url:`/api/imports/jobs/${j.id}`});
}));
r.get('/imports/jobs/:id',wrap((req,res)=>{const j=db.prepare("SELECT * FROM jobs WHERE id=? AND type='import'").get(+req.params.id);if(!j)return res.status(404).json({error:'Job not found'});if(j.owner_id!==req.user.id&&req.user.role_name!=='Admin')return res.status(403).json({error:'Not your job'});res.json(view(j));}));
r.get('/jobs',wrap((req,res)=>res.json(db.prepare('SELECT * FROM jobs ORDER BY id DESC LIMIT 100').all().map(view))));
r.get('/jobs/:id',wrap((req,res)=>{const j=db.prepare('SELECT * FROM jobs WHERE id=?').get(+req.params.id);if(!j)return res.status(404).json({error:'Job not found'});res.json(view(j));}));
r.post('/jobs/:id/retry',wrap((req,res)=>{const j=db.prepare('SELECT * FROM jobs WHERE id=?').get(+req.params.id);if(!j)return res.status(404).json({error:'Job not found'});if(j.status!=='dead')return bad(res,'Only dead jobs can be retried');db.prepare("UPDATE jobs SET status='queued',attempts=0,available_at=?,error=NULL WHERE id=?").run(Date.now(),j.id);res.json({ok:true});}));
// Every record receives its own ACK. Device capture is separate from server ingestion.
r.post('/sync/calls',wrap((req,res)=>{
 const b=req.body||{};if(typeof b.device_id!=='string'||!/^[\w.-]{1,100}$/.test(b.device_id)||!Array.isArray(b.events)||!b.events.length||b.events.length>100)return bad(res,'Provide device_id and 1–100 events');
 const results=b.events.map(e=>{try{
 if(!e||typeof e.event_id!=='string'||!/^[\w.-]{1,128}$/.test(e.event_id)||!Number.isSafeInteger(e.lead_id)||!Number.isSafeInteger(e.duration_sec)||e.duration_sec<0||e.duration_sec>86400||!['inbound','outbound','missed'].includes(e.direction)||!/^\d{4}-\d{2}-\d{2}T.*(?:Z|[+-]\d{2}:\d{2})$/.test(e.occurred_at||'')||!Number.isFinite(Date.parse(e.occurred_at))||Date.parse(e.occurred_at)>Date.now()+300000)throw Object.assign(new Error('Invalid call event; use an ISO timestamp with timezone'),{status:400});
 Access.lead(req.user,e.lead_id);
 const record={lead_id:e.lead_id,duration_sec:e.duration_sec,direction:e.direction,occurred_at:new Date(e.occurred_at).toISOString()},h=hash(record);
 return db.transaction(()=>{
 const old=db.prepare('SELECT * FROM call_sync WHERE user_id=? AND device_id=? AND event_id=?').get(req.user.id,b.device_id,e.event_id);
 if(old){if(old.payload_hash!==h)throw Object.assign(new Error('Event ID already used for different data'),{status:409});return {event_id:e.event_id,status:'duplicate'};}
 db.prepare('INSERT INTO call_sync(user_id,device_id,event_id,payload_hash,lead_id,occurred_at,duration_sec,direction) VALUES(?,?,?,?,?,?,?,?)').run(req.user.id,b.device_id,e.event_id,h,e.lead_id,record.occurred_at,e.duration_sec,e.direction);
 db.prepare("INSERT INTO activities(lead_id,user_id,kind,text,created_at) VALUES(?,?,'call',?,?)").run(e.lead_id,req.user.id,`${e.direction} call, ${e.duration_sec}s`,record.occurred_at);
 db.prepare('UPDATE leads SET first_contact_at=CASE WHEN first_contact_at IS NULL OR julianday(first_contact_at)>julianday(?) THEN ? ELSE first_contact_at END,last_contact_at=CASE WHEN last_contact_at IS NULL OR julianday(last_contact_at)<julianday(?) THEN ? ELSE last_contact_at END WHERE id=?').run(record.occurred_at,record.occurred_at,record.occurred_at,record.occurred_at,e.lead_id);
 return {event_id:e.event_id,status:'accepted'};
 }).immediate();
 }catch(err){return {event_id:e?.event_id??null,status:'rejected',code:err.status||500,error:err.status?err.message:'Event processing failed'};}});
 res.json({results,server_time:new Date().toISOString()});
}));
r.get('/sync/leads',wrap((req,res)=>{
 const after=Number(req.query.after||0),limit=Number(req.query.limit||100);
 if(!Number.isSafeInteger(after)||after<0||!Number.isSafeInteger(limit)||limit<1||limit>200)return bad(res,'Invalid cursor or limit');
 // Snapshot pagination, not incremental change feed. Clients must rebuild on each refresh to remove lost assignments.
 const s=Access.scope(req.user);const rows=db.prepare(`SELECT l.* FROM leads l WHERE ${s.sql} AND l.id>? ORDER BY l.id LIMIT ?`).all(...s.params,after,limit);
 res.json({data:rows,next_after:rows.length?rows.at(-1).id:after,has_more:rows.length===limit,mode:'full-refresh',server_time:new Date().toISOString()});
}));
r.post('/sync/changes',wrap((req,res)=>{
 const changes=req.body?.changes;if(!Array.isArray(changes)||!changes.length||changes.length>100)return bad(res,'Provide 1–100 changes');
 const results=changes.map(c=>{try{return db.transaction(()=>{
 if(!c||typeof c.event_id!=='string'||!/^[\w.-]{1,128}$/.test(c.event_id)||!Number.isSafeInteger(c.lead_id)||!Number.isSafeInteger(c.revision))throw Object.assign(new Error('Invalid change identity or revision'),{status:400});
 const h=hash(c),old=db.prepare('SELECT * FROM sync_changes WHERE user_id=? AND event_id=?').get(req.user.id,c.event_id);
 // Recheck visibility even when replaying an old ACK.
 const l=Access.lead(req.user,c.lead_id);
 if(old){if(old.payload_hash!==h)throw Object.assign(new Error('Event ID conflict'),{status:409});return {...JSON.parse(old.result),duplicate:true};}
 if(l.revision!==c.revision)throw Object.assign(new Error('Lead changed; fetch it and resolve the conflict'),{status:409});
 if(c.kind==='note'){
 if(!can(req.user,'Leads','Update Notes'))throw Object.assign(new Error('Notes permission required'),{status:403});
 if(typeof c.text!=='string'||!c.text.trim()||c.text.length>5000)throw Object.assign(new Error('Note must contain 1–5,000 characters'),{status:400});
 db.prepare("INSERT INTO activities(lead_id,user_id,kind,text) VALUES(?,?,'note',?)").run(l.id,req.user.id,c.text.trim());db.prepare("UPDATE leads SET last_contact_at=datetime('now') WHERE id=?").run(l.id);
 }else if(c.kind==='status'){
 if(!can(req.user,'Leads','Update Lead Status')&&!can(req.user,'Leads','Update'))throw Object.assign(new Error('Status permission required'),{status:403});
 // Bookings and invoicing require the richer web workflow, not a partial offline update.
 if(!require('../util').STATUSES.includes(c.status)||['Booked','Invoiced'].includes(c.status))throw Object.assign(new Error('This status requires the full booking workflow'),{status:400});
 if(require('../util').getSetting('leads',{}).note_required&&!String(c.text||'').trim())throw Object.assign(new Error('Status reason required'),{status:400});
 db.prepare("UPDATE leads SET status=?,last_contact_at=datetime('now') WHERE id=?").run(c.status,l.id);
 db.prepare('INSERT INTO lead_status_history(lead_id,from_status,to_status,user_id,notes) VALUES(?,?,?,?,?)').run(l.id,l.status,c.status,req.user.id,String(c.text||'').slice(0,5000));
 }else throw Object.assign(new Error('kind must be note or status'),{status:400});
 const result={event_id:c.event_id,status:'accepted',revision:db.prepare('SELECT revision FROM leads WHERE id=?').get(l.id).revision};db.prepare('INSERT INTO sync_changes VALUES(?,?,?,?)').run(req.user.id,c.event_id,h,JSON.stringify(result));return result;
 }).immediate();}catch(e){return {event_id:c?.event_id??null,status:'rejected',code:e.status||500,error:e.status?e.message:'Change failed'};}});
 res.json({results});
}));
function journal(body,user,k,reversal=null){
 if(body.currency!=='AED')throw Object.assign(new Error('Only AED journals are supported in v1'),{status:400});
 if(typeof body.description!=='string'||!body.description.trim()||body.description.length>500||!/^([A-Z]{3})$/.test(body.currency||'')||!Array.isArray(body.lines)||body.lines.length<2||body.lines.length>100)throw Object.assign(new Error('Description, currency and 2–100 journal lines are required'),{status:400});
 let debit=0,credit=0;const lines=body.lines.map(l=>{if(!l||typeof l.account!=='string'||!/^[A-Za-z0-9:_ .-]{1,80}$/.test(l.account)||!Number.isSafeInteger(l.debit_minor)||!Number.isSafeInteger(l.credit_minor)||l.debit_minor<0||l.credit_minor<0||!((l.debit_minor>0&&l.credit_minor===0)||(l.credit_minor>0&&l.debit_minor===0)))throw Object.assign(new Error('Use valid accounts and positive integer minor units on exactly one side'),{status:400});debit+=l.debit_minor;credit+=l.credit_minor;return {account:l.account,debit_minor:l.debit_minor,credit_minor:l.credit_minor};});
 if(!Number.isSafeInteger(debit)||!Number.isSafeInteger(credit)||debit!==credit)throw Object.assign(new Error('Journal must balance exactly'),{status:400});
 const h=hash({description:body.description,currency:body.currency,lines,reversal});
 return db.transaction(()=>{const old=db.prepare('SELECT * FROM journal_entries WHERE idempotency_key=?').get(k);if(old){if(old.payload_hash!==h)throw Object.assign(new Error('Idempotency key conflict'),{status:409});return {...old,duplicate:true};}
 if(reversal&&db.prepare('SELECT 1 FROM journal_entries WHERE reversal_of=?').get(reversal))throw Object.assign(new Error('Entry already reversed'),{status:409});
 const id=db.prepare('INSERT INTO journal_entries(idempotency_key,payload_hash,description,currency,reversal_of,created_by) VALUES(?,?,?,?,?,?)').run(k,h,body.description,body.currency,reversal,user.id).lastInsertRowid;
 for(const l of lines)db.prepare('INSERT INTO journal_lines(entry_id,account,debit_minor,credit_minor) VALUES(?,?,?,?)').run(id,l.account,l.debit_minor,l.credit_minor);
 db.prepare('INSERT INTO journal_seals(entry_id) VALUES(?)').run(id);
 return {...db.prepare('SELECT * FROM journal_entries WHERE id=?').get(id),lines};}).immediate();
}
r.post('/ledger/entries',wrap((req,res)=>res.status(201).json(journal(req.body||{},req.user,key(req)))));
r.get('/ledger/entries',wrap((req,res)=>res.json(db.prepare('SELECT * FROM journal_entries ORDER BY id DESC LIMIT 100').all().map(e=>({...e,lines:db.prepare('SELECT account,debit_minor,credit_minor FROM journal_lines WHERE entry_id=?').all(e.id)})))));
r.post('/ledger/entries/:id/reverse',wrap((req,res)=>{const e=db.prepare('SELECT * FROM journal_entries WHERE id=?').get(+req.params.id);if(!e)return res.status(404).json({error:'Entry not found'});const lines=db.prepare('SELECT account,credit_minor AS debit_minor,debit_minor AS credit_minor FROM journal_lines WHERE entry_id=?').all(e.id);res.status(201).json(journal({description:'Reversal: '+e.id,currency:e.currency,lines},req.user,key(req),e.id));}));
r.get('/finance/audit',wrap((req,res)=>res.json(db.prepare("SELECT id,user_id,user_name,method,path,status,action,at,detail FROM audit_log WHERE action LIKE 'Finance %' AND status<>0 ORDER BY id DESC LIMIT 100").all().map(row=>({...row,detail:JSON.parse(row.detail||'{}')})))));
r.get('/ops/status',wrap((req,res)=>{const check=db.prepare('PRAGMA quick_check').get();res.json({database:check.quick_check==='ok'?'ok':'error',jobs:db.prepare('SELECT status,COUNT(*) count FROM jobs GROUP BY status').all(),oldest_queued_at:db.prepare("SELECT MIN(created_at) at FROM jobs WHERE status='queued'").get().at,failed_portal_events:db.prepare("SELECT COUNT(*) n FROM portal_events WHERE status='error'").get().n,version:'3.1.0',capabilities:require('../features').forUser(req.user)});}));
module.exports=r;
