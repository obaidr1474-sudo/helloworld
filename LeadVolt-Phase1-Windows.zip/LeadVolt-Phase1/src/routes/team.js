const r = require('express').Router();
const bcrypt = require('bcryptjs');
const db = require('../db');
const { wrap, bad, isManager } = require('../util');
// GET /api/team  -> members with lead stats and target progress
r.get('/', wrap((req, res) => {
  const rows = db.prepare(`SELECT u.id,u.name,u.email,u.role,u.initials,u.monthly_target,
    (SELECT COUNT(*) FROM leads l WHERE l.agent_id=u.id AND l.is_deleted=0) leads,
    (SELECT COUNT(*) FROM leads l WHERE l.agent_id=u.id AND l.status IN ('Booked','Invoiced')) booked
    FROM users u WHERE u.active=1 ORDER BY u.id`).all();
  res.json(rows.map(u => ({ ...u, conversion: u.leads ? +(u.booked / u.leads * 100).toFixed(1) : 0, target_progress: Math.min(100, Math.round(u.booked / (u.monthly_target || 1) * 100)) })));
}));
// POST /api/team/invite { name, email, role, access }  (manager only). Returns a one-time password to share.
r.post('/invite', wrap((req, res) => {
  if (req.user.role_name !== 'Admin') return res.status(403).json({ error: 'Only managers can invite people' });
  const { name, email, role = 'Agent', access = 'Own leads only', role_name = 'SalesExecutive' } = req.body || {};
  if (!db.prepare('SELECT 1 FROM roles WHERE name=?').get(role_name)) return bad(res, 'Unknown role');
  if (typeof name!=='string'||!name.trim()||name.length>200) return bad(res, 'Enter a name up to 200 characters');
  if (typeof email!=='string'||email.length>254||! /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email.trim())) return bad(res, 'Enter a valid email address');
  if(typeof role!=='string'||role.length>80||!['Own leads only','Team leads','All leads'].includes(access))return bad(res,'Invalid role label or access scope');
  const address=email.trim().toLowerCase();
  if (db.prepare('SELECT 1 FROM users WHERE lower(email)=?').get(address)) return bad(res, 'Someone with that email is already on the team');
  const temp = require('crypto').randomBytes(18).toString('base64url');
  const i = db.prepare('INSERT INTO users (name,email,password_hash,role,role_name,access,initials) VALUES (?,?,?,?,?,?,?)').run(name.trim(), address, bcrypt.hashSync(temp, 12), role, role_name, access, name.trim().split(/\s+/).map(w => w[0]).join('').slice(0, 2).toUpperCase());
  db.prepare('UPDATE users SET password_reset_required=1 WHERE id=?').run(i.lastInsertRowid);
  res.status(201).json({ id: i.lastInsertRowid, temporary_password: temp });
}));
module.exports = r;
