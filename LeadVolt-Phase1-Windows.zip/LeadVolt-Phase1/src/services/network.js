// Restrict recording fetches; pin DNS answers and preserve TLS verification.
const dns=require('dns').promises,http=require('http'),https=require('https'),ipaddr=require('ipaddr.js');
async function safeFetch(input,options={}){
 const url=new URL(input);const test=process.env.NODE_ENV==='test';
 const hosts=(process.env.RECORDING_ALLOWED_HOSTS||'').split(',').map(x=>x.trim().toLowerCase()).filter(Boolean);
 if(url.username||url.password||url.hash||(!test&&url.protocol!=='https:')||(test&&!['https:','http:'].includes(url.protocol)))throw new Error('Unsupported recording URL');
 if(!test&&(!hosts.includes(url.hostname.toLowerCase())||(url.port&&url.port!=='443')))throw new Error('Recording host is not approved');
 const addresses=await dns.lookup(url.hostname,{all:true});
 if(!addresses.length||(!test&&addresses.some(x=>ipaddr.process(x.address).range()!=='unicast')))throw new Error('Private or reserved recording destination blocked');
 const address=addresses[0],limit=60*1048576;
 return new Promise((resolve,reject)=>{
  const transport=url.protocol==='https:'?https:http;
  const req=transport.get(url,{headers:options.headers||{},lookup:(name,opts,cb)=>opts.all?cb(null,[address]):cb(null,address.address,address.family)},res=>{
   if(![200,206].includes(res.statusCode)){res.resume();reject(new Error('Recording server rejected request or redirected'));return;}
   if(Number(res.headers['content-length'])>limit){res.destroy();reject(new Error('Recording exceeds 60 MB'));return;}
   let size=0;const chunks=[];
   res.on('data',chunk=>{size+=chunk.length;if(size>limit){res.destroy(new Error('Recording exceeds 60 MB'));return;}chunks.push(chunk);});
   res.on('end',()=>resolve(new Response(Buffer.concat(chunks),{status:res.statusCode,headers:Object.fromEntries(Object.entries(res.headers).filter(([,v])=>typeof v==='string'))})));res.on('error',reject);
  });
  const deadline=setTimeout(()=>req.destroy(new Error('Recording request timed out')),30000);deadline.unref();req.on('close',()=>clearTimeout(deadline));req.on('error',reject);
 });
}
module.exports={safeFetch};
