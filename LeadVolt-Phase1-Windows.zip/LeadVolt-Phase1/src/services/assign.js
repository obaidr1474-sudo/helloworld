// Lead routing: ad owner first, then the round robin. Also manual assign (which teaches the CRM the ad owner) and shuffle.
const db = require('../db');
const { getSetting } = require('../util');
const { notify, notifyManagers } = require('./notify');
const act = (lead, user, kind, text) => db.prepare('INSERT INTO activities (lead_id,user_id,kind,text) VALUES (?,?,?,?)').run(lead, user, kind, text);
// Round robin: the active agent in the pool assigned least recently. Call inside an IMMEDIATE transaction.
function nextAgent(exclude = []) {
  const cfg = getSetting('assignment', {});
  if (cfg.auto === false) return null;
  let pool = (cfg.pool && cfg.pool.length) ? cfg.pool : db.prepare("SELECT id FROM users WHERE active=1 AND COALESCE(role_name,'') NOT IN ('Admin','HR','ListingManager') AND role NOT LIKE '%Manager%'").all().map(x => x.id);
  pool = pool.filter(id => !exclude.includes(id)); if (!pool.length) return null;
  const a = db.prepare(`SELECT id FROM users WHERE active=1 AND id IN (${pool.map(() => '?').join(',')}) ORDER BY last_assigned_at IS NOT NULL, last_assigned_at, id LIMIT 1`).get(...pool);
  if (!a) return null;
  db.prepare("UPDATE users SET last_assigned_at=strftime('%Y-%m-%d %H:%M:%f','now') WHERE id=?").run(a.id);
  return a.id;
}
// Decide who gets a new portal lead. Returns { agent_id, why }.
function route({ portal, ad_ref }) {
  if (portal && ad_ref) {
    const ad = db.prepare('SELECT * FROM ad_refs WHERE portal=? AND ref=?').get(portal, String(ad_ref));
    if (ad && ad.owner_id) { const u = db.prepare('SELECT active FROM users WHERE id=?').get(ad.owner_id); if (u && u.active) return { agent_id: ad.owner_id, why: 'ad_owner' }; }
    const rule = getSetting('listing', { unknown_ref: 'unassigned' });
    if (rule.unknown_ref !== 'round_robin') return { agent_id: null, why: 'unknown_ad' }; // the rule you asked for: first lead on a new ad waits for an admin
  }
  return { agent_id: nextAgent(), why: 'round_robin' };
}
// Upsert the ad and bump its counter.
function touchAd(portal, ref, extra = {}) {
  if (!portal || !ref) return null;
  db.prepare(`INSERT INTO ad_refs (portal,ref,listing,posted_under,leads_count,last_lead_at) VALUES (?,?,?,?,1,datetime('now'))
    ON CONFLICT(portal,ref) DO UPDATE SET leads_count=leads_count+1, last_lead_at=datetime('now'), listing=COALESCE(ad_refs.listing,excluded.listing), posted_under=COALESCE(excluded.posted_under,ad_refs.posted_under)`).run(portal, String(ref), extra.listing || null, extra.posted_under || null);
  return db.prepare('SELECT * FROM ad_refs WHERE portal=? AND ref=?').get(portal, String(ref));
}
// Manual assignment. If the lead came from an ad with no owner yet, that agent becomes the owner (unless learn === false).
function assign(leadId, agentId, byUser, { learn = true, reason = null } = {}) {
  return db.transaction(() => {
    const l = db.prepare('SELECT * FROM leads WHERE id=?').get(leadId); if (!l) throw Object.assign(new Error('Lead not found'), { status: 404 });
    if (agentId) { const u = db.prepare('SELECT id,name,active FROM users WHERE id=?').get(agentId); if (!u || !u.active) throw Object.assign(new Error('That user is not active'), { status: 400 }); }
    db.prepare("UPDATE leads SET agent_id=?, assigned_at=CASE WHEN ? IS NULL THEN NULL ELSE datetime('now') END, first_opened_at=NULL WHERE id=?").run(agentId || null, agentId || null, leadId);
    const to = agentId ? db.prepare('SELECT name FROM users WHERE id=?').get(agentId).name : 'Unassigned';
    act(leadId, byUser, 'assign', `Assigned to ${to}${reason ? ' — ' + reason : ''}`);
    let learned = null;
    const learnOn = getSetting('listing', {}).learn !== false;
    if (agentId && learn && learnOn && l.portal && l.ad_ref) {
      const ad = db.prepare('SELECT * FROM ad_refs WHERE portal=? AND ref=?').get(l.portal, l.ad_ref);
      if (ad && !ad.owner_id) { db.prepare("UPDATE ad_refs SET owner_id=?, how='learned' WHERE id=?").run(agentId, ad.id); learned = { portal: l.portal, ref: l.ad_ref, owner: to }; }
    }
    return { lead_id: leadId, agent: to, learned };
  }).immediate();
}
function shuffle(leadId, toId, byUser, reason, auto = false) {
  const l = db.prepare('SELECT * FROM leads WHERE id=?').get(leadId); if (!l) throw Object.assign(new Error('Lead not found'), { status: 404 });
  if (!toId) toId = db.transaction(() => nextAgent([l.agent_id].filter(Boolean))).immediate();
  if (!toId) throw Object.assign(new Error('No other agent is available'), { status: 400 });
  if (toId === l.agent_id) throw Object.assign(new Error('The lead is already with that agent'), { status: 400 });
  const r = assign(leadId, toId, byUser, { learn: false, reason: (auto ? 'Auto shuffle: ' : 'Shuffled: ') + (reason || 'no reason given') });
  db.prepare('INSERT INTO shuffles (lead_id,from_id,to_id,by_id,reason,auto) VALUES (?,?,?,?,?,?)').run(leadId, l.agent_id, toId, byUser, reason || null, auto ? 1 : 0);
  return { ...r, from_id: l.agent_id, to_id: toId };
}
async function announce(lead, why, dedupe_key=null) {
  if (lead.agent_id) return notify(lead.agent_id, { dedupe_key, title: `New ${lead.portal || lead.source || ''} lead: ${lead.name}`.replace('  ', ' '), body: [lead.ad_ref && 'Ref ' + lead.ad_ref, lead.budget, lead.phone].filter(Boolean).join(' · '), lead_id: lead.id });
  return notifyManagers({ dedupe_key, title: `Unassigned lead: ${lead.name}`, body: why === 'unknown_ad' ? `New ad Ref ${lead.ad_ref} on ${lead.portal}. Assign it once and future leads on this ad follow.` : 'No agent available', lead_id: lead.id, kind: 'unassigned' });
}
module.exports = { nextAgent, route, touchAd, assign, shuffle, announce };
