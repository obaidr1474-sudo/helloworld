const db=require('../db');
function take(key,{capacity=120,perSecond=2,cost=1,now=Date.now()}={}){
 return db.transaction(()=>{const old=db.prepare('SELECT * FROM rate_buckets WHERE key=?').get(key),tokens=old?Math.min(capacity,old.tokens+Math.max(0,now-old.updated_at)/1000*perSecond):capacity;
 const allowed=tokens>=cost;db.prepare('INSERT INTO rate_buckets VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET tokens=excluded.tokens,updated_at=excluded.updated_at').run(key,allowed?tokens-cost:tokens,now);
 return {allowed,retryAfter:allowed?0:Math.max(1,Math.ceil((cost-tokens)/perSecond))};
 }).immediate();
}
function middleware(req,res,next){if(['GET','HEAD','OPTIONS'].includes(req.method))return next();const r=take('user:'+req.user.id);if(!r.allowed){res.set('Retry-After',String(r.retryAfter));return res.status(429).json({error:'Too many writes; retry after the indicated delay'});}next();}
module.exports={take,middleware};
