const db=require('../db'),P=require('../integrations/portals'),A=require('./assign'),J=require('./jobs'),crypto=require('crypto');
const canonical=o=>Array.isArray(o)?o.map(canonical):o&&typeof o==='object'?Object.fromEntries(Object.keys(o).sort().map(k=>[k,canonical(o[k])])):o;
const hash=o=>crypto.createHash('sha256').update(JSON.stringify(canonical(o))).digest('hex');
function ingest(portal,body){
 // Keep request-level payload durable before returning 202. Per-event dedupe remains in portal_events.
 const key='webhook:'+portal+':'+hash(body);
 return J.enqueue('webhook',key,{portal,body:canonical(body)});
}
J.register('webhook',async({portal,body})=>{
 const out=[];
 for(const ev of P.normalize(portal,body)){
  const r=P.processEvent(portal,ev);out.push({external_id:ev.external_id,status:r.status,lead_id:r.lead_id||null,error:r.error});
  // Notification intent is persisted in the same transaction as lead creation (see portals.js).
 }
 return {results:out};
});
J.register('announce',async({lead,why},job)=>{await A.announce(lead,why,job.dedupe_key);return {ok:true};});
module.exports={ingest,hash,canonical};
