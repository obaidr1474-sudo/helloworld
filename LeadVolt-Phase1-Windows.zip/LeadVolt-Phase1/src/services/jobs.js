// SQLite-backed durable queue for a SINGLE company/node. Claim leases survive restarts.
// Do not run this deployment on a network filesystem or across multiple hosts.
const db=require('../db'),crypto=require('crypto');
const handlers=new Map();let timer,busy=false;
function register(type,fn){handlers.set(type,fn);}
function enqueue(type,key,payload,owner=null,maxAttempts=5){
 const encoded=JSON.stringify(payload);
 const old=db.prepare('SELECT * FROM jobs WHERE dedupe_key=?').get(key);
 if(old){if(old.payload!==encoded||old.type!==type||old.owner_id!==owner)throw Object.assign(new Error('Idempotency key already used for a different request'),{status:409});return old;}
 if(db.prepare("SELECT COUNT(*) n FROM jobs WHERE status IN ('queued','running')").get().n>=10000)throw Object.assign(new Error('Queue is full; retry later'),{status:503});
 if(owner!==null&&db.prepare("SELECT COUNT(*) n FROM jobs WHERE owner_id=? AND status IN ('queued','running')").get(owner).n>=10)throw Object.assign(new Error('At most 10 pending jobs per user'),{status:429});
 const id=db.prepare('INSERT INTO jobs(type,dedupe_key,payload,owner_id,available_at,max_attempts) VALUES(?,?,?,?,?,?)').run(type,key,encoded,owner,Date.now(),maxAttempts).lastInsertRowid;
 return db.prepare('SELECT * FROM jobs WHERE id=?').get(id);
}
function claim(){return db.transaction(()=>{
 const now=Date.now();
 db.prepare("UPDATE jobs SET status='dead',error='Retry limit reached after expired lease',lease_until=NULL,lease_token=NULL WHERE status='running' AND lease_until<=? AND attempts>=max_attempts").run(now);
 const j=db.prepare("SELECT * FROM jobs WHERE (status='queued' AND available_at<=? OR status='running' AND lease_until<=?) AND attempts<max_attempts ORDER BY id LIMIT 1").get(now,now);
 if(!j)return null;const token=crypto.randomUUID();
 db.prepare("UPDATE jobs SET status='running',attempts=attempts+1,lease_until=?,lease_token=? WHERE id=?").run(now+120000,token,j.id);
 return {...j,attempts:j.attempts+1,lease_token:token};
 }).immediate();}
async function runOne(){const j=claim();if(!j)return false;
 const heartbeat=setInterval(()=>db.prepare("UPDATE jobs SET lease_until=? WHERE id=? AND lease_token=? AND status='running'").run(Date.now()+120000,j.id,j.lease_token),30000);heartbeat.unref();
 try{const fn=handlers.get(j.type);if(!fn)throw new Error('Unsupported job type');const result=await fn(JSON.parse(j.payload),j);
 db.prepare("UPDATE jobs SET status='done',result=?,error=NULL,lease_until=NULL,lease_token=NULL,finished_at=datetime('now') WHERE id=? AND lease_token=?").run(JSON.stringify(result??null),j.id,j.lease_token);
 }catch(e){const dead=j.attempts>=j.max_attempts;db.prepare("UPDATE jobs SET status=?,error=?,available_at=?,lease_until=NULL,lease_token=NULL WHERE id=? AND lease_token=?").run(dead?'dead':'queued',String(e.message).slice(0,300),Date.now()+Math.min(3600000,1000*2**j.attempts),j.id,j.lease_token);
 }finally{clearInterval(heartbeat);}return true;
}
async function drain(limit=20){if(busy)return 0;busy=true;let n=0;try{while(n<limit&&await runOne())n++;}finally{busy=false;}return n;}
function start(){if(timer)return;timer=setInterval(()=>drain().catch(e=>console.error('queue',e.message)),500);timer.unref();drain().catch(e=>console.error('queue',e.message));}
function stop(){clearInterval(timer);timer=null;}
module.exports={register,enqueue,claim,runOne,drain,start,stop};
