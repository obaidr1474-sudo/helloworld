// Reliable notifications: every alert is stored, pushed to every device the user has (Web Push),
// streamed live to open tabs (SSE), and tracked queued -> sent -> delivered -> seen.
const webpush = require('web-push');
const db = require('../db');
const { getSetting, putSetting } = require('../util');
let vapid = null;
function keys() {
  if (vapid) return vapid;
  if (process.env.VAPID_PUBLIC && process.env.VAPID_PRIVATE) vapid = { publicKey: process.env.VAPID_PUBLIC, privateKey: process.env.VAPID_PRIVATE };
  else { vapid = getSetting('vapid', null); if (!vapid) { vapid = webpush.generateVAPIDKeys(); putSetting('vapid', vapid); } }
  webpush.setVapidDetails(process.env.VAPID_SUBJECT || 'mailto:admin@leadvolt.app', vapid.publicKey, vapid.privateKey);
  return vapid;
}
const streams = new Map(); // userId -> Set(res)
function addStream(userId, res) { if (!streams.has(userId)) streams.set(userId, new Set()); streams.get(userId).add(res); res.on('close', () => streams.get(userId)?.delete(res)); }
function sse(userId, event, data) { const s = streams.get(userId); if (!s || !s.size) return 0; const msg = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`; s.forEach(r => r.write(msg)); return s.size; }
const onlineCount = (userId) => (streams.get(userId)?.size || 0);
let pushImpl = (sub, payload) => webpush.sendNotification(sub, payload, { TTL: 3600, urgency: 'high' });
const setPushImpl = (fn) => { pushImpl = fn; }; // tests replace the network call
async function deliver(n) {
  const channels = [];
  if (sse(n.user_id, 'notification', n)) channels.push('live');
  const subs = db.prepare('SELECT * FROM push_subs WHERE user_id=?').all(n.user_id);
  if (subs.length) keys();
  const ackTok = require('crypto').createHmac('sha256', process.env.JWT_SECRET || 'dev-secret-change-me').update(`ack:${n.id}:${n.user_id}`).digest('hex').slice(0, 32);
  const payload = JSON.stringify({ id: n.id, u: n.user_id, t: ackTok, title: n.title, body: n.body, lead_id: n.lead_id, kind: n.kind, url: n.lead_id ? `/#lead-${n.lead_id}` : '/' });
  await Promise.all(subs.map(async s => {
    try { await pushImpl({ endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } }, payload); channels.push('push'); db.prepare("UPDATE push_subs SET last_ok_at=datetime('now'), fails=0 WHERE id=?").run(s.id); }
    catch (e) { if (e.statusCode === 404 || e.statusCode === 410) db.prepare('DELETE FROM push_subs WHERE id=?').run(s.id); else db.prepare('UPDATE push_subs SET fails=fails+1 WHERE id=?').run(s.id); }
  }));
  const ok = channels.length > 0;
  db.prepare(`UPDATE notifications SET attempts=attempts+1, channels=?, status=CASE WHEN status IN ('delivered','seen') THEN status WHEN ? THEN 'sent' ELSE 'failed' END, sent_at=COALESCE(sent_at, CASE WHEN ? THEN datetime('now') END) WHERE id=?`).run([...new Set(channels)].join(','), ok ? 1 : 0, ok ? 1 : 0, n.id);
  return channels;
}
function persist(userId,{title,body='',lead_id=null,kind='lead',dedupe_key=null}){
 if(!userId)return null;
 return db.transaction(()=>{
 const key=String(userId)+':'+(dedupe_key||require('crypto').randomUUID());
 const old=db.prepare('SELECT * FROM notifications WHERE dedupe_key=?').get(key);if(old)return old;
 const id=db.prepare('INSERT INTO notifications(user_id,lead_id,kind,title,body,dedupe_key) VALUES(?,?,?,?,?,?)').run(userId,lead_id,kind,title,body,key).lastInsertRowid;
 if(!(process.env.NODE_ENV==='test'&&process.env.WEBHOOK_SYNC==='1'))require('./jobs').enqueue('notification','notification:'+id,{id});
 return db.prepare('SELECT * FROM notifications WHERE id=?').get(id);
 }).immediate();
}
async function notify(userId,msg){const n=persist(userId,msg);if(!n)return null;if(process.env.NODE_ENV==='test'&&process.env.WEBHOOK_SYNC==='1')await deliver(n);return db.prepare('SELECT * FROM notifications WHERE id=?').get(n.id);}
require('./jobs').register('notification',async({id})=>{
 const n=db.prepare('SELECT * FROM notifications WHERE id=?').get(id);if(!n||['sent','delivered','seen'].includes(n.status))return {already_sent:true};
 const channels=await deliver(n);const devices=db.prepare('SELECT COUNT(*) n FROM push_subs WHERE user_id=?').get(n.user_id).n;
 if(!channels.length&&devices)throw new Error('Push provider delivery failed');
 return {channels,no_registered_device:!devices};
});
const managers = () => db.prepare("SELECT id FROM users WHERE active=1 AND (role_name IN ('Admin','Manager') )").all().map(x => x.id);
async function notifyManagers(msg) { return Promise.all(managers().map(id => notify(id, msg))); }
function mark(id, userId, status) {
  const col = status === 'seen' ? 'seen_at' : 'delivered_at';
  const r = db.prepare(`UPDATE notifications SET status=CASE WHEN status='seen' THEN 'seen' ELSE ? END, ${col}=COALESCE(${col}, datetime('now')), delivered_at=COALESCE(delivered_at, datetime('now')) WHERE id=? AND user_id=?`).run(status, id, userId);
  return r.changes > 0;
}
module.exports = { persist, notify, notifyManagers, deliver, mark, addStream, sse, onlineCount, keys, setPushImpl, managers };
