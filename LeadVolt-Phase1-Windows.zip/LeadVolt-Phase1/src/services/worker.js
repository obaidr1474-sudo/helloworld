// Background jobs (every minute): resend unseen alerts, escalate untouched leads, auto-shuffle, copy recordings to our storage.
const fs = require('fs'), path = require('path');
const db = require('../db');
const { getSetting } = require('../util');
const N = require('./notify');
const A = require('./assign');
const STORE = process.env.STORAGE_DIR || path.join(__dirname, '..', '..', 'storage');
const mins = (col, m) => `${col} < datetime('now','-${Math.max(1, +m | 0)} minutes')`;
async function tick() {
  const esc = { resend_min: 5, escalate_min: 15, ...getSetting('escalation', {}) };
  const asg = getSetting('assignment', {});
  const out = { resent: 0, escalated: 0, shuffled: 0, unassigned_reminders: 0, recordings_saved: 0 };
  // 1) Resend lead alerts nobody has seen (max 3 tries)
  for (const n of db.prepare(`SELECT * FROM notifications WHERE kind IN ('lead','unassigned') AND status IN ('queued','sent','failed') AND attempts<3 AND ${mins('created_at', esc.resend_min * 1)} AND (sent_at IS NULL OR ${mins('sent_at', esc.resend_min)}) LIMIT 200`).all()) {
    db.prepare("UPDATE notifications SET sent_at=datetime('now') WHERE id=?").run(n.id); await N.deliver(n); out.resent++;
  }
  // 2) Assigned but not opened -> alert managers once
  for (const l of db.prepare(`SELECT l.*, u.name agent FROM leads l JOIN users u ON u.id=l.agent_id WHERE l.is_deleted=0 AND l.status='New' AND l.first_opened_at IS NULL AND l.assigned_at IS NOT NULL AND ${mins('l.assigned_at', esc.escalate_min)}
      AND NOT EXISTS (SELECT 1 FROM notifications n WHERE n.lead_id=l.id AND n.kind='escalation' AND n.created_at>=l.assigned_at) LIMIT 100`).all()) {
    await N.notifyManagers({ title: `${l.agent} hasn't opened ${l.name}`, body: `Assigned ${esc.escalate_min}+ minutes ago. Open it or shuffle it.`, lead_id: l.id, kind: 'escalation' }); out.escalated++;
  }
  // 3) Auto shuffle (if switched on): still not opened or contacted after N minutes. At most 2 auto shuffles per lead.
  if (asg.reassign) {
    const m = +asg.minutes || 30;
    for (const l of db.prepare(`SELECT l.* FROM leads l WHERE l.is_deleted=0 AND l.status='New' AND l.agent_id IS NOT NULL AND l.first_opened_at IS NULL AND l.first_contact_at IS NULL AND ${mins('l.assigned_at', m)}
        AND (SELECT COUNT(*) FROM shuffles s WHERE s.lead_id=l.id AND s.auto=1) < 2 LIMIT 50`).all()) {
      try { const r = A.shuffle(l.id, null, null, `not opened within ${m} minutes`, true); await N.notify(r.to_id, { title: `Lead moved to you: ${l.name}`, body: `Not opened by the previous agent in ${m} min.`, lead_id: l.id }); await N.notify(r.from_id, { title: `${l.name} was reassigned`, body: `You didn't open it within ${m} minutes.`, lead_id: l.id, kind: 'info' }); out.shuffled++; } catch (e) { /* no one available */ }
    }
  }
  // 4) Unassigned leads waiting 10+ minutes -> remind managers once an hour
  const un = db.prepare(`SELECT COUNT(*) c FROM leads WHERE is_deleted=0 AND agent_id IS NULL AND ${mins('created_at', 10)}`).get().c;
  if (un && !db.prepare("SELECT 1 FROM notifications WHERE kind='unassigned_digest' AND created_at>datetime('now','-60 minutes')").get()) { await N.notifyManagers({ title: `${un} unassigned lead${un > 1 ? 's' : ''} waiting`, body: 'Assign them so future leads on those ads route automatically.', kind: 'unassigned_digest' }); out.unassigned_reminders++; }
  // 5) Copy recordings into our own storage (portal links can expire)
  if (getSetting('integrations_cfg', {}).store_recordings !== false) {
    fs.mkdirSync(path.join(STORE, 'recordings'), { recursive: true });
    for (const rec of db.prepare('SELECT * FROM recordings WHERE stored_path IS NULL AND source_url IS NOT NULL AND created_at>datetime(\'now\',\'-7 days\') LIMIT 10').all()) {
      try {
        const res = await require('./network').safeFetch(rec.source_url); if (!res.ok) continue;
        const len = +res.headers.get('content-length') || 0; if (len > 60 * 1048576) continue;
        const buf = Buffer.from(await res.arrayBuffer()); if (buf.length > 60 * 1048576) continue;
        const ext = /wav/.test(res.headers.get('content-type') || '') ? 'wav' : 'mp3', file = path.join(STORE, 'recordings', `${rec.id}.${ext}`);
        fs.writeFileSync(file, buf); db.prepare('UPDATE recordings SET stored_path=? WHERE id=?').run(file, rec.id); out.recordings_saved++;
      } catch (e) { /* try again next minute */ }
    }
  }
  return out;
}
let timer = null, running = false;
function start(ms = 60000) { if (timer) return; timer = setInterval(async () => { if (running) return; running = true; try { await tick(); } catch (e) { console.error('worker', e); } finally { running = false; } }, ms); timer.unref(); }
module.exports = { tick, start };
