const db=require('../db'),J=require('./jobs'),{loadUser,can}=require('../util');
function parseCSV(t){if(typeof t!=='string'||Buffer.byteLength(t)>2*1024*1024)throw Object.assign(new Error('CSV must be at most 2 MB'),{status:400});
 const rows=[];let row=[],cur='',quoted=false;
 for(let i=0;i<t.length;i++){const c=t[i];if(quoted){if(c==='"'){if(t[i+1]==='"'){cur+='"';i++;}else quoted=false;}else cur+=c;}else if(c==='"'){if(cur)throw Object.assign(new Error('Invalid CSV quoting'),{status:400});quoted=true;}else if(c===','){row.push(cur);cur='';}else if(c==='\r'||c==='\n'){if(c==='\r'&&t[i+1]==='\n')i++;row.push(cur);if(row.some(x=>x.trim()))rows.push(row);row=[];cur='';}else cur+=c;
 if(rows.length>10000)throw Object.assign(new Error('Maximum 10,000 rows per import'),{status:400});}
 if(quoted)throw Object.assign(new Error('Unclosed CSV quote'),{status:400});row.push(cur);if(row.some(x=>x.trim()))rows.push(row);return rows;
}
function prepare(body){const all=parseCSV(body.csv);if(all.length<2)throw Object.assign(new Error('CSV needs a header and data'),{status:400});
 const headers=all[0].map(x=>x.trim().toLowerCase());const mapping=body.mapping||headers.map(h=>/^(name|phone|email|source|budget)$/.test(h)?h:null);
 if(!Array.isArray(mapping)||mapping.length!==headers.length||mapping.some(x=>x!==null&&!['name','phone','email','source','budget'].includes(x))||new Set(mapping.filter(Boolean)).size!==mapping.filter(Boolean).length||!mapping.includes('name')||!mapping.includes('phone'))throw Object.assign(new Error('Map each column once; name and phone are required'),{status:400});
 return {rows:all.slice(1),mapping,agent_id:body.agent_id??null,file_name:String(body.file_name||'import.csv').slice(0,200)};
}
J.register('import',async(payload,job)=>{
 const u=loadUser(job.owner_id);if(!u||!can(u,'Data','Bulk Upload'))throw new Error('Import owner no longer has permission');
 let progress=JSON.parse(db.prepare('SELECT result FROM jobs WHERE id=?').get(job.id).result||'{"cursor":0,"added":0,"skipped":0,"errors":[]}');
 const {createLead}=require('../routes/leads');
 for(let start=progress.cursor;start<payload.rows.length;start+=100){
 db.transaction(()=>{
 for(let i=start;i<Math.min(start+100,payload.rows.length);i++){
 const row=payload.rows[i],b={agent_id:payload.agent_id??u.id};payload.mapping.forEach((k,n)=>{if(k)b[k]=row[n]||'';});
 try{createLead(b,u.id);progress.added++;}catch(e){if(e.status!==400)throw e;progress.skipped++;if(progress.errors.length<100)progress.errors.push({row:i+2,error:e.message});}
 progress.cursor=i+1;
 }
 db.prepare('UPDATE jobs SET result=? WHERE id=? AND lease_token=?').run(JSON.stringify(progress),job.id,job.lease_token);
 }).immediate();
 await new Promise(r=>setImmediate(r));
 }
 return {...progress,total:payload.rows.length};
});
module.exports={prepare,parseCSV};
