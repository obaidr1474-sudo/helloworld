// Deny by default. Route handlers also enforce record ownership and field permissions.
const {can}=require('./util');
const rules=[
 [/^\/leads(?:\/|$)/,'Leads'],[/^\/tasks(?:\/|$)/,'Tasks'],
 [/^\/(projects|units|media)(?:\/|$)/,'Projects'],[/^\/invoices(?:\/|$)/,'Invoice'],
 [/^\/imports(?:\/|$)/,'Data'],[/^\/ai(?:\/|$)/,'Leads'],[/^\/sync(?:\/|$)/,'Leads'],
 [/^\/roles(?:\/|$)/,'Roles'],[/^\/users(?:\/|$)/,'Users'],[/^\/teams(?:\/|$)/,'Teams'],
 [/^\/ad-refs(?:\/|$)/,'Listing'],[/^\/integrations(?:\/|$)/,'Integration'],
 [/^\/team(?:\/|$)/,'Users'],[/^\/audit(?:\/|$)/,'Global Settings'],
];
module.exports=(req,res,next)=>{
 const p=req.path,m=req.method,u=req.user;
 const allow=(mod,perm)=>can(u,mod,perm);
 let ok=false;
 if(p==='/deals/my-closed'&&m==='GET')ok=true;
 else if(/^\/finance(?:\/|$)/.test(p))ok=u.role_name==='Admin';
 else if(/^\/(notifications|push|stream)(\/|$)/.test(p))ok=true; // handlers scope to current user
 else if(/^\/(ops|ledger|jobs)(\/|$)/.test(p))ok=u.role_name==='Admin';
 else if(p==='/dashboard')ok=allow('Dashboard','View');
 else if(/^\/(reports|deals)(\/|$)/.test(p))ok=u.role_name==='Admin'||allow('Reports','View All Users')||allow('Reports','View Reportees');
 else if(/^\/attendance(\/|$)/.test(p))ok=u.role_name==='Admin'||m==='GET'||p==='/attendance/clock-in'||p==='/attendance/clock-out'||allow('Attendance','View All Users');
 else if(/^\/settings(\/|$)/.test(p))ok=allow('Global Settings',m==='GET'?'View':'Update')||(/^\/settings\/(portals|integrations_cfg)$/.test(p)&&allow('Integration',m==='GET'?'View':'Update'));
 else {
  const rule=rules.find(([re])=>re.test(p));
  if(rule){let perm=m==='GET'?'View':m==='DELETE'?'Delete':m==='POST'?'Create':'Update';
   if(/^\/imports/.test(p))perm=m==='GET'?'View':'Bulk Upload';
   if(/^\/ai/.test(p))perm='View';
   if(/^\/sync/.test(p))perm='Communications';
   if(/^\/invoices/.test(p)&&m==='POST')perm='Update';
   if(/^\/leads\/.+\/(notes|activity|tags|restore|assign|shuffle)$/.test(p))perm={notes:'Update Notes',activity:'Communications',tags:'Update Tags',restore:'Bulk Restore',assign:'Assign',shuffle:'Shuffle Leads'}[p.split('/').pop()];
   if(p==='/leads/bulk')perm='View';
   if(/^\/projects\/\d+\/media$/.test(p)||/^\/media\//.test(p)&&m!=='GET')perm='Update Documents';
   if(/^\/units\/[^/]+\/reserve$/.test(p))perm='Update';
   if(p==='/team/invite')perm='Create';
   if(/^\/integrations\/.+\/replay$/.test(p))perm='Update';
   if(/^\/ad-refs\//.test(p)&&m!=='GET')perm='Manage Ref IDs';
   ok=allow(rule[1],perm);
   if(/^\/leads\/\d+$/.test(p)&&m==='PATCH')ok=ok||allow('Leads','Update Lead Status')||allow('Leads','Update Basic Info');
   if(/^\/sync\/leads$/.test(p)&&m==='GET')ok=allow('Leads','View');
   if(/^\/sync\/changes$/.test(p)&&m==='POST')ok=allow('Leads','Update Notes')||allow('Leads','Update Lead Status')||allow('Leads','Update');
  } else return res.status(404).json({error:'No such endpoint'});
 }
 if(!ok)return res.status(403).json({error:'Your role does not allow this operation'});
 next();
};
