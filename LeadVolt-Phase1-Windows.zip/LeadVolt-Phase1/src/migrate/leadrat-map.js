// Converts lead records in Leadrat's export/API format (camelCase) into LeadVolt leads.
// Use it to move YOUR OWN company's leads into LeadVolt, exported in line with Leadrat's terms.
const STAGE = s => {
  s = String(s || '').toLowerCase();
  if (/book/.test(s)) return 'Booked';
  if (/invoice/.test(s)) return 'Invoiced';
  if (/site visit/.test(s)) return /done|complete/.test(s) ? 'Site Visit Done' : 'Callback';
  if (/meeting/.test(s)) return /done|complete/.test(s) ? 'Meeting Done' : 'Callback';
  if (/callback|follow/.test(s)) return 'Callback';
  if (/overdue/.test(s)) return 'Overdue';
  return 'New';
};
const str = v => (v == null || v === '' ? null : typeof v === 'object' ? (v.displayName || v.name || null) : String(v));
const num = v => (v == null || v === '' || isNaN(+v) ? null : +v);
function mapLeadratLead(p) {
  const min = num(p.lowerBudget), max = num(p.upperBudget);
  return {
    external_ref: str(p.id),
    name: str(p.name),
    phone: str(p.contactNo ?? p.contact_no),
    alternate_phone: str(p.alternateContactNo),
    landline: str(p.landLine),
    email: str(p.email),
    country_code: str(p.countryCode),
    source: str(p.leadSource ?? p.enquiry?.leadSource) || 'Leadrat import',
    sub_source: str(p.subSource),
    enquired_for: str(p.enquiredFor),
    property_type: str(p.propSubType ?? p.propertyType),
    beds: num(p.beds ?? p.noOfBHK),
    baths: num(p.baths),
    budget_min: min, budget_max: max,
    budget: max ? `AED ${(max / 1e6).toFixed(2)}M` : min ? `AED ${(min / 1e6).toFixed(2)}M` : null,
    currency: str(p.currency) || 'AED',
    community: str(p.enquiredCommunity),
    city: str(p.enquiredCity),
    country: str(p.enquiredCountry),
    referral_name: str(p.referralName), referral_phone: str(p.referralContactNo), referral_email: str(p.referralEmail),
    notes: str(p.notes),
    status: STAGE(str(p.status) || str(p.leadStatus) || str(p.statusName)),
    agent_name: str(p.assignedUser ?? p.assignTo),
  };
}
module.exports = { mapLeadratLead, STAGE };
