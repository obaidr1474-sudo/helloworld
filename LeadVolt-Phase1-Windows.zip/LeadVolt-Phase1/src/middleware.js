// Security headers, login rate limiting and the audit trail for every change.
const db = require('./db');
function security(req, res, next) {
  // Report-only rollout; inline allowances preserve the existing theme/scripts.
  res.set('Content-Security-Policy-Report-Only', "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: blob:; media-src 'self' blob:; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'self'; form-action 'self'");
  res.set({ 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'SAMEORIGIN', 'Referrer-Policy': 'strict-origin-when-cross-origin', 'Permissions-Policy': 'geolocation=(self), camera=(self), microphone=()', 'Cross-Origin-Opener-Policy': 'same-origin' });
  if (req.secure || req.get('x-forwarded-proto') === 'https') res.set('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  next();
}
// 8 failed logins per email+IP in 15 minutes -> locked for the rest of the window
const WINDOW = 15 * 60 * 1000, MAX = 8;
const key = req => (String((req.body || {}).email || '').trim().toLowerCase().slice(0,254)) + '|' + req.ip;
function loginLimit(req, res, next) {
  const k = key(req), row = db.prepare('SELECT * FROM login_attempts WHERE key=?').get(k);
  if (row && Date.now() - row.first_at < WINDOW && row.count >= MAX) { res.set('Retry-After', Math.ceil((WINDOW - (Date.now() - row.first_at)) / 1000)); return res.status(429).json({ error: 'Too many failed sign-ins. Try again in 15 minutes.' }); }
  res.on('finish', () => {
    if (res.statusCode === 401) { if (!row || Date.now() - row.first_at >= WINDOW) db.prepare('INSERT INTO login_attempts (key,count,first_at) VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET count=1, first_at=excluded.first_at').run(k, Date.now()); else db.prepare('UPDATE login_attempts SET count=count+1 WHERE key=?').run(k); }
    else if (res.statusCode === 200) db.prepare('DELETE FROM login_attempts WHERE key=?').run(k);
  });
  next();
}
const SECRET_KEYS = /pass|secret|token|key|auth|p256dh|signature|^current$|^next$/i;
const redact = (o, d = 0) => { if (!o || typeof o !== 'object' || d > 4) return o; if (Array.isArray(o)) return o.slice(0, 50).map(x => redact(x, d + 1)); const r = {}; for (const [k, v] of Object.entries(o)) r[k] = SECRET_KEYS.test(k) ? '•••' : (typeof v === 'string' && v.length > 300 ? v.slice(0, 300) + '…' : redact(v, d + 1)); return r; };
const ACTIONS = [[/^POST \/api\/auth\/login/, 'Signed in'], [/^POST \/api\/leads\/bulk/, 'Bulk lead update'], [/^POST \/api\/leads\/\d+\/assign/, 'Lead assigned'], [/^POST \/api\/leads\/\d+\/shuffle/, 'Lead shuffled'], [/^PUT \/api\/leads\/\d+\/tags/, 'Lead tags changed'], [/^POST \/api\/leads\/\d+\/notes/, 'Note added'], [/^POST \/api\/leads$/, 'Lead created'], [/^PATCH \/api\/leads\/\d+/, 'Lead updated'], [/^DELETE \/api\/leads/, 'Lead deleted'],
  [/^PUT \/api\/settings\/(\w+)/, m => 'Settings changed: ' + m[1]], [/^(PUT|POST|DELETE) \/api\/roles/, 'Role changed'], [/^PATCH \/api\/users/, 'User changed'], [/^PATCH \/api\/ad-refs/, 'Ad owner set'], [/^POST \/api\/attendance\/clock-in/, 'Clocked in'], [/^POST \/api\/attendance\/clock-out/, 'Clocked out'], [/^POST \/api\/attendance\/mark/, 'Attendance marked'],
  [/^POST \/api\/projects/, 'Project created / media uploaded'], [/^POST \/api\/tasks/, 'Task created'], [/^PATCH \/api\/tasks/, 'Task updated'], [/^POST \/api\/imports/, 'Import'], [/^POST \/api\/invoices/, 'Invoice']];
function audit(req, res, next) {
  if (require('./features').isFinancePath(req.path.replace(/^\/api/i,'')))return next();
  if (req.method === 'GET' || req.method === 'OPTIONS' || req.path.includes('/webhook') || req.path.endsWith('/ack') || req.path.endsWith('/delivered') || req.path.endsWith('/seen')) return next();
  const started = Date.now();
  res.on('finish', () => {
    const sig = `${req.method} ${req.originalUrl.split('?')[0]}`; let action = sig;
    for (const [re, a] of ACTIONS) { const m = sig.match(re); if (m) { action = typeof a === 'function' ? a(m) : a; break; } }
    if (res.statusCode >= 400) action += ` (failed ${res.statusCode})`;
    const u = req.user || (res.locals.loginUser || null);
    try { db.prepare('INSERT INTO audit_log (user_id,user_name,method,path,status,action,detail,ip) VALUES (?,?,?,?,?,?,?,?)').run(u ? u.id : null, u ? u.name : (req.body && req.body.email) || null, req.method, req.originalUrl.split('?')[0], res.statusCode, action, JSON.stringify({ body: req.is('application/json') ? redact(req.body) : undefined, ms: Date.now() - started }), req.ip); } catch (e) { console.error('audit', e.message); }
  });
  next();
}
module.exports = { security, loginLimit, audit, redact };
