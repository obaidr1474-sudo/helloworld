// LeadVolt CRM API server
const fs = require('fs'), path = require('path');
require('./config');
const express = require('express');
const cors = require('cors');
const db = require('./db');
const { auth } = require('./util');
const { security, audit } = require('./middleware');
if (!db.prepare('SELECT COUNT(*) c FROM users').get().c && process.env.NODE_ENV !== 'production') require('./seed');

const app = express();
app.set('trust proxy', process.env.TRUST_PROXY ? +process.env.TRUST_PROXY || process.env.TRUST_PROXY : false);
app.disable('x-powered-by');
app.use((req,res,next)=>{req.requestId=require('crypto').randomUUID();res.set('X-Request-ID',req.requestId);res.set('Cache-Control','no-store');next();});
app.use(security);
app.get('/api/capabilities',(req,res)=>{const send=()=>res.json(require('./features').forUser(req.user));if(req.get('Authorization')||require('./browser-session').token(req))return auth(req,res,send);send();});
app.use(cors({ origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',').map(s=>s.trim()) : false, exposedHeaders:['X-Request-ID','ETag'], allowedHeaders:['Authorization','Content-Type','If-Match','Idempotency-Key'] }));
app.get('/api/health', (req, res) => res.json({ ok: true, name: 'LeadVolt API', version: '3.1.0', time: new Date().toISOString() }));
// Public, signed webhooks first (they need the raw body for signature checks)
const integ = require('./routes/integrations');
app.use('/api/integrations', integ.pub);
app.use('/api',require('./finance-audit'));
app.use('/api',(req,res,next)=>{const f=require('./features');if(!f.isFinancePath(req.path))return next();return auth(req,res,()=>f.guard(req,res,next));});
app.use(express.json({ limit: '2mb' }));
app.use(audit);
app.use('/api', require('./routes/notifications').ack);                 // service-worker delivery receipts
app.use('/api/recordings', require('./routes/recordings'));             // list/link need sign-in; /stream uses a signed short-lived link
app.use('/api/auth', require('./routes/auth'));
app.use('/api', auth);
app.use('/api',require('./finance-audit'));
app.use('/api',require('./features').guard);
app.use('/api', require('./policy'));
app.use('/api',require('./services/limits').middleware);
app.use('/api', require('./routes/strong'));                                                  // everything below needs a signed-in user
app.use('/api/integrations', integ.adm);
app.use('/api', require('./routes/notifications').router);              // /notifications, /push/*, /stream
app.use('/api', require('./routes/admin'));                             // /roles, /users/:id, /teams, /ad-refs, /audit
app.use('/api/leads', require('./routes/leads'));
app.use('/api/tasks', require('./routes/tasks'));
app.use('/api/attendance', require('./routes/attendance'));
app.use('/api/team', require('./routes/team'));
app.use('/api', require('./routes/projects'));                          // /projects, /units, /media
app.use('/api/invoices', require('./routes/invoices'));
app.use('/api/deals', require('./routes/deals'));
app.use('/api/imports', require('./routes/imports'));
app.use('/api/finance',require('./routes/reports'));
app.use('/api', require('./routes/reports'));
app.use('/api/settings', require('./routes/settings').router);
app.use('/api/ai', require('./routes/ai'));
app.use('/api', (req, res) => res.status(404).json({ error: 'No such endpoint' }));
app.use((err, req, res, next) => { if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Body must be valid JSON' }); if (err.type === 'entity.too.large') return res.status(413).json({ error: 'Request too large' }); if(err.status&&err.status>=400&&err.status<500)return res.status(err.status).json({error:err.message});console.error('request-error',req.requestId,err.message); res.status(500).json({ error: 'Something went wrong' }); });
// Front end + PWA from ../public
const pub = path.join(__dirname, '..', 'public');
if (fs.existsSync(pub)) app.use(express.static(pub, { setHeaders: (res, f) => { if (f.endsWith('sw.js')) res.set({ 'Cache-Control': 'no-cache', 'Service-Worker-Allowed': '/' }); } }));

const port = +process.env.PORT || 4000;
if (require.main === module) { app.listen(port, process.env.HOST || '127.0.0.1', () => console.log(`LeadVolt API running on http://localhost:${port}`)); require('./services/worker').start(); require('./services/jobs').start(); }
module.exports = app;
