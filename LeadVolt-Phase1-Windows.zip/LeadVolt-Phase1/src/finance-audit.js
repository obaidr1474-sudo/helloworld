// Persist an attempt before processing; preserve an outcome on finish or abort.
// Audit storage failure before processing is fail-closed. No bodies/tokens are logged.
const db=require('./db'),F=require('./features');
module.exports=function(req,res,next){
 const path=req.originalUrl.split('?')[0];const prefix=F.isFinancePath(path.replace(/^\/api/i,''));
 const mixed=F.canFinance(req.user)&&['/api/dashboard','/api/reports/summary'].includes(path);
 if(req._financeAudit||(!prefix&&!mixed))return next();req._financeAudit=true;
 let id;try{id=db.prepare('INSERT INTO audit_log(user_id,user_name,method,path,status,action,detail,ip) VALUES(?,?,?,?,?,?,?,?)').run(req.user?.id||null,req.user?.name||'Unauthenticated',req.method,path,0,'Finance request started',JSON.stringify({request_id:req.requestId,started_at:new Date().toISOString()}),req.ip).lastInsertRowid;}catch{return res.status(503).json({error:'Finance audit storage unavailable'});}
 let finished=false;const original=res.json.bind(res);let resource;
 res.json=function(body){if(Number.isSafeInteger(body?.id))resource=body.id;return original(body);};
 function end(aborted){if(finished)return;finished=true;const who=req.user;try{db.prepare('UPDATE audit_log SET user_id=?,user_name=?,status=?,action=?,detail=? WHERE id=?').run(who?.id||null,who?.name||'Unauthenticated',aborted?499:res.statusCode,`Finance ${req.method} ${path}${aborted?' (aborted)':''}`,JSON.stringify({request_id:req.requestId,finished_at:new Date().toISOString(),resource_id:resource,outcome:aborted?'aborted':res.statusCode<400?'succeeded':'denied-or-failed'}),id);}catch{console.error('finance-audit-outcome-write-failed',String(id));}}
 res.once('finish',()=>end(false));res.once('close',()=>end(!res.writableFinished));next();
};
