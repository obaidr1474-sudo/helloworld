// Seeds the database with the same sample data the front end shows. Run: npm run seed
const bcrypt = require('bcryptjs');
const db = require('./db');
const { put } = require('./routes/settings');
const PERMS = require('./perms.json');
const pw = bcrypt.hashSync('leadvolt123', 10);
if(process.env.NODE_ENV==='production')throw new Error('Demo seeding is disabled in production');
if(db.prepare('SELECT COUNT(*) n FROM users').get().n&&process.env.ALLOW_DEMO_RESET!=='yes')throw new Error('Refusing to erase existing users; use a separate empty demo database');
const tx = db.transaction(() => {
  ['audit_log', 'notifications', 'push_subs', 'shuffles', 'recordings', 'portal_events', 'ad_refs', 'team_members', 'teams', 'media', 'project_blocks', 'roles', 'login_attempts', 'lead_status_history', 'deals', 'activities', 'invoices', 'units', 'tasks', 'attendance', 'imports', 'leads', 'projects', 'users', 'settings'].forEach(t => db.prepare(`DELETE FROM ${t}`).run());
  const U = [['Obaid Raza', 'obaid@leadvolt.ae', 'Sales Manager', 'All leads'], ['Ashfaq Haji Haroon', 'ashfaq@leadvolt.ae', 'Senior Agent', 'Own leads only'], ['Raish Ahmed', 'raish@leadvolt.ae', 'Agent', 'Own leads only'], ['Farwa Shah', 'farwa@leadvolt.ae', 'Agent', 'Own leads only'], ['Daniel Costa', 'daniel@leadvolt.ae', 'Agent', 'Own leads only'], ['Mariam Khan', 'mariam@leadvolt.ae', 'Team Lead', 'Team leads']];
  const ir = db.prepare('INSERT INTO roles (name,description,perms) VALUES (?,?,?)'); PERMS.roles.forEach(x => ir.run(x.name, x.description, JSON.stringify(x.perms)));
  const RN = { 'Sales Manager': 'Admin', 'Team Lead': 'Manager', 'Senior Agent': 'SalesExecutive', Agent: 'SalesExecutive' };
  const iu = db.prepare('INSERT INTO users (name,email,password_hash,role,role_name,access,initials,monthly_target) VALUES (?,?,?,?,?,?,?,?)');
  const uid = U.map(([n, e, r, a]) => iu.run(n, e, pw, r, RN[r] || 'Basic', a, n.split(' ').map(w => w[0]).join('').slice(0, 2), 10).lastInsertRowid);
  const tm = db.prepare('INSERT INTO teams (name,lead_id) VALUES (?,?)').run('Sales Team A', uid[5]).lastInsertRowid; [uid[5], uid[1], uid[2]].forEach(u => db.prepare('INSERT INTO team_members VALUES (?,?)').run(tm, u));
  const P = [['Marina Vista', 'Dubai Marina', 'Azure Bay Developers', 'Ready', 1.2, 180, 142, '1–3 BR', '720–1,850 sqft', 100, null, 20, 30, 50, ['Infinity pool', 'Marina walk', 'Gym', 'Concierge']],
    ['Palm Residences', 'Palm Jumeirah', 'Sandline Properties', 'Off Plan', 3.4, 96, 61, '2–4 BR', '1,400–3,900 sqft', 72, '2027-06-30', 10, 50, 40, ['Private beach', 'Spa', 'Sky lounge']],
    ['Creek Heights', 'Dubai Creek Harbour', 'Northgate Estates', 'Off Plan', 1.6, 240, 118, '1–3 BR', '650–1,700 sqft', 45, '2027-12-31', 10, 60, 30, ['Creek views', 'Co-working', 'Pool deck']],
    ['Downtown Loft', 'Downtown Dubai', 'Azure Bay Developers', 'Ready', 2.1, 120, 104, 'Studio–2 BR', '480–1,350 sqft', 100, null, 25, 25, 50, ['Burj views', 'Rooftop cinema']],
    ['Hills Villas', 'Dubai Hills Estate', 'Greenleaf Communities', 'Off Plan', 4.8, 64, 52, '4–6 BR', '3,200–6,800 sqft', 88, '2027-03-31', 20, 40, 40, ['Golf course', 'Private garden']],
    ['Bay Square Offices', 'Business Bay', 'Northgate Estates', 'Off Plan', 0.9, 150, 39, 'Offices', '850–4,000 sqft', 20, '2028-09-30', 10, 40, 50, ['Metro access', 'EV charging']]];
  const ip = db.prepare('INSERT INTO projects (name,area,developer,status,price_from,total_units,sold_units,beds,size_range,construction_progress,handover_date,plan_booking,plan_construction,plan_handover,amenities) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
  const pid = P.map(p => ip.run(...p.slice(0, 14), JSON.stringify(p[14])).lastInsertRowid);
  const iun = db.prepare('INSERT INTO units (id,project_id,type,size_sqft,floor,view,price,status) VALUES (?,?,?,?,?,?,?,?)');
  P.forEach((p, i) => { const code = p[0].split(' ').map(w => w[0]).join(''); for (let k = 1; k <= 12; k++) { const size = 700 + ((k * 137 + i * 61) % 1400); iun.run(`${code}-${String(k + 100 * i).padStart(3, '0')}`, pid[i], ['1BR', '2BR', '3BR'][k % 3], size, String(2 + (k * 3) % 38), ['Sea', 'City', 'Park'][k % 3], Math.round(size * p[4] * 1e6 / 900 / 1000) * 1000, k % 5 === 0 ? 'Sold' : k % 4 === 0 ? 'Reserved' : 'Available'); } });
  const names = ['Khalid Mansoor', 'Elena Petrova', 'Rahul Verma', 'Fatima Zahra', 'James Whitfield', 'Aisha Karim', 'Yusuf Demir', 'Mei Lin', 'Carlos Rivera', 'Hana Sato', 'Tariq Aziz', 'Olivia Brooks', 'Arjun Mehta', 'Layla Hassan', 'Noah Fischer', 'Zara Sheikh', 'Ivan Kuznetsov', 'Grace Okafor', 'Samir Nasser', 'Chloe Martin'];
  const ST = ['Callback', 'Overdue', 'Meeting Done', 'Site Visit Done', 'Booked', 'Invoiced', 'New', 'Callback'], SRC = ['Bayut', 'Property Finder', 'Facebook', 'Website', 'Walk-in'];
  const il = db.prepare("INSERT INTO leads (name,phone,email,source,budget,budget_value,project_id,status,agent_id,score,created_at,last_contact_at) VALUES (?,?,?,?,?,?,?,?,?,?,datetime('now',?),datetime('now',?))");
  const ia = db.prepare("INSERT INTO activities (lead_id,user_id,kind,text,created_at) VALUES (?,?,?,?,datetime('now',?))");
  const lid = names.map((n, i) => { const b = 0.9 + ((i * 37) % 30) / 10, ag = uid[1 + i % 4];
    const id = il.run(n, `+971 5${i % 9} ${300 + i * 17} ${String(1000 + i * 263).slice(0, 4)}`, n.toLowerCase().replace(/ /g, '.') + '@mail.com', SRC[i % 5], `AED ${b.toFixed(1)}M`, b * 1e6, pid[i % 5], ST[i % 8], ag, 38 + (i * 17) % 60, `-${3 + (i * 5) % 40} days`, `-${i % 6} days`).lastInsertRowid;
    ia.run(id, ag, 'call', 'Intro call, 6 min', `-${4 + i % 3} days`); return id; });
  const d = o => { const x = new Date(); x.setDate(x.getDate() + o); return x.getFullYear() + '-' + String(x.getMonth() + 1).padStart(2, '0') + '-' + String(x.getDate()).padStart(2, '0'); };
  const it = db.prepare('INSERT INTO tasks (title,type,lead_id,assignee_id,due_date,due_time,priority) VALUES (?,?,?,?,?,?,?)');
  [['Call back about payment plan', 'Call', 0, 1, 0, '09:30', 'High'], ['Send floor plans', 'WhatsApp', 1, 2, 0, '11:00', 'Medium'], ['Site visit at Creek Heights', 'Site visit', 2, 3, 0, '13:45', 'High'], ['Follow up on brochure', 'Call', 5, 2, -1, null, 'High'], ['Book viewing slot', 'Meeting', 7, 4, 1, '10:00', 'Medium']]
    .forEach(([t, ty, l, a, o, tm, p]) => it.run(t, ty, lid[l], uid[a], d(o), tm, p));
  const iv = db.prepare('INSERT INTO invoices (number,lead_id,property_price,commission_pct,status,issued_at,due_at,paid_at) VALUES (?,?,?,?,?,?,?,?)');
  [[4, 5200000, 'Paid', -38, -24], [5, 1900000, 'Paid', -30, -12], [13, 2300000, 'Pending', -9, 6], [12, 4900000, 'Pending', -41, -11]].forEach(([l, pr, st, is, du], i) => iv.run(`INV-2026-${String(41 + i).padStart(4, '0')}`, lid[l], pr, 2, st, d(is), d(du), st === 'Paid' ? d(du) : null));
  const at = db.prepare('INSERT INTO attendance (user_id,day,clock_in,clock_out,status,location) VALUES (?,?,?,?,?,?)');
  for (let o = -20; o < 0; o++) { const day = d(o), dow = new Date(day).getDay(); if (dow === 0 || dow === 6) continue; uid.forEach((u, k) => at.run(u, day, day + 'T08:5' + k + ':00Z', day + 'T18:0' + k + ':00Z', (o + k) % 7 === 0 ? 'Late' : 'Present', 'Office')); }
  put('assignment', { auto: true, method: 'Round robin', reassign: false, minutes: 30, pool: uid.slice(1, 5) });
  put('notifications', { push: true, email: false, whatsapp: true, daily_digest: true, overdue_warnings: true });
  put('integrations', { Bayut: true, 'Property Finder': true, 'Facebook Lead Ads': true, 'WhatsApp Business': false, 'Google Ads': false, 'Website forms': true });
  put('security', { two_factor: true, session_timeout: '8 hours', office_network_only: false });
  put('org', { name: 'LeadVolt Real Estate LLC', orn: 'ORN 48213', trade_licence: 'TL-2026-118204', phone: '+971 4 555 0142', email: 'hello@leadvolt.ae', website: 'leadvolt.ae', address: 'Office 1804, Bay Square Tower 3, Business Bay, Dubai' });
  put('branding', { color: '#0B6BE6' });
  put('attendance', { start: '09:00', end: '18:00', late_after: '10:30', ask_reason: true, reason_required: true, geofence: true, radius_m: 150, max_accuracy_m: 100, offices: [{ name: 'Fortune4 Office, Business Bay', lat: 25.1857, lng: 55.2727, radius_m: 150 }], remote_roles: [] });
  put('listing', { learn: true, unknown_ref: 'unassigned' }); put('leads', { reenq_days: 30, note_required: false });
  put('escalation', { resend_min: 5, escalate_min: 15 }); put('integrations_cfg', { store_recordings: true }); put('working_days', ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']);
});
tx();
console.log('Seeded LeadVolt sample data. Sign in with obaid@leadvolt.ae / leadvolt123');
