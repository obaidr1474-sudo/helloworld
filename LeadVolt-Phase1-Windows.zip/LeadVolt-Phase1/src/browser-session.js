// Browser authentication shares the existing revocable sessions with bearer clients.
const secure=req=>process.env.NODE_ENV==='production'||req.secure;
const name=req=>secure(req)?'__Host-leadvolt_session':'leadvolt_session';
const options=req=>({httpOnly:true,secure:secure(req),sameSite:'strict',path:'/',maxAge:8*3600000});
function token(req){const entry=(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith(name(req)+'='));if(!entry)return null;try{return decodeURIComponent(entry.slice(name(req).length+1));}catch{return null;}}
function sameOrigin(req){const origin=req.get('Origin');return !origin||origin===req.protocol+'://'+req.get('Host');}
function mutationAllowed(req){return sameOrigin(req)&&req.get('X-LeadVolt-Browser')==='1';}
function set(req,res,value){res.cookie(name(req),value,options(req));}
function clear(req,res){const {maxAge,...opts}=options(req);res.clearCookie(name(req),opts);}
module.exports={token,set,clear,mutationAllowed};
