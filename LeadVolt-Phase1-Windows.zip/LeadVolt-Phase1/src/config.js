const path=require('path');
require('dotenv').config({path:path.join(__dirname,'..','.env'),quiet:true});
if(!process.env.TZ)process.env.TZ='Asia/Dubai';
if(Number(process.versions.node.split('.')[0])!==22)throw new Error('Use Node.js 22 LTS for this package');
if(process.env.NODE_ENV==='production'){
 const secret=process.env.JWT_SECRET||'';
 if(secret.length<32||/change-this|dev-secret/i.test(secret))throw new Error('Production requires a unique JWT_SECRET of 32+ characters');
 if(process.env.WEBHOOK_SYNC)throw new Error('WEBHOOK_SYNC is test-only and cannot be used in production');
}
module.exports={};
