// Record visibility is independent of permission to perform an action.
const db = require('./db');
const { can, fail } = require('./util');
function agentIds(u) {
 if (u.role_name === 'Admin' || can(u,'Leads','View All Leads')) return null;
 if (u.role_name === 'Manager') return db.prepare('SELECT user_id id FROM team_members WHERE team_id IN (SELECT id FROM teams WHERE lead_id=?) UNION SELECT ? id').all(u.id,u.id).map(r=>r.id);
 return [u.id];
}
function scope(u,alias='l') { const ids=agentIds(u);return ids===null?{sql:'1=1',params:[]}:{sql:`(${alias}.agent_id IN (${ids.map(()=>'?').join(',')})${can(u,'Leads','View Unassigned Lead')?' OR '+alias+'.agent_id IS NULL':''})`,params:ids}; }
function lead(u,id) {const l=db.prepare('SELECT * FROM leads WHERE id=?').get(Number(id));if(!l)throw fail(404,'Lead not found');const ids=agentIds(u);if(ids!==null&&!ids.includes(l.agent_id)&&!(l.agent_id===null&&can(u,'Leads','View Unassigned Lead')))throw fail(403,'Lead is outside your access');return l;}
module.exports={agentIds,scope,lead};
