// v1 finance is strictly Admin-only. Call capture remains deferred.
function flag(name, fallback=false){const value=process.env[name];if(value===undefined||value==='')return fallback;if(value!=='true'&&value!=='false')throw new Error(name+' must be true or false');return value==='true';}
const finance=flag('FEATURE_FINANCE_ENABLED',true),automaticCallSync=flag('FEATURE_CALL_SYNC_ENABLED');
const isFinancePath=p=>/^\/(invoices|ledger|deals|finance)(\/|$)/i.test(p);
const canFinance=user=>finance&&user?.role_name==='Admin'&&!user.password_reset_required;
function forUser(user){return {finance:canFinance(user),finance_admin_only:true,automatic_call_sync:automaticCallSync,web_push:true,native_mobile_app:false,finance_workflows:canFinance(user)?['overview','invoices','journal','reversals']:[]};}
const capabilities=forUser(null);
function guard(req,res,next){if(isFinancePath(req.path)){if(finance&&req.method==='GET'&&req.path==='/deals/my-closed'&&req.user&&!req.user.password_reset_required)return next();if(req.user?.role_name!=='Admin')return res.status(403).json({error:'Finance is restricted to Admin'});if(!finance)return res.status(404).json({error:'Finance is disabled'});}if(!automaticCallSync&&/^\/sync\/calls(?:\/|$)/i.test(req.path))return res.status(404).json({error:'Automatic device call sync is deferred'});next();}
module.exports={finance,automaticCallSync,capabilities,forUser,canFinance,isFinancePath,guard};
