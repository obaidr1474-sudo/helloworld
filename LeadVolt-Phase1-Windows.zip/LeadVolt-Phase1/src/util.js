// Shared helpers: auth, permissions, errors, dates
const jwt = require('jsonwebtoken');
const db = require('./db');
const SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';
if (process.env.NODE_ENV === 'production' && (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32 || /change-this|dev-secret/i.test(process.env.JWT_SECRET))) { console.error('JWT_SECRET must be set in production'); process.exit(1); }
const STATUSES = ['New', 'Callback', 'Meeting Done', 'Site Visit Done', 'Booked', 'Invoiced', 'Overdue', 'Not Interested', 'Dropped', 'Booking Cancel'];
const sign = (u) => { const id=require('crypto').randomUUID(); db.prepare('INSERT INTO sessions(id,user_id,expires_at) VALUES(?,?,?)').run(id,u.id,Date.now()+8*3600000); return jwt.sign({id:u.id,name:u.name},SECRET,{expiresIn:'8h',jwtid:id,issuer:'leadvolt',audience:'leadvolt-app',algorithm:'HS256'}); };
const verify = (t) => {const p=jwt.verify(t,SECRET,{algorithms:['HS256'],issuer:'leadvolt',audience:'leadvolt-app'});const s=db.prepare('SELECT * FROM sessions WHERE id=? AND revoked=0 AND expires_at>?').get(p.jti,Date.now());if(!s||s.user_id!==p.id)throw new Error('Session revoked');return p;};
// Permissions are read from the user's role on every request (cached 30 s), so changing a role takes effect without signing out.
const cache = new Map();
function loadUser(id) {
  const c = cache.get(id); if (c && c.at > Date.now() - 30000) return c.u;
  const u = db.prepare('SELECT id,name,email,role,role_name,access,active,password_reset_required FROM users WHERE id=?').get(id);
  if (!u || !u.active) return null;
  const r = db.prepare('SELECT perms FROM roles WHERE name=?').get(u.role_name || '');
  u.perms = r ? JSON.parse(r.perms) : {};
  cache.set(id, { u, at: Date.now() }); return u;
}
const clearUserCache = () => cache.clear();
function auth(req, res, next) {
  const h = req.headers.authorization || '';
  const t = h.startsWith('Bearer ') ? h.slice(7) : (req.path.endsWith('/stream') ? req.query.token : null);
  if (!t) return res.status(401).json({ error: 'Sign in required' });
  let p; try { p = verify(t); } catch { return res.status(401).json({ error: 'Session expired, sign in again' }); }
  const u = loadUser(p.id); if (!u) return res.status(401).json({ error: 'Account disabled' });
  req.user=u;req.sessionId=p.jti;if(u.password_reset_required&&!/^\/api\/auth\/(me|password|logout|logout-all|logout-others)(?:\?|$)/.test(req.originalUrl))return res.status(403).json({error:'Change your temporary password first',code:'PASSWORD_CHANGE_REQUIRED'});next();
}
const can = (u, mod, perm) => !!u && (u.role_name === 'Admin' || (u.perms[mod] || []).includes(perm));
const need = (mod, perm) => (req, res, next) => can(req.user, mod, perm) ? next() : res.status(403).json({ error: `You need the "${mod} › ${perm}" permission` });
const isManager = (u) => !!u && ['Admin','Manager'].includes(u.role_name);
const seesAll = (u) => !!u && (u.role_name === 'Admin' || can(u, 'Leads', 'View All Leads'));
const wrap = (fn) => async (req, res) => { try { await fn(req, res); } catch (e) { if (e.status) return res.status(e.status).json({ error: e.message }); console.error(e); res.status(500).json({ error: 'Something went wrong. It has been logged.' }); } };
const bad = (res, msg) => res.status(400).json({ error: msg });
const fail = (status, msg) => Object.assign(new Error(msg), { status });
const ymd = (d) => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
const today = () => ymd(new Date());
const money = (v) => Math.round(v * 100) / 100;
function parseBudget(s) { if (s == null || s === '') return null; if (typeof s === 'number') return s; const n = parseFloat(String(s).replace(/[^\d.]/g, '')); if (isNaN(n)) return null; return /m/i.test(s) ? n * 1e6 : /k/i.test(s) ? n * 1e3 : n; }
function rangeStart(r) { const d = new Date(); const map = { today: 0, week: 7, month: 30, quarter: 90 }; if (!(r in map)) return '1970-01-01'; d.setDate(d.getDate() - map[r]); return d.toISOString().slice(0, 10); }
const getSetting = (k, def) => { const s = db.prepare('SELECT value FROM settings WHERE key=?').get(k); return s ? JSON.parse(s.value) : def; };
const putSetting = (k, v) => db.prepare('INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(k, JSON.stringify(v));
const normPhone = (p) => { let s = String(p || '').replace(/[^\d+]/g, ''); if (s.startsWith('00')) s = '+' + s.slice(2); if (/^05\d{8}$/.test(s)) s = '+971' + s.slice(1); if (/^5\d{8}$/.test(s)) s = '+971' + s; return s; };
module.exports = { sign, verify, auth, can, need, isManager, seesAll, wrap, bad, fail, today, ymd, money, parseBudget, rangeStart, STATUSES, getSetting, putSetting, normPhone, clearUserCache, loadUser };
