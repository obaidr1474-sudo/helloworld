// Quiesce ALL writers first for a consistent database + storage recovery point.
const fs=require('fs'),path=require('path'),crypto=require('crypto'),db=require('../src/db');
(async()=>{
 if(process.env.BACKUP_WRITERS_STOPPED!=='yes')throw new Error('Stop all API/worker processes, then set BACKUP_WRITERS_STOPPED=yes');
 const target=path.resolve(process.argv[2]||'');if(!process.argv[2]||fs.existsSync(target))throw new Error('Provide a NEW backup directory');
 fs.mkdirSync(target,{recursive:true,mode:0o700});await db.backup(path.join(target,'database.sqlite'));
 const store=path.resolve(process.env.STORAGE_DIR||'storage');if(fs.existsSync(store))fs.cpSync(store,path.join(target,'storage'),{recursive:true});
 const files={};function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,e.name);if(e.isSymbolicLink())throw new Error('Backup refuses symbolic links');if(e.isDirectory())walk(p);else files[path.relative(target,p)]=crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');}}walk(target);
 fs.writeFileSync(path.join(target,'manifest.json'),JSON.stringify({version:1,created_at:new Date().toISOString(),files},null,2),{mode:0o600});console.log('Backup created; protect it as sensitive customer data.');
})().catch(e=>{console.error(e.message);process.exitCode=1;}).finally(()=>db.close());
