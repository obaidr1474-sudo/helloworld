#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
node -e "if(process.versions.node.split('.')[0]!=='22')throw Error('Activate Node.js 22 LTS before installation')"
export npm_config_devdir="${LEADVOLT_NODE_GYP_CACHE:-/tmp/leadvolt-node-gyp}"
export npm_config_cache="${LEADVOLT_NPM_CACHE:-/tmp/leadvolt-npm-cache}"
npm ci
node -e "const D=require('better-sqlite3');const d=new D(':memory:');if(d.prepare('SELECT 1 v').get().v!==1)process.exit(1);d.close()"
