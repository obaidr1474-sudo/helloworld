// Bootstrap an EMPTY production database. Set ADMIN_* securely in the shell/environment.
const db=require('../src/db'),bcrypt=require('bcryptjs');
try{
 const {ADMIN_EMAIL:email,ADMIN_NAME:name,ADMIN_PASSWORD:password}=process.env;
 if(!email||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||!name||!password||password.length<16)throw new Error('Set ADMIN_EMAIL, ADMIN_NAME and ADMIN_PASSWORD (16+ characters) securely');
 if(db.prepare('SELECT COUNT(*) n FROM users').get().n)throw new Error('Bootstrap only supports an empty database; manage existing users through authenticated admin APIs');
 db.transaction(()=>{for(const r of require('../src/perms.json').roles)db.prepare('INSERT OR IGNORE INTO roles(name,description,perms) VALUES(?,?,?)').run(r.name,r.description,JSON.stringify(r.perms));db.prepare("INSERT INTO users(name,email,password_hash,role,role_name,access,initials) VALUES(?,?,?,'Admin','Admin','All leads',?)").run(name,email.toLowerCase().trim(),bcrypt.hashSync(password,12),name.slice(0,2).toUpperCase());})();console.log('Administrator created. No demo accounts or demo leads were installed.');
}catch(e){console.error(e.message);process.exitCode=1;}finally{db.close();}
