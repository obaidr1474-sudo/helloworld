"""Local sample-data preview; separate from production data. Run from backend directory."""
import os,subprocess
from pathlib import Path
runtime=Path(os.environ.get('PREVIEW_DIR','/tmp/leadvolt-preview'))
runtime.mkdir(parents=True,exist_ok=True)
env=dict(os.environ,NODE_ENV='development',PORT=os.environ.get('PREVIEW_PORT','4100'),HOST='127.0.0.1',DB_FILE=str(runtime/'preview.db'),STORAGE_DIR=str(runtime/'storage'))
raise SystemExit(subprocess.call(['node','src/server.js'],env=env))
