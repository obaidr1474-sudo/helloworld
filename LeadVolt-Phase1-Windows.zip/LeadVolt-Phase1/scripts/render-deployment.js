// Produces reviewable files only. Does not install, enable services or request certificates.
const fs=require('fs'),path=require('path');
function render(options){
 const {domain,output,appDir='/opt/leadvolt/backend',nodeBin='/usr/local/bin/node',environmentFile='/etc/leadvolt/leadvolt.env',snippet='/etc/nginx/snippets/leadvolt-proxy.conf',certificate,certificateKey}=options;
 if(typeof domain!=='string'||domain.length>253||!domain.includes('.')||!domain.split('.').every(s=>/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(s)))throw new Error('Provide a lowercase ASCII fully qualified domain name');
 if(!output)throw new Error('Provide a NEW output directory');
 const values={DOMAIN:domain,APP_DIR:appDir,NODE_BIN:nodeBin,ENVIRONMENT_FILE:environmentFile,PROXY_SNIPPET:snippet,CERTIFICATE:certificate||`/etc/letsencrypt/live/${domain}/fullchain.pem`,CERTIFICATE_KEY:certificateKey||`/etc/letsencrypt/live/${domain}/privkey.pem`};
 for(const [k,v]of Object.entries(values))if(k!=='DOMAIN'&&(typeof v!=='string'||!/^\/[A-Za-z0-9_./-]+$/.test(v)||v.split('/').includes('..')))throw new Error(`Unsafe or non-absolute path for ${k}`);
 const target=path.resolve(output);if(fs.existsSync(target))throw new Error('Output already exists; refusing to overwrite files');
 const root=path.resolve(__dirname,'..'),files={};
 for(const [source,dest]of [['deploy/nginx/leadvolt.conf.template','nginx/leadvolt.conf'],['deploy/nginx/leadvolt-proxy.conf.template','nginx/leadvolt-proxy.conf'],['deploy/systemd/leadvolt.service.template','systemd/leadvolt.service']]){
 const text=fs.readFileSync(path.join(root,source),'utf8').replace(/@@([A-Z_]+)@@/g,(full,key)=>{if(!(key in values))throw new Error('Unknown template token');return values[key];});files[dest]=text;
 }
 files['leadvolt.env.example']=fs.readFileSync(path.join(root,'deploy/env/leadvolt.env.example'),'utf8');
 fs.mkdirSync(target,{recursive:true,mode:0o700});for(const [dest,text]of Object.entries(files)){const p=path.join(target,dest);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,text,{mode:0o600,flag:'wx'});}
 return {output:target,files:Object.keys(files),domain};
}
if(require.main===module){try{const args=process.argv.slice(2),options={};const names={'--domain':'domain','--output':'output','--app-dir':'appDir','--node-bin':'nodeBin','--environment-file':'environmentFile','--proxy-snippet':'snippet','--certificate':'certificate','--certificate-key':'certificateKey'};for(let i=0;i<args.length;i+=2){if(!names[args[i]]||!args[i+1])throw new Error('Use --domain <hostname> --output <new-directory> [--app-dir ... --node-bin ...]');options[names[args[i]]]=args[i+1];}console.log(JSON.stringify(render(options),null,2));}catch(e){console.error(e.message);process.exitCode=1;}}
module.exports={render};
