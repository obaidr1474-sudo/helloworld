// Verifies backup checksums and exercises SQLite recovery on an isolated copy.
const fs=require('fs'),path=require('path'),os=require('os'),crypto=require('crypto'),Database=require('better-sqlite3');
let tmp;
try{
 const root=path.resolve(process.argv[2]||'');if(!process.argv[2])throw new Error('Provide backup directory');
 const manifest=JSON.parse(fs.readFileSync(path.join(root,'manifest.json')));
 if(!manifest.files?.['database.sqlite'])throw new Error('Database missing from manifest');
 for(const [name,expected] of Object.entries(manifest.files)){const p=path.resolve(root,name);if(!p.startsWith(root+path.sep))throw new Error('Unsafe backup path');if(crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex')!==expected)throw new Error('Checksum mismatch: '+name);}
 tmp=fs.mkdtempSync(path.join(os.tmpdir(),'lv-restore-'));fs.copyFileSync(path.join(root,'database.sqlite'),path.join(tmp,'restore.sqlite'));
 const db=new Database(path.join(tmp,'restore.sqlite'));try{if(db.pragma('integrity_check',{simple:true})!=='ok'||db.pragma('foreign_key_check').length)throw new Error('Database integrity/foreign-key check failed');console.log('Restore check passed:',db.prepare('SELECT COUNT(*) count FROM users').get().count,'users,',db.prepare('SELECT COUNT(*) count FROM leads').get().count,'leads.');}finally{db.close();}
}catch(e){console.error(e.message);process.exitCode=1;}finally{if(tmp)fs.rmSync(tmp,{recursive:true,force:true});}
