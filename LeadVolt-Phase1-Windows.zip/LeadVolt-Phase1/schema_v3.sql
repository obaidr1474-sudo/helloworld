CREATE TABLE IF NOT EXISTS schema_migrations(version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS sessions(id TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), expires_at INTEGER NOT NULL, revoked INTEGER NOT NULL DEFAULT 0);
CREATE INDEX IF NOT EXISTS sessions_user ON sessions(user_id);
CREATE TABLE IF NOT EXISTS jobs(
 id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT NOT NULL, dedupe_key TEXT NOT NULL UNIQUE,
 payload TEXT NOT NULL, owner_id INTEGER REFERENCES users(id), status TEXT NOT NULL DEFAULT 'queued' CHECK(status IN ('queued','running','done','dead')),
 attempts INTEGER NOT NULL DEFAULT 0, max_attempts INTEGER NOT NULL DEFAULT 5,
 available_at INTEGER NOT NULL, lease_until INTEGER, lease_token TEXT, result TEXT, error TEXT,
 created_at TEXT NOT NULL DEFAULT (datetime('now')), finished_at TEXT
);
CREATE INDEX IF NOT EXISTS jobs_ready ON jobs(status,available_at,lease_until);
CREATE TABLE IF NOT EXISTS call_sync(
 user_id INTEGER NOT NULL REFERENCES users(id),device_id TEXT NOT NULL,event_id TEXT NOT NULL,
 payload_hash TEXT NOT NULL,lead_id INTEGER NOT NULL REFERENCES leads(id),occurred_at TEXT NOT NULL,
 duration_sec INTEGER NOT NULL CHECK(duration_sec>=0),direction TEXT NOT NULL CHECK(direction IN ('inbound','outbound','missed')),
 received_at TEXT NOT NULL DEFAULT (datetime('now')),PRIMARY KEY(user_id,device_id,event_id)
);
CREATE TABLE IF NOT EXISTS journal_entries(
 id INTEGER PRIMARY KEY AUTOINCREMENT,idempotency_key TEXT NOT NULL UNIQUE,payload_hash TEXT NOT NULL,
 description TEXT NOT NULL,currency TEXT NOT NULL CHECK(length(currency)=3),
 reversal_of INTEGER UNIQUE REFERENCES journal_entries(id),created_by INTEGER NOT NULL REFERENCES users(id),
 created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS journal_lines(
 id INTEGER PRIMARY KEY AUTOINCREMENT,entry_id INTEGER NOT NULL REFERENCES journal_entries(id),account TEXT NOT NULL,
 debit_minor INTEGER NOT NULL DEFAULT 0 CHECK(debit_minor>=0),credit_minor INTEGER NOT NULL DEFAULT 0 CHECK(credit_minor>=0),
 CHECK((debit_minor>0 AND credit_minor=0) OR (credit_minor>0 AND debit_minor=0))
);
CREATE TRIGGER IF NOT EXISTS journal_entries_no_update BEFORE UPDATE ON journal_entries BEGIN SELECT RAISE(ABORT,'Journal entries are immutable'); END;
CREATE TRIGGER IF NOT EXISTS journal_entries_no_delete BEFORE DELETE ON journal_entries BEGIN SELECT RAISE(ABORT,'Journal entries are immutable'); END;
CREATE TRIGGER IF NOT EXISTS journal_lines_no_update BEFORE UPDATE ON journal_lines BEGIN SELECT RAISE(ABORT,'Journal lines are immutable'); END;
CREATE TRIGGER IF NOT EXISTS journal_lines_no_delete BEFORE DELETE ON journal_lines BEGIN SELECT RAISE(ABORT,'Journal lines are immutable'); END;
CREATE INDEX IF NOT EXISTS idx_leads_agent_active ON leads(agent_id,is_deleted,created_at);
CREATE INDEX IF NOT EXISTS idx_leads_phone ON leads(phone);
CREATE INDEX IF NOT EXISTS idx_leads_email ON leads(email);
CREATE INDEX IF NOT EXISTS idx_tasks_assignee_due ON tasks(assignee_id,done,due_date);
INSERT OR IGNORE INTO schema_migrations(version) VALUES(3);

CREATE TRIGGER IF NOT EXISTS lead_revision AFTER UPDATE ON leads WHEN NEW.revision=OLD.revision BEGIN UPDATE leads SET revision=OLD.revision+1 WHERE id=OLD.id; END;
CREATE TABLE IF NOT EXISTS sync_changes(user_id INTEGER NOT NULL REFERENCES users(id),event_id TEXT NOT NULL,payload_hash TEXT NOT NULL,result TEXT NOT NULL,PRIMARY KEY(user_id,event_id));
CREATE TABLE IF NOT EXISTS journal_seals(entry_id INTEGER PRIMARY KEY REFERENCES journal_entries(id));
CREATE TRIGGER IF NOT EXISTS journal_seal_validate BEFORE INSERT ON journal_seals BEGIN
 SELECT CASE WHEN (SELECT COUNT(*) FROM journal_lines WHERE entry_id=NEW.entry_id)<2 OR (SELECT SUM(debit_minor)-SUM(credit_minor) FROM journal_lines WHERE entry_id=NEW.entry_id)!=0 THEN RAISE(ABORT,'Unbalanced journal') END;
END;
CREATE TRIGGER IF NOT EXISTS journal_lines_sealed BEFORE INSERT ON journal_lines WHEN EXISTS(SELECT 1 FROM journal_seals WHERE entry_id=NEW.entry_id) BEGIN SELECT RAISE(ABORT,'Journal is sealed'); END;
CREATE TRIGGER IF NOT EXISTS journal_seal_no_delete BEFORE DELETE ON journal_seals BEGIN SELECT RAISE(ABORT,'Journal seal is immutable'); END;
CREATE TRIGGER IF NOT EXISTS journal_seal_no_update BEFORE UPDATE ON journal_seals BEGIN SELECT RAISE(ABORT,'Journal seal is immutable'); END;
CREATE TABLE IF NOT EXISTS rate_buckets(key TEXT PRIMARY KEY,tokens REAL NOT NULL,updated_at INTEGER NOT NULL);

CREATE UNIQUE INDEX IF NOT EXISTS notification_dedupe ON notifications(dedupe_key) WHERE dedupe_key IS NOT NULL;
CREATE TABLE IF NOT EXISTS finance_requests(key TEXT PRIMARY KEY,payload_hash TEXT NOT NULL,resource_type TEXT NOT NULL,resource_id INTEGER NOT NULL,created_by INTEGER NOT NULL REFERENCES users(id),created_at TEXT NOT NULL DEFAULT (datetime('now')));
