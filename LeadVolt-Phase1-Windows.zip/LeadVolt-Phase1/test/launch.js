// Current v1: Admin-only finance, no automatic records from lead changes, call sync deferred.
const fs=require('fs'),path=require('path'),os=require('os'),assert=require('assert/strict');
process.env.NODE_ENV='test';delete process.env.FEATURE_FINANCE_ENABLED;delete process.env.FEATURE_CALL_SYNC_ENABLED;delete process.env.WEBHOOK_SYNC;
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'lv-launch-'));process.env.DB_FILE=path.join(dir,'db.sqlite');process.env.STORAGE_DIR=path.join(dir,'storage');
const app=require('../src/server'),db=require('../src/db');let server,count=0;function check(c,n){assert.ok(c,n);count++;console.log('PASS',n);}
(async()=>{server=app.listen(0,'127.0.0.1');await new Promise(r=>server.once('listening',r));const base='http://127.0.0.1:'+server.address().port;
 async function req(p,method='GET',body,token,headers={}){const r=await fetch(base+p,{method,headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{}),...headers},body:body===undefined?undefined:JSON.stringify(body)});return {status:r.status,j:await r.json(),requestId:r.headers.get('X-Request-ID')};}
 check(['commission_pct','commission_override_minor','commission_status','commission_paid_at','commission_paid_by','revision'].every(c=>db.prepare('PRAGMA table_info(deals)').all().some(x=>x.name===c)),'additive CRM commission columns are present');
 check(db.prepare("SELECT COUNT(*) n FROM deals WHERE commission_status NOT IN ('pending','paid')").get().n===0,'existing deal rows receive a valid pending status');
 const login=async email=>(await req('/api/auth/login','POST',{email,password:'leadvolt123'})).j.token;
 const admin=await login('obaid@leadvolt.ae'),agent=await login('raish@leadvolt.ae'),manager=await login('mariam@leadvolt.ae');
 check(!(await req('/api/capabilities')).j.finance,'anonymous capabilities expose no finance access');check((await req('/api/capabilities','GET',undefined,admin)).j.finance,'Admin capabilities allow completed finance workflows');check(!(await req('/api/capabilities','GET',undefined,agent)).j.finance,'agent capabilities hide finance');
 const agentId=db.prepare("SELECT id FROM users WHERE email='raish@leadvolt.ae'").get().id;
 const otherId=db.prepare("SELECT id FROM users WHERE email='mariam@leadvolt.ae'").get().id;
 const putDeal=db.prepare("INSERT INTO deals(lead_id,agent_id,agreement_value,stage) VALUES(1,?,?,?)");
 const ownDeal=Number(putDeal.run(agentId,100000,'Booked').lastInsertRowid);
 const otherDeal=Number(putDeal.run(otherId,200000,'Booked').lastInsertRowid);
 putDeal.run(agentId,300000,'Cancelled');
 const mine=await req('/api/deals/my-closed','GET',undefined,agent);
 check(mine.status===200&&mine.j.data.length===1&&mine.j.data[0].id===ownDeal,'agent sees only session-owned closed deals');
 check(!mine.j.data.some(d=>d.id===otherDeal),'Agent B deal never appears in Agent A response');
 for(const query of ['agent_id='+otherId,'agent_id='+agentId,'user_id='+otherId,'id='+otherDeal])check((await req('/api/deals/my-closed?'+query,'GET',undefined,agent)).status===403,'agent ownership selector blocked: '+query);
 check((await req('/api/deals/'+otherDeal,'GET',undefined,agent)).status===403,'Agent A cannot load Agent B deal by ID');
 check((await req('/api/deals/my-closed','POST',{},agent)).status===403,'agent cannot write through own-deals endpoint');
 check((await req('/api/deals/my-closed')).status===401,'own closed deals require authentication');
 const journal={description:'Manual journal fixture',currency:'AED',lines:[{account:'receivables',debit_minor:10000,credit_minor:0},{account:'income',debit_minor:0,credit_minor:10000}]};
 const invoice=(await req('/api/invoices','POST',{lead_id:1,property_price:1000000},admin,{'Idempotency-Key':'finance-fixture-invoice'}));check(invoice.status===201,'Admin manually creates invoice');
 const entry=await req('/api/ledger/entries','POST',journal,admin,{'Idempotency-Key':'finance-fixture-journal'});check(entry.status===201,'Admin manually creates balanced journal');
 // Narrow CRM finance workflows; fixtures are explicit manual records.
 db.prepare("UPDATE leads SET status='Booked' WHERE id IN (2,3)").run();
 const created=await req('/api/deals','POST',{lead_id:2,booked_date:'2026-10-01',agreement_value:100000,commission_pct:2.5},admin);
 check(created.status===201,'Admin manually records a closed deal');
 let deal=(await req('/api/deals','GET',undefined,admin)).j.data.find(d=>d.id===created.j.id);
 check(deal.commission_minor===250000,'percentage commission uses integer minor units');
 const edited=await req('/api/deals/'+deal.id,'PATCH',{revision:deal.revision,commission_override:1234.56,commission_status:'paid'},admin);
 check(edited.status===200,'Admin can override commission and mark paid');
 check((await req('/api/deals/'+deal.id,'PATCH',{revision:deal.revision,commission_pct:3},admin)).status===409,'stale deal update is rejected');
 deal=(await req('/api/deals','GET',undefined,admin)).j.data.find(d=>d.id===deal.id);
 check(deal.commission_minor===123456&&deal.commission_paid_by&&deal.commission_paid_at,'manual override wins and paid actor/time recorded');
 check((await req('/api/deals/'+deal.id,'PATCH',{revision:deal.revision,commission_override:null,commission_status:'pending'},admin)).status===200,'Admin can clear override and restore percentage commission');
 check((await req('/api/deals','POST',{lead_id:2,booked_date:'2026-10-01',agreement_value:100},admin)).status===409,'duplicate closed deal is rejected');
 check((await req('/api/deals','POST',{lead_id:3,booked_date:'2026-02-30',agreement_value:100},admin)).status===400,'invalid calendar date is rejected');
 check((await req('/api/deals/'+deal.id,'PATCH',{revision:deal.revision+1,commission_pct:-1},admin)).status===400,'negative commission rate is rejected');
 const summary=(await req('/api/finance/reports/closed-deals-summary','GET',undefined,admin)).j;
 check(summary.month.some(g=>g.key==='2026-10'&&g.commission_minor===250000),'monthly revenue comes from closed deals, not invoices');
 check(summary.agent.length>0&&summary.project.length>0&&summary.totals[0].commission_unset===2,'agent/project groups and unset commission counts are explicit');
 check((await req('/api/reports/closed-deals-summary','GET',undefined,agent)).status===403,'agent cannot use root summary alias');
 const routes=[['GET','/api/invoices'],['GET',`/api/invoices/${invoice.j.id}`],['POST','/api/invoices',{lead_id:1,property_price:500000},'matrix-invoice-create'],['PATCH',`/api/invoices/${invoice.j.id}`,{status:'Paid'}],['GET','/api/deals'],['POST','/api/deals',{lead_id:3,booked_date:'2026-10-02',agreement_value:200000,commission_pct:1}],['PATCH','/api/deals/'+deal.id,{revision:deal.revision+1,commission_status:'paid'}],['GET','/api/finance/reports/closed-deals-summary'],['GET','/api/ledger/entries'],['POST','/api/ledger/entries',journal,'matrix-journal-create'],['POST',`/api/ledger/entries/${entry.j.id}/reverse`,{},'matrix-reversal-create'],['GET','/api/finance/dashboard'],['GET','/api/finance/reports/summary'],['GET','/api/finance/audit']];
 const registered=[];
 for(const [module,prefix]of [['invoices','/api/invoices'],['deals','/api/deals'],['strong','/api'],['reports','/api/finance']])for(const layer of require('../src/routes/'+module).stack){if(!layer.route)continue;const route=layer.route;if(module==='deals'&&route.path==='/my-closed')continue;if(module==='strong'&&!/^\/(ledger|finance)\//.test(route.path))continue;for(const method of Object.keys(route.methods))registered.push(method.toUpperCase()+' '+prefix+(route.path==='/'?'':route.path));}
 const matrix=routes.map(([m,p])=>m+' '+p.replace(/\/\d+(?=\/|$)/g,'/:id'));check(JSON.stringify(registered.sort())===JSON.stringify(matrix.sort()),'matrix covers every registered finance handler');
 for(const [method,p,body,key]of routes){
 const allowed=await req(p,method,body,admin,key?{'Idempotency-Key':key}:{});check(allowed.status>=200&&allowed.status<300,'Admin allowed '+method+' '+p);
 for(const [role,token]of [['agent',agent],['manager',manager]]){const denied=await req(p,method,body,token,key?{'Idempotency-Key':'denied-'+key}:{});check(denied.status===403,role+' blocked '+method+' '+p);const audit=db.prepare('SELECT * FROM audit_log WHERE detail LIKE ?').get('%'+denied.requestId+'%');check(audit&&audit.user_id&&audit.status===403&&audit.at,'denied finance action attributed and timestamped');}
 const audit=db.prepare('SELECT * FROM audit_log WHERE detail LIKE ?').get('%'+allowed.requestId+'%');check(audit?.user_name==='Obaid Raza'&&audit.status===allowed.status&&audit.at,'Admin finance action attributed and timestamped');
 }
 // Full-module permissions never grant finance to a non-Admin.
 db.prepare("UPDATE roles SET perms=? WHERE name='SalesExecutive'").run(JSON.stringify(require('../src/perms.json').catalog));require('../src/util').clearUserCache();
 for(const [method,p,body,key]of routes)check((await req(p,method,body,agent,key?{'Idempotency-Key':'all-perms-'+key}:{})).status===403,'all-permissions agent still denied '+method+' '+p);
 check((await req('/api/audit','GET',undefined,agent)).status===403,'agent cannot use general audit to read finance actions');
 check((await req('/api/INVOICES/1','GET',undefined,agent)).status===403,'case variant cannot bypass Admin gate');
 for(const token of [agent,manager]){check(!('revenue'in(await req('/api/dashboard','GET',undefined,token)).j),'non-Admin dashboard has no revenue');check((await req('/api/reports/summary','GET',undefined,token)).j.agents.every(a=>!('revenue'in a)),'non-Admin report has no revenue');}
 check('revenue'in(await req('/api/dashboard','GET',undefined,admin)).j,'Admin dashboard includes revenue');
 const before={invoices:db.prepare('SELECT COUNT(*) n FROM invoices').get().n,deals:db.prepare('SELECT COUNT(*) n FROM deals').get().n,journal:db.prepare('SELECT COUNT(*) n FROM journal_entries').get().n};
 for(const token of [agent,admin]){const id=token===agent?db.prepare("SELECT l.id FROM leads l JOIN users u ON u.id=l.agent_id WHERE u.email='raish@leadvolt.ae' LIMIT 1").get().id:1;const l=(await req('/api/leads/'+id,'GET',undefined,token)).j;check((await req('/api/leads/'+id,'PATCH',{status:'Booked'},token,{'If-Match':String(l.revision)})).status===200,'lead closure allowed without financial posting');}
 check(JSON.stringify(before)===JSON.stringify({invoices:db.prepare('SELECT COUNT(*) n FROM invoices').get().n,deals:db.prepare('SELECT COUNT(*) n FROM deals').get().n,journal:db.prepare('SELECT COUNT(*) n FROM journal_entries').get().n}),'Admin and agent status changes create zero financial records');
 const body={lead_id:1,property_price:123456};const first=await req('/api/invoices','POST',body,admin,{'Idempotency-Key':'invoice-retry-test'}),second=await req('/api/invoices','POST',body,admin,{'Idempotency-Key':'invoice-retry-test'});check(first.j.id===second.j.id&&second.j.duplicate,'manual invoice retry is idempotent');
 check((await req('/api/sync/calls','POST',{},admin)).status===404,'automatic call capture remains deferred');
 const immutable=()=>db.prepare('UPDATE journal_lines SET debit_minor=2 WHERE entry_id=?').run(entry.j.id);assert.throws(immutable);check(true,'journal lines remain immutable after Admin reversal');
 const revision=(await req('/api/leads/1','GET',undefined,admin)).j.revision;
 const countsBeforeStatus=db.prepare('SELECT (SELECT COUNT(*) FROM invoices) i,(SELECT COUNT(*) FROM deals) d,(SELECT COUNT(*) FROM journal_entries) j').get();
 check((await req('/api/leads/1','PATCH',{status:'Invoiced'},admin,{'If-Match':String(revision)})).status===200,'Admin may update a status without automatic posting');check(JSON.stringify(countsBeforeStatus)===JSON.stringify(db.prepare('SELECT (SELECT COUNT(*) FROM invoices) i,(SELECT COUNT(*) FROM deals) d,(SELECT COUNT(*) FROM journal_entries) j').get()),'invoiced status also creates no finance records');
 check((await req('/api/ledger/entries','POST',{...journal,currency:'USD'},admin,{'Idempotency-Key':'unsupported-currency'})).status===400,'unfinished multi-currency workflow is rejected');
 const beforeFailure=db.prepare('SELECT COUNT(*) n FROM journal_entries').get().n;
 db.exec("CREATE TEMP TRIGGER simulate_audit_failure BEFORE INSERT ON audit_log WHEN NEW.action='Finance request started' BEGIN SELECT RAISE(ABORT,'Simulated audit storage failure'); END;");
 try{check((await req('/api/ledger/entries','POST',journal,admin,{'Idempotency-Key':'audit-failure-fixture'})).status===503,'finance fails closed when audit cannot persist');check(db.prepare('SELECT COUNT(*) n FROM journal_entries').get().n===beforeFailure,'audit failure creates no entry');}finally{db.exec('DROP TRIGGER simulate_audit_failure');}
 console.log(`${count} Admin-finance launch checks passed, 0 failed`);
})().catch(e=>{console.error(e);process.exitCode=1;}).finally(async()=>{if(server){server.closeAllConnections();await new Promise(r=>server.close(r));}db.close();fs.rmSync(dir,{recursive:true,force:true});});
