import os,json,secrets,subprocess,tempfile,urllib.request,time,signal
from pathlib import Path
node=subprocess.check_output(['sh','-c','command -v node'],text=True).strip()
root=Path.cwd();tmp=Path(tempfile.mkdtemp(prefix='lv-production-'))
env=dict(os.environ,NODE_ENV='production',JWT_SECRET=secrets.token_urlsafe(48),DB_FILE=str(tmp/'live.db'),STORAGE_DIR=str(tmp/'storage'),PORT='4110',HOST='127.0.0.1',ADMIN_EMAIL='owner@example.test',ADMIN_NAME='Owner',ADMIN_PASSWORD=secrets.token_urlsafe(24))
subprocess.run([node,'scripts/admin.js'],env=env,check=True,capture_output=True)
log=open(tmp/'server.log','w');server=subprocess.Popen([node,'src/server.js'],env=env,stdout=log,stderr=log)
def request(path,body=None,token=None):
 data=None if body is None else json.dumps(body).encode();req=urllib.request.Request('http://127.0.0.1:4110'+path,data=data,headers={'Content-Type':'application/json',**({'Authorization':'Bearer '+token} if token else {})});return json.load(urllib.request.urlopen(req,timeout=10))
try:
 for _ in range(50):
  try:health=request('/api/health');break
  except Exception:time.sleep(.1)
 else:raise Exception('Production start failed')
 auth=request('/api/auth/login',{'email':env['ADMIN_EMAIL'],'password':env['ADMIN_PASSWORD']});token=auth['token']
 assert request('/api/leads',token=token)['total']==0
 assert len(request('/api/team',token=token))==1
 assert request('/api/ops/status',token=token)['database']=='ok'
 invite=request('/api/team/invite',{'name':'Agent One','email':'agent@example.test'},token)
 temp=invite['temporary_password'];agent=request('/api/auth/login',{'email':'agent@example.test','password':temp});assert agent['user']['password_reset_required']
 try:request('/api/leads',token=agent['token']);raise Exception('Temporary password bypass')
 except urllib.error.HTTPError as e:assert e.code==403
 request('/api/auth/password',{'current':temp,'next':secrets.token_urlsafe(24)},agent['token'])
 print(json.dumps({'production_start':True,'sample_accounts':False,'empty_live_database':True,'admin_bootstrap':True,'agent_invitation':True,'forced_password_change':True,'database_ready':True},indent=2))
finally:
 server.terminate();server.wait(timeout=10);log.close()
 import shutil;shutil.rmtree(tmp)
