process.env.FEATURE_FINANCE_ENABLED='true';process.env.FEATURE_CALL_SYNC_ENABLED='true';
'use strict';
const fs=require('fs'),os=require('os'),path=require('path'),assert=require('assert/strict'),crypto=require('crypto'),{spawnSync}=require('child_process');
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'lv-strong-'));
process.env.NODE_ENV='test';delete process.env.WEBHOOK_SYNC;process.env.DB_FILE=path.join(tmp,'test.db');process.env.STORAGE_DIR=path.join(tmp,'storage');
const app=require('../src/server'),db=require('../src/db'),J=require('../src/services/jobs');
let srv,base,count=0;
function check(condition,name){assert.ok(condition,name);count++;console.log('PASS',name);}
async function call(method,url,body,token,headers={}){const r=await fetch(base+url,{method,headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{}),...headers},body:body===undefined?undefined:JSON.stringify(body)});const text=await r.text();let data;try{data=JSON.parse(text);}catch{data=text;}return {status:r.status,data,headers:r.headers};}
const login=async(email,password='leadvolt123')=>(await call('POST','/api/auth/login',{email,password})).data.token;
(async()=>{
 srv=app.listen(0,'127.0.0.1');await new Promise(r=>srv.once('listening',r));base='http://127.0.0.1:'+srv.address().port;
 let admin=await login('obaid@leadvolt.ae'),agent=await login('raish@leadvolt.ae');check(!!admin&&!!agent,'admin and agent authenticate');
 const uid=db.prepare("SELECT id FROM users WHERE email='raish@leadvolt.ae'").get().id;
 const own=db.prepare('SELECT * FROM leads WHERE agent_id=? LIMIT 1').get(uid),foreign=db.prepare('SELECT * FROM leads WHERE agent_id!=? LIMIT 1').get(uid);
 check((await call('GET','/api/leads/'+foreign.id,undefined,agent)).status===403,'foreign lead denied');
 const ai=await call('POST','/api/ai/ask',{question:foreign.name},agent);check(ai.status===200&&!ai.data.items.some(l=>l.id===foreign.id||l.name===foreign.name),'AI cannot leak foreign lead');
 const dash=await call('GET','/api/dashboard',undefined,agent);check(dash.data.total===db.prepare('SELECT COUNT(*) n FROM leads WHERE agent_id=? AND is_deleted=0').get(uid).n,'dashboard totals scoped to agent');
 check((await call('POST','/api/leads',{name:'No reassignment',phone:'+971555123123',agent_id:1},agent)).status===403,'agent cannot assign newly created lead to another user');
 check((await call('POST','/api/leads/bulk',{ids:[foreign.id],tags_add:['Secret']},agent)).status===403,'bulk mutation checks record visibility');
 check((await call('PATCH','/api/leads/'+own.id,{name:'Changed'},agent)).status===409,'missing revision rejects lead update');
 const rev=db.prepare('SELECT revision FROM leads WHERE id=?').get(own.id).revision;
 check((await call('PATCH','/api/leads/'+own.id,{name:'Updated own'},agent,{'If-Match':String(rev)})).status===200,'matching revision permits update');
 check((await call('PATCH','/api/leads/'+own.id,{name:'Overwrite'},agent,{'If-Match':String(rev)})).status===409,'stale revision rejects overwrite');
 const saved=db.prepare("SELECT perms FROM roles WHERE name='SalesExecutive'").get().perms;
 db.prepare("UPDATE roles SET perms='{}' WHERE name='SalesExecutive'").run();require('../src/util').clearUserCache();
 for(const [method,url,body]of [['GET','/api/leads'],['GET','/api/dashboard'],['GET','/api/reports/summary'],['GET','/api/invoices'],['GET','/api/deals'],['POST','/api/invoices',{lead_id:foreign.id,property_price:500}],['POST','/api/imports/jobs',{csv:'name,phone\nX,0500001111'}],['POST','/api/ai/ask',{question:'hot'}],['POST','/api/sync/calls',{device_id:'x',events:[]}],['GET','/api/settings/portals']])check((await call(method,url,body,agent)).status===403,'empty role denied '+method+' '+url);
 db.prepare("UPDATE roles SET perms=? WHERE name='SalesExecutive'").run(saved);require('../src/util').clearUserCache();
 // Make a restricted finance role to test resource checks independently from module checks.
 db.prepare("INSERT INTO roles(name,perms) VALUES('Finance',?)").run(JSON.stringify({Invoice:['View','Update'],Leads:['View']}));
 db.prepare("UPDATE users SET role_name='Finance' WHERE id=?").run(uid);require('../src/util').clearUserCache();
 check((await call('POST','/api/invoices',{lead_id:foreign.id,property_price:1000000},agent)).status===403,'finance permission cannot access another agent lead');
 const invoice=await call('POST','/api/invoices',{lead_id:own.id,property_price:1000000},admin,{'Idempotency-Key':'strong-invoice-0001'});check(invoice.status===201,'Admin can create manual invoice');
 check((await call('GET','/api/invoices',undefined,agent)).status===403,'custom Finance role cannot access Admin finance');
 db.prepare("UPDATE users SET role_name='SalesExecutive' WHERE id=?").run(uid);require('../src/util').clearUserCache();
 // Manager scope follows teams they lead, not the broad user-directory permission.
 const managerId=db.prepare("INSERT INTO users(name,email,password_hash,role,role_name) VALUES('Scoped Manager','scoped-manager@example.test',?,'Manager','Manager')").run(require('bcryptjs').hashSync('manager-test-password-123',10)).lastInsertRowid;
 const teamId=db.prepare("INSERT INTO teams(name,lead_id) VALUES('Scoped Team',?)").run(managerId).lastInsertRowid;db.prepare('INSERT INTO team_members(team_id,user_id) VALUES(?,?)').run(teamId,uid);
 const manager=await login('scoped-manager@example.test','manager-test-password-123');
 check((await call('GET','/api/leads/'+foreign.id,undefined,manager)).status===403,'manager cannot read lead outside led teams');
 check((await call('GET','/api/leads?limit=200',undefined,manager)).data.data.every(l=>l.agent_id===uid||l.agent_id===managerId),'manager list respects led team');
 const managerAi=await call('POST','/api/ai/ask',{question:foreign.name},manager);check(!managerAi.data.items.some(l=>l.id===foreign.id||l.name===foreign.name),'manager AI respects led team');
 // Async webhook path is the production-default path, not the legacy test adapter.
 const secret='test-webhook-secret-very-long';await call('PUT','/api/settings/portals',{Bayut:{secret}},admin);
 async function hook(body,sig){const raw=JSON.stringify(body);return call('POST','/api/integrations/bayut/webhook',body,undefined,{'X-LeadVolt-Signature':sig||'sha256='+crypto.createHmac('sha256',secret).update(raw).digest('hex')});}
 check((await hook({name:'Bad'},'sha256=bad')).status===401,'unsigned/invalid webhook denied');
 const event={id:'durable-event-1',name:'Durable Lead',phone:'+971555001234',ref:'durable-ad'};
 const h=await hook(event);check(h.status===202,'webhook acknowledged only after durable enqueue');
 check(!db.prepare("SELECT 1 FROM leads WHERE external_id='durable-event-1'").get(),'lead processing deferred to queue');
 const again=await hook({ref:'durable-ad',phone:'+971555001234',name:'Durable Lead',id:'durable-event-1'});check(again.data.receipt_id===h.data.receipt_id,'reordered identical webhook returns same receipt');
 await J.drain(100);check(db.prepare("SELECT COUNT(*) n FROM leads WHERE external_id='durable-event-1'").get().n===1,'async lead created once');
 check((await call('GET','/api/jobs/'+h.data.receipt_id,undefined,admin)).data.status==='done','receipt shows completion');
 await hook({...event,message:'sender retry with extra field'});await J.drain(100);check(db.prepare("SELECT COUNT(*) n FROM leads WHERE external_id='durable-event-1'").get().n===1,'per-event dedupe prevents duplicate across payload changes');
 const malformed=await hook({id:'missing-contact'});await J.drain(100);check(db.prepare("SELECT status FROM portal_events WHERE external_id='missing-contact'").get().status==='error','invalid event preserved for investigation');
 // Leased job recovery across a real process exit.
 const restart=J.enqueue('restart-test','restart-job',{});
 const child=spawnSync(process.execPath,['-e',"const J=require('./src/services/jobs');console.log(J.claim().id);"],{cwd:path.resolve(__dirname,'..'),env:process.env,encoding:'utf8'});
 check(child.status===0&&Number(child.stdout.trim())===restart.id,'separate worker claims durable job and exits');
 check(db.prepare('SELECT status FROM jobs WHERE id=?').get(restart.id).status==='running','claimed job survives worker process exit');
 db.prepare('UPDATE jobs SET lease_until=0 WHERE id=?').run(restart.id);J.register('restart-test',async()=>({recovered:true}));await J.drain(100);
 check(JSON.parse(db.prepare('SELECT result FROM jobs WHERE id=?').get(restart.id).result).recovered,'expired lease is recovered after restart');
 const failure=J.enqueue('always-fail','failure-job',{},null,2);J.register('always-fail',async()=>{throw new Error('Simulated provider outage');});await J.drain(100);
 let failed=db.prepare('SELECT * FROM jobs WHERE id=?').get(failure.id);check(failed.status==='queued'&&failed.attempts===1&&failed.available_at>Date.now(),'transient failure schedules backoff');
 db.prepare('UPDATE jobs SET available_at=0 WHERE id=?').run(failure.id);await J.drain(100);check(db.prepare('SELECT status FROM jobs WHERE id=?').get(failure.id).status==='dead','retry exhaustion visible as dead job');
 check((await call('POST','/api/jobs/'+failure.id+'/retry',{},admin)).status===200,'admin can replay dead job');
 db.prepare("UPDATE jobs SET status='dead' WHERE id=?").run(failure.id);
 const rows=['name,phone',...Array.from({length:250},(_,i)=>'Imported '+i+',+97155'+String(i).padStart(7,'0'))].join('\n');
 const imp=await call('POST','/api/imports/jobs',{csv:rows},admin,{'Idempotency-Key':'import-run-0001'});check(imp.status===202,'bulk CSV accepted as job');await J.drain(100);
 const state=(await call('GET','/api/imports/jobs/'+imp.data.id,undefined,admin)).data;check(state.status==='done'&&state.result.added===250&&state.result.cursor===250,'chunked import completed with row accounting');
 check((await call('POST','/api/imports/jobs',{csv:rows},admin,{'Idempotency-Key':'import-run-0001'})).data.id===imp.data.id,'import retry returns original job');
 check((await call('POST','/api/imports/jobs',{csv:rows+'\nDifferent,+971550000999'},admin,{'Idempotency-Key':'import-run-0001'})).status===409,'idempotency key rejects changed import');
 check((await call('POST','/api/imports/jobs',{csv:'name,phone\n"Unclosed,1234'},admin,{'Idempotency-Key':'invalid-0001'})).status===400,'malformed CSV rejected before job creation');
 // Offline call ACKs and immutable identity.
 const ce={event_id:'call-0001',lead_id:own.id,duration_sec:42,direction:'outbound',occurred_at:'2026-01-01T09:00:00Z'},cb={device_id:'agent-phone',events:[ce]};
 check((await call('POST','/api/sync/calls',cb,agent)).data.results[0].status==='accepted','offline historical call accepted');
 check((await call('POST','/api/sync/calls',cb,agent)).data.results[0].status==='duplicate','call retry acknowledged without duplicate');
 check((await call('POST','/api/sync/calls',{...cb,events:[{...ce,duration_sec:43}]},agent)).data.results[0].code===409,'call identity rejects payload mismatch');
 check((await call('POST','/api/sync/calls',{...cb,events:[{...ce,event_id:'call-foreign',lead_id:foreign.id}]},agent)).data.results[0].code===403,'call sync rejects another agent lead');
 check(db.prepare('SELECT COUNT(*) n FROM call_sync').get().n===1,'only one valid call persisted');
 let revision=db.prepare('SELECT revision FROM leads WHERE id=?').get(own.id).revision;
 const change={event_id:'note-0001',lead_id:own.id,revision,kind:'note',text:'Offline client meeting'};
 check((await call('POST','/api/sync/changes',{changes:[change]},agent)).data.results[0].status==='accepted','offline note accepted with revision');
 check((await call('POST','/api/sync/changes',{changes:[change]},agent)).data.results[0].duplicate,'offline note retry returns ACK');
 check((await call('POST','/api/sync/changes',{changes:[{...change,event_id:'note-stale'}]},agent)).data.results[0].code===409,'offline stale change requires conflict resolution');
 check((await call('GET','/api/sync/leads?limit=200',undefined,agent)).data.data.every(l=>l.agent_id===uid),'mobile refresh includes authorized records only');
 // Balanced journals and database-level seals.
 const journal={description:'Commission receivable',currency:'AED',lines:[{account:'receivables',debit_minor:10000,credit_minor:0},{account:'commission-income',debit_minor:0,credit_minor:10000}]};
 const jr=await call('POST','/api/ledger/entries',journal,admin,{'Idempotency-Key':'journal-0001'});check(jr.status===201,'balanced integer journal posted');
 check((await call('POST','/api/ledger/entries',journal,admin,{'Idempotency-Key':'journal-0001'})).data.id===jr.data.id,'journal idempotency prevents duplicate');
 check((await call('POST','/api/ledger/entries',{...journal,lines:[journal.lines[0],{...journal.lines[1],credit_minor:9999}]},admin,{'Idempotency-Key':'journal-0002'})).status===400,'unbalanced journal rejected');
 check((await call('POST','/api/ledger/entries',journal,agent,{'Idempotency-Key':'journal-0003'})).status===403,'agent cannot post journal');
 assert.throws(()=>db.prepare('UPDATE journal_lines SET debit_minor=1 WHERE entry_id=?').run(jr.data.id));check(true,'database blocks journal edits');
 assert.throws(()=>db.prepare("INSERT INTO journal_lines(entry_id,account,debit_minor,credit_minor) VALUES(?,'tamper',1,0)").run(jr.data.id));check(true,'database blocks appending lines after sealing');
 const reversal=await call('POST','/api/ledger/entries/'+jr.data.id+'/reverse',{},admin,{'Idempotency-Key':'reversal-0001'});check(reversal.status===201&&reversal.data.reversal_of===jr.data.id,'journal correction uses reversal');
 check((await call('POST','/api/ledger/entries/'+jr.data.id+'/reverse',{},admin,{'Idempotency-Key':'reversal-0002'})).status===409,'second reversal rejected');
 // Authorization/session lifecycle and browser status page.
 const tempToken=await login('raish@leadvolt.ae');await call('POST','/api/auth/logout',{},tempToken);check((await call('GET','/api/auth/me',undefined,tempToken)).status===401,'logout invalidates bearer token');
 const pwToken=await login('raish@leadvolt.ae');await call('POST','/api/auth/password',{current:'leadvolt123',next:'Changed-secure-password-123'},pwToken);check((await call('GET','/api/auth/me',undefined,agent)).status===401,'password change revokes every prior session');
 check((await call('GET','/api/ops/status',undefined,admin)).data.database==='ok','authenticated operational readiness check');
 const page=await fetch(base+'/backend-status.html');check(page.status===200&&(await page.text()).includes('Administrator sign-in'),'backend status page served');
 // Production settings reject empty/example secrets before opening data.
 for(const secret of ['', 'change-this-to-a-long-random-string-at-least-32-chars']){const child=spawnSync(process.execPath,['-e',"require('./src/config')"],{cwd:path.resolve(__dirname,'..'),env:{...process.env,NODE_ENV:'production',JWT_SECRET:secret},encoding:'utf8'});check(child.status!==0,'production rejects '+(secret?'example secret':'empty secret'));}
 const limiter=require('../src/services/limits');check(limiter.take('limit-test',{capacity:1,perSecond:1,now:1000}).allowed,'token bucket permits initial request');check(!limiter.take('limit-test',{capacity:1,perSecond:1,now:1000}).allowed,'token bucket blocks excess requests');check(limiter.take('limit-test',{capacity:1,perSecond:1,now:2000}).allowed,'token bucket refills over time');
 const N=require('../src/services/notify'),notice={title:'Outbox identity test',kind:'info',dedupe_key:'stable-notice-1'};
 const n1=N.persist(uid,notice),n2=N.persist(uid,notice);check(n1.id===n2.id,'notification outbox deduplicates stable intent');
 check(db.prepare('SELECT COUNT(*) n FROM jobs WHERE dedupe_key=?').get('notification:'+n1.id).n===1,'notification and one delivery job persisted together');await J.drain(100);
 // Network controls reject unsupported destinations before making a request.
 const blocked=spawnSync(process.execPath,['-e',"require('./src/services/network').safeFetch('http://127.0.0.1/private').then(()=>process.exit(1)).catch(()=>process.exit(0))"],{cwd:path.resolve(__dirname,'..'),env:{...process.env,NODE_ENV:'production',JWT_SECRET:crypto.randomBytes(48).toString('hex')},encoding:'utf8'});check(blocked.status===0,'production recording downloader rejects insecure/private target');
 // Backup and restore are exercised on this test fixture after HTTP server stops.
 await new Promise(r=>srv.close(r));srv=null;db.pragma('wal_checkpoint(TRUNCATE)');
 const backup=path.join(tmp,'backup'),env={...process.env,BACKUP_WRITERS_STOPPED:'yes'};
 let childBackup=spawnSync(process.execPath,['scripts/backup.js',backup],{cwd:path.resolve(__dirname,'..'),env,encoding:'utf8'});check(childBackup.status===0,'backup command produces checksummed snapshot: '+childBackup.stderr);
 const restore=spawnSync(process.execPath,['scripts/restore-check.js',backup],{cwd:path.resolve(__dirname,'..'),env,encoding:'utf8'});check(restore.status===0,'restore command validates isolated database copy: '+restore.stderr);
 fs.appendFileSync(path.join(backup,'database.sqlite'),'tamper');const tamper=spawnSync(process.execPath,['scripts/restore-check.js',backup],{cwd:path.resolve(__dirname,'..'),env,encoding:'utf8'});check(tamper.status!==0,'restore validation rejects corrupted backup');
 console.log(`\n${count} hardening checks passed, 0 failed`);
})().catch(e=>{console.error(e);process.exitCode=1;}).finally(async()=>{J.stop();if(srv){srv.closeAllConnections();await new Promise(r=>srv.close(r));}db.close();fs.rmSync(tmp,{recursive:true,force:true});});
