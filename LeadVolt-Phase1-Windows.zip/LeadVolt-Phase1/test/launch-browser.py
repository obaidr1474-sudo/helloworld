import asyncio,os,subprocess,tempfile,socket,shutil,json
from pathlib import Path
from playwright.async_api import async_playwright
root=Path(__file__).resolve().parents[1];tmp=Path(tempfile.mkdtemp(prefix='lv-finance-browser-'))
s=socket.socket();s.bind(('127.0.0.1',0));port=s.getsockname()[1];s.close()
env=dict(os.environ,NODE_ENV='development',DB_FILE=str(tmp/'test.sqlite'),STORAGE_DIR=str(tmp/'storage'),PORT=str(port),HOST='127.0.0.1',FEATURE_FINANCE_ENABLED='true',FEATURE_CALL_SYNC_ENABLED='false')
log=open(tmp/'server.log','w');server=subprocess.Popen(['node','src/server.js'],cwd=root,env=env,stdout=log,stderr=log)
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=os.environ.get('CHROMIUM_EXECUTABLE') or shutil.which('chromium'),headless=True,args=['--no-sandbox']);page=await browser.new_page(viewport={'width':1440,'height':1000});errors=[];page.on('pageerror',lambda e:errors.append(str(e)));base=f'http://127.0.0.1:{port}'
  for _ in range(50):
   try:await page.goto(base+'/finance.html');break
   except Exception:await asyncio.sleep(.1)
  else:raise Exception('Fixture did not start')
  await page.locator('#email').fill('obaid@leadvolt.ae');await page.locator('#password').fill('leadvolt123');await page.locator('#login button').click();await page.locator('#finance').wait_for(state='visible');assert 'AED' in await page.locator('#revenue').inner_text() or '20' in await page.locator('#revenue').inner_text()
  await page.locator('[data-tab=invoices]').click();await page.locator('#leadId').fill('1');await page.locator('#price').fill('500000');await page.locator('#invoiceForm button').click();await page.wait_for_function("document.querySelector('#message').textContent.includes('Invoice created manually')")
  await page.locator('[data-tab=journal]').click();await page.locator('#description').fill('Browser Admin posting');await page.locator('#debitAccount').fill('receivables');await page.locator('#creditAccount').fill('income');await page.locator('#amount').fill('100.25');await page.locator('#journalForm button').click();await page.wait_for_function("document.querySelector('#message').textContent.includes('Balanced entry posted')")
  page.once('dialog',lambda d:d.accept());await page.get_by_role('button',name='Reverse',exact=True).first.click();await page.wait_for_function("document.querySelector('#message').textContent.includes('Reversal posted')")
  out=Path(os.environ.get('ARTIFACT_DIR','/tmp/leadvolt-finance-evidence'));out.mkdir(exist_ok=True,parents=True);await page.screenshot(path=str(out/'admin-finance.png'),full_page=True)
  await page.locator('#logout').click();await page.locator('#signin').wait_for(state='visible');await page.locator('#email').fill('raish@leadvolt.ae');await page.locator('#password').fill('leadvolt123');await page.locator('#login button').click();await page.wait_for_function("document.querySelector('#error').textContent.includes('restricted to Admin')");assert not await page.locator('#finance').is_visible();assert await page.locator('#invoiceList').inner_text()=='';assert await page.locator('#journalList').inner_text()==''
  await page.screenshot(path=str(out/'agent-finance-blocked.png'),full_page=True)
  await page.goto(base+'/');await page.add_script_tag(url='/leadvolt-api.js');await page.evaluate("window.client=new LeadVoltClient();client.login('obaid@leadvolt.ae','leadvolt123')");await page.locator('#liveRevenueValue').wait_for(state='visible');assert await page.locator('#nav > li[data-feature-finance]').is_visible();assert not await page.locator('[data-w=rev]').is_visible(),'Unfinished sample revenue must stay hidden'
  await page.evaluate("client.logout()");await page.evaluate("client.login('raish@leadvolt.ae','leadvolt123')");assert not await page.locator('#nav > li[data-feature-finance]').is_visible();assert await page.locator('#liveRevenueValue').count()==0
  await page.evaluate("LV.show('Invoice')");assert await page.evaluate('LV.curName')=='Dashboard'
  await page.evaluate("LV.navTo('Reports')");await page.wait_for_timeout(250)
  for item in await page.get_by_text('Revenue',exact=True).all():assert not await item.is_visible()
  denied=await page.evaluate("async()=>{try{await client.request('/ledger/entries');return 200;}catch(e){return e.status;}}")
  assert denied==403
  assert not errors,errors
  print(json.dumps({'admin_finance_screens':True,'admin_invoice_form':True,'admin_journal_form':True,'admin_reversal_form':True,'admin_live_dashboard_revenue':True,'agent_finance_console_hidden':True,'agent_finance_api_403':True,'agent_navigation_and_revenue_hidden':True,'role_switch_clears_finance':True,'unfinished_sample_revenue_hidden':True,'page_errors':errors},indent=2));await browser.close()
try:asyncio.run(main())
finally:
 server.terminate();server.wait(timeout=10);log.close();shutil.rmtree(tmp)
