const fs=require('fs'),os=require('os'),path=require('path'),assert=require('assert/strict'),{spawnSync}=require('child_process'),crypto=require('crypto');
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'lv-migration-'));const file=path.join(tmp,'legacy.db');
const Database=require('better-sqlite3'),db=new Database(file);db.exec(fs.readFileSync('schema.sql','utf8'));db.exec(fs.readFileSync('schema_v2.sql','utf8'));db.exec('ALTER TABLE users ADD COLUMN role_name TEXT');
db.prepare("INSERT INTO roles(name,perms) VALUES('Admin','{}')").run();db.prepare("INSERT INTO users(name,email,password_hash,role_name) VALUES('Existing Owner','existing@example.test','existing-password-hash','Admin')").run();db.prepare("INSERT INTO leads(name,phone,status,agent_id) VALUES('Existing Lead','+971500001111','Callback',1)").run();db.close();
try{
 const env={...process.env,NODE_ENV:'production',JWT_SECRET:crypto.randomBytes(48).toString('hex'),DB_FILE:file};delete env.WEBHOOK_SYNC;
 for(let i=0;i<2;i++){
 const p=spawnSync(process.execPath,['-e',"const db=require('./src/db');console.log(JSON.stringify({lead:db.prepare('SELECT name,status,revision FROM leads WHERE id=1').get(),user:db.prepare('SELECT email,password_hash FROM users WHERE id=1').get(),migration:db.prepare('SELECT version FROM schema_migrations').get(),integrity:db.pragma('integrity_check',{simple:true})}));db.close();"],{cwd:path.resolve(__dirname,'..'),env,encoding:'utf8'});
 assert.equal(p.status,0,p.stderr);const r=JSON.parse(p.stdout);assert.equal(r.lead.name,'Existing Lead');assert.equal(r.lead.status,'Callback');assert.equal(r.lead.revision,1);assert.equal(r.user.password_hash,'existing-password-hash');assert.equal(r.user.email,'existing@example.test');assert.equal(r.migration.version,3);assert.equal(r.integrity,'ok');
 }
 console.log('PASS legacy schema upgrade preserves records and credentials; repeated upgrade is idempotent');
}finally{fs.rmSync(tmp,{recursive:true,force:true});}
