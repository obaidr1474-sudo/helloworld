// Model the confirmed 23-user team on one local Node/SQLite instance.
const fs=require('fs'),path=require('path'),os=require('os'),assert=require('assert/strict');
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'lv-team-load-'));process.env.NODE_ENV='test';process.env.DB_FILE=path.join(dir,'test.db');process.env.STORAGE_DIR=path.join(dir,'storage');process.env.FEATURE_FINANCE_ENABLED='false';process.env.FEATURE_CALL_SYNC_ENABLED='false';
const app=require('../src/server'),db=require('../src/db'),J=require('../src/services/jobs'),bcrypt=require('bcryptjs');let server;
(async()=>{server=app.listen(0,'127.0.0.1');await new Promise(r=>server.once('listening',r));const base='http://127.0.0.1:'+server.address().port;
 const hash=bcrypt.hashSync('concurrency-fixture-only-password',12),users=[];
 for(let i=0;i<23;i++){const id=db.prepare("INSERT INTO users(name,email,password_hash,role_name) VALUES(?,?,?,'SalesExecutive')").run('Load Agent '+i,`load-${i}@example.test`,hash).lastInsertRowid;const lead=db.prepare("INSERT INTO leads(name,phone,agent_id) VALUES(?,?,?)").run('Load Lead '+i,'+97155'+String(i).padStart(7,'0'),id).lastInsertRowid;users.push({id,lead,email:`load-${i}@example.test`});}
 for(const u of users){const r=await fetch(base+'/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:u.email,password:'concurrency-fixture-only-password'})});assert.equal(r.status,200);u.token=(await r.json()).token;}
 const metrics=[],start=performance.now();
 J.start();for(let i=0;i<50;i++)require('../src/services/ingest').ingest('Bayut',{id:'concurrent-webhook-'+i,name:'Concurrent portal '+i,phone:'+97156'+String(i).padStart(7,'0'),ref:'concurrent-ad-'+i});
 await Promise.all(users.map(async u=>{for(let i=0;i<10;i++){
 const headers={Authorization:'Bearer '+u.token,'Content-Type':'application/json'},r=await fetch(base+'/api/leads/'+u.lead,{headers});assert.equal(r.status,200);const lead=await r.json();const change={event_id:`user-${u.id}-event-${i}`,lead_id:Number(u.lead),revision:lead.revision,kind:'note',text:'Concurrent note '+i};
 const t=performance.now();const response=await fetch(base+'/api/sync/changes',{method:'POST',headers,body:JSON.stringify({changes:[change]})});assert.equal(response.status,200);const ack=(await response.json()).results[0];assert.equal(ack.status,'accepted',JSON.stringify(ack));metrics.push(performance.now()-t);
 if(i%5===0){const retry=await fetch(base+'/api/sync/changes',{method:'POST',headers,body:JSON.stringify({changes:[change]})});assert.equal((await retry.json()).results[0].duplicate,true);}
 }}));
 J.stop();while(await J.drain(1000)){};
 const changes=db.prepare('SELECT COUNT(*) n FROM sync_changes').get().n;assert.equal(changes,230);assert.equal(db.prepare("SELECT COUNT(*) n FROM activities WHERE text LIKE 'Concurrent note %'").get().n,230);assert.equal(db.prepare("SELECT COUNT(*) n FROM leads WHERE external_id LIKE 'concurrent-webhook-%'").get().n,50);
 assert.equal(db.pragma('journal_mode',{simple:true}),'wal');assert.equal(db.pragma('busy_timeout',{simple:true}),5000);
 metrics.sort((a,b)=>a-b);console.log(JSON.stringify({agents:23,accepted_unique_notes:changes,retry_attempts:46,concurrent_webhooks:50,all_operations_succeeded:true,wal:true,busy_timeout_ms:5000,write_p95_ms:Math.round(metrics[Math.floor(metrics.length*.95)]),elapsed_ms:Math.round(performance.now()-start),scope:'local synthetic 23-user workload; not real-device or hosting capacity certification'},null,2));
})().catch(e=>{console.error(e);process.exitCode=1;}).finally(async()=>{J.stop();if(server){server.closeAllConnections();await new Promise(r=>server.close(r));}db.close();fs.rmSync(dir,{recursive:true,force:true});});
