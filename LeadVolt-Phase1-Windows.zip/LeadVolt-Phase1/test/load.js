// Small local workload check; not a production capacity or provider-delivery benchmark.
const fs=require('fs'),path=require('path'),os=require('os'),crypto=require('crypto'),assert=require('assert/strict');
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'lv-workload-'));process.env.NODE_ENV='test';delete process.env.WEBHOOK_SYNC;process.env.DB_FILE=path.join(dir,'test.db');process.env.STORAGE_DIR=path.join(dir,'storage');process.env.BAYUT_WEBHOOK_SECRET='local-workload-test-secret-123456';
const app=require('../src/server'),db=require('../src/db'),J=require('../src/services/jobs');let server;
(async()=>{
 server=app.listen(0,'127.0.0.1');await new Promise(r=>server.once('listening',r));const url='http://127.0.0.1:'+server.address().port+'/api/integrations/bayut/webhook';
 const timings=[],n=200,start=performance.now();let next=0;
 await Promise.all(Array.from({length:20},async()=>{for(;;){const i=next++;if(i>=n)return;const body=JSON.stringify({id:'load-'+i,name:'Load '+i,phone:'+97155'+String(i).padStart(7,'0'),ref:'load-ad-'+i});const t=performance.now();const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json','X-LeadVolt-Signature':'sha256='+crypto.createHmac('sha256',process.env.BAYUT_WEBHOOK_SECRET).update(body).digest('hex')},body});assert.equal(r.status,202);timings.push(performance.now()-t);}}));
 const ingestMs=performance.now()-start;while(await J.drain(1000)){};
 assert.equal(db.prepare("SELECT COUNT(*) n FROM leads WHERE external_id LIKE 'load-%'").get().n,n);
 assert.equal(db.prepare("SELECT COUNT(*) n FROM jobs WHERE type='webhook' AND status='done'").get().n,n);
 assert.equal(db.prepare("SELECT COUNT(*) n FROM jobs WHERE status='dead'").get().n,0);
 timings.sort((a,b)=>a-b);console.log(JSON.stringify({requests:n,concurrency:20,accepted:n,leads_created:n,ingestion_elapsed_ms:Math.round(ingestMs),response_p50_ms:Math.round(timings[Math.floor(n*.5)]),response_p95_ms:Math.round(timings[Math.floor(n*.95)]),total_with_processing_ms:Math.round(performance.now()-start),scope:'local synthetic workload; no external delivery or production capacity claim'},null,2));
})().catch(e=>{console.error(e);process.exitCode=1;}).finally(async()=>{if(server){server.closeAllConnections();await new Promise(r=>server.close(r));}db.close();fs.rmSync(dir,{recursive:true,force:true});});
