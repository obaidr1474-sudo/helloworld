import asyncio,json,os,shutil
from pathlib import Path
OUT=Path(os.environ.get('ARTIFACT_DIR','/tmp/leadvolt-browser-evidence'));OUT.mkdir(parents=True,exist_ok=True)
BASE=os.environ.get('LEADVOLT_PREVIEW_URL','http://127.0.0.1:4100')
from pathlib import Path
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=os.environ.get('CHROMIUM_EXECUTABLE') or shutil.which('chromium'),headless=True,args=['--no-sandbox'])
  page=await browser.new_page(viewport={'width':1440,'height':1100},device_scale_factor=1)
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.goto(BASE+'/backend-status.html')
  await page.locator('#email').fill('obaid@leadvolt.ae');await page.locator('#password').fill('leadvolt123');await page.locator('#form button').click()
  await page.wait_for_function("document.querySelector('#status').textContent.includes('3.1.0')")
  await page.screenshot(path=str(OUT/'backend-status.png'),full_page=True)
  assert await page.locator('#error').inner_text()==''
  await page.locator('#logout').click();await page.locator('#login').wait_for(state='visible')
  await page.add_script_tag(url='/leadvolt-api.js')
  result=await page.evaluate('''async()=>{
    const c=new LeadVoltClient();await c.login('raish@leadvolt.ae','leadvolt123');
    const rows=await c.refreshLeads();if(!rows.length||rows.some(l=>l.agent_id!==c.user.id))throw Error('Bad lead scope');
    const cached=await c.cachedLeads();if(cached.length!==rows.length)throw Error('Bad cache');
    const l=rows[0];await c.queueChange({lead_id:l.id,revision:l.revision,kind:'note',text:'Browser SDK smoke test'});
    if((await c.pending()).length!==1)throw Error('Missing queued change');
    const ack=await c.flush();if(ack[0].status!=='accepted'||(await c.pending()).length)throw Error('ACK handling failed');
    await c.queueChange({lead_id:l.id,revision:l.revision,kind:'note',text:'Stale browser change'});
    const conflict=await c.flush();if(conflict[0].code!==409||(await c.pending()).length!==1)throw Error('Conflict handling failed');
    const token=c.token;await c.logout();const r=await fetch('/api/auth/me',{headers:{Authorization:'Bearer '+token}});if(r.status!==401)throw Error('Logout did not revoke session');
    return {scopedSnapshot:true,indexedDbCache:true,offlineQueue:true,ackRemovesAccepted:true,conflictRetained:true,logoutRevokes:true};
  }''')
  assert not errors,errors
  print(json.dumps({'browser_checks':result,'page_errors':errors,'screenshot':'backend-status.png'},indent=2))
  await page.goto(BASE+'/')
  await page.wait_for_timeout(1000)
  await page.screenshot(path=str(OUT/'preserved-frontend.png'),full_page=True)
  await browser.close()
asyncio.run(main())
