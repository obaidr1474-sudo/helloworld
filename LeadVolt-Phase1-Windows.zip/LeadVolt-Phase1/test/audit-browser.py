import asyncio,json,os,shutil,socket,subprocess,tempfile
from pathlib import Path
from datetime import datetime,timezone,timedelta
from playwright.async_api import async_playwright
root=Path(__file__).resolve().parents[1];tmp=Path(tempfile.mkdtemp(prefix='lv-audit-browser-'));out=Path(os.environ.get('ARTIFACT_DIR','/tmp/leadvolt-audit-evidence'));out.mkdir(parents=True,exist_ok=True)
s=socket.socket();s.bind(('127.0.0.1',0));port=s.getsockname()[1];s.close()
env=dict(os.environ,NODE_ENV='development',DB_FILE=str(tmp/'test.sqlite'),STORAGE_DIR=str(tmp/'storage'),PORT=str(port),HOST='127.0.0.1',FEATURE_FINANCE_ENABLED='true')
log=open(tmp/'server.log','w');server=subprocess.Popen(['node','src/server.js'],cwd=root,env=env,stdout=log,stderr=log)
checks=[]
def check(condition,name):
 assert condition,name
 checks.append(name)
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=shutil.which('chromium'),headless=True,args=['--no-sandbox'])
  context=await browser.new_context(viewport={'width':1440,'height':1000},timezone_id='Asia/Dubai',reduced_motion='reduce');context.set_default_timeout(10000)
  await context.add_init_script("window.cspViolations=[];addEventListener('securitypolicyviolation',e=>cspViolations.push({directive:e.violatedDirective,uri:e.blockedURI}));")
  page=await context.new_page();await page.clock.set_fixed_time(datetime(2026,10,21,17,49,tzinfo=timezone(timedelta(hours=4))));errors=[];page.on('pageerror',lambda e:errors.append(str(e)));base=f'http://127.0.0.1:{port}'
  for _ in range(80):
   try:response=await page.goto(base+'/',wait_until='domcontentloaded');break
   except Exception:await asyncio.sleep(.1)
  else:raise Exception('Fixture failed to start')
  await page.locator('#sessionLogin').wait_for(state='visible')
  check('content-security-policy-report-only' in response.headers,'Report-only CSP header is present')
  check(await page.locator('meta[name=description]').get_attribute('content')!='','Meta description is present')
  icon=await page.locator('link[rel=icon]').get_attribute('href');check((await page.request.get(base+icon)).status==200,'Favicon resolves successfully')
  check(await page.locator('#sessionLogin').get_attribute('method')=='post','Main login explicitly uses POST')
  check(await page.evaluate("getComputedStyle(document.querySelector('.main')).display==='none'"),'Signed-out dashboard is display:none, not an overlay')
  check(await page.evaluate("getComputedStyle(document.querySelector('.topbar')).display==='none'"),'Signed-out main navigation is display:none')
  for file in ['pages.js','session.js','leadvolt-api.js','index.html']:
   body=await (await page.request.get(base+'/'+file)).text();check('lv_live_' not in body and 'secret:' not in body,'Public asset contains no placeholder credentials: '+file)
  await page.locator('#sessionEmail').fill('obaid@leadvolt.ae');await page.locator('#sessionPassword').fill('leadvolt123');await page.locator('#sessionLogin button').click();await page.wait_for_function("document.documentElement.dataset.session==='active'")
  check(await page.evaluate("LV_SESSION.api.token===''") ,'Cookie login exposes no bearer token to JavaScript')
  await page.reload(wait_until='domcontentloaded');await page.wait_for_function("document.documentElement.dataset.session==='active'")
  check(await page.locator('.topbar .user .name').inner_text()=='Obaid Raza','Reload restores verified identity')
  await page.evaluate("LV.refreshReminders(new Date('2026-10-21T17:49:00+04:00'))")
  check(await page.locator('#remLeft').inner_text()=='1','At 17:49 only one reminder remains ahead')
  check(await page.locator('#remList .rem.overdue').count()==5,'Five past reminders are explicitly overdue')
  check('previous stage' in await page.locator('#funnelCols').inner_text(),'Funnel labels identify previous-stage percentage')
  check('of all leads' in await page.locator('#funnel').text_content(),'Funnel chart identifies percentage of all leads')
  async def clock_one_line():
   return await page.evaluate("(()=>{const boxes=['hm','ss','ap'].map(id=>document.getElementById(id).getBoundingClientRect());return Math.max(...boxes.map(b=>b.top))<Math.min(...boxes.map(b=>b.bottom));})()")
  check(await clock_one_line(),'Clock time, seconds and AM/PM share one line on desktop')
  await page.wait_for_timeout(1500)
  await page.screenshot(path=str(out/'audit-dashboard-desktop.png'),full_page=True)
  await page.locator('#bellBtn').click()
  check(await page.locator('#notes [data-ni][role=button][tabindex="0"]').count()==3,'All three notification items are keyboard reachable')
  for i in range(3):
   item=page.locator(f'#notes [data-ni="{i}"]');await item.focus();await page.keyboard.press('Enter');check(await page.evaluate(f'LV.notes[{i}].read'),'Enter activates notification '+str(i+1))
  await page.evaluate('LV.notes[0].read=false');await page.locator('#notes [data-ni="0"]').focus();await page.keyboard.press('Space');check(await page.evaluate('LV.notes[0].read'),'Space activates a notification')
  await page.locator('#bellBtn').click();await page.set_viewport_size({'width':390,'height':844});await page.wait_for_timeout(300)
  check(await clock_one_line(),'Clock remains one line at phone width')
  check(await page.evaluate('document.documentElement.scrollWidth<=innerWidth'),'Phone layout has no page-level horizontal overflow')
  await page.screenshot(path=str(out/'audit-dashboard-phone.png'),full_page=True)
  check(not await page.evaluate('cspViolations'),'No CSP violations on tested dashboard and login')
  await page.set_viewport_size({'width':1440,'height':1000});await page.locator('.topbar .user').click();await page.locator('#sessionLogout').click();await page.locator('#sessionLogin').wait_for(state='visible');await page.reload(wait_until='domcontentloaded');await page.locator('#sessionLogin').wait_for(state='visible')
  check(await page.evaluate("getComputedStyle(document.querySelector('.main')).display==='none'"),'Logout followed by reload keeps dashboard hidden')
  await page.wait_for_timeout(500);await page.screenshot(path=str(out/'audit-login.png'),full_page=True)
  # Simulate failure of the submit handler by replacing the form with a handler-free clone.
  await page.evaluate("const old=document.getElementById('sessionLogin'),fresh=old.cloneNode(true);old.replaceWith(fresh);fresh.querySelector('input[type=email]').name='email';fresh.querySelector('input[type=password]').name='password';")
  await page.locator('#sessionEmail').fill('fixture@example.test');await page.locator('#sessionPassword').fill('Fallback-Test-Password-123!')
  async with page.expect_navigation():await page.locator('#sessionLogin button').click()
  check(page.url==base+'/api/auth/login','Missing submit handler posts without password in URL')
  check(not errors,'No JavaScript exceptions: '+str(errors))
  print(json.dumps({'checks_passed':len(checks),'checks':checks,'screenshots':['audit-login.png','audit-dashboard-desktop.png','audit-dashboard-phone.png']},indent=2));await browser.close()
try:asyncio.run(main())
finally:server.terminate();server.wait(timeout=10);log.close();shutil.rmtree(tmp)
