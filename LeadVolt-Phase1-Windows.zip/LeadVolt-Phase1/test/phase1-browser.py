"""Isolated browser acceptance for Phase 1; never prints credentials."""
import asyncio,json,os,shutil,socket,subprocess,tempfile
from pathlib import Path
from playwright.async_api import async_playwright
root=Path(__file__).resolve().parents[1]
tmp=Path(tempfile.mkdtemp(prefix='lv-phase1-browser-'))
out=Path(os.environ.get('ARTIFACT_DIR','/tmp/leadvolt-phase1-evidence'));out.mkdir(parents=True,exist_ok=True)
s=socket.socket();s.bind(('127.0.0.1',0));port=s.getsockname()[1];s.close()
env=dict(os.environ,NODE_ENV='development',DB_FILE=str(tmp/'test.sqlite'),STORAGE_DIR=str(tmp/'storage'),PORT=str(port),HOST='127.0.0.1',FEATURE_FINANCE_ENABLED='true',FEATURE_CALL_SYNC_ENABLED='false')
log=open(tmp/'server.log','w');server=subprocess.Popen(['node','src/server.js'],cwd=root,env=env,stdout=log,stderr=log)
checks=[]
def check(condition,name):
 assert condition,name
 checks.append(name)
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=shutil.which('chromium'),headless=True,args=['--no-sandbox'])
  context=await browser.new_context(viewport={'width':1440,'height':1000},reduced_motion='reduce');context.set_default_timeout(10000);errors=[]
  context.on('page',lambda page:page.on('pageerror',lambda e:errors.append(str(e))))
  admin=await context.new_page();base=f'http://127.0.0.1:{port}'
  for _ in range(80):
   try:await admin.goto(base+'/',wait_until='domcontentloaded');break
   except Exception:await asyncio.sleep(.1)
  else:raise Exception('Fixture failed to start')
  await admin.locator('#sessionLogin').wait_for(state='visible')
  check(not await admin.locator('.topbar').is_visible(),'Anonymous main shell is hidden')
  check(await admin.get_by_text('Forgot password',exact=True).count()==0,'No self-service reset is offered')
  await admin.wait_for_timeout(800)
  await admin.screenshot(path=str(out/'phase1-login.png'),full_page=True)
  async def login(page,email,password):
   await page.locator('#sessionEmail').fill(email);await page.locator('#sessionPassword').fill(password);await page.locator('#sessionLogin button').click()
  async def signed_in(page):await page.wait_for_function("document.documentElement.dataset.session==='active'")
  await login(admin,'obaid@leadvolt.ae','wrong-fixture-password')
  await admin.wait_for_function("document.querySelector('#sessionError').textContent.includes('Wrong email')")
  check(not await admin.locator('.topbar').is_visible(),'Failed login does not open CRM')
  await login(admin,'obaid@leadvolt.ae','leadvolt123');await signed_in(admin)
  check(await admin.locator('.topbar .user .name').inner_text()=='Obaid Raza','Header uses authenticated server identity')
  check(await admin.evaluate("localStorage.getItem('token')===null&&sessionStorage.getItem('token')===null"),'Session token is not persisted in browser storage')
  await admin.evaluate("LV.navTo('Team')");await admin.locator('#accountRows tr[data-user-id]').first.wait_for()
  check(await admin.locator('#accountRows tr[data-user-id]').count()==6,'Directory loads real seeded accounts')
  await admin.locator('#accountAdd').click();await admin.locator('#accountName').fill('Phase One Browser Agent');await admin.locator('#accountEmail').fill('browser-phase1@example.test');await admin.locator('#accountSave').click();await admin.locator('#accountSecret').wait_for(state='visible')
  temp=await admin.locator('#accountPassword').inner_text()
  check(len(temp)>=16,'Create returns a generated temporary password once')
  check('No email was sent' in await admin.locator('#accountMessage').inner_text(),'Create explicitly confirms manual password sharing')
  row=admin.locator('#accountRows tr').filter(has_text='browser-phase1@example.test');await row.wait_for();uid=await row.get_attribute('data-user-id')
  await admin.locator('#accountDismiss').click()
  check(await admin.locator('#accountPassword').inner_text()=='','Dismiss removes temporary password from DOM')
  await admin.screenshot(path=str(out/'phase1-user-management.png'),full_page=True)
  new_agent=await context.new_page();await new_agent.goto(base+'/',wait_until='domcontentloaded');await login(new_agent,'browser-phase1@example.test',temp);await new_agent.locator('#sessionPasswordForm').wait_for(state='visible')
  check(not await new_agent.locator('.topbar').is_visible(),'Temporary login cannot see CRM shell')
  check((await new_agent.evaluate("async()=>{try{await LV_SESSION.api.request('/users');return 200}catch(e){return e.status}}"))==403,'Forced-change session cannot access directory API')
  permanent='Browser-Phase-One-Password-123!'
  await new_agent.locator('#sessionCurrent').fill(temp);await new_agent.locator('#sessionNext').fill(permanent);await new_agent.locator('#sessionConfirm').fill('Different-Password-123!');await new_agent.locator('#sessionPasswordForm button[type=submit]').click()
  check('do not match' in await new_agent.locator('#sessionError').inner_text(),'Password confirmation mismatch is rejected')
  await new_agent.locator('#sessionConfirm').fill(permanent);await new_agent.locator('#sessionPasswordForm button[type=submit]').click();await new_agent.wait_for_function("document.querySelector('#sessionMessage').textContent.includes('Password changed')")
  await login(new_agent,'browser-phase1@example.test',permanent);await signed_in(new_agent)
  check(not await new_agent.locator('#nav>li').filter(has_text='Manage Users').is_visible(),'Agent user-management menu is hidden')
  check(not await new_agent.locator('#nav>li').filter(has_text='Global Config').is_visible(),'Agent settings menu follows server permissions')
  await new_agent.evaluate("LV.show('Team')")
  check(await new_agent.locator('#accountPage').count()==0,'Direct client navigation cannot open Admin directory')
  check((await new_agent.evaluate("async()=>{try{await LV_SESSION.api.request('/users');return 200}catch(e){return e.status}}"))==403,'Agent directory API is forbidden')
  await row.get_by_role('button',name='Deactivate',exact=True).click();await admin.locator('#accountConfirm').click();await admin.wait_for_function("document.querySelector('#accountMessage').textContent.includes('deactivated')")
  check((await new_agent.evaluate("async()=>{try{await LV_SESSION.api.request('/auth/me');return 200}catch(e){return e.status}}"))==401,'Deactivation invalidates agent session')
  await new_agent.locator('#sessionLogin').wait_for(state='visible')
  await admin.locator('#accountStatus').select_option('inactive');await admin.wait_for_function("document.querySelectorAll('#accountRows tr[data-user-id]').length===1")
  check('browser-phase1@example.test' in await admin.locator('#accountRows').inner_text(),'Inactive directory contains deactivated account')
  await admin.screenshot(path=str(out/'phase1-inactive-users.png'),full_page=True)
  await admin.locator('#accountRows').get_by_role('button',name='Reactivate').click();await admin.locator('#accountConfirm').click();await admin.wait_for_function("document.querySelector('#accountMessage').textContent.includes('reactivated')")
  await admin.locator('#accountStatus').select_option('all');await admin.locator(f'tr[data-user-id="{uid}"]').wait_for()
  row=admin.locator(f'tr[data-user-id="{uid}"]');await row.get_by_role('button',name='Reset password').click();await admin.locator('#accountConfirm').click();await admin.locator('#accountSecret').wait_for(state='visible');reset=await admin.locator('#accountPassword').inner_text()
  check(reset!=temp and len(reset)>=16,'Reset generates a fresh temporary password')
  await admin.locator('#accountDismiss').click();await login(new_agent,'browser-phase1@example.test',reset);await new_agent.locator('#sessionPasswordForm').wait_for(state='visible')
  check(not await new_agent.locator('.topbar').is_visible(),'Reset forces password change again')
  second=await context.new_page();await second.goto(base+'/',wait_until='domcontentloaded');await login(second,'obaid@leadvolt.ae','leadvolt123');await signed_in(second)
  await admin.locator('.topbar .user').click();await admin.locator('#sessionOthers').click();await admin.wait_for_function("document.querySelector('.session-alert').textContent.includes('This session remains active')")
  check((await admin.evaluate("async()=>{try{await LV_SESSION.api.request('/auth/me');return 200}catch(e){return e.status}}"))==200,'Sign out others preserves current browser session')
  check((await second.evaluate("async()=>{try{await LV_SESSION.api.request('/auth/me');return 200}catch(e){return e.status}}"))==401,'Sign out others revokes second browser session')
  await admin.evaluate("LV.navTo('Global Config')");await admin.locator('[data-mod="Security"]').click()
  async with admin.expect_response(lambda r:r.url.endswith('/api/auth/logout-others') and r.request.method=='POST') as response:
   await admin.locator('[data-act="signout"]').click()
  check((await response.value).status==200,'Existing Security button calls real sign-out-others API')
  await admin.evaluate('LV.closeLayer()');await admin.locator('.topbar .user').click();await admin.locator('#sessionLogout').click();await admin.locator('#sessionLogin').wait_for(state='visible')
  check(await admin.locator('#accountRows').count()==0,'Logout removes account directory and one-time secrets')
  check(not await admin.locator('.topbar').is_visible(),'Logout locks main shell')
  await admin.reload(wait_until='domcontentloaded');await admin.locator('#sessionLogin').wait_for(state='visible')
  check(not await admin.locator('.topbar').is_visible(),'Reload requires sign-in; no stored token restores access')
  check(not errors,'No browser JavaScript exceptions: '+str(errors))
  print(json.dumps({'checks_passed':len(checks),'checks':checks,'screenshots':['phase1-login.png','phase1-user-management.png','phase1-inactive-users.png'],'page_errors':errors},indent=2))
  await browser.close()
try:asyncio.run(main())
finally:
 server.terminate();server.wait(timeout=10);log.close();shutil.rmtree(tmp)
