"""Exercise the rendered Nginx config using an isolated TLS fixture, not a live deployment."""
import os,sys,json,time,ssl,socket,threading,subprocess,tempfile,shutil,http.server,http.client
from pathlib import Path
root=Path(__file__).resolve().parents[1]
nginx=os.environ.get('NGINX_BIN') or shutil.which('nginx')
if not nginx:raise SystemExit('Set NGINX_BIN to a trusted installed Nginx binary')
tmp=Path(tempfile.mkdtemp(prefix='lv-proxy-'));proc=None;checks=0
class Fixture(http.server.BaseHTTPRequestHandler):
 protocol_version='HTTP/1.1'
 def log_message(self,*args):pass
 def do_GET(self):
  if self.path.startswith('/api/stream'):
   self.send_response(200);self.send_header('Content-Type','text/event-stream');self.end_headers()
   try:self.wfile.write(b'event: hello\ndata: {"ok":true}\n\n');self.wfile.flush();time.sleep(2);self.wfile.write(b': end\n\n');self.wfile.flush()
   except (BrokenPipeError,ConnectionResetError):pass
   self.close_connection=True;return
  body=json.dumps({'forwarded_for':self.headers.get('X-Forwarded-For'),'proto':self.headers.get('X-Forwarded-Proto'),'host':self.headers.get('Host'),'connection':self.headers.get('Connection')}).encode();self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
 def do_POST(self):
  n=int(self.headers.get('Content-Length','0'));raw=self.rfile.read(n);body=json.dumps({'size':len(raw),'raw':raw.decode() if len(raw)<100 else None}).encode();self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
def freeport():
 with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
def check(c,name):
 global checks
 assert c,name;checks+=1;print('PASS',name)
upstream=http.server.ThreadingHTTPServer(('127.0.0.1',0),Fixture);threading.Thread(target=upstream.serve_forever,daemon=True).start()
plain,tls=freeport(),freeport()
try:
 cert,key=tmp/'certificate.pem',tmp/'key.pem'
 subprocess.run(['openssl','req','-x509','-newkey','rsa:2048','-nodes','-keyout',str(key),'-out',str(cert),'-days','1','-subj','/CN=crm.example.test','-addext','subjectAltName=DNS:crm.example.test'],check=True,capture_output=True)
 out=tmp/'rendered';snippet=tmp/'proxy.conf'
 subprocess.run(['node','scripts/render-deployment.js','--domain','crm.example.test','--output',str(out),'--app-dir',str(root),'--node-bin',shutil.which('node'),'--proxy-snippet',str(snippet),'--certificate',str(cert),'--certificate-key',str(key)],cwd=root,check=True,capture_output=True)
 snippet.write_text((out/'nginx/leadvolt-proxy.conf').read_text().replace('127.0.0.1:4000','127.0.0.1:'+str(upstream.server_port)))
 site=(out/'nginx/leadvolt.conf').read_text().replace('listen 80','listen 127.0.0.1:'+str(plain)).replace('listen 443','listen 127.0.0.1:'+str(tls)).replace('/var/log/nginx',str(tmp))
 (tmp/'site.conf').write_text(site)
 (tmp/'nginx.conf').write_text(f'daemon off;\nworker_processes 1;\npid {tmp}/nginx.pid;\nerror_log {tmp}/main-error.log;\nevents {{ worker_connections 128; }}\nhttp {{ access_log off; client_body_temp_path {tmp}/body; proxy_temp_path {tmp}/proxy; fastcgi_temp_path {tmp}/fastcgi; uwsgi_temp_path {tmp}/uwsgi; scgi_temp_path {tmp}/scgi; include {tmp}/site.conf; }}\n')
 valid=subprocess.run([nginx,'-t','-p',str(tmp)+'/', '-c',str(tmp/'nginx.conf')],capture_output=True,text=True);check(valid.returncode==0,'Nginx configuration validates: '+valid.stderr.strip())
 proc=subprocess.Popen([nginx,'-p',str(tmp)+'/', '-c',str(tmp/'nginx.conf')],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
 for _ in range(50):
  try:
   with socket.create_connection(('127.0.0.1',tls),timeout=.2):pass
   break
  except OSError:time.sleep(.1)
 else:raise RuntimeError('Nginx failed to start')
 context=ssl.create_default_context(cafile=str(cert));context.minimum_version=ssl.TLSVersion.TLSv1_2
 def request(path,method='GET',body=None,headers=None):
  conn=http.client.HTTPSConnection('127.0.0.1',tls,context=context,timeout=5)
  conn.sock=context.wrap_socket(socket.create_connection(('127.0.0.1',tls),timeout=5),server_hostname='crm.example.test')
  conn.request(method,path,body=body,headers={'Host':'crm.example.test',**(headers or {})});res=conn.getresponse();data=res.read();result=(res.status,res.getheaders(),data);conn.close();return result
 status,_,body=request('/api/health?secret=access-log-must-not-contain-this',headers={'X-Forwarded-For':'198.51.100.123','X-Forwarded-Proto':'http'})
 result=json.loads(body);check(status==200 and result['proto']=='https','TLS proxy sets trusted HTTPS scheme');check(result['forwarded_for']=='127.0.0.1','spoofed forwarding header overwritten');check(result['host']=='crm.example.test','expected host forwarded')
 conn=http.client.HTTPConnection('127.0.0.1',plain,timeout=5);conn.request('GET','/api/health',headers={'Host':'crm.example.test'});r=conn.getresponse();check(r.status==308 and r.getheader('Location')=='https://crm.example.test/api/health','HTTP redirects to the fixed HTTPS hostname');r.read();conn.close()
 payload=b'{"message":"exact bytes matter"}';status,_,body=request('/api/integrations/bayut/webhook','POST',payload,{'Content-Type':'application/json'});check(status==200 and json.loads(body)['raw']==payload.decode(),'webhook payload reaches upstream unchanged')
 status,_,_=request('/api/tasks','POST',b'x'*(3*1024*1024+1),{'Content-Type':'application/json'});check(status==413,'proxy rejects oversized API request')
 limited=[]
 for i in range(14):limited.append(request('/api/auth/login','POST',b'{}')[0])
 check(429 in limited,'login burst is rate-limited');check(any(k.lower()=='retry-after' for k,v in request('/api/auth/login','POST',b'{}')[1]),'proxy limit includes Retry-After')
 conn=http.client.HTTPSConnection('127.0.0.1',tls,context=context,timeout=5);conn.sock=context.wrap_socket(socket.create_connection(('127.0.0.1',tls),timeout=5),server_hostname='crm.example.test');conn.request('GET','/api/stream',headers={'Host':'crm.example.test','Authorization':'Bearer synthetic-test-token'})
 start=time.monotonic();r=conn.getresponse();first=r.readline();elapsed=time.monotonic()-start;check(r.status==200 and first==b'event: hello\n' and elapsed<1,'SSE event arrives without buffering before stream closes');conn.close()
 time.sleep(.1);log=(tmp/'leadvolt-access.log').read_text();check('access-log-must-not-contain-this' not in log and 'synthetic-test-token' not in log,'access log excludes query credentials and authorization')
 # Structural validation only; this container does not run the target systemd service.
 verify=subprocess.run(['systemd-analyze','verify',str(out/'systemd/leadvolt.service')],capture_output=True,text=True);check(verify.returncode==0,'systemd unit passes structural verification: '+verify.stderr.strip())
 print(json.dumps({'proxy_checks_passed':checks,'nginx':subprocess.check_output([nginx,'-v'],stderr=subprocess.STDOUT,text=True).strip(),'scope':'isolated self-signed TLS fixture; not public deployment'},indent=2))
finally:
 if proc:
  proc.terminate()
  try:proc.wait(timeout=5)
  except subprocess.TimeoutExpired:proc.kill();proc.wait()
 upstream.shutdown();upstream.server_close();shutil.rmtree(tmp)
