const assert=require('assert/strict'),fs=require('fs'),os=require('os'),path=require('path'),{render}=require('../scripts/render-deployment');
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'lv-render-'));let checks=0;function ok(c){assert.ok(c);checks++;}
try{const out=path.join(tmp,'rendered');render({domain:'crm.example.test',output:out});ok(fs.existsSync(path.join(out,'nginx/leadvolt.conf')));ok(fs.existsSync(path.join(out,'systemd/leadvolt.service')));ok(!fs.readFileSync(path.join(out,'nginx/leadvolt.conf'),'utf8').includes('@@'));assert.throws(()=>render({domain:'crm.example.test',output:out}));checks++;
 for(const domain of ['EXAMPLE.COM','example.com;return 200','x\nserver {}','-bad.example','nodot']){assert.throws(()=>render({domain,output:path.join(tmp,'bad')}));checks++;}
 for(const bad of ['/opt/x;bad','/opt/../etc','relative','/opt/x%p']){assert.throws(()=>render({domain:'crm.example.test',output:path.join(tmp,'bad'),appDir:bad}));checks++;}
 ok(fs.readFileSync(path.join(out,'leadvolt.env.example'),'utf8').includes('FEATURE_FINANCE_ENABLED=true'));
 console.log(`${checks} deployment-render checks passed, 0 failed`);
}finally{fs.rmSync(tmp,{recursive:true,force:true});}
