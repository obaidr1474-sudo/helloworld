-- LeadVolt CRM database schema (SQLite; works on PostgreSQL with minor type changes)
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL, email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'Agent',            -- Sales Manager | Team Lead | Senior Agent | Agent | Junior Agent
  access TEXT NOT NULL DEFAULT 'Own leads only',  -- Own leads only | Team leads | All leads
  initials TEXT, phone TEXT, monthly_target INTEGER DEFAULT 10,
  active INTEGER NOT NULL DEFAULT 1, last_assigned_at TEXT, created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS projects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE, area TEXT, developer TEXT,
  status TEXT NOT NULL DEFAULT 'Ready',          -- Ready | Off Plan
  price_from REAL, total_units INTEGER, sold_units INTEGER DEFAULT 0,
  beds TEXT, size_range TEXT, construction_progress INTEGER DEFAULT 100,
  handover_date TEXT, plan_booking INTEGER, plan_construction INTEGER, plan_handover INTEGER,
  amenities TEXT, about TEXT
);
CREATE TABLE IF NOT EXISTS units (
  id TEXT PRIMARY KEY, project_id INTEGER NOT NULL REFERENCES projects(id),
  type TEXT, size_sqft INTEGER, floor TEXT, view TEXT, price INTEGER,
  status TEXT NOT NULL DEFAULT 'Available',      -- Available | Reserved | Sold
  reserved_for_lead_id INTEGER REFERENCES leads(id), reserved_until TEXT
);
CREATE TABLE IF NOT EXISTS leads (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  root_id INTEGER REFERENCES leads(id),          -- original lead when the same person enquires again
  name TEXT NOT NULL, phone TEXT NOT NULL, alternate_phone TEXT, landline TEXT, email TEXT, country_code TEXT,
  source TEXT, sub_source TEXT, budget TEXT, budget_value REAL, budget_min REAL, budget_max REAL, currency TEXT DEFAULT 'AED',
  enquired_for TEXT,                             -- Buy | Rent
  property_type TEXT, beds INTEGER, baths INTEGER, community TEXT, city TEXT, country TEXT,
  referral_name TEXT, referral_phone TEXT, referral_email TEXT, notes TEXT,
  external_ref TEXT,                             -- id in the system the lead was migrated from
  project_id INTEGER REFERENCES projects(id),
  status TEXT NOT NULL DEFAULT 'New',            -- New | Callback | Meeting Done | Site Visit Done | Booked | Invoiced | Overdue
  agent_id INTEGER REFERENCES users(id),
  score INTEGER DEFAULT 50, is_deleted INTEGER DEFAULT 0, is_duplicate INTEGER DEFAULT 0,
  last_contact_at TEXT, created_at TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_leads_status ON leads(status);
CREATE INDEX IF NOT EXISTS idx_leads_agent ON leads(agent_id);
CREATE TABLE IF NOT EXISTS activities (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lead_id INTEGER NOT NULL REFERENCES leads(id), user_id INTEGER REFERENCES users(id),
  kind TEXT NOT NULL,                             -- note | call | whatsapp | status | visit | import | reservation
  text TEXT, created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL, type TEXT DEFAULT 'Call',  -- Call | Meeting | Site visit | WhatsApp | Email
  lead_id INTEGER REFERENCES leads(id), assignee_id INTEGER REFERENCES users(id),
  due_date TEXT NOT NULL, due_time TEXT, priority TEXT DEFAULT 'Medium', done INTEGER DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS attendance (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id), day TEXT NOT NULL,
  clock_in TEXT, clock_out TEXT, status TEXT DEFAULT 'Present', location TEXT,
  UNIQUE(user_id, day)
);
CREATE TABLE IF NOT EXISTS invoices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  number TEXT NOT NULL UNIQUE, lead_id INTEGER REFERENCES leads(id), unit_id TEXT REFERENCES units(id),
  property_price REAL NOT NULL, commission_pct REAL NOT NULL DEFAULT 2, vat_pct REAL NOT NULL DEFAULT 5,
  status TEXT NOT NULL DEFAULT 'Pending',        -- Draft | Pending | Paid | Overdue
  issued_at TEXT DEFAULT (date('now')), due_at TEXT, paid_at TEXT
);
CREATE TABLE IF NOT EXISTS imports (
  id INTEGER PRIMARY KEY AUTOINCREMENT, file_name TEXT, user_id INTEGER REFERENCES users(id),
  added INTEGER, skipped INTEGER, created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS settings ( key TEXT PRIMARY KEY, value TEXT NOT NULL );

-- A deal is created when a lead is booked
CREATE TABLE IF NOT EXISTS deals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lead_id INTEGER NOT NULL REFERENCES leads(id) ON DELETE CASCADE, agent_id INTEGER REFERENCES users(id),
  booked_under_name TEXT, purchased_from TEXT, booked_date TEXT, agreement_value REAL, currency TEXT DEFAULT 'AED',
  project_id INTEGER REFERENCES projects(id), unit_id TEXT REFERENCES units(id), stage TEXT NOT NULL DEFAULT 'Booked',
  created_at TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_deals_lead ON deals(lead_id);
-- Every status change, with the next scheduled follow-up
CREATE TABLE IF NOT EXISTS lead_status_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lead_id INTEGER NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
  from_status TEXT, to_status TEXT NOT NULL, user_id INTEGER REFERENCES users(id),
  scheduled_at TEXT, notes TEXT, created_at TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_status_hist ON lead_status_history(lead_id, id DESC);
CREATE INDEX IF NOT EXISTS idx_leads_phone ON leads(phone);
